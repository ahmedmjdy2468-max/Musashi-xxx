import fs from 'node:fs';import path from 'node:path';import archiver from 'archiver';
const root=process.cwd(), archivePath=path.resolve(root,'..','MUSASHI.zip');
const required=['plugins','plugins_legacy','system','src','config','scripts','docs','tests'];
const archive=archiver('zip',{zlib:{level:6}});const output=fs.createWriteStream(archivePath);
const done=new Promise((resolve,reject)=>{output.on('close',resolve);output.on('error',reject);archive.on('error',reject)});archive.pipe(output);
for(const dir of required)if(fs.existsSync(path.join(root,dir)))archive.append(Buffer.alloc(0),{name:dir.replaceAll('\\','/')+'/' });
function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){if(e.name==='node_modules'||e.name==='session')continue;const full=path.join(dir,e.name),rel=path.relative(root,full).replaceAll('\\','/');if(rel==='work-check-output.txt'||rel.startsWith('scripts/patch-'))continue;if(e.isDirectory())walk(full);else if(e.isFile())archive.file(full,{name:rel})}}
walk(root);await archive.finalize();await done;
const outputDir=path.resolve(root,'..','..','outputs');fs.mkdirSync(outputDir,{recursive:true});fs.copyFileSync(archivePath,path.join(outputDir,'MUSASHI.zip'));
console.log(`Created ${archivePath} (${archive.pointer()} bytes)`);console.log(`Copied ${path.join(outputDir,'MUSASHI.zip')}`);
