import fs from 'node:fs';
for(const file of ['system/commandCatalog.json','system/commandCatalog.ai.json']){
 const d=JSON.parse(fs.readFileSync(file,'utf8'));
 for(const e of Object.values(d.commands||{})){
  if(e.usageArgs===undefined&&e.usage){const value=String(e.usage).trim();e.usageArgs=value.replace(/^\.?\S+\s*/u,'').trim()}
  e.exampleArgs='';delete e.usage;delete e.example;
 }
 fs.writeFileSync(file,JSON.stringify(d,null,2)+'\n','utf8');
}
