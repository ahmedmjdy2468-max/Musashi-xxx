import fs from 'node:fs';
import { normalizeArabic } from '../system/normalizeArabic.js';

const rules = JSON.parse(fs.readFileSync('scripts/name-rules.json', 'utf8'));
const brands = JSON.parse(fs.readFileSync('scripts/brand-names.json', 'utf8'));
const known = new Set([...rules.knownWords, ...Object.values(brands), ...(rules.approvedProperNames || [])].map(normalizeArabic));
let restored = 0;
let hidden = 0;

for (const file of ['system/commandCatalog.json', 'system/commandCatalog.ai.json']) {
  const data = JSON.parse(fs.readFileSync(file, 'utf8'));
  for (const [key, entry] of Object.entries(data.commands || {})) {
    if (!entry.nameNeedsReview || !entry.reviewName || entry.aliasOf) continue;
    const candidate = rules.overrides?.[key] || entry.reviewName;
    const words = String(candidate).split(/[_\s-]+/u).filter(Boolean);
    const clearArabic = words.length > 0 && words.every(word =>
      !/[\u0600-\u06ff]/u.test(word) || known.has(normalizeArabic(word))
    );
    if (!clearArabic) { hidden++; continue; }
    entry.ar = candidate;
    entry.nameNeedsReview = false;
    entry.reviewName = '';
    restored++;
  }
  fs.writeFileSync(file, JSON.stringify(data, null, 2) + '\n');
}
console.log(`أسماء من مراجعة معجمية يدوية استُعيدت: ${restored}`);
console.log(`أسماء بقيت مخفية لعدم ثبوت كلمة عربية: ${hidden}`);
