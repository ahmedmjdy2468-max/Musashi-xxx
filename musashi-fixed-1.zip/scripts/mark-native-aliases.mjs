import fs from 'node:fs';

const groups = [
  ['حذف', ['مسح', 'del', 'delete']],
  ['ترجم', ['ترجمة', 'translate', 'tr']],
  ['برمجة', ['كود_ذكي', 'مستر_كود', 'codeai']],
  ['تأليف', ['انشاء_نص', 'مقال', 'قصة']],
  ['حلل_صورة', ['وصف_صورة', 'تحليل_صورة', 'vision']],
  ['اسأل', ['مساعد', 'ai', 'ask']],
  ['تخيل', ['رسم', 'ارسم', 'رسمة', 'imagine', 'img', 'image']],
  ['موساشي', ['musashi', 'بومني', 'pomni']],
  ['حاسبة', ['احسب', 'calc', 'calculator']],
  ['تحويل_عملات', ['تحويل_عملة', 'عملة', 'عملات', 'صرف', 'currency']],
  ['طقس', ['الجو', 'حالة_الطقس', 'weather']],
  ['توليد', ['صورة_ذكاء', 'ارسم_لي', 'ai_image']],
];

for (const file of ['system/commandCatalog.json', 'system/commandCatalog.ai.json']) {
  const data = JSON.parse(fs.readFileSync(file, 'utf8'));
  const commands = data.commands || {};
  let changed = 0;
  for (const [primary, aliases] of groups) {
    const base = commands[primary];
    if (!base) continue;
    for (const key of aliases) {
      const entry = commands[key];
      if (!entry || entry.sourceFile !== base.sourceFile) continue;
      entry.aliasOf = primary;
      entry.hiddenForAudience = true;
      entry.nameNeedsReview = false;
      entry.desc = String(base.desc || '');
      changed++;
    }
  }
  // The two image commands share intent but are separate handlers with different options.
  const imageEntry = commands['توليد'];
  if (imageEntry?.sourceFile === 'plugins\\tools\\generate_image.js') {
    imageEntry.desc = 'ينشئ صورة من وصف نصي مع تحديد الأبعاد ونسبة العرض إلى الارتفاع.';
    changed++;
  }
  fs.writeFileSync(file, JSON.stringify(data, null, 2) + '\n');
  console.log(`${file}: ربط ${changed} مرادفاً بوصف الأمر الأساسي.`);
}
