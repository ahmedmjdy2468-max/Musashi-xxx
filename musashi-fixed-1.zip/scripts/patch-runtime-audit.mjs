import fs from 'node:fs';const p='scripts/audit-runtime-80.mjs';let s=fs.readFileSync(p,'utf8');
s=s.replace("const out=['# تدقيق تنفيذ عينة الأوامر'", "const must=['رفع','upload','toswgc','swgc','سؤال','ask','بوم','ping','ai','ذكاء','facebook','twitter','mediafire','spotify','joke','truth','delete','setcity','getcode','restartvps','cekbaik','cekbucin','ytmp4','ig','disable_link','disable_badword','groupinfo','http','cekjahat'];for(const k of must)if(cat[k])picked.add(k);const out=['# تدقيق تنفيذ عينة الأوامر'");
s=s.replace('العينة العشوائية الثابتة: ${picked.size} أمراً.', 'عينة عشوائية ثابتة: 80 أمراً، إضافة إلى الأوامر المذكورة في الطلب (${picked.size} إجمالاً).');
fs.writeFileSync(p,s);
