import fs from 'node:fs';
const check=fs.readFileSync('docs/validation/npm-run-check.txt','utf8');
const test=fs.readFileSync('docs/validation/npm-test.txt','utf8');
const generated=fs.readFileSync('audit-build-final.txt','utf8');
const lines=check.split(/\r?\n/u);
const metrics=lines.filter(l=>/^(✅ كل الملفات سليمة|المعالجات الأصلية المحمّلة|المعالجات legacy المسجّلة فعلياً|أسماء مكررة في تعريفات المصدر|أسماء متعارضة في dispatch الفعلي|أسماء تجاوزها loader|أسماء بأجزاء مكررة|أسماء عربية غير مفهومة|أسماء غير مؤكدة مخفية للاسم|مرادفات legacy المخفية|عدم اتساق usage|أوصاف عامة أو لاتينية|أمثلة أو وسائط|مجموعات أوصاف مشتركة|أوامر كتالوج بلا معالج|أوامر ظاهرة بلا معالج|أوامر ظاهرة بلا ملف مصدر|ملفات تعذّر تحميلها|✅ فحص الكتالوج|فحص سلامة الشبكة|مواضع placeholder API|نجح فحص سلامة)/u.test(l));
const pass=Number(test.match(/ℹ pass (\d+)/u)?.[1]||0),fail=Number(test.match(/ℹ fail (\d+)/u)?.[1]||0);
const rows=Number(generated.match(/سجلات الكتالوج: (\d+)/u)?.[1]||0),visible=Number(generated.match(/ظاهرة بالقائمة: (\d+)/u)?.[1]||0);
const visibility=JSON.parse(fs.readFileSync('system/legacy-command-visibility.json','utf8'));
const underdev=JSON.parse(fs.readFileSync('src/data/underdev.json','utf8'));
const unavailable=JSON.parse(fs.readFileSync('system/unavailable-services.json','utf8'));
const doc=[
'# تقرير تدقيق MUSASHI بعد دمج الإصلاحات', '',
'أُنشئ هذا التقرير من مخرجات التشغيل المحفوظة في `docs/validation/`، ومن `scripts/build-command-audit.mjs`. لا تمثل الفحوص الآلية مراجعة بشرية.', '',
'## نتائج التشغيل', '',
...metrics.map(x=>`- ${x}`),
`- اختبارات npm test: ${pass} ناجحة، ${fail} فاشلة.`,
`- سجلات الكتالوج: ${rows}؛ الأوامر التي تظهر حسب التقرير الحي: ${visible}.`,
`- underDev: ${underdev.commands.length} اسم أمر و${underdev.plugins.length} اسم إضافة محجوب.`,
`- ملفات legacy الموسومة لمراجعة نصوص المستخدم: ${visibility.sources.length}.`,
`- ملفات legacy المعطلة لغياب خدمة أو مفتاح صالح: ${unavailable.disabledLegacySources.length}.`, '',
'## حدود هذه النسخة', '',
'- بقيت أسماء وأوصاف legacy غير محسومة مخفية؛ لم أفتحها لمجرد وجود مدخل كتالوج.',
'- فحص الكتالوج يبلغ عن تعريفات مكررة تجاوزها التسجيل. التعارض الفعلي في dispatch هو المعيار، لا مجرد تكرار الاسم بين ملفات المصدر.',
'- ملف `plugins_legacy/owner/autoreadsw.js` صفري الحجم؛ لم أختلق معالجاً أو سلوكاً له، وتظل أسماؤه غير قابلة للتحقق.',
'- بقيت مؤشرات alias مكررة بين بعض الأقسام في تحذيرات سجل الكتالوج، لكنها لا تظهر كتعارض dispatch. عالجت حلقة alias التي كانت تمنع بوابة التعريب من اكتشاف الاسم الأساسي.',
'- لا تُضمَّن ملفات `.env` أو بيانات الجلسة وقواعد البيانات التشغيلية في ZIP التسليم.', '',
'## الملفات الدليلية', '',
'- `docs/validation/npm-run-check.txt` مخرج `npm run check` الكامل.',
'- `docs/validation/npm-test.txt` مخرج `npm test` الكامل.',
'- `docs/COMMAND-AUDIT.csv` جميع سجلات الكتالوج مع الحالة وسبب الحجب والمسار.',
'- `docs/NEEDS-REVIEW.md` الحالات التي بقيت محجوبة وأسبابها.', '',
];
fs.writeFileSync('docs/AUDIT-AFTER.md',doc.join('\n'));
console.log(`تم إنشاء docs/AUDIT-AFTER.md من المخرجات: check=${check.includes('نجح فحص سلامة روابط الشبكة')?'نجح':'غير مكتمل'}; tests=${pass}/${fail}; catalog=${rows}; visible=${visible}`);
