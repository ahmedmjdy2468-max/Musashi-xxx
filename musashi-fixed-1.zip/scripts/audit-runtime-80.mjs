import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { isIndonesianUserText } from '../system/legacyCommandVisibility.js';

const catalog = JSON.parse(fs.readFileSync('system/commandCatalog.json', 'utf8')).commands;
const entries = Object.entries(catalog).filter(([, entry]) => entry.sourceFile);
let seed = 20261112;
const picked = new Set();
while (picked.size < 80 && picked.size < entries.length) {
  seed = (seed * 1664525 + 1013904223) >>> 0;
  picked.add(entries[seed % entries.length][0]);
}
const must = ['رفع','upload','toswgc','swgc','سؤال','ask','بوم','ping','ai','ذكاء','facebook','twitter','mediafire','spotify','joke','truth','delete','setcity','getcode','restartvps','cekbaik','cekbucin','ytmp4','ig','delfile','cekmalas','cekcantik','cekgabut','cekcupu','cekgamer','cekfemboy','whatsappme','stalktt','stalkwa','disable_link','disable_badword','groupinfo','http','cekjahat'];
for (const key of must) if (catalog[key]) picked.add(key);

const visibilityPath = 'system/legacy-command-visibility.json';
const overridesPath = 'scripts/legacy-visibility-overrides.json';
const visibility = JSON.parse(fs.readFileSync(visibilityPath, 'utf8'));
const overrides = JSON.parse(fs.readFileSync(overridesPath, 'utf8'));
const blocked = new Set((visibility.sources || []).map(file => String(file).replaceAll('\\', '/').toLowerCase()));
const external = /https?:\/\/|fetchJson|axios\.|\bfetch\s*\(|generateImage|generativeai|openai|gemini|groq|ytSearch|downloadContentFromMessage|sock\.send/iu;
const clip = value => String(value ?? '').replace(/\r?\n/g, '\\n').replaceAll('|', '\\|').slice(0, 900);
const counts = { reply: 0, error: 0, external: 0, missing: 0, underDev: 0, indonesianOutput: 0 };
const rows = [];
let discovered = false;

for (const key of picked) {
  const entry = catalog[key];
  const source = String(entry.sourceFile || '').replaceAll('\\', '/');
  const file = path.resolve(source);
  let code = '';
  try { code = fs.readFileSync(file, 'utf8'); }
  catch {
    rows.push(`| ${entry.ar || key} | ${source || '—'} | بلا معالج |`);
    counts.missing++;
    continue;
  }
  if (blocked.has(source.toLowerCase())) {
    rows.push(`| ${entry.ar || key} | ${source} | 🚧 قيد التعريب؛ التنفيذ معطّل |`);
    counts.underDev++;
    continue;
  }
  if (external.test(code)) {
    rows.push(`| ${entry.ar || key} | ${source} | يحتاج خدمة خارجية (لم تُستدعَ) |`);
    counts.external++;
    continue;
  }

  const result = spawnSync(process.execPath, ['scripts/audit-run-one.mjs', key, source, entry.original || key, entry.ar || key], {
    encoding: 'utf8', timeout: 10000, maxBuffer: 1024 * 1024,
  });
  const line = (result.stdout || '').split(/\r?\n/).find(value => value.startsWith('AUDIT_ROW:'));
  if (!line) {
    rows.push(`| ${entry.ar || key} | ${source} | خطأ: ${clip(result.error?.message || result.stderr || result.stdout || 'تعذر التشغيل')} |`);
    counts.error++;
    continue;
  }
  let simulated;
  try { simulated = JSON.parse(line.slice('AUDIT_ROW:'.length)); }
  catch { simulated = { status: 'خطأ', text: line }; }

  if (simulated.status === 'ردّ' && isIndonesianUserText(simulated.text)) {
    counts.indonesianOutput++;
    if (source.startsWith('plugins_legacy/')) {
      overrides.forceDisableSources ||= {};
      overrides.forceDisableSources[source] = 'رصدت محاكاة المعالج نصاً إندونيسياً ديناميكياً في مخرج المستخدم.';
      fs.writeFileSync(overridesPath, JSON.stringify(overrides, null, 2) + '\n');
      blocked.add(source.toLowerCase());
      const sources = [...new Set([...(visibility.sources || []), source.toLowerCase()])].sort();
      visibility.sources = sources;
      visibility.forcedSources = overrides.forceDisableSources;
      visibility.generatedAt = new Date().toISOString();
      fs.writeFileSync(visibilityPath, JSON.stringify(visibility, null, 2) + '\n');
      discovered = true;
      counts.underDev++;
      rows.push(`| ${entry.ar || key} | ${source} | 🚧 قيد التعريب؛ أُوقف بعد رصد إندونيسية في المحاكاة |`);
      continue;
    }
    counts.error++;
    rows.push(`| ${entry.ar || key} | ${source} | خطأ: رُصد نص غير عربي في مخرج المحاكاة: ${clip(simulated.text)} |`);
    continue;
  }

  if (simulated.status === 'ردّ') counts.reply++;
  else if (simulated.status === 'قيد التعريب') counts.underDev++;
  else if (simulated.status === 'لا ردّ') counts.reply++;
  else counts.error++;
  rows.push(`| ${entry.ar || key} | ${source} | ${simulated.status}: ${clip(simulated.text)} |`);
}

const output = [
  '# تدقيق تنفيذ عينة الأوامر',
  '',
  `عينة عشوائية ثابتة: 80 أمراً، إضافة إلى أسماء الجولة المطلوبة (${picked.size} إجمالاً). كل معالج متاح شُغّل في عملية Node معزولة بسياق محاكى.`,
  'مصادر قيد التعريب لم تُنفّذ، والخدمات الخارجية لم تُستدعَ. فُحص نص المخرج نفسه؛ أي مصدر legacy ظهر منه نص إندونيسي أُضيف للحظر قبل التشغيل التالي.',
  '',
  `مخرج التشغيل: ${counts.reply} ردّ أو لا رد، ${counts.error} أخطاء، ${counts.external} يحتاج خدمة خارجية، ${counts.underDev} قيد التعريب، ${counts.missing} بلا معالج.`,
  `نصوص إندونيسية مرصودة في هذه الجولة: ${counts.indonesianOutput}${discovered ? '؛ أضيفت مصادرها إلى الحظر وتحتاج إعادة المحاكاة للتحقق' : ''}.`,
  '',
  '| الاسم | المعالج | النتيجة |',
  '|---|---|---|',
  ...rows,
  '',
];
fs.writeFileSync('docs/AUDIT-RUNTIME-80.md', output.join('\n'));
console.log(`عينة التنفيذ: ${picked.size}`);
console.log(`ردّ/لا رد: ${counts.reply} · خطأ: ${counts.error} · يحتاج خدمة خارجية: ${counts.external} · قيد التعريب: ${counts.underDev} · بلا معالج: ${counts.missing}`);
console.log(`نصوص إندونيسية مرصودة في المخرج: ${counts.indonesianOutput}`);
console.log(discovered ? 'أضيفت مصادر ديناميكية إلى قائمة الحظر؛ أعد تشغيل هذا الفحص.' : 'مخرجات العينة الحالية خالية من مؤشرات الإندونيسية.');
console.log('حُفظ الجدول: docs/AUDIT-RUNTIME-80.md');
if (counts.error || counts.missing || counts.indonesianOutput) process.exitCode = 1;
