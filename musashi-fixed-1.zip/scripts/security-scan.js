/**
 * 🔱 MUSASHI BOT — فاحص الأمان والأبواب الخلفية
 * الاستخدام: node scripts/security-scan.js
 *
 * يفحص:
 *  1. أي محاولة لإرسال جلسة/creds إلى جهة خارجية
 *  2. أرقام/معرّفات المطورين السابقين
 *  3. مفاتيح وتوكنات وكلمات مرور مكتوبة صراحةً
 *  4. استخدامات eval/exec/child_process
 *  5. عناوين سيرفرات خارجية داخل نظام WebSocket
 *  6. كتل base64 ضخمة (شيفرة مخفية محتملة)
 */
import { readdir, readFile, stat, writeFile, mkdir } from "node:fs/promises";
import { join, relative, extname } from "node:path";

const ROOT = process.cwd();
const SKIP = new Set(["node_modules", ".git", "session", "sub", "tmp", "cache", "deliverables", "tests", "scripts"]);

const PATTERNS = [
  {
    id: "session-exfiltration",
    label: "إرسال الجلسة/creds خارجياً",
    severity: "critical",
    regex: /(creds\.json|auth_info)[^\n]{0,80}(fetch|axios|uploadTo|catbox)/i,
  },
  {
    id: "dev-identity",
    label: "هوية مطور سابق",
    severity: "high",
    regex: /sius\.psrb|siuspsrb|AlwaysLennz|itsuki-nakano|6285135869785|628311563267|6289677659055/i,
  },
  {
    id: "hardcoded-secret",
    label: "مفتاح/توكن/كلمة مرور مكتوبة",
    severity: "high",
    regex: /(apiKey|api_key|token|password|passwd|secret)\s*[:=]\s*["'][A-Za-z0-9_\-.]{20,}["']/i,
  },
  {
    id: "remote-exec",
    label: "تنفيذ كود من مصدر بعيد",
    severity: "critical",
    regex: /(eval|new Function)\s*\(\s*(await\s+)?(fetch|axios|await\s+res)/i,
  },
  {
    id: "dynamic-require",
    label: "تحميل وحدة من رابط",
    severity: "critical",
    regex: /require\s*\(\s*(url|href|link|remote)/i,
  },
  {
    id: "hidden-phone",
    label: "رقم واتساب مخفي",
    severity: "medium",
    regex: /["']\+?\d{10,15}@s\.whatsapp\.net["']/,
  },
];

const DANGEROUS_CALLS = /\b(eval|execSync|exec|spawn|child_process|Function)\s*\(/;

async function* walk(dir) {
  let entries;
  try {
    entries = await readdir(dir, { withFileTypes: true });
  } catch {
    return;
  }
  for (const e of entries) {
    if (SKIP.has(e.name)) continue;
    const full = join(dir, e.name);
    if (e.isDirectory()) yield* walk(full);
    else if (e.name === "SECURITY_SCAN.json") continue;
    else if ([".js", ".mjs", ".cjs", ".json"].includes(extname(e.name).toLowerCase())) yield full;
  }
}

const findings = [];
const dangerous = [];
let scanned = 0;

for await (const file of walk(ROOT)) {
  const info = await stat(file).catch(() => null);
  if (!info || info.size > 2_000_000) continue;
  const text = await readFile(file, "utf8").catch(() => "");
  if (!text) continue;
  scanned++;

  const rel = relative(ROOT, file).replace(/\\/g, "/");

  for (const rule of PATTERNS) {
    const re = new RegExp(rule.regex.source, rule.regex.flags.includes("g") ? rule.regex.flags : rule.regex.flags + "g");
    let match;
    while ((match = re.exec(text))) {
      const line = text.slice(0, match.index).split("\n").length;
      findings.push({ rule: rule.id, label: rule.label, severity: rule.severity, file: rel, line, snippet: match[0].slice(0, 100) });
    }
  }

  if (DANGEROUS_CALLS.test(text)) {
    const lines = text.split("\n");
    lines.forEach((l, i) => {
      if (DANGEROUS_CALLS.test(l) && !/\.test\(|RegExp|exec\(\)/.test(l)) {
        dangerous.push({ file: rel, line: i + 1, snippet: l.trim().slice(0, 110) });
      }
    });
  }

  const b64 = text.match(/["'`][A-Za-z0-9+/]{800,}={0,2}["'`]/);
  if (b64) findings.push({ rule: "base64-blob", label: "كتلة base64 ضخمة", severity: "medium", file: rel, line: 1, snippet: b64[0].slice(0, 60) });
}

const bySeverity = { critical: [], high: [], medium: [] };
for (const f of findings) (bySeverity[f.severity] ||= []).push(f);

console.log(`\n🔱 فحص أمني — ${scanned} ملفاً\n`);
console.log(`🚨 حرج: ${bySeverity.critical.length} · ⚠️ عالٍ: ${bySeverity.high.length} · ℹ️ متوسط: ${bySeverity.medium.length}\n`);

for (const sev of ["critical", "high"]) {
  for (const f of (bySeverity[sev] || []).slice(0, 12)) {
    console.log(`  ${sev === "critical" ? "🚨" : "⚠️"} ${f.file}:${f.line}  [${f.label}]`);
    console.log(`      ${f.snippet}`);
  }
  if ((bySeverity[sev] || []).length > 12) console.log(`  … و${bySeverity[sev].length - 12} أخرى`);
}

console.log(`\n🔧 مواضع تنفيذ كود (eval/exec/child_process): ${dangerous.length}`);
for (const d of dangerous.slice(0, 10)) console.log(`  • ${d.file}:${d.line} — ${d.snippet}`);

const reportPath = join(ROOT, "SECURITY_SCAN.json");
await mkdir(ROOT, { recursive: true });
await writeFile(reportPath, JSON.stringify({ scannedAt: new Date().toISOString(), scanned, findings, dangerous }, null, 2), "utf8");
console.log(`\n📄 التقرير الكامل: SECURITY_SCAN.json\n`);

if (bySeverity.critical.length) process.exitCode = 1;
