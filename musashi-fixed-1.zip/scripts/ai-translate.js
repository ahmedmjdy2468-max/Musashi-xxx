/**
 * 🔱 MUSASHI BOT — مترجم آلي للسلاسل المتبقية
 * ------------------------------------------------------------
 * يستخدم مفتاحك (Groq أو Gemini) لترجمة كل النصوص الأجنبية المتبقية
 * دفعة واحدة، ويحفظ النتيجة في قاموس التعريب ثم يطبّقها.
 *
 * التشغيل:
 *   node scripts/ai-translate.js            # ترجمة + تطبيق
 *   node scripts/ai-translate.js --dry      # عرض ما سيُترجم فقط
 *   node scripts/ai-translate.js --limit 300
 *
 * المتطلبات: GROQ_API_KEY أو GEMINI_API_KEY في .env
 *            (كلاهما مجاني: console.groq.com / aistudio.google.com)
 */
import { readdir, readFile, writeFile, stat, mkdir } from "node:fs/promises";
import { join, extname } from "node:path";

const ROOT = process.cwd();
const TARGET = "plugins_legacy";
const DRY = process.argv.includes("--dry");
const limIdx = process.argv.indexOf("--limit");
const LIMIT = limIdx > -1 ? Number(process.argv[limIdx + 1]) || 200 : 200;
const BATCH = 30;

await loadEnv();

function literals(code) {
  const out = [];
  let i = 0;
  const n = code.length;
  while (i < n) {
    const c = code[i];
    if (c === "/" && code[i + 1] === "/") { while (i < n && code[i] !== "\n") i++; continue; }
    if (c === "/" && code[i + 1] === "*") { i += 2; while (i < n && !(code[i] === "*" && code[i + 1] === "/")) i++; i += 2; continue; }
    if (c === "'" || c === '"' || c === "`") {
      const q = c, s = i; i++; let d = 0;
      while (i < n) {
        if (code[i] === "\\") { i += 2; continue; }
        if (q === "`" && code[i] === "$" && code[i + 1] === "{") { d++; i += 2; continue; }
        if (q === "`" && code[i] === "}" && d > 0) { d--; i++; continue; }
        if (code[i] === q && d === 0) break;
        if (q !== "`" && code[i] === "\n") break;
        i++;
      }
      out.push(code.slice(s + 1, i));
      i++;
      continue;
    }
    i++;
  }
  return out;
}

async function* walk(dir) {
  for (const e of await readdir(dir, { withFileTypes: true })) {
    const full = join(dir, e.name);
    if (e.isDirectory()) yield* walk(full);
    else if (extname(e.name) === ".js") yield full;
  }
}

async function loadEnv() {
  try {
    const raw = await readFile(join(ROOT, ".env"), "utf8");
    for (const line of raw.split("\n")) {
      const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
      if (m && !process.env[m[1]]) process.env[m[1]] = m[2].trim();
    }
  } catch {}
}

const MARKER = /\b(dan|yang|tidak|bisa|silakan|gunakan|untuk|dengan|atau|kalau|jika|sedang|gagal|berhasil|contoh|cara|pakai|kirim|balas|tunggu|grup|kamu|saya|hanya|khusus|fitur|perintah|pesan|gambar|stiker|tautan|waktu|hari|jam|menit|detik|koin|energi|level|limit|belum|harus|juga|lebih|kurang|semua|sekarang|nanti|mode|aksi|status|data|user|admin|owner|variant|server|panel|file|angkot|ikan|buruan|kerja|toko|jual|beli|menang|kalah)\b/i;
const TECH = /^(axios|path|owner|tools|image|group|reply|error|off|on|center|middle|POST|GET|User-Agent|Content-Type|utf-?8|arraybuffer|application\/|text\/|imageMessage|videoMessage|audioMessage|stickerMessage|itsuki|rpg|cek|game|search|MUSASHI|@s\.whatsapp\.net|Bearer|json|string|[a-z_]+)$/i;

const found = new Map();
for await (const file of walk(join(ROOT, TARGET))) {
  const code = await readFile(file, "utf8").catch(() => "");
  for (const text of literals(code)) {
    if (!/[A-Za-z]{3,}/.test(text)) continue;
    if (/[\u0600-\u06FF]/.test(text)) continue;
    const trimmed = text.trim();
    if (!trimmed || TECH.test(trimmed)) continue;
    if (/^(https?:|[./])/.test(trimmed)) continue;
    if (!/\s/.test(trimmed) && !/[\u2600-\u27BF\uD83C-\uDBFF]/.test(trimmed)) continue;
    if (!MARKER.test(trimmed)) continue;
    if (trimmed.length > 240) continue;
    const key = trimmed.replace(/\s+/g, " ");
    found.set(key, (found.get(key) || 0) + 1);
  }
}

const list = [...found.entries()].sort((a, b) => b[1] - a[1]).map(([t]) => t).slice(0, LIMIT);
console.log(`\n🔱 مرشّحون للترجمة: ${list.length} (من ${found.size} فريد)\n`);
if (DRY) {
  list.slice(0, 15).forEach((t) => console.log("  •", t.slice(0, 100)));
  process.exit(0);
}

const provider = process.env.GROQ_API_KEY ? "groq" : process.env.GEMINI_API_KEY ? "gemini" : null;
if (!provider) {
  console.error("❌ لا يوجد مفتاح. ضع GROQ_API_KEY أو GEMINI_API_KEY في .env");
  console.error("   Groq مجاني: https://console.groq.com/keys");
  process.exit(1);
}
console.log(`المزوّد: ${provider}\n`);

const SYSTEM = `أنت مترجم تقني. تترجم نصوص بوت واتساب من الإندونيسية/الإنجليزية إلى العربية الفصحى الواضحة.
قواعد صارمة:
- حافظ على الرموز التعبيرية والفواصل والأسطر (\\n) كما هي تماماً.
- لا تترجم: ${"${...}"} ولا أسماء المتغيرات ولا الروابط ولا أسماء الحزم.
- اجعل الترجمة قصيرة ومناسبة لواجهة دردشة.
- أعد JSON فقط: {"items":[{"i":0,"ar":"..."}]}`;

async function translateBatch(batch) {
  const userMsg = JSON.stringify({ items: batch.map((t, i) => ({ i, text: t })) });
  let raw = "";

  if (provider === "groq") {
    const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${process.env.GROQ_API_KEY}` },
      body: JSON.stringify({
        model: process.env.GROQ_MODEL || "llama-3.3-70b-versatile",
        temperature: 0.2,
        response_format: { type: "json_object" },
        messages: [{ role: "system", content: SYSTEM }, { role: "user", content: userMsg }],
      }),
      signal: AbortSignal.timeout(90000),
    });
    const j = await res.json();
    raw = j?.choices?.[0]?.message?.content || "";
  } else {
    const model = process.env.GEMINI_MODEL || "gemini-2.0-flash";
    const res = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(process.env.GEMINI_API_KEY)}`,
      {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: `${SYSTEM}\n\n${userMsg}` }] }],
          generationConfig: { responseMimeType: "application/json", temperature: 0.2 },
        }),
        signal: AbortSignal.timeout(90000),
      }
    );
    const j = await res.json();
    raw = j?.candidates?.[0]?.content?.parts?.map((p) => p.text).join("") || "";
  }

  const parsed = JSON.parse(raw.replace(/```json|```/g, "").trim());
  const out = {};
  for (const item of parsed.items || []) {
    const src = batch[item.i];
    if (typeof src === "string" && typeof item.ar === "string" && item.ar.trim()) {
      out[src] = item.ar.trim();
    }
  }
  return out;
}

const map = {};
for (let i = 0; i < list.length; i += BATCH) {
  const batch = list.slice(i, i + BATCH);
  process.stdout.write(`  دفعة ${Math.floor(i / BATCH) + 1}/${Math.ceil(list.length / BATCH)} … `);
  try {
    const res = await translateBatch(batch);
    Object.assign(map, res);
    console.log(`${Object.keys(res).length}/${batch.length} ✓`);
  } catch (err) {
    console.log(`فشل: ${String(err.message).slice(0, 70)}`);
  }
  await new Promise((r) => setTimeout(r, 1200));
}

const dir = join(ROOT, "scripts", "i18n");
await mkdir(dir, { recursive: true });
const path = join(dir, "07-ai.json");
let existing = {};
try { existing = JSON.parse(await readFile(path, "utf8")).fragments || {}; } catch {}
const merged = { ...existing, ...map };
await writeFile(path, JSON.stringify({ _note: "ترجمة آلية — scripts/ai-translate.js", fragments: merged }, null, 2), "utf8");

console.log(`\n✅ حُفظ ${Object.keys(merged).length} ترجمة في scripts/i18n/07-ai.json`);
console.log("   طبّقها: node scripts/apply-i18n.js plugins_legacy\n");
