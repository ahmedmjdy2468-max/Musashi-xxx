import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
import Module from 'node:module';
import { parse } from '@babel/parser';
import { Client } from '#meowsab';
import { registerLegacyPlugins } from '../system/legacy/loader.js';
import { registerCatalogAliases } from '../system/catalog.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const require = createRequire(import.meta.url);
const { initDatabase } = require('../src/lib/database.js');
const catalog = JSON.parse(fs.readFileSync(path.join(ROOT, 'system/commandCatalog.json'), 'utf8')).commands;
const sources = [
  'plugins_legacy/group/close.js', 'plugins_legacy/group/open.js', 'plugins_legacy/group/kick.js',
  'plugins_legacy/group/mute.js', 'plugins_legacy/group/absen.js', 'plugins_legacy/group/acc.js',
  'plugins_legacy/tools/toimg.js', 'plugins_legacy/tools/removebg.js', 'plugins_legacy/tools/translate.js',
  'plugins_legacy/tools/whatsappme.js', 'plugins_legacy/tools/addsong.js', 'plugins_legacy/tools/convertfile.js',
  'plugins_legacy/sticker/qc.js', 'plugins_legacy/sticker/bratrb.js', 'plugins_legacy/sticker/bratblueai.js',
  'plugins_legacy/sticker/animebrat2.js', 'plugins_legacy/sticker/animebrat3.js', 'plugins_legacy/sticker/attp.js',
  'plugins_legacy/sticker/brat.js', 'plugins_legacy/sticker/bratanime4.js', 'plugins_legacy/sticker/bratcewek.js',
  'plugins_legacy/sticker/bratcewek2.js', 'plugins_legacy/sticker/bratchika.js', 'plugins_legacy/sticker/bratemon.js',
  'plugins_legacy/sticker/brathd.js', 'plugins_legacy/sticker/bratvid.js', 'plugins_legacy/sticker/kannabrat.js',
  'plugins_legacy/sticker/ttp.js', 'plugins_legacy/sticker/emojimix.js', 'plugins_legacy/sticker/swm.js',
  'plugins_legacy/tools/tojadul.js', 'plugins_legacy/tools/emojitoanimasi.js', 'plugins_legacy/tools/emojitoimage.js',
  'plugins_legacy/tools/ocr.js', 'plugins_legacy/tools/readmore.js', 'plugins_legacy/tools/txt2qr.js',
  'plugins_legacy/tools/nulis.js', 'plugins_legacy/tools/qrcustom.js', 'plugins_legacy/tools/audionoicereducer.js',
  'plugins_legacy/tools/facedetector.js', 'plugins_legacy/tools/imgtoprompt.js', 'plugins_legacy/tools/lonjong.js',
  'plugins_legacy/tools/tovn.js', 'plugins_legacy/tools/transkrip.js', 'plugins_legacy/tools/converter.js',
];

// أزواج الاسم/الوصف المعتمدة بعد مراجعة وظيفة كل معالج. وجود الملف وحده لا يكفي.
const expected = {
  'plugins_legacy/group/close.js': { name: 'إغلاق_المجموعة', desc: 'يقصر إرسال الرسائل في المجموعة على المشرفين.' },
  'plugins_legacy/group/open.js': { name: 'فتح_المجموعة', desc: 'يسمح لجميع أعضاء المجموعة بإرسال الرسائل.' },
  'plugins_legacy/group/kick.js': { name: 'طرد_عضو', desc: 'يطرد العضو المحدد من المجموعة.' },
  'plugins_legacy/group/mute.js': { name: 'كتم_المجموعة', desc: 'يقصر إرسال الرسائل في المجموعة على المشرفين.' },
  'plugins_legacy/group/absen.js': { name: 'الحضور', desc: 'يسجل حضور أعضاء المجموعة أو يعرض سجل الحضور.' },
  'plugins_legacy/group/acc.js': { name: 'طلبات_الانضمام', desc: 'يعرض طلبات الانضمام إلى المجموعة ويقبلها أو يرفضها.' },
  'plugins_legacy/tools/toimg.js': { name: 'تحويل_ملصق_إلى_صورة', desc: 'يحوّل الملصق إلى صورة.' },
  'plugins_legacy/tools/removebg.js': { name: 'إزالة_خلفية_الصورة', desc: 'يزيل خلفية الصورة.' },
  'plugins_legacy/tools/translate.js': { name: 'ترجمة_إلى_لغة', desc: 'يترجم النص إلى اللغة التي تحددها.' },
  'plugins_legacy/tools/whatsappme.js': { name: 'رابط_واتساب', desc: 'ينشئ رابط محادثة واتساب للرقم المحدد مع رسالة اختيارية.' },
  'plugins_legacy/tools/addsong.js': { name: 'إضافة_أغنية_إلى_صورة', desc: 'ينشئ فيديو من صورة ومقطع صوتي.' },
  'plugins_legacy/tools/convertfile.js': { name: 'تحويل_ملف', desc: 'يحوّل الملف إلى الصيغة التي تحددها.' },
  'plugins_legacy/sticker/qc.js': { name: 'ملصق_اقتباس_ملون', desc: 'ينشئ ملصق اقتباس بالنص واللون المحددين.' },
  'plugins_legacy/sticker/bratrb.js': { name: 'ملصق_برات', desc: 'ينشئ ملصق برات من النص الذي تدخله.' },
  'plugins_legacy/sticker/bratblueai.js': { name: 'ملصق_برات_أزرق', desc: 'ينشئ ملصق برات أزرق من النص الذي تدخله.' },
  'plugins_legacy/sticker/animebrat2.js': { name: 'ملصق_برات_أنمي_متحرك', desc: 'ينشئ ملصقاً متحركاً بطابع برات وأنمي.' },
  'plugins_legacy/sticker/animebrat3.js': { name: 'ملصق_برات_أنمي_متحرك_ثان', desc: 'ينشئ إصداراً ثانياً من الملصق المتحرك بطابع برات وأنمي.' },
  'plugins_legacy/sticker/attp.js': { name: 'ملصق_نص_متحرك', desc: 'ينشئ ملصقاً متحركاً من النص الذي تدخله.' },
  'plugins_legacy/sticker/brat.js': { name: 'ملصق_برات_نصي', desc: 'ينشئ ملصق برات من النص الذي تدخله.' },
  'plugins_legacy/sticker/bratanime4.js': { name: 'ملصق_أنمي_برات_رابع', desc: 'ينشئ ملصقاً لشخصية أنمي بأسلوب برات من النص الذي تدخله.' },
  'plugins_legacy/sticker/bratcewek.js': { name: 'ملصق_برات_أنثوي', desc: 'ينشئ ملصق برات بطابع أنثوي من النص الذي تدخله.' },
  'plugins_legacy/sticker/bratcewek2.js': { name: 'ملصق_برات_أنثوي_ثان', desc: 'ينشئ الإصدار الثاني من ملصق برات ذي الطابع الأنثوي.' },
  'plugins_legacy/sticker/bratchika.js': { name: 'ملصق_برات_تشيكا', desc: 'ينشئ ملصقاً لشخصية تشيكا بأسلوب برات من النص الذي تدخله.' },
  'plugins_legacy/sticker/bratemon.js': { name: 'ملصق_برات_دورايمون', desc: 'ينشئ ملصقاً لدورايمون يحمل النص الذي تدخله.' },
  'plugins_legacy/sticker/brathd.js': { name: 'ملصق_برات_عالي_الدقة', desc: 'ينشئ ملصق برات عالي الدقة من النص الذي تدخله.' },
  'plugins_legacy/sticker/bratvid.js': { name: 'ملصق_برات_متحرك', desc: 'ينشئ ملصقاً متحركاً من النص الذي تدخله.' },
  'plugins_legacy/sticker/kannabrat.js': { name: 'ملصق_كانا_برات', desc: 'ينشئ ملصقاً لشخصية كانا يحمل النص الذي تدخله.' },
  'plugins_legacy/sticker/ttp.js': { name: 'نص_إلى_صورة', desc: 'ينشئ ملصقاً ثابتاً من النص الذي تدخله.' },
  'plugins_legacy/sticker/emojimix.js': { name: 'دمج_رمزين_تعبيريين', desc: 'يمزج رمزين تعبيريين في ملصق واحد.' },
  'plugins_legacy/sticker/swm.js': { name: 'تعديل_حقوق_الملصق', desc: 'يغيّر اسم الحزمة واسم المؤلف في الملصق الذي ترد عليه.' },
  'plugins_legacy/tools/tojadul.js': { name: 'تأثير_قديم', desc: 'يضيف إلى الصورة تأثيراً قديماً مع خفض دقتها وطمسها.' },
  'plugins_legacy/tools/emojitoanimasi.js': { name: 'إيموجي_إلى_ملصق_متحرك', desc: 'يحوّل الرمز التعبيري إلى ملصق متحرك.' },
  'plugins_legacy/tools/emojitoimage.js': { name: 'إيموجي_إلى_صورة', desc: 'ينشئ صورة ثابتة للرمز التعبيري بالأسلوب الذي تحدده.' },
  'plugins_legacy/tools/ocr.js': { name: 'استخراج_نص_من_صورة', desc: 'يستخرج النص الظاهر في الصورة التي ترد عليها.' },
  'plugins_legacy/tools/readmore.js': { name: 'إظهار_المزيد', desc: 'يضيف فاصل «اقرأ المزيد» بين أجزاء النص.' },
  'plugins_legacy/tools/txt2qr.js': { name: 'إنشاء_رمز_من_نص', desc: 'ينشئ رمز استجابة سريعة للنص الذي تدخله.' },
  'plugins_legacy/tools/nulis.js': { name: 'كتابة_بخط_يدوي', desc: 'يحوّل النص إلى صورة تبدو كأنها مكتوبة بخط اليد.' },
  'plugins_legacy/tools/qrcustom.js': { name: 'إنشاء_رمز_مخصص', desc: 'ينشئ رمز استجابة سريعة للرابط الذي تدخله.' },
  'plugins_legacy/tools/audionoicereducer.js': { name: 'إزالة_ضوضاء_الصوت', desc: 'يقلل الضوضاء في المقطع الصوتي الذي ترسله أو ترد عليه.' },
  'plugins_legacy/tools/facedetector.js': { name: 'كشف_الوجوه', desc: 'يتعرّف على الوجوه في الصورة التي ترسلها أو ترد عليها.' },
  'plugins_legacy/tools/imgtoprompt.js': { name: 'وصف_الصورة', desc: 'يحلل الصورة ويرسل وصفاً لمحتواها.' },
  'plugins_legacy/tools/lonjong.js': { name: 'إطالة_الصورة', desc: 'يطيل الصورة التي ترد عليها مع الحفاظ على أبعادها قدر الإمكان.' },
  'plugins_legacy/tools/tovn.js': { name: 'تحويل_إلى_رسالة_صوتية', desc: 'يحوّل الصوت أو الفيديو إلى رسالة صوتية.' },
  'plugins_legacy/tools/transkrip.js': { name: 'تفريغ_الصوت', desc: 'يحوّل الكلام في المقطع الصوتي إلى نص.' },
  'plugins_legacy/tools/converter.js': { name: 'تحويل_صيغة_ملف', desc: 'يحوّل الملف الذي ترد عليه إلى صيغة أخرى.' },
};
const canonical = {
  'plugins_legacy/group/close.js': 'close', 'plugins_legacy/group/open.js': 'open',
  'plugins_legacy/group/kick.js': 'kick', 'plugins_legacy/group/mute.js': 'mute',
  'plugins_legacy/group/absen.js': 'absen', 'plugins_legacy/group/acc.js': 'acc',
  'plugins_legacy/tools/toimg.js': 'stickertoimage', 'plugins_legacy/tools/removebg.js': 'rmbg',
  'plugins_legacy/tools/translate.js': 'tran', 'plugins_legacy/tools/whatsappme.js': 'whatsappme',
  'plugins_legacy/tools/addsong.js': 'addsong', 'plugins_legacy/tools/convertfile.js': 'convert file',
  'plugins_legacy/sticker/qc.js': 'qcstc', 'plugins_legacy/sticker/bratrb.js': 'bratrb',
  'plugins_legacy/sticker/bratblueai.js': 'bratblueai',
  'plugins_legacy/sticker/animebrat2.js': 'bratanime2', 'plugins_legacy/sticker/animebrat3.js': 'bratanime3',
  'plugins_legacy/sticker/attp.js': 'attp2', 'plugins_legacy/sticker/brat.js': 'brattext',
  'plugins_legacy/sticker/bratanime4.js': 'bratanime4', 'plugins_legacy/sticker/bratcewek.js': 'bratcewek',
  'plugins_legacy/sticker/bratcewek2.js': 'bratcewek2', 'plugins_legacy/sticker/bratchika.js': 'bratchika',
  'plugins_legacy/sticker/bratemon.js': 'bratemon', 'plugins_legacy/sticker/brathd.js': 'brathd',
  'plugins_legacy/sticker/bratvid.js': 'bratvid', 'plugins_legacy/sticker/kannabrat.js': 'kannabrat',
  'plugins_legacy/sticker/ttp.js': 'texttoimg', 'plugins_legacy/sticker/emojimix.js': 'emojimix',
  'plugins_legacy/sticker/swm.js': 'swm', 'plugins_legacy/tools/tojadul.js': 'tojadul',
  'plugins_legacy/tools/emojitoanimasi.js': 'emojitoanimasi', 'plugins_legacy/tools/emojitoimage.js': 'emojitoimage',
  'plugins_legacy/tools/ocr.js': 'totext', 'plugins_legacy/tools/readmore.js': 'readmore',
  'plugins_legacy/tools/txt2qr.js': 'txt2qr', 'plugins_legacy/tools/nulis.js': 'nulis',
  'plugins_legacy/tools/qrcustom.js': 'qrcustom', 'plugins_legacy/tools/audionoicereducer.js': 'audionoicereducer',
  'plugins_legacy/tools/facedetector.js': 'facedetector', 'plugins_legacy/tools/imgtoprompt.js': 'imgtoprompt',
  'plugins_legacy/tools/lonjong.js': 'lonjong', 'plugins_legacy/tools/tovn.js': 'tovn',
  'plugins_legacy/tools/transkrip.js': 'transkrip', 'plugins_legacy/tools/converter.js': 'converter',
};
const batch3 = JSON.parse(fs.readFileSync(path.join(ROOT, 'scripts/localization-batch3.json'), 'utf8'));
for (const [source, entry] of Object.entries(batch3)) {
  sources.push(source);
  expected[source] = { name: entry.name, desc: entry.description };
  canonical[source] = entry.canonical;
}
const allowedLatin = new Set([
  'en', 'ja', 'id', 'ko', 'ar', 'zh', 'fr', 'pink', 'red', 'blue', 'green', 'black', 'white',
  'mp3', 'wav', 'ogg', 'opus', 'm4a', 'aac', 'flac', 'jpeg', 'jpg', 'png', 'webp', 'WebP', 'mp4', 'gif', 'JPG', 'JPEG', 'PNG', 'GIF',
  'apple', 'google', 'microsoft', 'samsung', 'whatsapp', 'twitter', 'facebook', 'ffmpeg',
  'API', 'AI', 'WhatsApp', 'MUSASHI', 'Brat', 'HD', 'FFmpeg', 'URL',
  'yellow', 'purple', 'darkblue', 'lightblue', 'ash', 'orange', 'teal', 'lightpink', 'chocolate', 'salmon', 'magenta',
  'tan', 'wheat', 'deeppink', 'fire', 'skyblue', 'brightskyblue', 'hotpink', 'lightskyblue', 'seagreen', 'darkred',
  'orangered', 'cyan', 'violet', 'mossgreen', 'darkgreen', 'navyblue', 'darkorange', 'darkpurple', 'fuchsia',
  'darkmagenta', 'darkgray', 'peachpuff', 'darkishgreen', 'darkishred', 'goldenrod', 'darkishgray', 'darkishpurple',
  'gold', 'silver',
]);
const issues = [];
const fail = (file, reason) => issues.push(`FAIL ${file}: ${reason}`);
const norm = (s) => String(s || '').replaceAll('\\', '/').replace(/^\.\//u, '').toLowerCase();
const latinWords = (text) => [...String(text).matchAll(/[A-Za-z][A-Za-z0-9+/-]*/gu)].map(x => x[0]);
const firstCommandWord = (text) => String(text || '').trim().match(/^\.?([^\s]+)/u)?.[1] || '';
const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'musashi-batch1-strict-'));
const testChat = 'batch1-strict@g.us';

// استخدم commandSystem الحقيقي لتحميل plugins/، ثم loader الحقيقي لـ plugins_legacy/.
const runtimeClient = new Client({
  phoneNumber: '', prefix: ['.'], fromMe: false, owners: [],
  commandsPath: path.join(ROOT, 'plugins'), showLogs: false, autoReconnect: false,
});
await runtimeClient.commandSystem.loadDirectory(path.join(ROOT, 'plugins'));
await registerLegacyPlugins(runtimeClient, {
  dir: path.join(ROOT, 'plugins_legacy'),
  logger: { log() {}, warn() {}, error() {} },
});
registerCatalogAliases(runtimeClient, { logger: { log() {}, warn() {} } });
const testDb = await initDatabase(path.join(tempDir, 'db'));
process.on('exit', () => fs.rmSync(tempDir, { recursive: true, force: true }));
const nativeQc = runtimeClient.getCommand('qc');
const nativeQcPath = nativeQc?.__filePath ? path.relative(ROOT, nativeQc.__filePath).replaceAll('\\', '/') : '';
if (norm(nativeQcPath) !== 'plugins/sticker/textmaker.js') fail('plugins_legacy/sticker/qc.js', `الأمر qc الأصلي مسجل من «${nativeQcPath || 'غير مسجل'}»، وليس من المعالج الذي عدلناه.`);
console.log(`ROUTE qc → ${nativeQcPath || 'غير مسجل'} (المعالج الفائز فعلياً؛ مغاير لملف qc.js الخاص بالاسم qcstc)`);
if (nativeQc?.execute) {
  try {
    const replies = [];
    const m = { quoted: null, chat: testChat, async reply(value) { replies.push(String(value)); }, async react() {} };
    await nativeQc.execute(m, { conn: {}, command: 'qc', text: '' });
    const reply = replies.join('\n');
    const bad = latinWords(reply).filter(word => !allowedLatin.has(word));
    if (!/[\u0600-\u06FF]/u.test(reply)) fail('plugins/sticker/textmaker.js', 'رد qc الفعلي لا يحتوي نصاً عربياً.');
    if (bad.length) fail('plugins/sticker/textmaker.js', `رد qc الفعلي يحتوي لاتينية غير مسموحة: ${[...new Set(bad)].join(', ')}.`);
    console.log(`REPLY qc → ${reply.replace(/\s+/gu, ' ').slice(0, 120)}`);
  } catch (error) { fail('plugins/sticker/textmaker.js', `تعذرت محاكاة رد qc الفعلي: ${error?.message || error}`); }
}

function readReplyStrings(ast) {
  const found = [];
  const bindings = new Map();
  const walk = (node, fn) => {
    if (!node || typeof node !== 'object') return;
    fn(node);
    for (const [key, value] of Object.entries(node)) {
      if (['loc', 'start', 'end', 'extra', 'comments', 'tokens'].includes(key)) continue;
      if (Array.isArray(value)) value.forEach(child => walk(child, fn));
      else if (value && typeof value === 'object') walk(value, fn);
    }
  };
  walk(ast, node => {
    if ((node.type === 'VariableDeclarator' || node.type === 'AssignmentExpression') && node.id?.type === 'Identifier') bindings.set(node.id.name, node.init || node.right);
  });
  const extract = (node, seen = new Set()) => {
    if (!node || typeof node !== 'object') return;
    if (node.type === 'StringLiteral') { found.push(node.value); return; }
    if (node.type === 'TemplateLiteral') {
      for (const quasi of node.quasis || []) found.push(quasi.value?.cooked || quasi.value?.raw || '');
      for (const expr of node.expressions || []) extract(expr, seen);
      return;
    }
    if (node.type === 'Identifier') {
      if (seen.has(node.name)) return;
      seen.add(node.name);
      extract(bindings.get(node.name), seen);
      return;
    }
    if (node.type === 'ObjectExpression') {
      for (const property of node.properties || []) {
        const key = property.key?.name || property.key?.value;
        if (['text', 'caption'].includes(key)) extract(property.value, seen);
      }
      return;
    }
    if (node.type === 'BinaryExpression' || node.type === 'LogicalExpression') { extract(node.left, seen); extract(node.right, seen); return; }
    if (node.type === 'ConditionalExpression') { extract(node.consequent, seen); extract(node.alternate, seen); return; }
    if (node.type === 'ArrayExpression') for (const item of node.elements || []) extract(item, seen);
  };
  walk(ast, node => {
    if (node.type !== 'CallExpression' || node.callee?.type !== 'MemberExpression') return;
    const method = node.callee.property?.name;
    if (method === 'reply' || method === 'sendText') node.arguments.forEach(arg => extract(arg));
    if (method === 'sendMessage' && node.arguments[1]) extract(node.arguments[1]);
  });
  return found;
}

for (const relative of sources) {
  const file = path.join(ROOT, relative);
  const label = relative.replaceAll('\\', '/');
  let originalText = fs.readFileSync(file, 'utf8');
  const override = process.env.MUSASHI_BATCH_SOURCE_OVERRIDE;
  if (override && label === 'plugins_legacy/group/kick.js') originalText = fs.readFileSync(path.resolve(override), 'utf8');
  let mod;
  try {
    if (override && label === 'plugins_legacy/group/kick.js') {
      const compiled = new Module(file);
      compiled.filename = file;
      compiled.paths = Module._nodeModulePaths(path.dirname(file));
      compiled._compile(originalText, file);
      mod = compiled.exports;
    } else mod = require(file);
  } catch (error) { fail(label, `تعذّر تحميل المعالج: ${error.message}`); continue; }
  const cfg = mod.config || mod.pluginConfig || {};
  if (label === 'plugins_legacy/sticker/qc.js') {
    for (const [arabic, english] of [['وردي', 'pink'], ['أحمر', 'red'], ['أزرق', 'blue'], ['أخضر', 'green']]) {
      const aliasPattern = new RegExp(`["']${arabic}["']\\s*:\\s*["']${english}["']`, 'u');
      if (!aliasPattern.test(originalText)) fail(label, `لا يوجد اسم اللون العربي «${arabic}» مرتبطاً باللون ${english}.`);
    }
  }
  const commandNames = [...new Set([].concat(cfg.name || [], cfg.alias || []).filter(x => typeof x === 'string' && x.trim()).map(x => x.trim().toLowerCase()))];
  if (!commandNames.length) fail(label, 'لا يحتوي الملف على اسم أمر أو مرادف مسجل.');

  const commandKey = canonical[label];
  const primary = catalog[commandKey];
  const entriesForFile = Object.entries(catalog).filter(([, entry]) => norm(entry.sourceFile) === norm(label));
  const matchingEntries = Object.entries(catalog).filter(([key, entry]) =>
    commandNames.includes(String(entry.original || key).toLowerCase()) || commandNames.includes(key.toLowerCase())
  );
  if (!entriesForFile.length) fail(label, `لا يوجد اسم من أوامره في commandCatalog.json يشير إلى هذا الملف؛ المطابقات: ${matchingEntries.map(([k,e]) => `${k}→${e.sourceFile || '(بلا ملف)'}`).join(', ') || 'لا شيء'}`);

  const target = expected[label];
  if (!target) fail(label, 'لا توجد مراجعة دلالية معتمدة للاسم والوصف.');
  else {
    if (!primary) fail(label, `تعذر إيجاد سجل الكتالوج للأمر الأساسي ${commandKey}.`);
    else {
      if (primary.ar !== target.name) fail(label, `الاسم العربي في الكتالوج «${primary.ar}» لا يطابق الوظيفة؛ المتوقع «${target.name}».`);
      if (primary.desc !== target.desc) fail(label, `الوصف في الكتالوج «${primary.desc}» لا يطابق وظيفة المعالج؛ المتوقع «${target.desc}».`);
      for (const field of ['usage', 'example']) {
        const configured = String(cfg[field] || '').trim();
        if (!configured) continue;
        const configuredName = firstCommandWord(configured).replace(/^\./u, '');
        if (configuredName !== target.name) fail(label, `حقل ${field} في ملف المعالج يبدأ بـ «${configuredName || '(فارغ)'}» بدلاً من الاسم العربي الرسمي «${target.name}»: «${configured}».`);
      }
      for (const [field, value] of [['الاسم', primary.ar], ['الوصف', primary.desc], ['الاستخدام', `.${primary.ar}${primary.usageArgs ? ` ${primary.usageArgs}` : ''}`]]) {
        if (/\d/u.test(value)) fail(label, `${field} يحتوي رقماً مفرداً: «${value}».`);
        const unknown = latinWords(value).filter(word => !allowedLatin.has(word));
        if (unknown.length) fail(label, `${field} يحتوي كلمات لاتينية غير مسموحة: ${unknown.join(', ')}.`);
      }
      const usage = `.${primary.ar}${primary.usageArgs ? ` ${primary.usageArgs}` : ''}`;
      const example = primary.exampleArgs ? `.${primary.ar} ${primary.exampleArgs}` : '';
      for (const [field, value] of [['usage', usage], ['example', example]]) {
        if (value && firstCommandWord(value) !== primary.ar) fail(label, `${field} لا يبدأ بالاسم العربي الرسمي «${primary.ar}»: «${value}».`);
      }
      for (const [key, entry] of entriesForFile) {
        if (entry.desc !== primary.desc) fail(label, `المرادف ${key} لا ينسخ وصف الأمر الأساسي حرفياً.`);
        const aliasUsage = `.${entry.ar}${entry.usageArgs ? ` ${entry.usageArgs}` : ''}`;
        const aliasExample = entry.exampleArgs ? `.${entry.ar} ${entry.exampleArgs}` : '';
        for (const [field, value] of [['الاسم', entry.ar], ['الوصف', entry.desc], ['الاستخدام', aliasUsage], ['المثال', aliasExample]]) {
          if (!value) continue;
          if (/\d/u.test(value)) fail(label, `سجل ${key} في ${field} يحتوي رقماً: «${value}».`);
          const bad = latinWords(value).filter(word => !allowedLatin.has(word));
          if (bad.length) fail(label, `سجل ${key} في ${field} يحتوي لاتينية غير مسموحة: ${bad.join(', ')}.`);
        }
        for (const [field, value] of [['usage', aliasUsage], ['example', aliasExample]]) {
          if (value && firstCommandWord(value) !== entry.ar) fail(label, `سجل ${key}: ${field} لا يبدأ بالاسم العربي الرسمي «${entry.ar}».`);
        }
      }
    }
  }

  // تحميل وتجميع سجل الإضافات legacy بنفس normalizePlugin/loader الفعلي، بلا تنفيذ الشبكة.
  try {
    const ast = parse(originalText, { sourceType: 'unambiguous', errorRecovery: true, plugins: ['jsx', 'classProperties', 'dynamicImport', 'topLevelAwait'] });
    const strings = readReplyStrings(ast);
    for (const text of strings) {
      const bad = latinWords(text).filter(word => !allowedLatin.has(word));
      if (bad.length) fail(label, `نص رد/رسالة يحتوي لاتينية غير مسموحة (${[...new Set(bad)].join(', ')}): «${text.trim().slice(0, 100)}».`);
    }
  } catch (error) { fail(label, `تعذّر تحليل النصوص المرسلة للمستخدم: ${error.message}`); }

  const catalogRoute = catalog[commandKey]?.sourceFile;
  const winner = runtimeClient.getCommand(commandKey);
  const winningPath = winner?.__filePath || winner?.filePath;
  const runtimeRoute = winningPath ? path.relative(ROOT, winningPath).replaceAll('\\', '/') : '';
  if (norm(catalogRoute) !== norm(label)) fail(label, `الأمر «${commandKey}» يسجّل في الكتالوج الملف «${catalogRoute || 'بلا ملف'}»، لا الملف الذي ترجمناه.`);
  if (!winner) fail(label, `الأمر «${commandKey}» غير مسجل في registry وقت التشغيل.`);
  else if (norm(runtimeRoute) !== norm(label)) fail(label, `الملف الفائز فعلياً للأمر «${commandKey}» هو «${runtimeRoute}»، بينما الملف المترجم «${label}».`);
  else console.log(`ROUTE ${commandKey} → ${runtimeRoute} (المعالج الفائز فعلياً)`);

  // استدعاء فعلي لمسار ردّ آمن لكل معالج (لا إنترنت ولا تغييرات إدارية).
  try {
    const db = testDb;
    db.setGroup(testChat, { mute: true });
    global.absensi ||= {};
    const replies = [];
    const m = {
      chat: testChat, sender: '123456789@s.whatsapp.net', pushName: 'مراجع', name: 'مراجع',
      prefix: '.', command: commandKey, body: `.${commandKey}`, text: '', args: [], isGroup: true,
      isAdmin: true, isOwner: false, isImage: false, isAudio: false, isMedia: false, isSticker: false,
      type: 'conversation', mentionedJid: [], quoted: null, groupMembers: [],
      groupMetadata: { subject: 'مجموعة اختبار', announce: label.endsWith('/close.js'), participants: [] },
      async reply(value) { replies.push(typeof value === 'string' ? value : JSON.stringify(value)); },
      async react() {}, async download() { return Buffer.alloc(0); },
    };
    if (label.endsWith('/open.js')) m.groupMetadata.announce = false;
    const sock = { user: { id: '999999999@s.whatsapp.net', jid: '999999999@s.whatsapp.net' } };
    await mod.handler(m, { sock, conn: sock, db, config: {} });
    if (!replies.length) fail(label, 'المحاكاة الفعلية لم تلتقط m.reply.');
    const actualReply = replies.join('\n');
    if (!/[\u0600-\u06FF]/u.test(actualReply)) fail(label, `الرد الفعلي لا يحتوي نصاً عربياً: «${actualReply.slice(0, 100)}».`);
    const runtimeLatin = latinWords(actualReply).filter(word => !allowedLatin.has(word));
    if (runtimeLatin.length) fail(label, `الرد الفعلي يحتوي لاتينية غير مسموحة (${[...new Set(runtimeLatin)].join(', ')}): «${actualReply.slice(0, 120)}».`);
    if (/\b(?:dikeluarkan|belum|gak|Aduh|Hai~|Nee~|Cek lagi)\b/iu.test(actualReply)) fail(label, `الرد الفعلي يحتوي إندونيسية معروفة: «${actualReply.slice(0, 100)}».`);
    console.log(`REPLY ${label} → ${actualReply.replace(/\s+/gu, ' ').slice(0, 100)}`);
  } catch (error) { fail(label, `فشلت محاكاة المعالج: ${error?.message || error}`); }
}

if (issues.length) {
  console.error(`فشل فحص الدفعة الأولى: ${issues.length} مشكلة`);
  for (const issue of issues) console.error(issue);
  process.exitCode = 1;
} else {
  console.log(`نجحت الفحوص الصارمة للملفات: ${sources.length}`);
}
testDb.flushAll?.();
if (testDb.flushTimer) clearInterval(testDb.flushTimer);
runtimeClient.commandSystem.destroy?.();
process.exit(process.exitCode || 0);
