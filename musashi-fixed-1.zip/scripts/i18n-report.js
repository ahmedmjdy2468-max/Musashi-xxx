/**
 * 🔱 MUSASHI BOT — تقرير التعريب
 * يستخرج كل السلاسل النصية التي ما زالت بلغة أجنبية، ويرتّبها حسب التكرار
 * حتى تُترجم الأكثر شيوعاً أولاً (تغطية أوسع لكل جهد).
 *
 * الاستخدام:
 *   node scripts/i18n-report.js [--top 40] [--write]
 */
import { readdir, readFile, writeFile, stat } from "node:fs/promises";
import { join, extname, relative } from "node:path";

const ROOT = process.cwd();
const TARGET = process.argv[2] && !process.argv[2].startsWith("--") ? process.argv[2] : "plugins_legacy";
const topArg = process.argv.indexOf("--top");
const TOP = topArg > -1 ? Number(process.argv[topArg + 1]) || 40 : 40;
const WRITE = process.argv.includes("--write");

function literals(code) {
  const out = [];
  let i = 0;
  const n = code.length;
  while (i < n) {
    const c = code[i];
    if (c === "/" && code[i + 1] === "/") { while (i < n && code[i] !== "\n") i++; continue; }
    if (c === "/" && code[i + 1] === "*") { i += 2; while (i < n && !(code[i] === "*" && code[i + 1] === "/")) i++; i += 2; continue; }
    if (c === "'" || c === '"' || c === "`") {
      const q = c, s = i; i++; let d = 0;
      while (i < n) {
        if (code[i] === "\\") { i += 2; continue; }
        if (q === "`" && code[i] === "$" && code[i + 1] === "{") { d++; i += 2; continue; }
        if (q === "`" && code[i] === "}" && d > 0) { d--; i++; continue; }
        if (code[i] === q && d === 0) break;
        if (q !== "`" && code[i] === "\n") break;
        i++;
      }
      out.push({ text: code.slice(s + 1, i), start: s });
      i++;
      continue;
    }
    i++;
  }
  return out;
}

async function* walk(dir) {
  const info = await stat(dir).catch(() => null);
  if (info?.isFile()) { if (extname(dir) === ".js") yield dir; return; }
  for (const e of await readdir(dir, { withFileTypes: true })) {
    if (["node_modules", ".git", "session", "tmp", "scripts"].includes(e.name)) continue;
    const full = join(dir, e.name);
    if (e.isDirectory()) yield* walk(full);
    else if (extname(e.name) === ".js") yield full;
  }
}

const counter = new Map();
let totalLiterals = 0, arabicLiterals = 0, foreignLiterals = 0, scanned = 0;

for await (const file of walk(TARGET)) {
  scanned++;
  const code = await readFile(file, "utf8").catch(() => "");
  for (const lit of literals(code)) {
    const text = lit.text;
    if (!/[A-Za-z]{2,}/.test(text)) continue;
    totalLiterals++;
    const hasArabic = /[\u0600-\u06FF]/.test(text);
    if (hasArabic) { arabicLiterals++; continue; }
    if (!/[a-zA-Z]{3,}/.test(text)) continue;
    if (/^(https?:|[./]|[A-Za-z0-9_-]+\.(js|json|png|jpg|webp|mp4|mp3))$/.test(text.trim())) continue;

    // استبعاد النصوص التقنية (مفاتيح، ترويسات، مسارات، أسماء حقول)
    const TECH = /^(axios|path|owner|tools|image|group|reply|error|off|on|center|middle|POST|GET|User-Agent|Content-Type|utf-?8|arraybuffer|application\/|text\/|imageMessage|videoMessage|audioMessage|stickerMessage|itsuki|rpg|cek|game|search|MUSASHI|@s\.whatsapp\.net|Bearer|json|string|[a-z_]+)$/i;
    if (TECH.test(text.trim())) continue;
    if (!/\s/.test(text.trim()) && !/[\u2600-\u27BF\uD83C-\uDBFF]/.test(text)) continue;

    // نُبقي فقط ما يشبه واجهة مستخدم
    const MARKER = /\b(dan|yang|tidak|bisa|silakan|gunakan|untuk|dengan|atau|kalau|jika|sedang|gagal|berhasil|contoh|cara|pakai|kirim|balas|tunggu|grup|kamu|saya|hanya|khusus|fitur|perintah|pesan|gambar|stiker|tautan|waktu|hari|jam|menit|detik|koin|energi|level|limit|belum|harus|juga|lebih|kurang|semua|sekarang|nanti|mode|aksi|status|data|user|admin|owner|variant|server|panel|data|file)\b/i;
    if (!MARKER.test(text)) continue;

    foreignLiterals++;

    const key = text
      .replace(/\$\{[^}]*\}/g, "{x}")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 160);

    if (!counter.has(key)) counter.set(key, { count: 0, files: new Set() });
    const rec = counter.get(key);
    rec.count++;
    rec.files.add(relative(ROOT, file));
  }
}

const sorted = [...counter.entries()].sort((a, b) => b[1].count - a[1].count);

console.log(`\n🔱 تقرير التعريب — ${TARGET}`);
console.log(`ملفات: ${scanned} · سلاسل نصية: ${totalLiterals} · عربية: ${arabicLiterals} · أجنبية: ${foreignLiterals}`);
console.log(`تغطية عربية: ${((arabicLiterals / Math.max(totalLiterals, 1)) * 100).toFixed(1)}% · قوالب فريدة متبقية: ${sorted.length}\n`);

for (const [k, v] of sorted.slice(0, TOP)) {
  console.log(`[${String(v.count).padStart(3)}] ${k.slice(0, 120)}`);
}

if (WRITE) {
  const out = sorted.slice(0, 400).map(([k, v]) => ({ text: k, count: v.count, files: [...v.files].slice(0, 3) }));
  await writeFile(join(ROOT, "I18N_REMAINING.json"), JSON.stringify({ generatedAt: new Date().toISOString(), totals: { scanned, totalLiterals, arabicLiterals, foreignLiterals }, remaining: out }, null, 2), "utf8");
  console.log(`\n📄 كُتب I18N_REMAINING.json (${out.length} قالب)`);
}
