import fs from 'node:fs';

const visibility = JSON.parse(fs.readFileSync('system/legacy-command-visibility.json', 'utf8'));
const blockedSources = new Set((visibility.sources || []).map(file => String(file).replaceAll('\\', '/').toLowerCase()));
const catalog = new Map();
for (const file of ['system/commandCatalog.json', 'system/commandCatalog.ai.json']) {
  const commands = JSON.parse(fs.readFileSync(file, 'utf8')).commands || {};
  for (const [key, entry] of Object.entries(commands)) catalog.set(key, { ...(catalog.get(key) || {}), ...entry, key });
}

const generatedNames = new Set();
const resolvedLegacyNames = new Set();
for (const entry of catalog.values()) {
  const source = String(entry.sourceFile || '').replaceAll('\\', '/').toLowerCase();
  if (!source.startsWith('plugins_legacy/')) continue;
  for (const name of [entry.key, entry.original].filter(Boolean)) {
    resolvedLegacyNames.add(name);
    if (blockedSources.has(source)) generatedNames.add(name);
  }
}

const file = 'src/data/underdev.json';
const data = JSON.parse(fs.readFileSync(file, 'utf8'));
const existing = (data.commands || []).filter(name => !resolvedLegacyNames.has(name));
data.commands = [...new Set([...existing, ...generatedNames])].sort((a, b) => a.localeCompare(b));
fs.writeFileSync(file, JSON.stringify(data, null, 2) + '\n', 'utf8');
console.log(`ملفات legacy غير المترجمة المعطّلة عند التنفيذ: ${blockedSources.size}`);
console.log(`أسماء legacy المضافة لـ underDev: ${generatedNames.size}`);
console.log(`أسماء legacy القديمة المعاد تقييمها: ${resolvedLegacyNames.size}`);
