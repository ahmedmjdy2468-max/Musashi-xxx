/**
 * 🔱 MUSASHI BOT — تطبيق قاموس التعريب
 * الاستخدام: node scripts/apply-i18n.js <مجلد أو ملف> [--dry]
 *
 * يستبدل المقاطع المعرّفة في scripts/i18n/ar.json داخل السلاسل النصية فقط،
 * ويحافظ على تعبيرات ${...} كما هي.
 */
import { readdir, readFile, writeFile, stat } from "node:fs/promises";
import { join, extname, relative } from "node:path";

// يدمج كل ملفات القاموس في scripts/i18n (كل قسم له ملفه الخاص)
const dictDir = join(process.cwd(), "scripts", "i18n");
const allFragments = {};
const allStyled = {};
for (const name of await readdir(dictDir)) {
  if (!name.endsWith(".json")) continue;
  const d = JSON.parse(await readFile(join(dictDir, name), "utf8"));
  Object.assign(allFragments, d.fragments || {});
  Object.assign(allStyled, d.styledWords || {});
}
const fragments = Object.entries(allFragments).sort((a, b) => b[0].length - a[0].length);
const styled = Object.entries(allStyled).sort((a, b) => b[0].length - a[0].length);

const target = process.argv[2] || "plugins_legacy";
const dry = process.argv.includes("--dry");

/** يعيد نطاقات السلاسل النصية */
function findLiterals(code) {
  const out = [];
  let i = 0;
  const n = code.length;
  while (i < n) {
    const ch = code[i];
    if (ch === "/" && code[i + 1] === "/") { while (i < n && code[i] !== "\n") i++; continue; }
    if (ch === "/" && code[i + 1] === "*") { i += 2; while (i < n && !(code[i] === "*" && code[i + 1] === "/")) i++; i += 2; continue; }
    if (ch === "'" || ch === '"' || ch === "`") {
      const q = ch;
      const start = i;
      i++;
      let depth = 0;
      while (i < n) {
        if (code[i] === "\\") { i += 2; continue; }
        if (q === "`" && code[i] === "$" && code[i + 1] === "{") { depth++; i += 2; continue; }
        if (q === "`" && code[i] === "}" && depth > 0) { depth--; i++; continue; }
        if (code[i] === q && depth === 0) break;
        if (q !== "`" && code[i] === "\n") break;
        i++;
      }
      out.push({ start, end: i });
      i++;
      continue;
    }
    i++;
  }
  return out;
}

function translateLiteral(text) {
  // عزل تعبيرات ${...} قبل أي استبدال حتى لا تُمَس أسماء المتغيرات
  const parts = [];
  let masked = text.replace(/\$\{[^}]*\}/g, (m) => {
    parts.push(m);
    return `\u0000${parts.length - 1}\u0000`;
  });

  let out = masked;
  let changed = false;

  // الأحرف الصغيرة الزخرفية (small caps) التي تستخدمها القوالب
  const SC = "\\u1D00-\\u1D2B\\u1D62-\\u1D6A\\u2071\\u207F\\u2090-\\u209C";

  const escape = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

  const apply = (from, to, mode) => {
    // القوالب تحتوي باكتيك مهروب (\`) في الكود — نجرّب الشكلين
    const variants = [from];
    if (from.includes("`")) variants.push(from.replace(/`/g, "\\`"));
    for (let vi = 0; vi < variants.length; vi++) {
      const safeTo = vi === 0 ? to : to.replace(/`/g, "\\`");
      applyOne(variants[vi], safeTo, mode);
    }
  };

  const applyOne = (from, to, mode) => {
    if (!out.includes(from)) return;
    let re;
    if (mode === "latin") {
      // الشرطة السفلية ليست حرف كلمة في القوالب المنسّقة (_Coba lagi…)
      re = new RegExp(`(?<![A-Za-z0-9$])${escape(from)}(?![A-Za-z0-9$])`, "g");
    } else if (mode === "styled") {
      // لا نستبدل داخل كلمة زخرفية أطول
      re = new RegExp(`(?<![${SC}])${escape(from)}(?![${SC}])`, "g");
    } else {
      re = new RegExp(escape(from), "g");
    }
    const next = out.replace(re, to);
    if (next !== out) { out = next; changed = true; }
  };

  for (const [from, to] of styled) apply(from, to, "styled");
  for (const [from, to] of fragments) apply(from, to, "latin");

  if (!changed) return null;

  return out.replace(/\u0000(\d+)\u0000/g, (_, idx) => parts[Number(idx)]);
}

function translateCode(code) {
  const lits = findLiterals(code);
  let result = "";
  let cursor = 0;
  let changed = 0;

  for (const lit of lits) {
    result += code.slice(cursor, lit.start);
    const raw = code.slice(lit.start + 1, lit.end);
    // Module specifiers are executable identifiers, not user-facing copy.
    // Never run localization fragments over require/import paths.
    const beforeLiteral = code.slice(Math.max(0, lit.start - 48), lit.start);
    const isModuleSpecifier = /(?:\brequire\s*\(\s*|\bimport\s*\(\s*|\bfrom\s*|\bimport\s*)$/.test(beforeLiteral);
    // Preserve wire values, content types, URL literals, and single-token
    // identifiers. These are code/protocol values even when dictionaries
    // contain common English words such as "text", "file", or "link".
    const isProtocolLiteral = /(?:https?|wss?):\/\//i.test(raw)
      || /^(?:text|video|audio|image|application)\/[a-z0-9.+-]+$/i.test(raw.trim())
      || /^(?:[A-Za-z][A-Za-z0-9_.-]*|[A-Z][A-Z0-9_-]*)$/.test(raw.trim())
      || /(?:\.append|\.set)\s*\(\s*$/.test(beforeLiteral);
    const translated = isModuleSpecifier || isProtocolLiteral ? null : translateLiteral(raw);
    if (translated) {
      result += code[lit.start] + translated + code[lit.end];
      changed++;
    } else {
      result += code.slice(lit.start, lit.end + 1);
    }
    cursor = lit.end + 1;
  }
  result += code.slice(cursor);
  return { code: result, changed };
}

async function* walk(p) {
  const info = await stat(p).catch(() => null);
  if (info?.isFile()) { if (extname(p) === ".js") yield p; return; }
  for (const e of await readdir(p, { withFileTypes: true })) {
    if (["node_modules", ".git", "session", "tmp"].includes(e.name)) continue;
    const full = join(p, e.name);
    if (e.isDirectory()) yield* walk(full);
    else if (extname(e.name) === ".js") yield full;
  }
}

let files = 0, changedFiles = 0, changedStrings = 0;
for await (const file of walk(target)) {
  const code = await readFile(file, "utf8");
  const { code: out, changed } = translateCode(code);
  files++;
  if (changed) {
    changedFiles++;
    changedStrings += changed;
    if (!dry) await writeFile(file, out, "utf8");
  }
}

console.log(`\n🔱 تعريب — ${target}`);
console.log(`ملفات: ${files} · تغيّرت: ${changedFiles} · سلاسل مترجمة: ${changedStrings}${dry ? " (تجريبي)" : ""}\n`);
