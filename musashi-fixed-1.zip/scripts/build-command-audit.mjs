import fs from 'node:fs';
import path from 'node:path';
import { loadCatalog, isCatalogEntryVisible } from '../system/catalog.js';
import { isUnderDevCommand } from '../system/underDev.js';

const base = JSON.parse(fs.readFileSync('system/commandCatalog.json', 'utf8')).commands || {};
const ai = JSON.parse(fs.readFileSync('system/commandCatalog.ai.json', 'utf8')).commands || {};
const visibility = JSON.parse(fs.readFileSync('system/legacy-command-visibility.json', 'utf8'));
const unavailable = JSON.parse(fs.readFileSync('system/unavailable-services.json', 'utf8'));
const underdev = JSON.parse(fs.readFileSync('src/data/underdev.json', 'utf8'));
const runtime = loadCatalog();
const rows = Object.entries(base).map(([key, raw]) => {
  const entry = runtime[key] || {};
  const source = String(raw.sourceFile || ai[key]?.sourceFile || '').replaceAll('\\', '/');
  const fullSource = source ? path.resolve(source) : '';
  const sourceIssue = !fullSource || !fs.existsSync(fullSource) ? 'ملف المعالج غير موجود' : fs.statSync(fullSource).size === 0 ? 'ملف المعالج صفر بايت' : '';
  let status = 'ظاهر';
  let reason = '';
  if (raw.aliasOf || ai[key]?.aliasOf) { status = 'مرادف مخفي'; reason = `مرادف للاسم الأساسي: ${raw.aliasOf || ai[key]?.aliasOf}`; }
  else if (raw.hiddenForAudience || ai[key]?.hiddenForAudience) { status = 'مخفي للجمهور'; reason = 'إخفاء صريح في الكتالوج'; }
  else if (isUnderDevCommand(raw.original || key)) { status = 'قيد التعريب/التطوير'; reason = 'موجود في src/data/underdev.json'; }
  else if (raw.nameNeedsReview || ai[key]?.nameNeedsReview) { status = 'مراجعة الاسم'; reason = raw.reviewName || ai[key]?.reviewName || 'الاسم لم يعتمد'; }
  else if (source && visibility.sources?.map(x=>String(x).replaceAll('\\','/').toLowerCase()).includes(source.toLowerCase())) { status = 'مراجعة ترجمة legacy'; reason = 'ملف المعالج معلّم لمراجعة نصوص المستخدم'; }
  else if (source && unavailable.disabledLegacySources?.map(x=>String(x).replaceAll('\\','/').toLowerCase()).includes(source.toLowerCase())) { status = 'خدمة غير مفعلة'; reason = 'يحتاج خدمة أو مفتاحاً غير متاح'; }
  else if (sourceIssue) { status = 'مصدر غير صالح'; reason = sourceIssue; }
  else if (!isCatalogEntryVisible(entry)) { status = 'مراجعة الوصف/الاسم'; reason = 'بوابة الكتالوج تمنع عرضه'; }
  return {
    key, original: raw.original || key, aliasOf: raw.aliasOf || ai[key]?.aliasOf || '', ar: raw.ar || ai[key]?.ar || '', desc: raw.desc || ai[key]?.desc || '',
    usage: entry.usage || '', example: entry.example || '', perm: raw.perm || ai[key]?.perm || 'all',
    sourceFile: source, status, reason, sourceIssue,
  };
});

function csv(value) { return `"${String(value ?? '').replaceAll('"', '""')}"`; }
const headers = ['الاسم_الأصلي','الاسم_العربي','الوصف','الاستخدام','المثال','الصلاحية','ملف_المعالج','حالة_المصدر','الحالة','سبب_الحجب'];
const csvText = '\uFEFF' + [headers, ...rows.map(r=>[r.original,r.ar,r.desc,r.usage,r.example,r.perm,r.sourceFile,r.sourceIssue,r.status,r.reason])].map(row=>row.map(csv).join(',')).join('\r\n') + '\r\n';
fs.writeFileSync('docs/COMMAND-AUDIT.csv', csvText);
const visible = rows.filter(r=>r.status==='ظاهر').length;
const byStatus = new Map(); for (const row of rows) byStatus.set(row.status,(byStatus.get(row.status)||0)+1);
const brokenSources = [...new Map(rows.filter(r=>r.sourceIssue).map(r=>[r.sourceFile,r])).values()];
const reviewSources = new Set([
  ...(visibility.sources || []),
  ...(unavailable.disabledLegacySources || []),
].map(source => String(source).replaceAll('\\','/').toLowerCase()));
const forcedReviewReasons = Object.fromEntries(Object.entries(visibility.forcedSources || {}).map(([source, reason]) => [String(source).replaceAll('\\','/').toLowerCase(), reason]));
const unavailableReviewReasons = Object.fromEntries((unavailable.disabledLegacySources || []).map(source => [String(source).replaceAll('\\','/').toLowerCase(), unavailable.message || 'الخدمة غير مفعّلة.']));
const reviewQueue = rows
  .filter(r => String(r.sourceFile).startsWith('plugins_legacy/'))
  .filter(r => !r.aliasOf)
  .filter(r => ['قيد التعريب/التطوير','مراجعة ترجمة legacy','مراجعة الاسم','مراجعة الوصف/الاسم'].includes(r.status) || reviewSources.has(String(r.sourceFile).toLowerCase()))
  .map(r => ({ ...r, reviewReason: forcedReviewReasons[String(r.sourceFile).toLowerCase()] || unavailableReviewReasons[String(r.sourceFile).toLowerCase()] || r.reason || r.status }))
  .sort((a,b) => a.sourceFile.localeCompare(b.sourceFile) || a.original.localeCompare(b.original));
const lines = [
  '# مراجعة الأوامر غير المحسومة', '',
  `هذا التقرير مولّد من الكتالوج والملفات المحلية عند تشغيل \`node scripts/build-command-audit.mjs\`. إجمالي سجلات الكتالوج: **${rows.length}**؛ الظاهر بعد تطبيق بوابة القائمة وunderDev: **${visible}**.`, '',
  '## الحالات بالأرقام', '',
  ...[...byStatus].sort((a,b)=>a[0].localeCompare(b[0],'ar')).map(([status,count])=>`- ${status}: ${count}`), '',
  `- أسماء underDev في سجل التعطيل: ${underdev.commands?.length || 0}; ملفات/إضافات underDev: ${underdev.plugins?.length || 0}.`,
  `- ملفات legacy المعلّمة لمراجعة التعريب: ${visibility.sources?.length || 0}.`,
  `- مصادر legacy المعطلة لعدم توافر الخدمة: ${unavailable.disabledLegacySources?.length || 0}.`,
  '', '## ملفات معالج غير قابلة للتحقق', '',
  ...(brokenSources.length ? brokenSources.map(r=>`- \`${r.sourceFile || '(بلا مسار)'}\`: ${r.sourceIssue}; الأسماء المرتبطة: ${rows.filter(x=>x.sourceFile===r.sourceFile).map(x=>x.original).join('، ')}.`) : ['- لا توجد ملفات مفقودة أو فارغة مرتبطة بسجلات الكتالوج.']),
  '', '## آلية العمل', '',
  '- الأوامر ذات الملفات الفارغة أو المفقودة تبقى مخفية؛ لم أُنشئ معالجات وهمية لها.',
  '- legacy المعلّم لمراجعة الترجمة أو الخدمة يبقى وراء بوابة التعطيل، ولا يظهر في القائمة قبل المراجعة أو تفعيل الخدمة.',
  '- التفاصيل لكل سجل، بما فيها aliases والاستخدام والصلاحية والمسار وسبب الحجب، موجودة في `docs/COMMAND-AUDIT.csv`.', '',
  '## جاري الترجمة — قائمة التجربة اليدوية', '',
  'هذه الأوامر لم تُعتمد بعد. الأوامر التي يحجبها loader سترد حالياً برسالة «قيد التعريب» ولا تنفّذ المعالج؛ أرسل اسم الأمر الذي تريد تجربته وسأراجع ملفه وأترجم ردوده قبل فتحه.', '',
  '| الأمر الحالي للتعرّف عليه | اسم العرض الحالي | الملف | سبب المراجعة |',
  '|---|---|---|---|',
  ...(reviewQueue.length ? reviewQueue.map(r => '| `.' + r.original + '` | ' + (r.ar || 'غير محسوم') + ' | `' + r.sourceFile + '` | ' + r.reviewReason + ' |') : ['| لا توجد أوامر معلّقة | — | — | — |']),
  '',
];
fs.writeFileSync('docs/NEEDS-REVIEW.md', lines.join('\n'));
console.log(`سجلات الكتالوج: ${rows.length}; ظاهرة بالقائمة: ${visible}; مخفية/تحتاج مراجعة: ${rows.length-visible}`);
console.log(`ملفات legacy لمراجعة التعريب: ${visibility.sources?.length||0}; خدمات غير مفعلة: ${unavailable.disabledLegacySources?.length||0}`);
console.log(`ملفات المعالج الفارغة/المفقودة: ${brokenSources.length}`);
