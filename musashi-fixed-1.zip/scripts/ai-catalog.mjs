/**
 * 🔱 MUSASHI BOT — تسمية الأوامر بالذكاء الاصطناعي
 * ------------------------------------------------------------
 * يقرأ system/commandCatalog.json ويسمّي/يشرح الأوامر التي بلا اسم عربي،
 * عبر OpenRouter (مفتاحك في .env)، ويحفظ النتيجة في:
 *   system/commandCatalog.ai.json
 *
 * التشغيل:
 *   node scripts/ai-catalog.mjs --limit 400
 */
import { readFile, writeFile, mkdir } from "node:fs/promises";
import { join } from "node:path";

const ROOT = process.cwd();
const LIMIT = (() => {
  const i = process.argv.indexOf("--limit");
  return i > -1 ? Number(process.argv[i + 1]) || 300 : 300;
})();
const BATCH = 35;
const WORKERS = (() => { const i = process.argv.indexOf("--workers"); return i > -1 ? Number(process.argv[i + 1]) || 4 : 4; })();

await loadEnv();

async function loadEnv() {
  try {
    const raw = await readFile(join(ROOT, ".env"), "utf8");
    for (const line of raw.split("\n")) {
      const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
      if (m && !process.env[m[1]]) process.env[m[1]] = m[2].trim();
    }
  } catch {}
}

const key = process.env.OPENROUTER_API_KEY?.trim();
if (!key) {
  console.error("❌ ضع OPENROUTER_API_KEY في .env");
  process.exit(1);
}

const catalogPath = join(ROOT, "system", "commandCatalog.json");
const outPath = join(ROOT, "system", "commandCatalog.ai.json");

const catalog = JSON.parse(await readFile(catalogPath, "utf8"));
const commands = catalog.commands || {};

let ai = {};
try {
  ai = JSON.parse(await readFile(outPath, "utf8")).commands || {};
} catch {}

const pending = Object.entries(commands)
  .filter(([key2, v]) => !v.ar && !ai[key2])
  .slice(0, LIMIT)
  .map(([key2, v]) => ({ key: key2, category: v.category || "other", original: v.original }));

console.log(`\n🔱 تسمية بالذكاء الاصطناعي — ${pending.length} أمراً (${BATCH}/دفعة)\n`);
if (!pending.length) process.exit(0);

const TECH_AR = {
  GIF: "صورة_متحركة", MP3: "صوت", MP4: "فيديو", PDF: "بي_دي_اف", QR: "كيو_آر",
  API: "اي_بي_اي", VPS: "في_بي_اس", SSH: "اس_اس_اتش", URL: "رابط", ID: "معرف",
  AI: "ذكاء_اصطناعي", RPG: "اربيجي", XP: "خبرة", EXP: "خبرة", HP: "صحة", MP: "طاقة",
  OT: "او_تي", JPM: "بث", GC: "مجموعة", PM: "خاص", BOT: "بوت",
};

function sanitizeArabic(value) {
  let out = String(value || "").replace(/\s+/g, "_");
  for (const [latin, ar] of Object.entries(TECH_AR)) {
    out = out.replace(new RegExp(latin, "gi"), ar);
  }
  // إزالة أي بقايا لاتينية
  out = out.replace(/[A-Za-z]+/g, "").replace(/_+/g, "_").replace(/^_|_$/g, "");
  return out;
}
const SYSTEM = `أنت مصمم واجهات بوت واتساب عربي.
تسمّي أوامر برمجية بأسماء عربية واضحة وتشرحها باختصار.
قواعد:
- "ar": اسم عربي من كلمة إلى ثلاث كلمات، بحروف عربية، استخدم _ بين الكلمات، بلا مسافات، بلا رموز.
- "desc": شرح عربي ≤ 55 حرفاً يوضح وظيفة الأمر.
- "usage": مثال استخدام قصير يبدأ بنقطة، مثل "إضافة_طاقة <رقم> <كمية>".
- "perm": "all" أو "admin" أو "owner".
- لا تشتق الاسم من الوصف. سمّ الأمر من وظيفته الأصلية ومفتاحه.
- لا تضف أرقاماً أو لاحقات مثل _2 لحل التعارض؛ اختر اسماً عربياً مميزاً أو أبلغ عن التعارض.
- لا تستخدم كلمات إندونيسية أو حروفاً لاتينية في ar/desc/usage/example، عدا QR وPDF وOCR وGIF وMP3 وURL وHD.
- أعد JSON فقط بالشكل: {"items":[{"key":"...","ar":"...","desc":"...","usage":"...","example":"...","perm":"..."}]}`;

async function translateBatch(batch) {
  const payload = {
    items: batch.map((b) => ({ key: b.key, category: b.category, original: b.original })),
  };

  const res = await fetch("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      authorization: `Bearer ${key}`,
      "HTTP-Referer": process.env.BOT_CHANNEL_URL || "https://musashi.bot",
      "X-Title": "MUSASHI BOT Catalog",
    },
    body: JSON.stringify({
      model: process.env.OPENROUTER_MODEL || "openai/gpt-4o-mini",
      temperature: 0.3,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: SYSTEM },
        { role: "user", content: JSON.stringify(payload) },
      ],
    }),
    signal: AbortSignal.timeout(120000),
  });

  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const data = await res.json();
  const raw = data?.choices?.[0]?.message?.content || "";
  const parsed = JSON.parse(raw.replace(/```json|```/g, "").trim());
  return parsed.items || [];
}

let done = 0;
const batches = [];
for (let i = 0; i < pending.length; i += BATCH) batches.push(pending.slice(i, i + BATCH));

let cursor = 0;
async function worker(id) {
  while (cursor < batches.length) {
    const index = cursor++;
    const batch = batches[index];
    process.stdout.write(`  [ع${id}] دفعة ${index + 1}/${batches.length} … `);
    try {
      const items = await translateBatch(batch);
      for (const it of items) {
        if (!it?.key || !it?.ar) continue;
        const cleanAr = sanitizeArabic(it.ar);
        if (!cleanAr) continue;
        ai[it.key] = {
          ar: cleanAr,
          desc: String(it.desc || "").slice(0, 90),
          usage: String(it.usage || `.${it.key}`).slice(0, 80),
          example: String(it.example || "").slice(0, 100),
          perm: ["all", "admin", "owner"].includes(it.perm) ? it.perm : "all",
        };
        done += 1;
      }
      console.log(`+${items.length}`);
      await writeFile(outPath, JSON.stringify({ generatedAt: new Date().toISOString(), count: Object.keys(ai).length, commands: ai }, null, 2), "utf8");
    } catch (err) {
      console.log(`فشل: ${String(err.message).slice(0, 60)}`);
    }

    await new Promise((r) => setTimeout(r, 300));
  }
}

await Promise.all(Array.from({ length: WORKERS }, (_, i) => worker(i + 1)));

await mkdir(join(ROOT, "system"), { recursive: true });
await writeFile(
  outPath,
  JSON.stringify({ generatedAt: new Date().toISOString(), count: Object.keys(ai).length, commands: ai }, null, 2),
  "utf8"
);

console.log(`\n✅ أُضيف ${done} اسماً — الإجمالي في الملف: ${Object.keys(ai).length}\n`);
