import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { parse } from '@babel/parser';
import unavailableServices from '../system/unavailable-services.json' with { type: 'json' };

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SCOPES = ['plugins_legacy', 'plugins', 'src'];
const ARABIC = /[\u0600-\u06ff\u0750-\u077f\u08a0-\u08ff]/u;
const URL_RE = /\b(?:https?|wss?):\/\/[^\s`"'<>]+/gu;
const PLACEHOLDERS = /ISI_API_KEY_KAMU|YOUR_API_KEY|YOUR_KEY|API_KEY_HERE|CHANGE_ME|CHANGEME|INSERT_API_KEY|<API_KEY>/giu;
const failures = [];

function walk(dir) {
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) return walk(full);
    return /\.(?:js|cjs|mjs|ts)$/iu.test(entry.name) ? [full] : [];
  });
}

function lineAt(text, offset) { return text.slice(0, offset).split('\n').length; }
function rel(file) { return path.relative(ROOT, file).replaceAll('\\', '/'); }
function redact(value) { return String(value).replace(/([?&](?:api[_-]?key|apikey|key|token)=)[^&#\s]+/giu, '$1[REDACTED]'); }
function record(file, text, offset, reason, value) {
  failures.push(`${rel(file)}:${lineAt(text, offset)} ${reason}: ${redact(value)}`);
}

function isNetworkCall(node) {
  if (node?.type !== 'CallExpression') return false;
  const callee = node.callee;
  const root = callee.type === 'MemberExpression' ? callee.object : callee;
  const rootName = root?.name || (root?.type === 'MemberExpression' ? root.property?.name : '');
  const method = callee.type === 'MemberExpression' ? callee.property?.name : '';
  return ['fetch', 'axios', 'got', 'request', 'https', 'http', 'undici'].includes(rootName)
    || ['get', 'post', 'put', 'patch', 'delete', 'request'].includes(method);
}

function scanAst(file, text, ast) {
  function visit(node, networkDepth = 0, requestObject = false) {
    if (!node || typeof node !== 'object') return;
    const depth = networkDepth + (isNetworkCall(node) ? 1 : 0);
    const wireObject = node.type === 'ObjectExpression' && node.properties.some((property) => {
      if (property.type !== 'ObjectProperty') return false;
      const key = String(property.key?.name ?? property.key?.value ?? '').toLowerCase();
      const value = property.value?.type === 'StringLiteral' ? property.value.value : '';
      return /^(?:url|uri|endpoint|headers|params|query|body|data|apikey|api_key|key|sticker-pack-id|is-text-sticker)$/u.test(key)
        || /\bhttps?:\/\//u.test(value);
    });
    const objectContext = requestObject || wireObject;
    if (node.type === 'StringLiteral' || node.type === 'TemplateLiteral') {
      const value = node.type === 'StringLiteral'
        ? node.value
        : node.quasis.map((part) => part.value.cooked || '').join('__DYNAMIC__');
      for (const match of value.matchAll(URL_RE)) {
        if (ARABIC.test(match[0])) record(file, text, node.start, 'حرف عربي داخل URL', match[0]);
      }
      for (const match of value.matchAll(/[?&]([^?&#=\s]+)=/gu)) {
        if (ARABIC.test(match[1])) record(file, text, node.start, 'اسم معامل استعلام عربي', match[1]);
      }
    }
    if (node.type === 'ObjectProperty' && !node.computed) {
      const key = node.key?.name ?? node.key?.value;
      if (typeof key === 'string' && ARABIC.test(key) && (depth > 0 || objectContext)) {
        record(file, text, node.key.start, 'مفتاح عربي ضمن خيارات طلب شبكة', key);
      }
      if (node.value?.type === 'ObjectExpression') {
        const keyName = String(key || '').toLowerCase();
        const nestedRequest = objectContext || ['params', 'query', 'searchparams', 'headers', 'data', 'body'].includes(keyName);
        visit(node.value, depth, nestedRequest);
      }
      if (node.computed && node.key?.type === 'StringLiteral' && ARABIC.test(node.key.value) && (depth > 0 || requestObject)) {
        record(file, text, node.key.start, 'مفتاح عربي ضمن خيارات طلب شبكة', node.key.value);
      }
      // Visit key and non-object values without treating user text as property names.
      if (node.value?.type !== 'ObjectExpression') visit(node.value, depth, requestObject);
      return;
    }
    if (node.type === 'CallExpression' && node.callee?.type === 'MemberExpression'
      && ['append', 'set'].includes(node.callee.property?.name)
      && node.arguments?.[0]?.type === 'StringLiteral' && ARABIC.test(node.arguments[0].value)) {
      record(file, text, node.arguments[0].start, 'مفتاح عربي في form/searchParams', node.arguments[0].value);
    }
    for (const [key, child] of Object.entries(node)) {
      if (['loc', 'start', 'end', 'leadingComments', 'trailingComments', 'innerComments'].includes(key)) continue;
      if (Array.isArray(child)) {
        for (const item of child) if (item && typeof item.type === 'string') visit(item, depth, objectContext);
      } else if (child && typeof child.type === 'string') visit(child, depth, objectContext);
    }
  }
  visit(ast);
}

const files = SCOPES.flatMap((scope) => walk(path.join(ROOT, scope)));
const placeholders = new Map();
let placeholderCount = 0;

for (const file of files) {
  const text = fs.readFileSync(file, 'utf8');
  try {
    const ast = parse(text, { sourceType: 'unambiguous', errorRecovery: true, plugins: ['jsx', 'classProperties', 'dynamicImport', 'topLevelAwait', 'typescript'] });
    scanAst(file, text, ast);
  } catch (error) {
    failures.push(`${rel(file)} تعذر تحليل JavaScript: ${error.message}`);
  }
  for (const match of text.matchAll(PLACEHOLDERS)) {
    placeholderCount += 1;
    const entry = placeholders.get(file) || { count: 0, lines: [] };
    entry.count += 1;
    entry.lines.push(lineAt(text, match.index));
    placeholders.set(file, entry);
  }
}

const configuredPlaceholders = new Map((unavailableServices.entries || []).map((entry) => [entry.file.replaceAll('\\', '/'), entry]));
for (const [file, entry] of placeholders) {
  const relPath = rel(file);
  if (configuredPlaceholders.get(relPath)?.currentCount !== entry.count) {
    failures.push(`${relPath} قائمة الخدمات الوهمية لا تطابق العدد الحالي (${entry.count}).`);
  }
}
for (const [relPath, listed] of configuredPlaceholders) {
  const actual = placeholders.get(path.join(ROOT, relPath));
  if ((actual?.count || 0) !== listed.currentCount) failures.push(`${relPath} سجل القائمة يذكر ${listed.currentCount} مواضع حالية لكن الملف لا يطابقه.`);
}
const historicalCount = (unavailableServices.entries || []).reduce((sum, entry) => sum + Number(entry.count || 0), 0);
if (historicalCount !== unavailableServices.occurrences) failures.push(`قائمة placeholders التاريخية تجمع ${historicalCount} موضعاً، والمتوقع ${unavailableServices.occurrences}.`);
const disabledSources = new Set((unavailableServices.disabledLegacySources || []).map((source) => source.toLowerCase()));
let blockedPlaceholderFiles = 0;
let unregisteredPlaceholderFiles = 0;
for (const [file] of placeholders) {
  const relPath = rel(file).toLowerCase();
  if (relPath.startsWith('plugins_legacy/') && !disabledSources.has(relPath)) {
    const entry = configuredPlaceholders.get(rel(file));
    if (!entry || !/غير مسجل/iu.test(entry.action || '')) failures.push(`${rel(file)} يحتوي مفتاحاً وهمياً ومعالجه غير محجوب في loader.`);
    else unregisteredPlaceholderFiles += 1;
  } else if (relPath.startsWith('plugins_legacy/')) blockedPlaceholderFiles += 1;
}

console.log(`فحص سلامة الشبكة: ${files.length} ملفاً.`);
console.log(`مواضع placeholder API قبل الإصلاح: ${unavailableServices.occurrences}؛ المتبقية في المصدر: ${placeholderCount} في ${placeholders.size} ملفاً (${blockedPlaceholderFiles} محجوبة بالـloader، ${unregisteredPlaceholderFiles} في ملف غير مسجل).`);
for (const [file, entry] of placeholders) console.log(`PLACEHOLDER ${rel(file)}:${entry.lines.join(',')} × ${entry.count}`);
if (failures.length) {
  console.error(`فشل فحص سلامة الشبكة: ${failures.length} موضعاً.`);
  for (const failure of failures) console.error(failure);
  process.exitCode = 1;
} else {
  console.log('نجح فحص سلامة روابط الشبكة ومعاملاتها ومفاتيحها.');
}
