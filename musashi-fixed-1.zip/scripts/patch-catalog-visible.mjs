import fs from 'node:fs';
const p='system/catalog.js';let s=fs.readFileSync(p,'utf8');
s=s.replace('const DESCRIPTION_TEMPLATES = /', 'const DESCRIPTION_TEMPLATES = /');
s=s.replace('export function isCatalogEntryVisible(entry) {\n  if (!entry?.ar', 'const sharedDescriptions = new Set([...Object.entries(loadJson(join(__dirname, "commandCatalog.json"))?.commands || {}).reduce((map, [, e]) => { const d=String(e.desc || "").trim(); if (d) map.set(d, (map.get(d) || 0) + 1); return map; }, new Map())].filter(([, count]) => count > 3).map(([desc]) => desc));\n\nexport function isCatalogEntryVisible(entry) {\n  if (!entry?.ar');
s=s.replace('if (!entry?.ar || entry.nameNeedsReview || !String(entry.desc || "").trim() || DESCRIPTION_TEMPLATES.test(entry.desc)) return false;', 'if (!entry?.ar || entry.nameNeedsReview || !String(entry.desc || "").trim() || DESCRIPTION_TEMPLATES.test(entry.desc) || sharedDescriptions.has(String(entry.desc || "").trim())) return false;');
fs.writeFileSync(p,s);
