import fs from 'node:fs';
import path from 'node:path';
import { inspectLegacyUserText } from '../system/legacyCommandVisibility.js';
const ROOT='plugins_legacy', sources=[], scanned=new Set();
function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const file=path.join(dir,e.name).replaceAll('\\','/');if(e.isDirectory()){if(!['node_modules','.git','tmp','session'].includes(e.name))walk(file)}else if(file.endsWith('.js')){scanned.add(file.toLowerCase());if(inspectLegacyUserText(file).needsReview)sources.push(file.toLowerCase())}}}
walk(ROOT);sources.sort();
const overrides=JSON.parse(fs.readFileSync('scripts/legacy-visibility-overrides.json','utf8'));
for(const file of Object.keys(overrides.forceDisableSources||{})){
 const normalized=file.replaceAll('\\','/').toLowerCase();
 if(scanned.has(normalized)&&!sources.includes(normalized))sources.push(normalized);
}
sources.sort();
const merged=new Map();
for(const f of ['system/commandCatalog.json','system/commandCatalog.ai.json']){const d=JSON.parse(fs.readFileSync(f,'utf8'));for(const [k,v]of Object.entries(d.commands||{}))merged.set(k,{...(merged.get(k)||{}),...v,key:k})}
const rules=JSON.parse(fs.readFileSync('scripts/name-rules.json','utf8'));
const brands=JSON.parse(fs.readFileSync('scripts/brand-names.json','utf8'));
const norm=s=>String(s).normalize('NFKD').replace(/[\u064B-\u065F\u0670\u06D6-\u06ED]/g,'').replace(/[أإآٱ]/g,'ا').replace(/ى/g,'ي').replace(/ة/g,'ه').toLowerCase();
const known=new Set([...rules.knownWords,...Object.values(brands),...(rules.approvedProperNames||[])].map(norm));
const template=/يعرض محتوى ترفيهياً من نوع|يعرض محتوى ترفيهيا من نوع|ينفّذ .* ضمن أوامر المتنوعة|ينفذ .* ضمن أوامر المتنوعة|يستخدم الذكاء الاصطناعي لتنفيذ ذكاء اصطناعي/u;
const foreign=new Set(sources);const counts={catalogEntries:merged.size,legacyFilesScanned:scanned.size,legacyFilesWithIndonesianUserText:sources.length,commandsHiddenForLegacyText:0,commandsHiddenForName:0,commandsHiddenForDescription:0};
for(const e of merged.values()){
 const src=String(e.sourceFile||'').replaceAll('\\','/').toLowerCase();
 if(foreign.has(src))counts.commandsHiddenForLegacyText++;
 if(e.ar&&String(e.ar).split(/[_\s-]+/u).filter(Boolean).some(w=>/[\u0600-\u06ff]/u.test(w)&&!known.has(norm(w))))counts.commandsHiddenForName++;
 if(!e.desc||template.test(e.desc))counts.commandsHiddenForDescription++;
}
const prior=JSON.parse(fs.readFileSync('system/legacy-command-visibility.json','utf8'));const output={unloadableSources:prior.unloadableSources||['plugins_legacy/tools/cleanslash.js'],forcedSources:overrides.forceDisableSources||{},generatedAt:new Date().toISOString(),method:'AST user-output scan of m.reply and message send payloads; follows variables and local return expressions; checks Indonesian markers in extracted text, plus explicit review of dynamic data sources.',sources,counts};
fs.writeFileSync('system/legacy-command-visibility.json',JSON.stringify(output,null,2)+'\n');
console.log(`ملفات legacy المفحوصة: ${counts.legacyFilesScanned}`);
console.log(`ملفات legacy ذات ردود إندونيسية مرصودة: ${counts.legacyFilesWithIndonesianUserText}`);
console.log(`سجلات الكتالوج المحجوبة بسبب ردود إندونيسية: ${counts.commandsHiddenForLegacyText}`);
console.log(`سجلات محجوبة بسبب الاسم: ${counts.commandsHiddenForName}`);
console.log(`سجلات محجوبة بسبب الوصف: ${counts.commandsHiddenForDescription}`);
console.log('حُفظ system/legacy-command-visibility.json');
