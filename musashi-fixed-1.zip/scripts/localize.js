/**
 * 🔱 MUSASHI BOT — محرّك التعريب (Localization Engine)
 * ------------------------------------------------------------
 * يترجم النصوص الظاهرة للمستخدم داخل السلاسل النصية فقط،
 * دون المساس بأسماء المتغيرات أو الدوال أو المسارات أو الاستيرادات.
 *
 * فيه مُحلّل لغوي بسيط يميّز:
 *   الكود · السلاسل المفردة والمزدوجة · القوالب (`...${x}...`) · التعليقات
 * ثم يستبدل العبارات الإندونيسية/الإنجليزية الشائعة بالعربية الفصحى.
 *
 * الاستخدام:
 *   node scripts/localize.js <مجلد> [--dry] [--report]
 */

import { readdir, readFile, writeFile, stat } from "node:fs/promises";
import { join, extname, relative } from "node:path";

/* ─────────────── القاموس: عبارات كاملة أولاً (الأطول أولاً) ─────────────── */

const PHRASES = {
  // عبارات شائعة في الإضافات القديمة، بصياغة عربية طبيعية ومباشرة
  "nee~ khusus owner": "هذا الأمر خاص بمالك البوت",
  "nee~ khusus owner! fitur ini cuma buat owner aja ya~ ☆": "هذا الأمر مخصص لمالك البوت فقط.",
  "fitur ini cuma buat owner aja ya": "هذه الميزة متاحة لمالك البوت فقط",
  "khusus owner": "خاص بمالك البوت",
  "akses ditolak": "تم رفض الوصول",
  "kamu belum punya akses buat ini": "لا تملك صلاحية استخدام هذا الأمر",
  "belum punya akses": "لا تملك الصلاحية المطلوبة",
  "cara pakainya gini lho": "طريقة الاستخدام",
  "cara pakainya": "طريقة الاستخدام",
  "balas yes untuk tetap lanjut": "رد بكلمة نعم للمتابعة",
  "tiap giliran bebas pilih mau taruh s atau o": "يمكنك اختيار وضع علامة س أو و في كل دور.",
  "nee~ angkanya harus 1-9 ya~": "يجب أن يكون الرقم من 1 إلى 9.",
  "semua uploader gagal": "تعذّر الرفع عبر جميع الخدمات.",
  "file ini melebihi batas aman": "يتجاوز هذا الملف الحد الآمن.",
  "tetap mau lanjut buat file ini": "هل تريد متابعة استخدام هذا الملف؟",
  "pola berbahaya ditemukan di dalam file ini": "عُثر على نمط ضار داخل هذا الملف.",
  "musashi gak mau file rusak masuk ke server": "لن يسمح موساشي برفع ملفات تالفة إلى الخادم.",
  "mau main lagi": "هل تريد اللعب مجدداً؟",
  "apakah tebakan musashi benar": "هل كانت إجابة موساشي صحيحة؟",
  "chat owner": "محادثة المالك",
  "tidak diset": "غير مضبوط",
  "tidak tahu": "لا أعرف",
  "daftar grup": "قائمة المجموعات",
  "total grup": "إجمالي المجموعات",
  "tiktok user": "مستخدم تيك توك",
  "rate limit": "تجاوز حد الطلبات",
  "variant saat ini": "النسخة الحالية",
  "variant aktif": "النسخة النشطة",
  "file melebihi batas aman 5mb nih": "يتجاوز الملف الحد الآمن البالغ 5 ميغابايت.",
  "pilih variant dari daftar di bawah": "اختر النسخة من القائمة أدناه",
  "variant saat ini": "النسخة الحالية",
  "koneksi gagal": "تعذّر الاتصال",
  "ip atau password tidak valid": "عنوان IP أو كلمة المرور غير صحيح",
  "password tidak valid": "كلمة المرور غير صحيحة",
  "ip tidak valid": "عنوان IP غير صحيح",
  "tidak dapat mengunduh media": "تعذّر تنزيل الوسائط",
  "path harus di dalam direktori bot": "يجب أن يكون المسار داخل مجلد البوت",
  "path tidak boleh di luar direktori bot": "يجب ألا يكون المسار خارج مجلد البوت",
  "coba kirim ulang": "أعد الإرسال",
  "daftar grup": "قائمة المجموعات",
  "total grup": "إجمالي المجموعات",
  "owner bot": "مالك البوت",
  "musashi sayang kamu": "موساشي يقدّرك",
  "nekohime gagal": "تعذّر الاتصال بخدمة نيكو هيمي",
  "faddlaninco gagal": "تعذّر الاتصال بالخدمة",
  "ketik `.web back` untuk kembali": "اكتب `.web back` للعودة",
  "status:": "الحالة:",
  "file:": "الملف:",
  "media:": "الوسائط:",
  "pilih variant dari daftar di bawah": "اختر النسخة من القائمة أدناه",
  "variant aktif": "النسخة النشطة",
  "build assets": "تجهيز الملفات",
  "compiling panel assets": "جارٍ تجهيز ملفات اللوحة",
  "data dari layanan pihak ketiga": "بيانات من خدمة خارجية",
  "musashi gak mau file rusak masuk ke server": "لن يسمح موساشي برفع ملفات تالفة إلى الخادم",
  "akses ditolak": "تم رفض الوصول",
  "kamu bukan admin": "هذا الأمر مخصص لمشرفي المجموعة.",
  "bot bukan admin": "يجب ترقية البوت إلى مشرف في المجموعة.",
  "bot harus admin": "يجب أن يكون البوت مشرفاً في المجموعة.",
  "data tidak ditemukan": "لم يتم العثور على البيانات المطلوبة.",
  "terjadi kesalahan": "حدث خطأ أثناء تنفيذ الطلب.",
  "nomor tidak valid": "الرقم غير صالح.",
  "masukkan nomor yang valid": "أدخل رقماً صالحاً.",
  "gunakan perintah": "طريقة الاستخدام:",
  "contoh penggunaan": "مثال الاستخدام:",
  "interval:": "الفاصل الزمني:",
  "mode:": "الوضع:",
  "ᴍᴇᴅɪᴀ:": "الوسائط:",
  "claninvite @user": "دعوة_القبيلة @عضو",
  "clankick @user": "طرد_من_القبيلة @عضو",
  "demote @user": "تخفيض @عضو",
  "kick @user": "طرد @عضو",
  "promote @user": "ترقية @عضو",
  "resetwarn @user": "تصفير_الإنذارات @عضو",
  // حالات عامة
  "berhasil di": "تم بنجاح في",
  "berhasil": "بنجاح",
  "gagal mengambil": "تعذّر جلب",
  "gagal mengirim": "تعذّر إرسال",
  "gagal membuat": "تعذّر إنشاء",
  "gagal memuat": "تعذّر تحميل",
  "gagal menghapus": "تعذّر حذف",
  "gagal menyimpan": "تعذّر حفظ",
  "gagal": "فشل",
  "tidak ditemukan": "غير موجود",
  "tidak valid": "غير صالح",
  "tidak ada": "لا يوجد",
  "tidak bisa": "لا يمكن",
  "tidak dapat": "لا يمكن",
  "tidak tersedia": "غير متاح",
  "tidak diizinkan": "غير مسموح",
  "belum terdaftar": "غير مسجل",
  "sudah terdaftar": "مسجل بالفعل",
  "sedang diproses": "قيد المعالجة",
  "sedang berjalan": "جارٍ",
  "sedang memuat": "جارٍ التحميل",
  "mohon tunggu": "يرجى الانتظار",
  "harap tunggu": "يرجى الانتظار",
  "silakan": "رجاءً",
  "gunakan": "استخدم",
  "kirim": "أرسل",
  "balas": "ردّ على",
  "reply": "ردّ على",
  "contoh": "مثال",
  "cara pakai": "طريقة الاستخدام",
  "cara penggunaan": "طريقة الاستخدام",
  "format": "الصيغة",
  "url tidak valid": "الرابط غير صالح",
  "link tidak valid": "الرابط غير صالح",
  "hanya untuk owner": "للمالك فقط",
  "khusus owner": "خاص بالمالك",
  "khusus admin": "خاص بالمشرفين",
  "khusus premium": "خاص بالمميزين",
  "hanya bisa digunakan di grup": "يعمل داخل المجموعات فقط",
  "hanya bisa digunakan di private": "يعمل في الخاص فقط",
  "kamu bukan admin": "أنت لست مشرفاً",
  "bot bukan admin": "البوت ليس مشرفاً",
  "bot harus admin": "يجب أن يكون البوت مشرفاً",
  "limit habis": "انتهى الحد",
  "limit kamu habis": "انتهى حدّك",
  "saldo tidak cukup": "الرصيد غير كافٍ",
  "koin tidak cukup": "العملات غير كافية",
  "energi habis": "انتهت الطاقة",
  "energi tidak cukup": "الطاقة غير كافية",
  "waktu habis": "انتهى الوقت",
  "waktu tersisa": "الوقت المتبقي",
  "tidak ada data": "لا توجد بيانات",
  "data tidak ditemukan": "لم يتم العثور على البيانات",
  "terjadi kesalahan": "حدث خطأ",
  "kesalahan": "خطأ",
  "error": "خطأ",
  "peringatan": "تحذير",
  "informasi": "معلومة",
  "pengaturan": "الإعدادات",
  "daftar": "القائمة",
  "menu": "القائمة",
  "bantuan": "المساعدة",
  "batal": "إلغاء",
  "ya": "نعم",
  "tidak": "لا",
  "aktif": "مفعّل",
  "nonaktif": "متوقف",
  "diaktifkan": "تم تفعيله",
  "dinonaktifkan": "تم إيقافه",
  "dibuka": "مفتوح",
  "ditutup": "مغلق",
  "terbuka": "مفتوح",
  "tertutup": "مغلق",
  "berhasil diubah": "تم التغيير بنجاح",
  "berhasil ditambahkan": "تمت الإضافة بنجاح",
  "berhasil dihapus": "تم الحذف بنجاح",
  "berhasil dikirim": "تم الإرسال بنجاح",
  "berhasil dibuat": "تم الإنشاء بنجاح",
  "grup": "المجموعة",
  "grup wa": "مجموعة واتساب",
  "anggota": "عضو",
  "anggota grup": "أعضاء المجموعة",
  "admin grup": "مشرف المجموعة",
  "owner bot": "مالك البوت",
  "nomor": "الرقم",
  "nama": "الاسم",
  "umur": "العمر",
  "tanggal": "التاريخ",
  "waktu": "الوقت",
  "jam": "الساعة",
  "menit": "دقيقة",
  "detik": "ثانية",
  "hari": "يوم",
  "minggu": "أسبوع",
  "bulan": "شهر",
  "tahun": "سنة",
  "sekarang": "الآن",
  "selesai": "انتهى",
  "mulai": "ابدأ",
  "lanjut": "متابعة",
  "kembali": "رجوع",
  "tutup": "إغلاق",
  "buka": "فتح",
  "tambah": "إضافة",
  "hapus": "حذف",
  "ubah": "تعديل",
  "edit": "تعديل",
  "simpan": "حفظ",
  "cari": "بحث",
  "pilih": "اختر",
  "masukkan": "أدخل",
  "ketik": "اكتب",
  "perintah": "الأمر",
  "fitur": "ميزة",
  "sistem": "النظام",
  "pengguna": "المستخدم",
  "pemilik": "المالك",
  "pesan": "رسالة",
  "gambar": "صورة",
  "video": "فيديو",
  "audio": "صوت",
  "suara": "صوت",
  "dokumen": "مستند",
  "file": "ملف",
  "stiker": "ملصق",
  "tautan": "رابط",
  "link": "رابط",
  "ukuran": "الحجم",
  "durasi": "المدة",
  "kualitas": "الجودة",
  "judul": "العنوان",
  "deskripsi": "الوصف",
  "penulis": "المؤلف",
  "channel": "القناة",
  "saluran": "القناة",
  "kirim ke": "أرسل إلى",
  "menunggu": "بانتظار",
  "selama": "خلال",
  "sampai": "حتى",
  "sebelum": "قبل",
  "sesudah": "بعد",
  "hari ini": "اليوم",
  "kemarin": "أمس",
  "besok": "غداً",
  "selalu": "دائماً",
  "kadang": "أحياناً",
  "mungkin": "ربما",
  "pasti": "بالتأكيد",
  "segera": "قريباً",
  "lagi": "مرة أخرى",
  "ulangi": "أعد المحاولة",
  "coba lagi": "حاول مرة أخرى",
  "silakan coba lagi": "رجاءً حاول مرة أخرى",
  "nanti": "لاحقاً",
};

/* ─────────────── قاموس الكلمات (يُطبَّق بعد العبارات) ─────────────── */

const WORDS = {
  dan: "و", atau: "أو", yang: "الذي", dengan: "مع", untuk: "لـ", dari: "من",
  ke: "إلى", ini: "هذا", itu: "ذلك", bisa: "يمكن", sudah: "تم", akan: "سوف",
  kalau: "إذا", jika: "إذا", karena: "لأن", tetapi: "لكن", tapi: "لكن",
  juga: "أيضاً", hanya: "فقط", semua: "كل", lebih: "أكثر", kurang: "أقل",
  di: "في", pada: "في", oleh: "بواسطة", adalah: "هو", bukan: "ليس",
  belum: "لم", pernah: "سبق", harus: "يجب", perlu: "يلزم", ingin: "يريد",
  mau: "يريد", sedang: "جارٍ", telah: "قد", agar: "لكي", supaya: "لكي",
  jika: "إذا", maka: "إذن", pun: "أيضاً", lagi: "مرة أخرى",
  saya: "أنا", kamu: "أنت", anda: "أنت", kami: "نحن", mereka: "هم",
  dia: "هو", kita: "نحن", kalian: "أنتم",
  grup: "مجموعة", grupnya: "المجموعة", member: "عضو", admin: "مشرف",
  owner: "المالك", user: "المستخدم", bot: "البوت",
  koin: "عملة", uang: "مال", saldo: "الرصيد", harga: "السعر", bayar: "دفع",
  energi: "طاقة", limit: "الحد", level: "المستوى", exp: "الخبرة",
  hadiah: "جائزة", menang: "فاز", kalah: "خسر", skor: "النقاط", nilai: "القيمة",
  benar: "صحيح", salah: "خطأ", jawaban: "الإجابة", pertanyaan: "السؤال",
  soal: "سؤال", tebak: "خمّن", permainan: "لعبة", main: "العب",
  beli: "شراء", jual: "بيع", toko: "متجر", barang: "بضاعة", item: "عنصر",
  tas: "الحقيبة", senjata: "سلاح", armor: "درع", pedang: "سيف",
  ikan: "سمكة", berburu: "صيد", tambang: "تعدين", kebun: "مزرعة",
  kerja: "عمل", tugas: "مهمة", misi: "مهمة", petualangan: "مغامرة",
  waktu: "وقت", menit: "دقيقة", detik: "ثانية", hari: "يوم",
  pagi: "صباح", siang: "ظهر", sore: "عصر", malam: "ليل",
  selamat: "مرحباً", halo: "مرحباً", hai: "مرحباً",
  terima: "شكراً", kasih: "شكراً", maaf: "عذراً",
  cara: "طريقة", pakai: "استخدام", pake: "استخدام", kirim: "أرسل", balas: "ردّ",
  tunggu: "انتظر", anggota: "عضو", fitur: "ميزة", perintah: "أمر", pesan: "رسالة",
  gambar: "صورة", teks: "نص", foto: "صورة", nama: "اسم", nomor: "رقم", jumlah: "كمية",
  status: "الحالة", daftar: "قائمة", variant: "نسخة",
  gagal: "تعذّر", berhasil: "تم بنجاح", gratis: "مجاني", berbayar: "مدفوع", pilih: "اختر",
  kirimfile: "إرسال_ملف", sekarang: "الآن", aktif: "مفعّل", nonaktif: "معطّل",
};

/* كلمات لا تُترجم أبداً (مفاتيح تقنية/أسماء حقول) */
const PROTECTED = new Set([
  "admin", "owner", "user", "public", "private", "self", "group", "text", "image",
  "video", "audio", "document", "sticker", "true", "false", "null", "undefined",
  "button", "list", "menu", "error", "success", "warning", "info", "system",
]);

const MARKERS = /\b(dan|yang|ini|itu|tidak|bisa|sudah|silakan|gunakan|untuk|dengan|atau|kalau|jika|sedang|gagal|berhasil|contoh|cara|pakai|kirim|balas|tunggu|grup|anggota|admin|owner|kamu|saya|hanya|khusus|fitur|perintah|pesan|gambar|stiker|tautan|waktu|hari|jam|menit|detik|koin|energi|level|limit|belum|harus|juga|lebih|kurang|semua|sekarang|nanti|giliran|pilih|taruh|lanjut|tetap|uploader|gagal|aman|file|rusak|server|otomatis|validasi|berbahaya|ditemukan|tahu|mau|main|lagi|owner|set|status|interval|total|backup|diperiksa|syntax|check)\b/i;

/* ─────────────── مُحلّل السلاسل ─────────────── */

/** يعيد قائمة نطاقات السلاسل النصية في الكود: [{start, end, quote, content}] */
function findStringLiterals(code) {
  const out = [];
  let i = 0;
  const n = code.length;

  while (i < n) {
    const ch = code[i];

    // تعليق سطري
    if (ch === "/" && code[i + 1] === "/") {
      while (i < n && code[i] !== "\n") i++;
      continue;
    }
    // تعليق كتلي
    if (ch === "/" && code[i + 1] === "*") {
      i += 2;
      while (i < n && !(code[i] === "*" && code[i + 1] === "/")) i++;
      i += 2;
      continue;
    }

    // Skip regular-expression literals before scanning quotes. Regex character
    // classes can contain quotes and backticks; treating those as JS strings can
    // corrupt identifiers such as m.reply during localization.
    if (ch === "/" && beginsRegexLiteral(code, i)) {
      let j = i + 1;
      let inClass = false;
      while (j < n) {
        if (code[j] === "\\") { j += 2; continue; }
        if (code[j] === "[" && !inClass) { inClass = true; j++; continue; }
        if (code[j] === "]" && inClass) { inClass = false; j++; continue; }
        if (code[j] === "/" && !inClass) { j++; while (/[a-z]/i.test(code[j] || "")) j++; break; }
        if (code[j] === "\n") break;
        j++;
      }
      i = j;
      continue;
    }

    if (ch === "'" || ch === '"') {
      const quote = ch;
      const start = i;
      i++;
      while (i < n) {
        if (code[i] === "\\") { i += 2; continue; }
        if (code[i] === quote) break;
        if (code[i] === "\n") break; // سلسلة غير مغلقة (احتياط)
        i++;
      }
      out.push({ start, end: i, quote, content: code.slice(start + 1, i), kind: "string" });
      i++;
      continue;
    }

    if (ch === "`") {
      const start = i;
      i++;
      let depth = 0;
      while (i < n) {
        if (code[i] === "\\") { i += 2; continue; }
        if (code[i] === "$" && code[i + 1] === "{") { depth++; i += 2; continue; }
        if (code[i] === "}" && depth > 0) { depth--; i++; continue; }
        if (code[i] === "`" && depth === 0) break;
        i++;
      }
      out.push({ start, end: i, quote: "`", content: code.slice(start + 1, i), kind: "template" });
      i++;
      continue;
    }

    i++;
  }
  return out;
}

function beginsRegexLiteral(code, index) {
  let cursor = index - 1;
  while (cursor >= 0 && /\s/u.test(code[cursor])) cursor--;
  if (cursor < 0) return true;
  if (/[=(:,!;?{}\[\]&|>]/u.test(code[cursor])) return true;
  const prefix = code.slice(Math.max(0, cursor - 32), cursor + 1);
  return /\b(?:return|throw|case|typeof|instanceof|in|of|yield|await|delete|void|new)\s*$/u.test(prefix);
}

/** يترجم نصاً مع الحفاظ على تعبيرات ${...} */
function translateText(text) {
  // نعزل تعبيرات القوالب حتى لا تُترجم
  const parts = [];
  const masked = text.replace(/\$\{[^}]*\}/g, (m) => {
    parts.push(m);
    return `\u0000${parts.length - 1}\u0000`;
  });

  if (!/[A-Za-z]{3,}/.test(masked)) return null; // لا نص لاتيني
  
  // نتخطى النصوص التي لا تحمل أي مؤشر إندونيسي
  const uiPhrase = /(?:👑\s*owner\b|\bstatus\s*:|\bfile\s*:|\bmedia\s*:|\bvariant\s+(?:aktif|saat)|pilih variant|build assets|compiling panel assets|data dari layanan pihak ketiga|musashi gak mau file rusak|\binterval\s*:|\bmode\s*:|ᴍᴇᴅɪᴀ:|\.(?:claninvite|clankick|demote|kick|promote|resetwarn)\s+@user)/i.test(masked);
  if (!MARKERS.test(masked) && !uiPhrase) return null;

  let result = masked;

  // 1) العبارات (الأطول أولاً)
  const phrases = Object.keys(PHRASES).sort((a, b) => b.length - a.length);
  for (const ph of phrases) {
    const re = new RegExp(`\\b${ph.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`, "gi");
    result = result.replace(re, PHRASES[ph]);
  }

  // 2) الكلمات المفردة
  for (const [word, ar] of Object.entries(WORDS)) {
    if (PROTECTED.has(word)) continue;
    const re = new RegExp(`\\b${word}\\b`, "gi");
    result = result.replace(re, ar);
  }

  // نعيد التعبيرات كما هي
  result = result.replace(/\u0000(\d+)\u0000/g, (_, idx) => parts[Number(idx)]);

  return result === masked ? null : result;
}

function shouldTranslateLiteral(code, literal) {
  const before = code.slice(Math.max(0, literal.start - 280), literal.start);
  const after = code.slice(literal.end + 1, Math.min(code.length, literal.end + 281));
  const context = `${before}\n${after}`;
  // Avoid enum values and comparison operands even if their spelling appears in
  // the phrase dictionary; those strings are program data, not user messages.
  if (/(?:===|!==|case\s+|\.includes\s*\(|\.has\s*\()\s*["'`]?[^\n]*$/u.test(before)) return false;
  const messageSink = /(?:\.reply\s*\(|\.sendMessage\s*\(|\.sendButton\s*\(|\.sendText\s*\(|\.msgUrl\s*\(|\b(?:text|caption|body|description|responseMsg|help|usage|errorMessage|successMessage|footerText)\s*[:=])/iu;
  if (messageSink.test(context)) return true;
  const text = literal.content;
  return text.length > 22 && /\s/u.test(text) && MARKERS.test(text);
}

/** يترجم ملفاً كاملاً ويعيد {code, changed, literals, translated} */
function translateFile(code) {
  const literals = findStringLiterals(code);
  let result = "";
  let cursor = 0;
  let changed = 0;
  let translated = 0;

  for (const lit of literals) {
    result += code.slice(cursor, lit.start);
    translated++;
    const text = lit.content;
    const ar = shouldTranslateLiteral(code, lit) ? translateText(text) : null;

    if (ar && ar !== text) {
      changed++;
      result += lit.quote + ar + lit.quote;
    } else {
      result += code.slice(lit.start, lit.end + 1);
    }
    cursor = lit.end + 1;
  }
  result += code.slice(cursor);

  return { code: result, changed, literals: translated };
}

/* ─────────────── التشغيل ─────────────── */

async function* walk(dir) {
  const info = await stat(dir).catch(() => null);
  if (info?.isFile()) {
    if (extname(dir) === ".js") yield dir;
    return;
  }
  for (const e of await readdir(dir, { withFileTypes: true })) {
    if (["node_modules", ".git", "session", "tmp"].includes(e.name)) continue;
    const full = join(dir, e.name);
    if (e.isDirectory()) yield* walk(full);
    else if (extname(e.name) === ".js") yield full;
  }
}

const target = process.argv[2] || "plugins_legacy";
const dry = process.argv.includes("--dry");

let files = 0, changedFiles = 0, changedStrings = 0, totalStrings = 0;
const remaining = [];

for await (const file of walk(target)) {
  const code = await readFile(file, "utf8");
  const { code: out, changed, literals } = translateFile(code);
  files++;
  totalStrings += literals;

  if (changed > 0) {
    changedFiles++;
    changedStrings += changed;
    if (!dry) await writeFile(file, out, "utf8");

    // نلتقط ما تبقّى إندونيسياً (للمراجعة اليدوية)
    if (remaining.length < 40) {
      const left = out.match(/[`'"][^`'"]*\b(dan|yang|tidak|bisa|gagal|berhasil|silakan|untuk|dengan)\b[^`'"]*[`'"]/i);
      if (left) remaining.push(`${relative(process.cwd(), file)} → ${left[0].slice(0, 90)}`);
    }
  }
}

console.log(`\n🔱 تعريب — ${target}`);
console.log(`ملفات مفحوصة: ${files} · ملفات تغيّرت: ${changedFiles}`);
console.log(`سلاسل: ${totalStrings} · مترجمة: ${changedStrings}`);
console.log(dry ? "(تجريبي — لم يُكتب أي ملف)\n" : "(تم الحفظ)\n");
if (remaining.length) {
  console.log("نماذج تحتاج مراجعة يدوية:");
  for (const r of remaining.slice(0, 10)) console.log("  •", r);
}
