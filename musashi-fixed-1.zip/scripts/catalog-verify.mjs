/** Verifies the generated command catalog without importing WhatsApp packages. */
import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

const root = process.cwd();
const raw = JSON.parse(await readFile(join(root, 'system', 'commandCatalog.json'), 'utf8'));
const commands = raw.commands || {};
const entries = Object.entries(commands);
const isArabic = (s) => /[\u0600-\u06ff]/.test(String(s || ''));
const missingArabic = [], missingDesc = [], missingUsage = [], conflicts = new Map();
for (const [name, entry] of entries) {
  if (!isArabic(entry.ar) || /[A-Za-z]/.test(entry.ar || '')) missingArabic.push(name);
  if (!isArabic(entry.desc)) missingDesc.push(name);
  if (!entry.usage || !isArabic(entry.usage)) missingUsage.push(name);
  if (entry.ar) conflicts.set(entry.ar.toLowerCase(), [...(conflicts.get(entry.ar.toLowerCase()) || []), name]);
}
const duplicates = [...conflicts].filter(([, names]) => names.length > 1);
const total = entries.length;
const report = {
  generatedAt: new Date().toISOString(),
  totals: { registered: total, withArabic: total - missingArabic.length, withDesc: total - missingDesc.length, withUsage: total - missingUsage.length, conflicts: duplicates.length },
  missingArabic, missingDesc, missingUsage,
  conflicts: duplicates.map(([ar, names]) => ({ ar, commands: names })),
  note: 'يشمل التقرير أسماء الأوامر والمرادفات المستخرجة من إعدادات الإضافات، ولا يحسب أسماء العناصر أو بيانات الألعاب. تبقى القيم والأعلام التي يتطلبها الأمر بصيغتها المقبولة للحفاظ على عمله.'
};
await writeFile(join(root, 'CATALOG_REPORT.json'), JSON.stringify(report, null, 2), 'utf8');
const lines = [
  '# 🔱 تقرير دليل الأوامر العربية', '',
  `> ${report.generatedAt}`, '',
  '| المقياس | العدد |', '|---|---:|',
  `| الأوامر والأسماء البديلة | ${total} |`,
  `| اسم عربي بلا حروف لاتينية | ${report.totals.withArabic} |`,
  `| شرح عربي | ${report.totals.withDesc} |`,
  `| طريقة استخدام موضّحة | ${report.totals.withUsage} |`,
  `| تعارض أسماء العرض | ${report.totals.conflicts} |`, '',
  report.totals.withArabic === total && report.totals.withDesc === total && report.totals.withUsage === total && !report.totals.conflicts
    ? '✅ كل أمر في الكتالوج له اسم عربي وشرح وطريقة استخدام.'
    : '⚠️ توجد بيانات ناقصة؛ راجع CATALOG_REPORT.json.', '',
  report.note, ''
];
await writeFile(join(root, 'CATALOG_REPORT.md'), lines.join('\n'), 'utf8');
console.log(lines.slice(0, 17).join('\n'));
if (report.totals.withArabic !== total || report.totals.withDesc !== total || report.totals.withUsage !== total || report.totals.conflicts) process.exitCode = 1;
