import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import { registerLegacyPlugins } from '../system/legacy/loader.js';
import { normalizeArabic } from '../system/normalizeArabic.js';

const require = createRequire(import.meta.url);
const root = process.cwd();
const apply = process.argv.includes('--apply');
const parser = require('@babel/parser');

async function* walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (['node_modules', '.git', 'session', 'tmp', 'temp'].includes(entry.name)) continue;
    const file = path.join(dir, entry.name);
    if (entry.isDirectory()) yield* walk(file);
    else if (entry.isFile() && file.endsWith('.js')) yield file;
  }
}

function names(mod) {
  const m = mod?.default ?? mod;
  return [...new Set([m?.command, m?.config?.command, m?.config?.name, m?.config?.alias, m?.alias]
    .flatMap(value => Array.isArray(value) ? value : [value])
    .filter(value => typeof value === 'string').map(value => value.trim()).filter(Boolean))];
}

const registered = [];
const declared = new Map();
const loadErrors = [];
const client = {
  registerCommand(item) { registered.push(item); },
  getAllCommands() { return registered; },
  getCommand(name) { const key = normalizeArabic(name); return registered.find(item => [].concat(item.command || []).some(n => normalizeArabic(n) === key)) || null; },
};

for await (const file of walk(path.join(root, 'plugins'))) {
  try {
    const mod = await import(pathToFileURL(file).href);
    const commandNames = names(mod);
    if (!commandNames.length) continue;
    const rel = path.relative(root, file).replaceAll('\\', '/');
    declared.set(rel, commandNames);
    registered.push({ command: commandNames, filePath: file, category: (mod.default ?? mod).category || 'native' });
  } catch (error) {
    loadErrors.push({ file: path.relative(root, file), error: error?.message || String(error) });
  }
}

const legacyStats = await registerLegacyPlugins(client, { dir: './plugins_legacy', logger: { log() {}, warn() {}, error() {} } });
for await (const file of walk(path.join(root, 'plugins_legacy'))) {
  const rel = path.relative(root, file).replaceAll('\\', '/');
  try {
    delete require.cache[require.resolve(file)];
    const mod = require(file);
    const commandNames = names(mod);
    if (commandNames.length) declared.set(rel, commandNames);
  } catch (error) {
    loadErrors.push({ file: rel, error: error?.message || String(error) });
  }
}

const winners = new Map();
for (const handler of registered) {
  const file = handler.filePath ? path.relative(root, handler.filePath).replaceAll('\\', '/') : '(unknown)';
  for (const name of [].concat(handler.command || [])) {
    const key = normalizeArabic(name);
    if (key && !winners.has(key)) winners.set(key, { name, file });
  }
}

const groups = new Map();
for (const [file, commandNames] of declared) for (const name of commandNames) {
  const key = normalizeArabic(name);
  const group = groups.get(key) || [];
  if (!group.some(item => item.file === file)) group.push({ file, name });
  groups.set(key, group);
}
const conflicts = [...groups].filter(([, owners]) => owners.length > 1);
const losersByFile = new Map();
for (const [key, owners] of conflicts) {
  const winner = winners.get(key) || owners[0];
  for (const owner of owners) {
    if (owner.file === winner.file) continue;
    const namesToDrop = losersByFile.get(owner.file) || new Set();
    namesToDrop.add(key);
    losersByFile.set(owner.file, namesToDrop);
  }
}

function stringValue(node) {
  return node?.type === 'StringLiteral' ? node.value : null;
}
function propertyName(node) {
  if (!node || node.type !== 'ObjectProperty') return '';
  return node.key?.name || node.key?.value || '';
}
function isMetadataProperty(node) {
  return node?.type === 'ObjectProperty' && ['command', 'alias', 'name'].includes(propertyName(node));
}

let filesChanged = 0;
let namesRemoved = 0;
for (const [rel, keysToDrop] of losersByFile) {
  const file = path.resolve(root, rel);
  const source = fs.readFileSync(file, 'utf8');
  let ast;
  try {
    ast = parser.parse(source, { sourceType: 'unambiguous', errorRecovery: true, plugins: ['jsx', 'decorators-legacy', 'classProperties', 'dynamicImport', 'topLevelAwait'] });
  } catch (error) {
    loadErrors.push({ file: rel, error: `parse: ${error.message}` });
    continue;
  }
  const edits = [];
  const declarations = new Map();
  function findDeclarations(node) {
    if (!node) return;
    if (Array.isArray(node)) { for (const child of node) findDeclarations(child); return; }
    if (node.type === 'VariableDeclarator' && node.id?.type === 'Identifier') declarations.set(node.id.name, node.init);
    for (const [key, value] of Object.entries(node)) {
      if (['loc', 'start', 'end', 'tokens', 'comments'].includes(key)) continue;
      if (value && typeof value === 'object') findDeclarations(value);
    }
  }
  findDeclarations(ast);

  function objectKeysSource(value) {
    if (value?.type !== 'CallExpression' || value.callee?.type !== 'MemberExpression') return null;
    const method = value.callee.computed ? value.callee.property?.value : value.callee.property?.name;
    const object = value.callee.object?.name;
    const sourceName = value.arguments?.[0]?.name;
    if (!['keys', 'values'].includes(method) || object !== 'Object' || !sourceName) return null;
    const initializer = declarations.get(sourceName);
    return initializer?.type === 'ObjectExpression' ? initializer : null;
  }

  function collect(node) {
    if (!node) return;
    if (Array.isArray(node)) { for (const child of node) collect(child); return; }
    if (isMetadataProperty(node)) {
      if (node.value?.type === 'ArrayExpression') {
        const kept = node.value.elements.filter(element => !keysToDrop.has(normalizeArabic(stringValue(element) || '')));
        if (kept.length !== node.value.elements.length) {
          const rendered = kept.map(element => source.slice(element.start, element.end)).join(', ');
          edits.push({ start: node.value.start, end: node.value.end, text: `[${rendered}]`, removed: node.value.elements.length - kept.length });
        }
      } else if (stringValue(node.value) !== null && keysToDrop.has(normalizeArabic(stringValue(node.value)))) {
        edits.push({ start: node.value.start, end: node.value.end, text: '""', removed: 1 });
      } else {
        const sourceObject = objectKeysSource(node.value);
        if (sourceObject) {
          const kept = sourceObject.properties.filter(property => {
            const key = property.key?.name || property.key?.value;
            return !keysToDrop.has(normalizeArabic(String(key || '')));
          });
          if (kept.length !== sourceObject.properties.length) {
            const rendered = kept.map(property => source.slice(property.start, property.end)).join(', ');
            edits.push({ start: sourceObject.start, end: sourceObject.end, text: `{ ${rendered} }`, removed: sourceObject.properties.length - kept.length });
          }
        }
      }
    }
    if (node.type === 'AssignmentExpression' && node.left?.type === 'MemberExpression') {
      const prop = node.left.computed ? node.left.property?.value : node.left.property?.name;
      if (['command', 'alias', 'name'].includes(prop)) {
        if (node.right?.type === 'ArrayExpression') {
          const kept = node.right.elements.filter(element => !keysToDrop.has(normalizeArabic(stringValue(element) || '')));
          if (kept.length !== node.right.elements.length) {
            const rendered = kept.map(element => source.slice(element.start, element.end)).join(', ');
            edits.push({ start: node.right.start, end: node.right.end, text: `[${rendered}]`, removed: node.right.elements.length - kept.length });
          }
        } else if (stringValue(node.right) !== null && keysToDrop.has(normalizeArabic(stringValue(node.right)))) {
          edits.push({ start: node.right.start, end: node.right.end, text: '""', removed: 1 });
        }
      }
    }
    for (const [key, value] of Object.entries(node)) {
      if (['loc', 'start', 'end', 'tokens', 'comments'].includes(key)) continue;
      if (value && typeof value === 'object') collect(value);
    }
  }
  collect(ast);
  const byRange = new Map(edits.map(edit => [`${edit.start}:${edit.end}`, edit]));
  const uniqueEdits = [...byRange.values()].sort((a, b) => b.start - a.start);
  if (!uniqueEdits.length) {
    console.log(`لم يتغير المصدر رغم وجود تعارض معلن: ${rel} ← ${[...keysToDrop].join(', ')}`);
    continue;
  }
  let output = source;
  for (const edit of uniqueEdits) {
    output = output.slice(0, edit.start) + edit.text + output.slice(edit.end);
    namesRemoved += edit.removed;
  }
  filesChanged += 1;
  if (apply) fs.writeFileSync(file, output, 'utf8');
  console.log(`${apply ? 'حُذف' : 'سيُحذف'}: ${rel} ← ${[...keysToDrop].join(', ')}`);
}

console.log(`تعريفات متعارضة قبل الحسم: ${conflicts.length}`);
console.log(`الأسماء المتجاوزة في loader: ${legacyStats.conflicts || 0}`);
console.log(`ملفات ${apply ? 'عُدّلت' : 'ستُعدّل'}: ${filesChanged}`);
console.log(`عناصر أسماء ${apply ? 'حُذفت' : 'ستُحذف'}: ${namesRemoved}`);
console.log(`ملفات تعذر تحميلها: ${loadErrors.length}`);
if (!apply) console.log('لم تتغير الملفات. أضف --apply لتطبيق الحذف.');
if (loadErrors.length) process.exitCode = 1;
