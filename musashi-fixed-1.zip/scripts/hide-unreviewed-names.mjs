import fs from 'node:fs';
import { normalizeArabic } from '../system/normalizeArabic.js';

const files = ['system/commandCatalog.json', 'system/commandCatalog.ai.json'];
const catalogs = files.map(file => ({ file, root: JSON.parse(fs.readFileSync(file, 'utf8')) }));
const rules = JSON.parse(fs.readFileSync('scripts/name-rules.json', 'utf8'));
const brands = JSON.parse(fs.readFileSync('scripts/brand-names.json', 'utf8'));
const known = new Set([...rules.knownWords, ...Object.values(brands), ...(rules.approvedProperNames || [])].map(normalizeArabic));
const isUnknown = name => String(name || '').split(/[_\s-]+/u).filter(Boolean).some(word =>
  !/^[0-9٠-٩]+$/u.test(word) && /[\u0600-\u06ff]/u.test(word) && !known.has(normalizeArabic(word))
);
const canonical = new Map();
for (const { root } of catalogs) for (const [key, entry] of Object.entries(root.commands || {})) {
  const source = String(entry.sourceFile || '').replaceAll('\\', '/').toLowerCase();
  canonical.set(`${source}:${normalizeArabic(key)}`, entry);
}

let hidden = 0;
for (const { root } of catalogs) for (const [key, entry] of Object.entries(root.commands || {})) {
  const source = String(entry.sourceFile || '').replaceAll('\\', '/').toLowerCase();
  if (entry.aliasOf) {
    const primary = canonical.get(`${source}:${normalizeArabic(entry.aliasOf)}`);
    if (primary?.nameNeedsReview || (!primary?.ar && primary?.reviewName) || isUnknown(primary?.ar)) {
      entry.reviewName ||= entry.ar || primary?.reviewName || '';
      entry.ar = '';
      entry.nameNeedsReview = true;
      entry.hiddenForAudience = true;
      hidden++;
    }
    continue;
  }
  if (!entry.ar || !isUnknown(entry.ar)) continue;
  entry.reviewName = entry.ar;
  entry.ar = '';
  entry.nameNeedsReview = true;
  entry.hiddenForAudience = true;
  entry.nameReviewReason = 'اللفظ غير مثبت في قاموس الاسم العربي؛ يبقى الأمر مخفياً إلى حين مراجعته.';
  hidden++;
}
for (const { file, root } of catalogs) fs.writeFileSync(file, JSON.stringify(root, null, 2) + '\n', 'utf8');
console.log(`أسماء غير مؤكدة أُخفيت من القائمة وسُجلت للمراجعة: ${hidden}`);
