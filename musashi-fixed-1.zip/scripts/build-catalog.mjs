// Backwards-compatible entry point. The previous scanner matched arbitrary
// object fields such as item names as commands. Use the config-aware builder.
await import('./complete-catalog.mjs');
