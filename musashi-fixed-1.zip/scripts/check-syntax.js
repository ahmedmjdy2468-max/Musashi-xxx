/**
 * 🔱 MUSASHI BOT — فاحص صحة الكود
 * يمرّ على كل ملفات المشروع (JS) ويتحقق من سلامة الصياغة قبل التشغيل،
 * حتى لا يؤدي ملف واحد معطوب إلى إسقاط البوت كله.
 *
 * الاستخدام:
 *   npm run check
 *   npm run check -- --quiet
 */
import { readdir, stat } from "node:fs/promises";
import { join, extname, relative } from "node:path";
import { spawnSync } from "node:child_process";

const ROOT = process.cwd();
const SKIP_DIRS = new Set([
  "node_modules", ".git", "session", "sub", "tmp", "temp", ".cache", "dist",
]);
const CHECK_EXT = new Set([".js", ".mjs", ".cjs"]);

const quiet = process.argv.includes("--quiet");

async function* walk(dir) {
  let entries;
  try {
    entries = await readdir(dir, { withFileTypes: true });
  } catch {
    return;
  }
  for (const entry of entries) {
    if (entry.name.startsWith(".") && entry.name !== ".env") continue;
    const full = join(dir, entry.name);
    if (entry.isDirectory()) {
      if (SKIP_DIRS.has(entry.name)) continue;
      yield* walk(full);
    } else if (entry.isFile() && CHECK_EXT.has(extname(entry.name).toLowerCase())) {
      yield full;
    }
  }
}

async function main() {
  const started = Date.now();
  let ok = 0;
  const failed = [];

  for await (const file of walk(ROOT)) {
    // الملفات الضخمة المولّدة (bundle) تُفحص مرة واحدة فقط عند الحاجة
    const info = await stat(file).catch(() => null);
    if (!info) continue;
    if (info.size > 900_000 && file.includes("meowsab")) continue;

    const res = spawnSync(process.execPath, ["--check", file], { encoding: "utf8" });
    if (res.status === 0) {
      ok += 1;
    } else {
      failed.push({ file: relative(ROOT, file), error: (res.stderr || "").split("\n").slice(0, 3).join(" ") });
    }
  }

  const seconds = ((Date.now() - started) / 1000).toFixed(1);

  if (failed.length) {
    console.log(`\n❌ فشل ${failed.length} ملف — صحيح: ${ok} — المدة: ${seconds}s\n`);
    for (const f of failed) {
      console.log(`• ${f.file}`);
      if (!quiet) console.log(`   ${f.error.trim()}`);
    }
    process.exitCode = 1;
    return;
  }

  console.log(`\n✅ كل الملفات سليمة (${ok} ملف) — المدة: ${seconds}s\n`);
}

main().catch((err) => {
  console.error("فشل الفاحص:", err?.message || err);
  process.exitCode = 1;
});
