import { readdir, readFile } from 'node:fs/promises';
import { readFileSync } from 'node:fs';
import { extname, join, relative, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';
import { normalizeArabic } from '../system/normalizeArabic.js';
import { loadCatalog, isCatalogEntryVisible } from '../system/catalog.js';
import { isUnderDevCommand } from '../system/underDev.js';
import { registerLegacyPlugins } from '../system/legacy/loader.js';

const ROOT = process.cwd();
const require = createRequire(import.meta.url);
const SKIP = new Set(['node_modules', '.git', 'session', 'tmp', 'temp', 'dist']);

async function* walk(dir) {
  let entries = [];
  try { entries = await readdir(dir, { withFileTypes: true }); } catch { return; }
  for (const entry of entries) {
    if (SKIP.has(entry.name)) continue;
    const file = join(dir, entry.name);
    if (entry.isDirectory()) yield* walk(file);
    else if (entry.isFile() && extname(entry.name).toLowerCase() === '.js') yield file;
  }
}

function names(mod) {
  const m = mod?.default ?? mod;
  const values = [m?.command, m?.config?.command, m?.config?.name, m?.config?.alias, m?.alias];
  return [...new Set(values.flatMap(value => Array.isArray(value) ? value : [value])
    .filter(value => typeof value === 'string').map(value => value.trim()).filter(Boolean))];
}

function rel(file) { return relative(ROOT, file).replaceAll('\\', '/'); }
function norm(value) { return normalizeArabic(String(value || '').trim()); }

const declared = [];
const loadErrors = [];
const registry = {
  commands: [],
  registerCommand(command) { this.commands.push(command); },
  getAllCommands() { return this.commands; },
  getCommand(command) {
    const target = norm(command);
    return this.commands.find(item => [].concat(item.command || []).some(name => norm(name) === target)) || null;
  },
};

// Load native handlers first, matching production registration order.
for await (const file of walk(join(ROOT, 'plugins'))) {
  try {
    const mod = await import(pathToFileURL(resolve(file)).href);
    const commandNames = names(mod);
    if (!commandNames.length) continue;
    const item = { command: commandNames, filePath: resolve(file), category: (mod.default ?? mod).category || 'native' };
    declared.push({ file: rel(file), names: commandNames, kind: 'native' });
    registry.registerCommand(item);
  } catch (error) { loadErrors.push({ file: rel(file), error: error?.message || String(error) }); }
}

// registerLegacyPlugins applies the same conflict filtering and wrappers used by the bot.
const legacyStats = await registerLegacyPlugins(registry, {
  dir: './plugins_legacy',
  logger: { log() {}, warn() {}, error() {} },
});

for await (const file of walk(join(ROOT, 'plugins_legacy'))) {
  try {
    delete require.cache[require.resolve(file)];
    const mod = require(file);
    const commandNames = names(mod);
    if (commandNames.length) declared.push({ file: rel(file), names: commandNames, kind: 'legacy' });
  } catch (error) { loadErrors.push({ file: rel(file), error: error?.message || String(error) }); }
}

const active = new Map();
for (const handler of registry.commands) {
  const file = handler.filePath ? rel(handler.filePath) : '(مسار غير معروف)';
  for (const command of [].concat(handler.command || [])) {
    const key = norm(command);
    if (!key) continue;
    const owners = active.get(key) || [];
    owners.push(file);
    active.set(key, owners);
  }
}
const activeCollisions = [...active].filter(([, owners]) => new Set(owners).size > 1);

const declaredOwners = new Map();
for (const handler of declared) for (const command of handler.names) {
  const key = norm(command);
  const owners = declaredOwners.get(key) || [];
  owners.push(handler.file);
  declaredOwners.set(key, owners);
}
const declaredCollisions = [...declaredOwners].filter(([, owners]) => new Set(owners).size > 1);

const rules = JSON.parse(await readFile(join(ROOT, 'scripts/name-rules.json'), 'utf8'));
const brands = JSON.parse(await readFile(join(ROOT, 'scripts/brand-names.json'), 'utf8'));
const known = new Set([...rules.knownWords, ...Object.values(brands), ...(rules.approvedProperNames || [])].map(norm));
const baseCatalog = JSON.parse(await readFile(join(ROOT, 'system/commandCatalog.json'), 'utf8')).commands || {};
const aiCatalog = JSON.parse(await readFile(join(ROOT, 'system/commandCatalog.ai.json'), 'utf8')).commands || {};
const rows = Object.entries(baseCatalog).map(([key, entry]) => {
  const ai = aiCatalog[key] || {};
  return {
    ...entry,
    ar: (entry.nameNeedsReview || ai.nameNeedsReview) ? '' : (entry.ar || ai.ar || ''),
    desc: entry.desc || ai.desc || '',
    sourceFile: entry.sourceFile || ai.sourceFile || '',
    usageArgs: entry.usageArgs ?? ai.usageArgs ?? '',
    exampleArgs: entry.exampleArgs ?? ai.exampleArgs ?? '',
    aliasOf: entry.aliasOf || ai.aliasOf || '',
    hiddenForAudience: Boolean(entry.hiddenForAudience || ai.hiddenForAudience),
    nameNeedsReview: Boolean(entry.nameNeedsReview || ai.nameNeedsReview),
    reviewName: entry.reviewName || ai.reviewName || '',
    key,
  };
});
const runtimeCatalog = loadCatalog();
const isActuallyVisible = entry => isCatalogEntryVisible(entry) && !isUnderDevCommand(entry?.original || entry?.ar || '');
const unknownNames = [];
for (const entry of rows) {
  if (!entry.ar || entry.aliasOf) continue;
  const badWords = String(entry.ar).split(/[_\s-]+/u).filter(Boolean)
    .filter(word => !/^[0-9٠-٩]+$/u.test(word) && /[\u0600-\u06ff]/u.test(word) && !known.has(norm(word)));
  if (badWords.length) unknownNames.push({ key: entry.key, ar: entry.ar, badWords });
}
const unknownVisible = unknownNames.filter(entry => isActuallyVisible(runtimeCatalog[entry.key]));
const hiddenUnreviewedNames = rows.filter(entry => !entry.aliasOf && entry.nameNeedsReview && entry.reviewName);

const repeatedParts = [];
for (const entry of rows) {
  const parts = String(entry.ar || '').split(/[_\s-]+/u).map(norm).filter(Boolean);
  if (new Set(parts).size !== parts.length) repeatedParts.push({ key: entry.key, ar: entry.ar });
}

const nameMismatch = [];
for (const entry of rows) {
  if (entry.usage || entry.example) nameMismatch.push({ key: entry.key, field: 'stored usage/example', value: entry.usage || entry.example });
  for (const field of ['usageArgs', 'exampleArgs']) {
    if (entry[field] && /^\./u.test(String(entry[field]).trim())) nameMismatch.push({ key: entry.key, field, value: entry[field] });
  }
  const finalName = String(runtimeCatalog[entry.key]?.ar || '').trim();
  if (finalName) {
    const actualFirst = `.${finalName}`;
    const generatedUsage = runtimeCatalog[entry.key]?.usage || '';
    const generatedExample = runtimeCatalog[entry.key]?.example || '';
    if (generatedUsage && generatedUsage.split(/\s+/u)[0] !== actualFirst) nameMismatch.push({ key: entry.key, field: 'usage', value: generatedUsage });
    if (generatedExample && generatedExample.split(/\s+/u)[0] !== actualFirst) nameMismatch.push({ key: entry.key, field: 'example', value: generatedExample });
  }
}

const sourceMap = new Map(declared.map(handler => [handler.file.toLowerCase(), handler]));
const missingSources = rows.filter(entry => {
  const source = String(entry.sourceFile || '').replaceAll('\\', '/').toLowerCase();
  const handler = sourceMap.get(source);
  if (!handler) return true;
  const expected = new Set(handler.names.map(norm));
  return !expected.has(norm(entry.original || entry.key)) && !expected.has(norm(entry.key));
});
const visibleWithoutDispatch = rows.filter(entry => {
  if (!isActuallyVisible(runtimeCatalog[entry.key])) return false;
  const calledName = norm(entry.original || entry.key);
  return !(active.get(calledName) || []).length;
});
const visibleWithoutSource = rows.filter(entry => isActuallyVisible(runtimeCatalog[entry.key]) && missingSources.includes(entry));
const loadErrorsByFile = new Map(loadErrors.map(error => [error.file.toLowerCase(), error]));
const visibleUnloadable = rows.filter(entry => isActuallyVisible(runtimeCatalog[entry.key]) && loadErrorsByFile.has(String(entry.sourceFile || '').replaceAll('\\', '/').toLowerCase()));

const templateRE = /يعرض محتوى ترفيهياً من نوع|يعرض محتوى ترفيهيا من نوع|ينفّذ .* ضمن أوامر المتنوعة|ينفذ .* ضمن أوامر المتنوعة|يستخدم الذكاء الاصطناعي لتنفيذ ذكاء اصطناعي/u;
const badDescRE = /يدير ريستارتفبس|إجراء طلب هتتب|تحقق من حالة الشر|يستخدم .* لتنفيذ .*|ينفّذ وظيفة|يوفر وظيفة|أمر ضمن قسم/u;
const allowedLatin = new Set(['QR','PDF','OCR','GIF','MP3','MP4','URL','HD','H.264','VPS','API','AI','RPG','HTTP','ID','GPS','IP','HTML','JPG','JPEG','PNG','WebP','TikTok','YouTube','Instagram','Facebook','WhatsApp','Spotify','MediaFire','Discord','GitHub','Google','OpenAI','FFmpeg','GET','POST','DramaBox','DaFont','npm','Carbon','DNS','Minecraft','UUID','Sticker.ly','NGL']);
const hasBadLatin = text => [...String(text || '').matchAll(/[A-Za-z][A-Za-z0-9+/-]*(?:\.[A-Za-z0-9+/-]+)*/gu)].some(([word]) => !allowedLatin.has(word));
const badDescriptions = rows.filter(entry => !String(entry.desc || '').trim() || templateRE.test(entry.desc) || badDescRE.test(entry.desc) || hasBadLatin(entry.desc));
const badDescVisible = badDescriptions.filter(entry => isActuallyVisible(runtimeCatalog[entry.key]));
const phantom = rows.filter(entry => /مثال للاستخدام|https?:\/\/example\.com|\(بالرد على الوسائط\)|\(بالرد على الصورة\)/iu.test(`${entry.exampleArgs || ''} ${entry.example || ''}`));
const mediaUsageInvalid = rows.filter(entry => /بالرد على (?:صورة|فيديو|وسائط)/u.test(String(entry.usageArgs || '')) && !/m\.quoted|quoted\.|m\.download|downloadMedia|download\s*\(/u.test((() => { try { return readFileSync(String(entry.sourceFile || '').replaceAll('\\', '/'), 'utf8'); } catch { return ''; } })()));

const descriptions = new Map();
for (const entry of rows) {
  if (entry.aliasOf) continue;
  const description = String(entry.desc || '').trim();
  if (!description) continue;
  const group = descriptions.get(description) || [];
  group.push(entry);
  descriptions.set(description, group);
}
const sharedDescriptions = [...descriptions].filter(([, entries]) => entries.length > 3);
const crossHandlerShared = sharedDescriptions.filter(([, entries]) => new Set(entries.map(entry => String(entry.sourceFile || '').replaceAll('\\', '/').toLowerCase()).filter(Boolean)).size > 1);
const sharedVisible = sharedDescriptions.filter(([, entries]) => entries.some(entry => isActuallyVisible(runtimeCatalog[entry.key])));

const errors = [];
if (activeCollisions.length) errors.push(`تعارضات dispatch الفعلية: ${activeCollisions.length}`);
if (unknownVisible.length) errors.push(`أسماء عربية غير مفهومة ظاهرة: ${unknownVisible.length}`);
if (repeatedParts.length) errors.push(`أسماء بأجزاء مكررة: ${repeatedParts.length}`);
if (nameMismatch.length) errors.push(`usage/example لا يطابق الاسم النهائي: ${nameMismatch.length}`);
if (badDescVisible.length) errors.push(`أوصاف عامة أو لاتينية ظاهرة: ${badDescVisible.length}`);
if (mediaUsageInvalid.length) errors.push(`وسيط رد/صورة غير مثبت بالكود: ${mediaUsageInvalid.length}`);
if (phantom.length) errors.push(`أمثلة أو وسائط وهمية: ${phantom.length}`);
if (visibleWithoutDispatch.length) errors.push(`أوامر ظاهرة بلا معالج قابل للاستدعاء: ${visibleWithoutDispatch.length}`);
if (visibleWithoutSource.length) errors.push(`أوامر ظاهرة بلا ملف معالج قابل للتحقق: ${visibleWithoutSource.length}`);
if (visibleUnloadable.length) errors.push(`أوامر ظاهرة من ملفات تعذّر تحميلها: ${visibleUnloadable.length}`);
if (crossHandlerShared.some(([, entries]) => entries.some(entry => isActuallyVisible(runtimeCatalog[entry.key])))) errors.push('وصف واحد ظاهر لأوامر من معالجات مختلفة');

console.log(`المعالجات الأصلية المحمّلة: ${declared.filter(handler => handler.kind === 'native').length}`);
console.log(`المعالجات legacy المسجّلة فعلياً: ${legacyStats.loaded}`);
console.log(`أسماء مكررة في تعريفات المصدر وحُسمت عند التسجيل: ${declaredCollisions.length}`);
console.log(`أسماء متعارضة في dispatch الفعلي: ${activeCollisions.length}`);
console.log(`أسماء تجاوزها loader: ${legacyStats.conflicts || 0}`);
console.log(`أسماء بأجزاء مكررة: ${repeatedParts.length}`);
console.log(`أسماء عربية غير مفهومة في الكتالوج: ${unknownNames.length}`);
console.log(`أسماء عربية غير مفهومة ظاهرة: ${unknownVisible.length}`);
console.log(`أسماء غير مفهومة مخفية للمراجعة: ${unknownNames.length - unknownVisible.length}`);
console.log(`أسماء غير مؤكدة مخفية للاسم: ${hiddenUnreviewedNames.length}`);
console.log(`مرادفات legacy المخفية المرتبطة باسمها الأساسي: ${rows.filter(entry => entry.aliasOf).length}`);
console.log(`عدم اتساق usage/example: ${nameMismatch.length}`);
console.log(`أوصاف عامة أو لاتينية إجمالاً: ${badDescriptions.length}`);
console.log(`أوصاف عامة أو لاتينية ظاهرة: ${badDescVisible.length}`);
console.log(`أمثلة أو وسائط وهمية: ${phantom.length}`);
console.log(`وسائط رد/صورة غير مثبتة بالكود: ${mediaUsageInvalid.length}`);
console.log(`مجموعات أوصاف مشتركة (>3): ${sharedDescriptions.length}؛ عبر معالجات مختلفة: ${crossHandlerShared.length}؛ ظاهرة: ${sharedVisible.length}`);
console.log(`أوامر كتالوج بلا معالج مطابق: ${missingSources.length}`);
console.log(`أوامر ظاهرة بلا معالج قابل للاستدعاء: ${visibleWithoutDispatch.length}`);
console.log(`أوامر ظاهرة بلا ملف مصدر قابل للتحقق: ${visibleWithoutSource.length}`);
console.log(`ملفات تعذّر تحميلها بلا أوامر ظاهرة: ${loadErrors.length - visibleUnloadable.length}`);

for (const [description, entries] of sharedDescriptions) {
  const files = [...new Set(entries.map(entry => entry.sourceFile || '(بلا ملف)'))];
  console.log(`وصف مشترك (${entries.length}; ${files.join(', ')}): ${description} ← ${entries.map(entry => entry.key).join(', ')}`);
}
for (const [name, owners] of declaredCollisions) console.log(`اسم متكرر في المصدر: ${name} ← ${[...new Set(owners)].join(' | ')}`);
for (const collision of activeCollisions) console.log(`تعارض dispatch: ${collision[0]} ← ${[...new Set(collision[1])].join(' | ')}`);
for (const entry of unknownNames.slice(0, 50)) console.log(`اسم يحتاج مراجعة: ${entry.key} → ${entry.ar} [${entry.badWords.join(', ')}]`);
for (const entry of badDescriptions.slice(0, 50)) console.log(`وصف يحتاج مراجعة: ${entry.key} → ${entry.desc || '(فارغ)'}`);
for (const entry of missingSources.slice(0, 50)) console.log(`مصدر كتالوج غير مطابق: ${entry.key} → ${entry.sourceFile || '(بلا ملف)'}`);
for (const entry of visibleWithoutDispatch.slice(0, 50)) console.log(`لا يوجد dispatch ظاهر: ${entry.key} → ${entry.sourceFile || '(بلا ملف)'}`);
for (const error of loadErrors) console.log(`تعذر تحميل ملف معزول: ${error.file} ← ${error.error}`);

if (errors.length) {
  for (const error of errors) console.log(`❌ ${error}`);
  process.exit(1);
}
console.log('✅ فحص الكتالوج وdispatch الفعلي ناجح.');
process.exit(0);
