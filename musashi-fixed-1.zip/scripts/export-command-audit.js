import fs from 'node:fs';
import path from 'node:path';
import { loadCatalog, isCatalogEntryVisible } from '../system/catalog.js';
import { isUnderDevCommand } from '../system/underDev.js';

const ROOT = process.cwd();
const OUT = path.join(ROOT, 'docs', 'COMMANDS-AUDIT.md');
const catalog = loadCatalog();
const visibility = JSON.parse(fs.readFileSync(path.join(ROOT, 'system/legacy-command-visibility.json'), 'utf8'));
const unavailable = JSON.parse(fs.readFileSync(path.join(ROOT, 'system/unavailable-services.json'), 'utf8'));
const untranslated = new Set((visibility.sources || []).map((x) => String(x).replaceAll('\\', '/').toLowerCase()));
const unavailableFiles = new Set((unavailable.disabledLegacySources || []).map((x) => String(x).replaceAll('\\', '/').toLowerCase()));
const entries = Object.entries(catalog);
const aliases = new Map();
for (const [key, entry] of entries) {
  if (!entry.aliasOf) continue;
  const list = aliases.get(entry.aliasOf) || [];
  list.push(key);
  aliases.set(entry.aliasOf, list);
}

function hiddenReason(key, entry) {
  const file = String(entry.sourceFile || '').replaceAll('\\', '/').toLowerCase();
  if (unavailableFiles.has(file)) return 'الخدمة الخارجية غير مفعّلة؛ المعالج يرد برسالة آمنة';
  if (untranslated.has(file)) return 'ردود المعالج تحتاج تعريباً ومراجعة';
  if (isUnderDevCommand(key)) return 'قيد التطوير';
  if (entry.nameNeedsReview || !entry.ar) return 'الاسم العربي يحتاج حسمًا';
  if (entry.hiddenForAudience) return 'مخفي بإعداد الكتالوج';
  if (!entry.sourceFile) return 'لا يوجد ملف معالج مرتبط';
  const source = path.resolve(ROOT, entry.sourceFile);
  if (!fs.existsSync(source)) return 'ملف المعالج غير موجود';
  if (fs.statSync(source).size === 0) return 'ملف المعالج فارغ';
  if (!entry.desc) return 'الوصف غير موجود';
  if (!isCatalogEntryVisible(entry)) return 'مخفي ببوابة الكتالوج';
  return '';
}

const groups = new Map();
let visible = 0;
let hidden = 0;
for (const [key, entry] of entries) {
  if (entry.aliasOf) continue;
  const reason = hiddenReason(key, entry);
  const shown = !reason;
  shown ? visible++ : hidden++;
  const category = entry.category || 'other';
  const rows = groups.get(category) || [];
  const label = entry.ar || entry.reviewName || entry.original || key;
  const aliasList = aliases.get(key) || [];
  rows.push(`| ${escapeCell(label)} | ${escapeCell(entry.desc || '—')} | ${escapeCell([key, ...aliasList].join(', '))} | ${escapeCell(entry.sourceFile || '—')} | ${shown ? 'ظاهر' : `محجوب: ${escapeCell(reason)}`} |`);
  groups.set(category, rows);
}

function escapeCell(value) { return String(value).replaceAll('|', '\\|').replaceAll('\n', ' ').trim(); }
const lines = [
  '# تدقيق كتالوج الأوامر',
  '',
  `مولّد آلياً من الكتالوج والمعالجات المسجلة بتاريخ ${new Date().toISOString()}.`,
  '',
  `الأوامر الأساسية: ${visible + hidden}؛ الظاهرة: ${visible}؛ المحجوبة: ${hidden}. المرادفات مدرجة مع أمرها الأساسي ولا تُحسب أوامر مستقلة في القائمة.`,
  '',
  'حالة «ظاهر» تعني أن الكتالوج يعرض الأمر حالياً. حالة «محجوب» تشرح سبب عدم ظهوره ولا تثبت وحدها أن الخدمة الخارجية تعمل.',
  '',
];
for (const [category, rows] of [...groups].sort(([a], [b]) => a.localeCompare(b, 'ar'))) {
  lines.push(`## ${category}`, '', '| الاسم العربي | الوصف المسجل | الاسم الأساسي والمرادفات | ملف المعالج | الظهور |', '|---|---|---|---|---|', ...rows, '');
}
fs.writeFileSync(OUT, `${lines.join('\n')}\n`, 'utf8');
console.log(`الأوامر الأساسية: ${visible + hidden}؛ الظاهرة: ${visible}؛ المحجوبة: ${hidden}`);
console.log(`أُنشئ ${path.relative(ROOT, OUT).replaceAll('\\', '/')}`);
