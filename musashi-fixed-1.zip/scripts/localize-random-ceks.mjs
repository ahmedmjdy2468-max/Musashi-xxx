import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { normalizeArabic } from '../system/normalizeArabic.js';

const require = createRequire(import.meta.url);
const parser = require('@babel/parser');
const dir = 'plugins_legacy/cek';
const catalog = JSON.parse(fs.readFileSync('system/commandCatalog.json', 'utf8')).commands || {};
const localized = [];
const leftForReview = [];

for (const name of fs.readdirSync(dir).filter(file => file.endsWith('.js') && !file.startsWith('_'))) {
  const file = path.join(dir, name).replaceAll('\\', '/');
  let source = fs.readFileSync(file, 'utf8');
  if (!source.includes('Math.random')) continue;
  if (name === 'cekjodoh.js') { leftForReview.push(file); continue; }
  const ast = parser.parse(source, { sourceType: 'unambiguous', errorRecovery: true });
  let handler = null;
  function visit(node) {
    if (!node || handler) return;
    if (Array.isArray(node)) { for (const child of node) visit(child); return; }
    if (node.type === 'FunctionDeclaration' && node.id?.name === 'handler') { handler = node; return; }
    for (const [key, value] of Object.entries(node)) {
      if (['loc', 'start', 'end', 'tokens', 'comments'].includes(key)) continue;
      if (value && typeof value === 'object') visit(value);
    }
  }
  visit(ast);
  if (!handler) { leftForReview.push(`${file} (handler form not recognized)`); continue; }
  const entry = Object.values(catalog).find(item => String(item.sourceFile || '').replaceAll('\\', '/').toLowerCase() === file.toLowerCase() && item.ar);
  const label = String(entry?.ar || '').replace(/^فحص_/u, '').replaceAll('_', ' ').trim();
  if (!label) { leftForReview.push(`${file} (Arabic label missing)`); continue; }
  const replacement = `async function handler(m) {\n    return sendLocalizedScore(m, ${JSON.stringify(label)});\n}`;
  source = source.slice(0, handler.start) + replacement + source.slice(handler.end);
  if (!source.includes("require('./_localizedScore')")) {
    source = `const { sendLocalizedScore } = require('./_localizedScore');\n${source}`;
  }
  fs.writeFileSync(file, source, 'utf8');
  localized.push({ file, label });
}

console.log(`ملفات فحص cek ذات النتيجة العشوائية المعرّبة: ${localized.length}`);
for (const item of localized) console.log(`عُرّب الرد: ${item.file} ← فحص ${item.label}`);
console.log(`ملفات بقيت للمراجعة: ${leftForReview.length}`);
for (const file of leftForReview) console.log(`تحتاج مراجعة: ${file}`);
