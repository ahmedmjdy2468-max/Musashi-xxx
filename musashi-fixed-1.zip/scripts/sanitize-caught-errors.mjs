import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const parser = require('@babel/parser');
const roots = ['plugins', 'plugins_legacy'];
const generic = JSON.stringify('حدث خطأ، حاول لاحقاً');
const changed = [];
const parseErrors = [];
let catchesUpdated = 0;
let outputsSanitized = 0;

function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (['node_modules', '.git', 'session', 'tmp', 'temp'].includes(entry.name)) continue;
    const file = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(file);
    else if (entry.isFile() && file.endsWith('.js')) sanitize(file);
  }
}

function identifiers(node, result = new Set()) {
  if (!node) return result;
  if (Array.isArray(node)) { for (const child of node) identifiers(child, result); return result; }
  if (node.type === 'Identifier') result.add(node.name);
  for (const [key, value] of Object.entries(node)) {
    if (['loc', 'start', 'end', 'tokens', 'comments'].includes(key)) continue;
    if (value && typeof value === 'object') identifiers(value, result);
  }
  return result;
}

function hasErrorBinding(node, names) {
  const ids = identifiers(node);
  return [...names].some(name => ids.has(name));
}

function propertyName(node) {
  if (node?.type !== 'MemberExpression') return '';
  return node.computed ? node.property?.value : node.property?.name;
}

function isUserOutput(node) {
  if (node?.type !== 'CallExpression') return false;
  if (node.callee?.type === 'Identifier' && ['reply', 'sendText'].includes(node.callee.name)) return true;
  return ['reply', 'sendMessage', 'sendButton', 'sendText', 'send'].includes(propertyName(node.callee));
}

function sanitize(file) {
  const source = fs.readFileSync(file, 'utf8');
  let ast;
  try {
    ast = parser.parse(source, { sourceType: 'unambiguous', errorRecovery: true, plugins: ['jsx', 'decorators-legacy', 'classProperties', 'dynamicImport', 'topLevelAwait'] });
  } catch (error) {
    parseErrors.push({ file: path.relative(process.cwd(), file).replaceAll('\\', '/'), error: error.message });
    return;
  }
  const edits = [];
  const rel = path.relative(process.cwd(), file).replaceAll('\\', '/');
  function visit(node) {
    if (!node) return;
    if (Array.isArray(node)) { for (const child of node) visit(child); return; }
    if (node.type === 'CatchClause') {
      const param = node.param;
      const names = param?.type === 'Identifier' ? new Set([param.name]) : new Set();
      if (names.size) {
        const calls = [];
        function findCalls(child) {
          if (!child) return;
          if (Array.isArray(child)) { for (const item of child) findCalls(item); return; }
          if (isUserOutput(child) && hasErrorBinding(child.arguments, names)) calls.push(child);
          for (const [key, value] of Object.entries(child)) {
            if (['loc', 'start', 'end', 'tokens', 'comments'].includes(key)) continue;
            if (value && typeof value === 'object') findCalls(value);
          }
        }
        findCalls(node.body);
        if (calls.length) {
          for (const call of calls) {
            const first = call.arguments?.[0];
            if (!first) continue;
            // Preserve sent media while replacing only the user-visible error text.
            if (propertyName(call.callee) !== 'reply' && first.type === 'ObjectExpression') {
              for (const property of first.properties || []) {
                const key = property.key?.name || property.key?.value;
                if (['text', 'caption', 'conversation', 'bodyText'].includes(key) && hasErrorBinding(property.value, names)) {
                  edits.push({ start: property.value.start, end: property.value.end, text: generic });
                  outputsSanitized++;
                }
              }
            } else {
              edits.push({ start: first.start, end: first.end, text: generic });
              outputsSanitized++;
            }
          }
          const alreadyLogged = identifiers(node.body).has('console') && /console\.(?:error|warn|log)\s*\(/u.test(source.slice(node.body.start, node.body.end));
          if (!alreadyLogged && param.start !== undefined && node.body?.type === 'BlockStatement') {
            const logger = `\n        console.error(${JSON.stringify(`[MUSASHI][${rel}] exception`)}, ${param.name}?.stack || ${param.name});`;
            edits.push({ start: node.body.start + 1, end: node.body.start + 1, text: logger });
          }
          catchesUpdated++;
        }
      }
    }
    for (const [key, value] of Object.entries(node)) {
      if (['loc', 'start', 'end', 'tokens', 'comments'].includes(key)) continue;
      if (value && typeof value === 'object') visit(value);
    }
  }
  visit(ast);
  if (!edits.length) return;
  const unique = [...new Map(edits.map(edit => [`${edit.start}:${edit.end}`, edit])).values()].sort((a, b) => b.start - a.start);
  let output = source;
  for (const edit of unique) output = output.slice(0, edit.start) + edit.text + output.slice(edit.end);
  fs.writeFileSync(file, output, 'utf8');
  changed.push(rel);
}

for (const root of roots) walk(root);
console.log(`ملفات عدّلت معالجة استثناءاتها: ${changed.length}`);
console.log(`كتل catch سجلت التفاصيل وحُوّلت ردودها: ${catchesUpdated}`);
console.log(`مخارج مستخدم عُدّلت إلى رسالة عامة: ${outputsSanitized}`);
console.log(`أخطاء تحليل لم تُعدّل: ${parseErrors.length}`);
for (const file of changed) console.log(`تعديل: ${file}`);
for (const item of parseErrors) console.log(`تعذر تحليل ${item.file}: ${item.error}`);
