import { readdir, readFile, mkdir, writeFile } from 'node:fs/promises';
import { extname, join, relative } from 'node:path';
import { normalizeArabic } from '../system/normalizeArabic.js';

const ROOT = process.cwd();
const AFTER = process.argv.includes('--after');
const REPORT_JSON = AFTER ? 'docs/AUDIT-AFTER.json' : 'docs/AUDIT-BEFORE.json';
const REPORT_MD = AFTER ? 'docs/AUDIT-AFTER.md' : 'docs/AUDIT-BEFORE.md';
const CATALOGS = ['system/commandCatalog.json', 'system/commandCatalog.ai.json'];
const LATIN_ALLOW = new Set(['QR', 'PDF', 'OCR', 'GIF', 'MP3', 'URL', 'HD']);
const INDONESIAN = /\b(?:dengan|untuk|kamu|atau|reply media|teks|atur|cek|set|gunakan|contoh|masukkan|silakan|berhasil|gagal|tidak ditemukan|fitur|perintah|gambar|suara|unduh|tautan|pesan|cari|pilih|masukkan|berikan|masukkan|masukan|masih|sudah|belum|silahkan|ketik|terima kasih|maaf|hapus|ambil|buatkan|menambahkan|menghapus|mengubah|menampilkan|memeriksa|memulai|menghentikan|berhasil|gagal)\b/i;
const LATIN = /\b[A-Za-z][A-Za-z0-9_-]*\b/g;
const ARABIC = /[\u0600-\u06FF]/;

async function* walk(dir) {
  let entries;
  try { entries = await readdir(dir, { withFileTypes: true }); } catch { return; }
  for (const entry of entries) {
    if (['node_modules', '.git', 'session', 'tmp', 'temp', 'dist'].includes(entry.name)) continue;
    const full = join(dir, entry.name);
    if (entry.isDirectory()) yield* walk(full);
    else if (entry.isFile()) yield full;
  }
}

function literalArrayAt(source, start) {
  let i = start;
  while (/\s/.test(source[i] || '')) i++;
  if (source[i] !== '[') return null;
  const open = i++;
  let depth = 1, quote = '', escape = false, line = false, block = false;
  for (; i < source.length; i++) {
    const c = source[i], n = source[i + 1];
    if (line) { if (c === '\n') line = false; continue; }
    if (block) { if (c === '*' && n === '/') { block = false; i++; } continue; }
    if (quote) { if (escape) { escape = false; continue; } if (c === '\\') { escape = true; continue; } if (c === quote) quote = ''; continue; }
    if (c === '/' && n === '/') { line = true; i++; continue; }
    if (c === '/' && n === '*') { block = true; i++; continue; }
    if (c === '"' || c === "'" || c === '`') { quote = c; continue; }
    if (c === '[') depth++;
    if (c === ']' && --depth === 0) return source.slice(open, i + 1);
  }
  return null;
}

function commandNames(source) {
  const names = [];
  const code = source.replace(/\/\*[\s\S]*?\*\//g, ' ').replace(/^[\t ]*\/\/.*$/gm, ' ');
  const patterns = [
    /\b(?:handler|plugin|cmd|command)\.command\s*=/g,
    /\bcommand\s*:/g,
  ];
  for (const pattern of patterns) {
    let match;
    while ((match = pattern.exec(code))) {
      const array = literalArrayAt(code, pattern.lastIndex);
      if (!array) continue;
      for (const m of array.matchAll(/(['"])([^'"\r\n]+)\1/g)) {
        const name = m[2].trim();
        if (name && name.length < 80) names.push(name);
      }
      pattern.lastIndex += array.length;
    }
  }
  return [...new Set(names)];
}

function wordCount(name) { return String(name || '').split('_').filter(Boolean).length; }
function latinOutsideAllowlist(value) {
  const hits = [...String(value || '').matchAll(LATIN)].map(m => m[0]);
  return hits.filter(token => !LATIN_ALLOW.has(token.toUpperCase()));
}

const files = [];
for (const root of ['plugins', 'plugins_legacy']) {
  for await (const file of walk(join(ROOT, root))) {
    if (extname(file).toLowerCase() !== '.js') continue;
    const source = await readFile(file, 'utf8').catch(() => '');
    files.push({ path: relative(ROOT, file).replaceAll('\\', '/'), source, commands: commandNames(source) });
  }
}

const registered = new Map();
for (const file of files) {
  for (const command of file.commands) {
    const key = normalizeArabic(command);
    const paths = registered.get(key) || [];
    if (!paths.includes(file.path)) paths.push(file.path);
    registered.set(key, paths);
  }
}
const duplicates = [...registered].filter(([, paths]) => paths.length > 1)
  .map(([name, paths]) => ({ name, files: paths }));

const catalogEntries = new Map();
for (const path of CATALOGS) {
  const data = JSON.parse(await readFile(join(ROOT, path), 'utf8'));
  for (const [key, entry] of Object.entries(data.commands || {})) {
    const old = catalogEntries.get(key) || { ...entry };
    catalogEntries.set(key, {
      ...old,
      ...Object.fromEntries(Object.entries(entry).filter(([, value]) => value !== '' && value != null)),
    });
  }
}

const commands = [...catalogEntries].map(([key, entry]) => ({ key, ...entry }));
const badNames = commands.filter(c => /_\d+$/.test(c.ar || ''));
const longNames = commands.filter(c => wordCount(c.ar) > 3);
const descriptiveNames = commands.filter(c => /^(?:يعالج|يستخدم|يعرض|عرض|إنشاء|تحقق|جار|جاري)_/.test(c.ar || ''));
const latinDescUsage = commands.filter(c => latinOutsideAllowlist(`${c.desc || ''} ${c.usage || ''}`).length);
const indonesianDescUsage = commands.filter(c => INDONESIAN.test(`${c.desc || ''} ${c.usage || ''}`));
const genericDescriptions = commands.filter(c => /يحمّل أو يعالج|يعالج .* من الرابط|يعالج .* الوارد|ينفذ الأمر المطلوب|ينفذ هذا الأمر/.test(c.desc || ''));
const bareUsage = commands.filter(c => {
  const usage = String(c.usage || '').trim().replace(/^\./, '').toLowerCase();
  return usage && (usage === c.key.toLowerCase() || usage === String(c.ar || '').toLowerCase());
});
const byCommand = new Map(files.flatMap(file => file.commands.map(name => [name.toLowerCase(), file])));
const bareUsageReadsInput = bareUsage.filter(c => {
  const file = byCommand.get(c.key.toLowerCase());
  return file && /\b(?:args|text|quoted|caption|media|m\.quoted|m\.text)\b/.test(file.source);
});

const legacyFiles = files.filter(f => f.path.startsWith('plugins_legacy/'));
const indonesianReplies = legacyFiles.filter(f => INDONESIAN.test(f.source));
const dataFiles = [];
for await (const file of walk(join(ROOT, 'src/data'))) {
  if (extname(file).toLowerCase() !== '.json') continue;
  const source = await readFile(file, 'utf8').catch(() => '');
  if (INDONESIAN.test(source) || !ARABIC.test(source)) {
    dataFiles.push({ file: relative(ROOT, file).replaceAll('\\', '/'), hasArabic: ARABIC.test(source), hasIndonesian: INDONESIAN.test(source) });
  }
}

const underDevData = JSON.parse(await readFile(join(ROOT, 'src/data/underdev.json'), 'utf8'));

const featureReferences = new Map();
for (const file of files) {
  if (!/plugins\/auto\/|plugins\/admins\/(?:settings|group_panel|features_panel|protection)|system\/(?:control|welcome|reception)\.js/.test(file.path)) continue;
  const keys = [...file.source.matchAll(/\b(?:g|groupSettings|settings|group|config)\??\.([A-Za-z_$][\w$]*)/g)].map(m => m[1]);
  for (const key of keys) {
    const list = featureReferences.get(key) || new Set();
    list.add(file.path);
    featureReferences.set(key, list);
  }
}

const report = {
  scannedPluginFiles: files.length,
  commandNamesFound: registered.size,
  duplicateNameCount: duplicates.length,
  duplicates,
  catalog: {
    entries: commands.length,
    arabicNamesEndingNumber: badNames.length,
    namesOverThreeWords: longNames.length,
    descriptiveVerbNames: descriptiveNames.length,
    descOrUsageWithLatinOutsideAllowlist: latinDescUsage.length,
    descOrUsageWithIndonesian: indonesianDescUsage.length,
    genericDescriptions: genericDescriptions.length,
    usageOnlyCommandName: bareUsage.length,
    bareUsageWithInputReadInSource: bareUsageReadsInput.length,
    bareUsageInputCommands: bareUsageReadsInput.map(c => ({ key: c.key, ar: c.ar, file: byCommand.get(c.key.toLowerCase())?.path || null })),
    samples: {
      arabicNamesEndingNumber: badNames.slice(0, 30).map(c => [c.key, c.ar]),
      namesOverThreeWords: longNames.slice(0, 30).map(c => [c.key, c.ar]),
      latinDescOrUsage: latinDescUsage.slice(0, 30).map(c => c.key),
      indonesianDescOrUsage: indonesianDescUsage.slice(0, 30).map(c => c.key),
      bareUsage: bareUsage.slice(0, 30).map(c => c.key),
    },
  },
  legacyIndonesianReplyFiles: { count: indonesianReplies.length, total: legacyFiles.length, samples: indonesianReplies.slice(0, 40).map(f => f.path) },
  nonArabicGameData: dataFiles,
  underDevelopment: {
    pluginCount: Array.isArray(underDevData.plugins) ? underDevData.plugins.length : 0,
    commandAliasCount: Array.isArray(underDevData.commands) ? underDevData.commands.length : 0,
  },
  featureStorageReferences: Object.fromEntries([...featureReferences].map(([key, paths]) => [key, [...paths].sort()])),
  limitations: [
    'الأسماء المستخرجة من تعريفات command الثابتة في المصدر؛ الملفات لم تُستورد حتى لا تنفذ شيفرة الإضافات وآثارها الجانبية أثناء التدقيق.',
    'حساب الكلمات الإندونيسية مبني على قائمة مطابقة أولية، وقد يشمل أسماء المتغيرات أو التعليقات والنصوص غير الموجّهة للمستخدم.',
  ],
};

await mkdir(join(ROOT, 'docs'), { recursive: true });
await writeFile(join(ROOT, REPORT_JSON), JSON.stringify(report, null, 2), 'utf8');
const markdown = [
  `# تدقيق أوامر MUSASHI — ${AFTER ? 'بعد الإصلاح' : 'قبل الإصلاح'}`,
  '',
  `- ملفات الإضافات المفحوصة: ${report.scannedPluginFiles}`,
  `- أسماء الأوامر الثابتة: ${report.commandNamesFound}`,
  `- الأسماء المكررة بين الملفات: ${report.duplicateNameCount}`,
  `- مدخلات الكتالوج: ${report.catalog.entries}`,
  `- أسماء تنتهي بـ _رقم: ${report.catalog.arabicNamesEndingNumber}`,
  `- أسماء أكثر من ثلاث كلمات: ${report.catalog.namesOverThreeWords}`,
  `- أسماء تبدأ بأفعال وصفية: ${report.catalog.descriptiveVerbNames}`,
  `- أوصاف/استخدامات بها لاتينية خارج السماح: ${report.catalog.descOrUsageWithLatinOutsideAllowlist}`,
  `- أوصاف/استخدامات بها مؤشرات إندونيسية: ${report.catalog.descOrUsageWithIndonesian}`,
  `- قوالب شرح عامة: ${report.catalog.genericDescriptions}`,
  `- استخدام يساوي اسم الأمر فقط: ${report.catalog.usageOnlyCommandName}`,
  `- ملفات legacy ذات مؤشرات إندونيسية: ${report.legacyIndonesianReplyFiles.count}/${report.legacyIndonesianReplyFiles.total}`,
  `- ملفات بيانات ألعاب غير عربية/إندونيسية: ${report.nonArabicGameData.length}`,
  `- إضافات/ألعاب ضمن سجل قيد التعريب: ${report.underDevelopment.pluginCount}`,
  `- أسماء أوامر محجوبة حتى اكتمال التعريب: ${report.underDevelopment.commandAliasCount}`,
  '',
  '## ملاحظات على دقة التدقيق',
  '',
  ...report.limitations.map(note => `- ${note}`),
  '',
].join('\n');
await writeFile(join(ROOT, REPORT_MD), markdown, 'utf8');
console.log(`إضافات مفحوصة: ${report.scannedPluginFiles}`);
console.log(`أسماء أوامر ثابتة: ${report.commandNamesFound}`);
console.log(`أسماء مكررة بين الملفات: ${report.duplicateNameCount}`);
for (const duplicate of duplicates) console.log(`مكرر: ${duplicate.name} ← ${duplicate.files.join(' | ')}`);
console.log(`الكتالوج: ${commands.length} · أسماء تنتهي بـ _رقم: ${badNames.length} · أكثر من 3 كلمات: ${longNames.length} · أفعال وصفية: ${descriptiveNames.length}`);
console.log(`لاتينية في الوصف/الاستخدام: ${latinDescUsage.length} · إندونيسية في الوصف/الاستخدام: ${indonesianDescUsage.length} · قوالب عامة: ${genericDescriptions.length}`);
console.log(`الاستخدام اسم فقط: ${bareUsage.length} · منها يقرأ مدخلات حسب المصدر: ${bareUsageReadsInput.length}`);
console.log(`ملفات legacy ذات مؤشرات إندونيسية: ${indonesianReplies.length}/${legacyFiles.length}`);
console.log(`ملفات بيانات غير عربية/إندونيسية: ${dataFiles.length}`);
console.log('مراجع تخزين الميزات:', JSON.stringify(report.featureStorageReferences));
console.log(`تفاصيل التدقيق: ${REPORT_JSON}`);
