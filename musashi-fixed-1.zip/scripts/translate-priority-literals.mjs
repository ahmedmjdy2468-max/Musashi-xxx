import fs from 'node:fs';const repl={
 'plugins_legacy/sticker/smemevid.js':{'Terjadi kesalahan saat memproses video':'حدث خطأ أثناء معالجة الفيديو.'},
 'plugins_legacy/group/acc.js':{'Gagal':'فشل تنفيذ العملية.'},
 'plugins_legacy/group/cidukdelmsg.js':{'Nggak ada yang bisa sembunyi-sembunyi hapus pesan sekarang~ 👁️':'لا يمكن حذف الرسائل سراً الآن. 👁️','reply الصورة/video/stiker أو + url':'رد على صورة أو فيديو أو ملصق، أو أرسل رابطاً.'},
 'plugins_legacy/group/mute.js':{'Hanya مشرف الذي يمكن إرسال رسالة.':'يمكن للمشرفين فقط إرسال الرسائل.','تم تم كتمه بواسطة':'تم كتم المجموعة بواسطة'},
 'plugins_legacy/group/resetlinkgc.js':{'Link المجموعة lama تم لا صالح.\nGunakan':'انتهت صلاحية رابط المجموعة السابق.\nاستخدم'},
 'plugins_legacy/group/sider.js':{'Periode لم يبدأ!\nGunakan':'لم تبدأ الفترة بعد.\nاستخدم'},
 'plugins_legacy/tools/amprem.js':{'API gagal memproses':'تعذرت معالجة الطلب عبر API'},
 'plugins_legacy/tools/amverify.js':{'Verifikasi gagal':'تعذر التحقق'},
 'plugins_legacy/tools/bypass.js':{'Gagal bypass link':'تعذر تجاوز الرابط'},
 'plugins_legacy/tools/designextractor.js':{'API gagal memproses':'تعذرت معالجة الطلب عبر API'},
 'plugins_legacy/tools/imgtoprompt.js':{'Tidak dapat menghasilkan prompt dari gambar ini':'تعذر استخراج وصف من هذه الصورة'},
 'plugins_legacy/tools/iqcv2.js':{'Kirim صورة أو ردّ على الصورة terus شكراً caption نص نعم!':'أرسل صورة أو رد على صورة، ثم أرسل نص التعليق.','مثال: ${m.prefix}iqcv2 مرحباً عزيزي!':'مثال: ${m.prefix}iqcv2 مرحباً!'},
 'plugins_legacy/tools/ptv.js':{'> فيديو من ردّ على لا يمكن diambil 😢':'> تعذر تنزيل الفيديو الذي رددت عليه 😢','> فيديو أنت فشل diproses 😣':'> تعذرت معالجة الفيديو 😣','> أرسل أو ردّ على فيديو lalu اكتب:':'> أرسل فيديو أو رد عليه، ثم اكتب:','> Lagi أنا ubah jadi *circle video lucu* 💖':'> جارٍ تحويله إلى فيديو دائري 💖'},
 'plugins_legacy/tools/reactchch2.js':{'Terjadi kesalahan.':'حدث خطأ.'},
 'plugins_legacy/tools/reactchv3.js':{'Gagal mengirim reaksi':'تعذر إرسال التفاعل'},
 'plugins_legacy/tools/amprem.js':{'API gagal memproses':'تعذرت معالجة الطلب عبر API'}
};for(const [file,map]of Object.entries(repl)){let s=fs.readFileSync(file,'utf8');for(const [a,b]of Object.entries(map))s=s.replaceAll(a,b);fs.writeFileSync(file,s)}
