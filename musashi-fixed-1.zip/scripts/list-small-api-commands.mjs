import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { parse } from '@babel/parser';
import unavailableServices from '../system/unavailable-services.json' with { type: 'json' };

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const MAX_BYTES = 5 * 1024;
const catalog = JSON.parse(fs.readFileSync(path.join(ROOT, 'system/commandCatalog.json'), 'utf8')).commands;
const unavailable = new Set((unavailableServices.disabledLegacySources || []).map((p) => p.replaceAll('\\', '/').toLowerCase()));

function walk(dir) {
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) return walk(full);
    return entry.isFile() && entry.name.endsWith('.js') ? [full] : [];
  });
}
function property(object, name) {
  return object?.properties?.find((p) => p.type === 'ObjectProperty' && (p.key.name || p.key.value) === name)?.value;
}
function staticValue(node) {
  if (!node) return [];
  if (node.type === 'StringLiteral') return [node.value];
  if (node.type === 'ArrayExpression') return node.elements.flatMap(staticValue);
  return [];
}
function detectNetwork(ast) {
  let found = false;
  const visit = (node) => {
    if (!node || typeof node !== 'object' || found) return;
    if (node.type === 'CallExpression') {
      const callee = node.callee;
      const root = callee.type === 'MemberExpression' ? callee.object : callee;
      const name = root?.name || (root?.type === 'MemberExpression' ? root.property?.name : '');
      const method = callee.type === 'MemberExpression' ? callee.property?.name : '';
      if (name === 'fetch' || ['axios', 'got', 'request', 'https', 'http'].includes(name)
        || (['axios', 'got', 'request', 'https', 'http'].includes(name)
          && ['get', 'post', 'put', 'patch', 'delete', 'request'].includes(method))) found = true;
    }
    for (const [key, child] of Object.entries(node)) {
      if (['loc', 'start', 'end', 'leadingComments', 'trailingComments', 'innerComments'].includes(key)) continue;
      if (Array.isArray(child)) child.forEach(visit);
      else if (child && typeof child.type === 'string') visit(child);
    }
  };
  visit(ast);
  return found;
}

const results = [];
for (const file of walk(path.join(ROOT, 'plugins_legacy'))) {
  const stat = fs.statSync(file);
  if (stat.size >= MAX_BYTES) continue;
  const text = fs.readFileSync(file, 'utf8');
  let ast;
  try { ast = parse(text, { sourceType: 'unambiguous', errorRecovery: true, plugins: ['jsx', 'classProperties', 'dynamicImport', 'topLevelAwait'] }); }
  catch { continue; }
  if (!detectNetwork(ast)) continue;
  const cfgDecl = ast.program.body.find((n) => n.type === 'VariableDeclaration'
    && n.declarations.some((d) => ['pluginConfig', 'config'].includes(d.id?.name)));
  const declarator = cfgDecl?.declarations.find((d) => ['pluginConfig', 'config'].includes(d.id?.name));
  const cfg = declarator?.init?.type === 'ObjectExpression' ? declarator.init : null;
  if (!cfg) continue;
  const names = [...staticValue(property(cfg, 'name')), ...staticValue(property(cfg, 'command')), ...staticValue(property(cfg, 'alias'))];
  if (!names.length) continue;
  const rel = path.relative(ROOT, file).replaceAll('\\', '/');
  const catalogEntries = Object.values(catalog).filter((entry) => String(entry.sourceFile || '').replaceAll('\\', '/') === rel);
  const primary = catalogEntries[0];
  const blocked = unavailable.has(rel.toLowerCase());
  results.push({ file: rel, bytes: stat.size, command: primary?.ar || primary?.reviewName || primary?.original || names[0] || '(اسم غير مضبوط)', aliases: [...new Set(names)], status: blocked ? 'غير مختبر — معطل بسبب مفتاح placeholder' : 'غير مختبر شبكياً' });
}

results.sort((a, b) => a.file.localeCompare(b.file));
const lines = [
  '# أوامر legacy صغيرة تعتمد على الشبكة',
  '',
  `فُحصت ملفات JavaScript في plugins_legacy بحجم أقل من ${MAX_BYTES} بايت. اكتُشفت ${results.length} إضافة تستخدم استدعاء شبكة. لم تُجرَ طلبات فعلية إلى خدمات خارجية في هذا الفحص؛ لذلك الحالة «غير مختبر شبكياً» صريحة. الأوامر المحجوبة بمفاتيح وهمية موسومة بأنها معطلة.`,
  '',
  '| الأمر | الملف | الحجم (بايت) | الحالة |',
  '|---|---|---:|---|',
  ...results.map((item) => `| ${item.command} (${item.aliases.join(', ')}) | \`${item.file}\` | ${item.bytes} | ${item.status} |`),
  '',
];
const output = path.join(ROOT, 'docs/API-SMALL-COMMANDS.md');
fs.writeFileSync(output, lines.join('\n'), 'utf8');
console.log(`أنشئ ${path.relative(ROOT, output)}: ${results.length} أمراً صغيراً يستخدم الشبكة؛ لم يُختبر أي اتصال خارجي.`);
