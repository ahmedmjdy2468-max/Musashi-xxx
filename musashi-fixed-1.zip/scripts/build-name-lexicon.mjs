import fs from 'node:fs';
import path from 'node:path';
import readline from 'node:readline';

const rules = JSON.parse(fs.readFileSync('scripts/name-rules.json', 'utf8'));
const catalogs = ['system/commandCatalog.json', 'system/commandCatalog.ai.json'];
const needed = new Set();
for (const file of catalogs) {
  const data = JSON.parse(fs.readFileSync(file, 'utf8'));
  for (const entry of Object.values(data.commands || {})) {
    for (const word of String(entry.ar || '').split(/[_\s-]+/u)) if (word) needed.add(norm(word));
  }
}

function norm(value) {
  return String(value).normalize('NFKD')
    .replace(/[\u064B-\u065F\u0670\u06D6-\u06ED]/gu, '')
    .replace(/[أإآٱ]/gu, 'ا').replace(/ى/gu, 'ي').replace(/ة/gu, 'ه').toLowerCase();
}

const found = new Set(rules.knownWords.map(norm));
const sourcePath = process.env.ARABIC_WORD_LIST || path.resolve('scripts/data/DA_freq_lists.tsv');
if (!fs.existsSync(sourcePath)) {
  console.error('ضع قائمة CAMeL المحلية في scripts/data/DA_freq_lists.tsv أو حدّد ARABIC_WORD_LIST؛ لم تُرسل أي بيانات إلى الإنترنت.');
  process.exit(1);
}
const source = fs.createReadStream(sourcePath, { encoding: 'utf8' });
const lines = readline.createInterface({ input: source, crlfDelay: Infinity });
for await (const line of lines) {
  const [word, frequency] = line.split('\t');
  if (Number(frequency) >= 50 && needed.has(norm(word))) found.add(norm(word));
}
rules.knownWords = [...found].sort();
fs.writeFileSync('scripts/name-rules.json', JSON.stringify(rules, null, 2) + '\n');
console.log(`known words ${rules.knownWords.length}; source matches with frequency >= 50: ${found.size}`);
