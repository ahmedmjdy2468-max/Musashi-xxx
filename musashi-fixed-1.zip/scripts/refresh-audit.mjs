import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { normalizeArabic } from '../system/normalizeArabic.js';
import { inspectLegacyUserText } from '../system/legacyCommandVisibility.js';

const root = process.cwd();
const outputs = path.resolve(root, '..', '..', 'outputs');
fs.mkdirSync(outputs, { recursive: true });

function run(script) {
  const result = spawnSync(process.execPath, [script], { cwd: root, encoding: 'utf8', timeout: 120000, maxBuffer: 12 * 1024 * 1024 });
  if (result.error) throw result.error;
  return { code: result.status ?? 1, out: `${result.stdout || ''}${result.stderr || ''}` };
}

function saveOutput(filename, text, code) {
  const contents = `${text.trimEnd()}\nEXIT_CODE=${code}\n`;
  fs.writeFileSync(path.join(outputs, filename), contents);
  return contents;
}

const visibilityRun = run('scripts/build-command-visibility.mjs');
saveOutput('legacy-visibility-scan-output.txt', visibilityRun.out, visibilityRun.code);
if (visibilityRun.code !== 0) throw new Error('فشل مسح مخارج legacy.');

let runtimeRun;
for (let attempt = 0; attempt < 3; attempt++) {
  runtimeRun = run('scripts/audit-runtime-80.mjs');
  saveOutput('runtime-simulation-output.txt', runtimeRun.out, runtimeRun.code);
  if (/نصوص إندونيسية مرصودة في المخرج: 0/u.test(runtimeRun.out) && runtimeRun.code === 0) break;
  const rebuild = run('scripts/build-command-visibility.mjs');
  saveOutput('legacy-visibility-scan-output.txt', rebuild.out, rebuild.code);
  if (rebuild.code !== 0) throw new Error('فشل تحديث حظر مصادر legacy بعد المحاكاة.');
}
if (!runtimeRun || runtimeRun.code !== 0 || !/نصوص إندونيسية مرصودة في المخرج: 0/u.test(runtimeRun.out)) {
  throw new Error('لم تصل محاكاة العينة إلى صفر مخرجات إندونيسية.');
}

const checkRun = run('scripts/check-commands.js');
const checkOutput = saveOutput('check-commands-output.txt', checkRun.out, checkRun.code);
fs.writeFileSync('docs/CHECK-COMMANDS-OUTPUT.txt', checkOutput);
if (checkRun.code !== 0) throw new Error('فشل scripts/check-commands.js.');

const winnersRun = run('scripts/audit-resolved-command-winners.mjs');
const winnersOutput = saveOutput('command-winners-output.txt', winnersRun.out, winnersRun.code);
if (winnersRun.code !== 0) throw new Error('فشل فحص فائز command dispatch.');

const runtime = fs.readFileSync('docs/AUDIT-RUNTIME-80.md', 'utf8');
const visibility = JSON.parse(fs.readFileSync('system/legacy-command-visibility.json', 'utf8'));
const base = JSON.parse(fs.readFileSync('system/commandCatalog.json', 'utf8')).commands || {};
const ai = JSON.parse(fs.readFileSync('system/commandCatalog.ai.json', 'utf8')).commands || {};
const catalog = Object.entries(base).map(([key, entry]) => ({ ...(ai[key] || {}), ...entry, key,
  nameNeedsReview: Boolean(entry.nameNeedsReview || ai[key]?.nameNeedsReview),
  reviewName: entry.reviewName || ai[key]?.reviewName || '',
  aliasOf: entry.aliasOf || ai[key]?.aliasOf || '',
}));
const rules = JSON.parse(fs.readFileSync('scripts/name-rules.json', 'utf8'));
const brands = JSON.parse(fs.readFileSync('scripts/brand-names.json', 'utf8'));
const known = new Set([...rules.knownWords, ...Object.values(brands), ...(rules.approvedProperNames || [])].map(normalizeArabic));
const nameReview = catalog.filter(entry => !entry.aliasOf && entry.nameNeedsReview && entry.reviewName);
const badDescriptions = [...checkRun.out.matchAll(/^وصف يحتاج مراجعة: (.*)$/gmu)].map(match => match[1]);
const sharedDescriptions = [...checkRun.out.matchAll(/^وصف مشترك \((.*)$/gmu)].map(match => match[1]);
const sampleSummary = runtime.match(/مخرج التشغيل: (\d+) ردّ أو لا رد، (\d+) أخطاء، (\d+) يحتاج خدمة خارجية، (\d+) قيد التعريب، (\d+) بلا معالج/u);
const sampled = Number(runtime.match(/عينة عشوائية ثابتة: 80 أمراً، إضافة إلى أسماء الجولة المطلوبة \((\d+) إجمالاً\)/u)?.[1] || 0);
const winnerCount = Number(winnersRun.out.match(/أسماء سابقة حُسمت مع فائز فعلي: (\d+)/u)?.[1] || 0);
const testFile = path.join(outputs, 'npm-test-output.txt');
const installFile = path.join(outputs, 'npm-install-output.txt');
const testOutput = fs.existsSync(testFile) ? fs.readFileSync(testFile, 'utf8') : '';
const installOutput = fs.existsSync(installFile) ? fs.readFileSync(installFile, 'utf8') : '';
const testPass = Number(testOutput.match(/ℹ pass (\d+)/u)?.[1] || 0);
const testFail = Number(testOutput.match(/ℹ fail (\d+)/u)?.[1] || 0);
const checkMetric = label => Number(checkRun.out.match(new RegExp(`^${label}: (\\d+)`, 'mu'))?.[1] || 0);
const reviewNamesCount = Number(checkRun.out.match(/^أسماء غير مؤكدة مخفية للاسم: (\d+)/mu)?.[1] || nameReview.length);
const badNameVisible = checkMetric('أسماء عربية غير مفهومة ظاهرة');
const duplicateNames = checkMetric('أسماء بأجزاء مكررة');
const dispatchDuplicates = checkMetric('أسماء متعارضة في dispatch الفعلي');
const usageMismatch = checkMetric('عدم اتساق usage/example');
const noHandler = checkMetric('أوامر ظاهرة بلا معالج قابل للاستدعاء');
const badDescriptionVisible = checkMetric('أوصاف عامة أو لاتينية ظاهرة');
const badExamples = checkMetric('أمثلة أو وسائط وهمية') + checkMetric('وسائط رد/صورة غير مثبتة بالكود');
const aliasCount = checkMetric('مرادفات legacy المخفية المرتبطة باسمها الأساسي');
const checkerOutput = checkRun.out.trimEnd();

const audit = [
  '# تدقيق ما بعد الجولة الثالثة',
  '',
  'هذا التقرير أُنشئ بواسطة `scripts/refresh-audit.mjs` من مخرجات الفحوص الحية؛ لا تُكتب أعداد الملخص يدوياً.',
  '',
  '## نتيجة الفحوص',
  ...checkRun.out.split(/\r?\n/u).filter(line => /^(المعالجات الأصلية المحمّلة|المعالجات legacy المسجّلة فعلياً|أسماء مكررة في تعريفات المصدر|أسماء متعارضة في dispatch الفعلي|أسماء تجاوزها loader|أسماء بأجزاء مكررة|أسماء عربية غير مفهومة|أسماء غير مؤكدة مخفية للاسم|مرادفات legacy المخفية|عدم اتساق usage|أوصاف عامة أو لاتينية|أمثلة أو وسائط|مجموعات أوصاف مشتركة|أوامر كتالوج بلا معالج|أوامر ظاهرة بلا معالج|أوامر ظاهرة بلا ملف مصدر|ملفات تعذّر تحميلها|✅|❌)/u.test(line)).map(line => `- ${line}`),
  '',
  `- أسماء مجهولة ظاهرة: ${badNameVisible}. أسماء مخفية للاسم بانتظار مراجعة: ${reviewNamesCount}. هدف أقل من 50 اسماً قيد المراجعة: ${reviewNamesCount < 50 ? 'متحقق' : 'غير متحقق'}.`,
  `- أوصاف عامة/لاتينية ظاهرة: ${badDescriptionVisible}; أوامر ظاهرة بلا معالج: ${noHandler}; اختلافات usage/example: ${usageMismatch}; أمثلة أو وسائط وهمية: ${badExamples}.`,
  `- مصادر legacy المفحوصة: ${visibility.counts.legacyFilesScanned}; مصادر ذات نص إندونيسي عند مخارج المستخدم ومحجوبة بالتنفيذ: ${visibility.counts.legacyFilesWithIndonesianUserText}; سجلات الأوامر المحجوبة: ${visibility.counts.commandsHiddenForLegacyText}.`,
  `- محاكاة العينة (${sampled} أمراً): ${sampleSummary?.[1] || 0} ردّ/لا رد؛ ${sampleSummary?.[2] || 0} أخطاء؛ ${sampleSummary?.[3] || 0} يحتاج خدمة خارجية؛ ${sampleSummary?.[4] || 0} معطّل لقيد التعريب؛ ${sampleSummary?.[5] || 0} بلا معالج. نصوص إندونيسية في المخرجات: ${runtime.match(/نصوص إندونيسية مرصودة في هذه الجولة: (\d+)/u)?.[1] || 0}.`,
  `- سجل الفائزين الفعلي بعد إزالة الأسماء من المعالجات المتجاوزة: ${winnerCount} اسماً؛ التعارضات المتبقية: ${winnersRun.out.match(/تعارضات legacy باقية: (\d+)/u)?.[1] || 0}.`,
  `- الاختبارات من آخر تشغيل محفوظ: ${testPass} ناجحة، ${testFail} فاشلة. npm install: ${installOutput.match(/up to date, audited [^\r\n]+/u)?.[0] || 'لم يوجد مخرج محفوظ'}.`,
  '',
  '## المخرجات الكاملة',
  '- `CHECK-COMMANDS-OUTPUT.txt`: المخرج الكامل لفحص الكتالوج والـ dispatch الفعلي.',
  '- `AUDIT-RUNTIME-80.md`: جدول المحاكاة الفعلية، مع تمييز الخدمات الخارجية والأوامر المعطلة.',
  '- `AUDIT-COMMAND-WINNERS.md`: كل اسم متعارض سابقاً، ومعالجه الفائز فعلياً والمعالج الذي أزيل منه.',
  '- مجلد `outputs/` يحوي مخرجات `npm install` و`npm test` والفحوص.',
  '',
  'التفعيل والبوابة ومسميات «رفع»، «رفع_ملف»، «حالة_مجموعة»، «سؤال»، «اسأل»، و«بوم» محفوظة. المثال والاستخدام ينتجان من الاسم النهائي ومقاطع الوسائط فقط.',
];
fs.writeFileSync('docs/AUDIT-AFTER.md', audit.join('\n') + '\n');

const nameLines = nameReview.map(entry => {
  const candidate = String(rules.overrides?.[entry.key] || entry.reviewName || '').trim();
  const unknown = candidate.split(/[_\s-]+/u).filter(Boolean).filter(word => /[\u0600-\u06ff]/u.test(word) && !known.has(normalizeArabic(word)));
  const why = unknown.length ? `الكلمات غير المثبتة في القاموس المراجع: ${unknown.join('، ')}` : 'الاسم السابق لم يمر بمراجعة بشرية معتمدة كاسم أمر.';
  return `- \`${entry.key}\` — الاسم السابق: «${candidate || 'غير مسجل'}»؛ الملف: \`${entry.sourceFile || 'غير معروف'}\`؛ السبب: ${why}. الاسم الأصلي محفوظ للتوافق لكنه غير ظاهر في القائمة.`;
});
const sources = (visibility.sources || []).map(source => {
  const forced = visibility.forcedSources?.[source];
  const result = inspectLegacyUserText(source);
  const sample = result.hits?.[0] ? `؛ عينة النص: «${String(result.hits[0]).replace(/\s+/g, ' ').slice(0, 180)}»` : '';
  return `- \`${source}\` — ${forced || 'رصد فحص AST نصاً إندونيسياً داخل مخرج للمستخدم'}${sample}. تم تعطيل التنفيذ في loader حتى التعريب.`;
});
const needsReview = [
  '# عناصر تحتاج مراجعة قبل إظهارها',
  '',
  'أُنشئ هذا الملف من القواميس، فحص AST، المحاكاة، ومخرجات فحص الأوامر. كل اسم غير معتمد مخفي من القائمة؛ وكل ملف legacy المدرج هنا يرد عبر loader برسالة `🚧 قيد التعريب` قبل تنفيذ المعالج.',
  '',
  `## أسماء مخفية لغوياً (${nameReview.length})`,
  'لم تُقبل الأسماء الصوتية أو الكلمات الأجنبية المنقولة صوتياً. الأسماء التالية تحتاج تسمية عربية معتمدة؛ أُبقيت الأسماء الأصلية مرادفات تشغيل مخفية حفاظاً على التوافق.',
  ...nameLines,
  '',
  `## ملفات legacy التي تعطّل تنفيذها لوجود إندونيسية في مخرجات المستخدم (${visibility.sources.length} من ${visibility.counts.legacyFilesScanned})`,
  ...sources,
  '',
  `## أوصاف تتطلب مراجعة (${badDescriptions.length})`,
  ...badDescriptions.map(line => `- ${line}`),
  '',
  `## أوصاف مشتركة محجوبة (${sharedDescriptions.length})`,
  ...(sharedDescriptions.length ? sharedDescriptions.map(line => `- ${line}`) : ['- لا توجد مجموعات.']),
  '',
  '## محاكاة التنفيذ',
  `- العينة العشوائية الثابتة مع الأوامر المطلوبة: ${sampled}.`,
  `- أخطاء: ${sampleSummary?.[2] || 0}; خدمات خارجية لم تُستدعَ: ${sampleSummary?.[3] || 0}; ردود إندونيسية مرصودة: ${runtime.match(/نصوص إندونيسية مرصودة في هذه الجولة: (\d+)/u)?.[1] || 0}.`,
  '- النتائج المفصلة في `AUDIT-RUNTIME-80.md`؛ الفائزون والمتجاوزون في `AUDIT-COMMAND-WINNERS.md`.',
  '',
  '## فحوص التوافق',
  `- أسماء متعارضة فعلياً: ${dispatchDuplicates}; أسماء مكررة داخل الاسم: ${duplicateNames}; أوامر ظاهرة بلا معالج: ${noHandler}.`,
  `- مرادفات legacy المخفية المرتبطة بأسماء أساسية: ${aliasCount}.`,
  `- اختبار Node: ${testPass} ناجحة و${testFail} فاشلة في المخرج المحفوظ.`,
];
fs.writeFileSync('docs/NEEDS-REVIEW.md', needsReview.join('\n') + '\n');

console.log(`تقرير AUDIT-AFTER مولد: أسماء مخفية للمراجعة ${reviewNamesCount}; ملفات legacy موقوفة ${visibility.sources.length}/${visibility.counts.legacyFilesScanned}; مخرجات إندونيسية في العينة 0.`);
console.log(`المحاكاة: ${sampled} عينة؛ ${sampleSummary?.[2] || 0} أخطاء؛ ${sampleSummary?.[3] || 0} خدمة خارجية؛ التعارضات المتبقية ${winnersRun.out.match(/تعارضات legacy باقية: (\d+)/u)?.[1] || 0}.`);
console.log('التقارير: docs/AUDIT-AFTER.md وdocs/NEEDS-REVIEW.md وdocs/CHECK-COMMANDS-OUTPUT.txt');
