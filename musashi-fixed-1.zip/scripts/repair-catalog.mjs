import fs from "node:fs";
import path from "node:path";
import { normalizeArabic } from "../system/normalizeArabic.js";

const root = path.resolve(process.argv[2] || ".");
const systemDir = path.join(root, "system");
const catalogFiles = ["commandCatalog.json", "commandCatalog.ai.json"];
const ALIAS_KEYS_TO_SKIP = new Set(["ضغط_فيديو"]);

const NAME_FIXES = {
  image: "صورة_ذكاء", ig: "إنستغرام", twitter: "تويتر", video: "فيديو",
  truth: "صراحة", dare: "تحدي_جرأة", memory: "اختبار_ذاكرة", chess: "شطرنج",
  help: "شرح_الأوامر", dua: "دعاء_خاص", compress_video: "ضغط_فيديو", speed_video: "تسريع_فيديو",
  tt: "تيك_توك", ttmp3: "صوت_تيك_توك", asupantiktok: "مقاطع_تيك_توك",
  fakestory2: "قصة_مزيفة", fakestory3: "قصة_مزيفة_مصورة", fakestory4: "قصة_مزيفة_مميزة",
  fstory2: "قصة_فيسبوك", fstory3: "قصة_فيسبوك_مصورة", fstory4: "قصة_فيسبوك_مميزة",
  igstory3: "قصة_انستغرام", igstory4: "قصة_انستغرام_مميزة",
  certpacar: "شهادة_حب", pacarcert: "شهادة_حبيب", fortune: "حظ_اليوم",
  infogc: "معلومات_مجموعة", setnamagrup: "اسم_مجموعة", setppgroup: "صورة_مجموعة",
  setgrouprules: "قوانين_مجموعة", fq2: "اقتباس_عشوائي", block: "حظر_عضو",
  blgc: "حظر_مجموعة", dmsg: "حذف_خاص", gantiitsukiv8: "تغيير_الإصدار_الثامن",
  setitsukiv8: "ضبط_الإصدار_الثامن", gantiitsukiv9: "تغيير_الإصدار_التاسع",
  setitsukiv9: "ضبط_الإصدار_التاسع", setnamadev: "اسم_المطور", setownername: "اسم_المالك",
  reboot: "إعادة_تشغيل", setmenuhsn: "قائمة_النظام", settq: "إعداد_إضافي", tqtoset: "ضبط_إضافي",
  unblock: "فك_حظر_عضو", puskontak2: "نشر_جهات_الاتصال", doa: "دعاء_قرآني",
  berdoa: "طلب_دعاء", sholat: "صلاة_اليوم", create: "إنشاء_عنصر", rpglevelup: "ترقية_المستوى",
  "apkmod-get": "تحميل_تطبيق", play2: "تشغيل_مقطع", playaudio2: "تشغيل_صوت",
  playch: "تشغيل_قناة", pch: "تشغيل_قائمة", "putar-play2": "تشغيل_مقطع_آخر",
  spotplay: "تشغيل_سبوتيفاي", splay: "تشغيل_الأغنية", cekdana: "فحص_المحفظة",
  convert: "تحويل_ملف", fakequoted: "اقتباس_مزيف", "ai-shazam": "تعرف_على_الأغنية",
  setname: "تغيير_الاسم", setbotnama: "اسم_البوت", ssweb: "لقطة_موقع",
  animebrat: "ملصق_أنمي", bratanime2: "ملصق_أنمي_متحرك", animebrat2: "ملصق_أنمي_ملون",
  bratanime3: "ملصق_أنمي_ثان", animebrat3: "ملصق_أنمي_مميز", attp2: "ملصق_نص_متحرك",
  attp3: "ملصق_نص_ملون", bahlil: "ملصق_باهيليل", bratbahlil: "ملصق_باهيليل_متحرك",
  bahliltext: "نص_باهيليل", brattext: "ملصق_نصي", bratanime4: "ملصق_أنمي_رابع",
  bratanimegura: "ملصق_غورا_أنمي", bratgura: "ملصق_غورا", bratganime: "ملصق_أنمي_بديل",
  bratcewek: "ملصق_فتاة", cewekbrat: "صورة_فتاة", bratperempuan: "ملصق_نسائي",
  bratgirl: "ملصق_بنت", bratcewek2: "ملصق_فتاة_آخر", cewekbrat2: "صورة_فتاة_أخرى",
  bratperempuan2: "ملصق_نسائي_آخر", bratgirl2: "ملصق_بنت_آخر", bratchika: "ملصق_تشيكا",
  chikabrat: "تشيكا_ملصق", bratemon: "ملصق_إيمون", bratemontext: "نص_إيمون",
  bratvermeilvid: "فيديو_فيرميل", sticker: "إنشاء_ملصق", stiker: "ملصق_واتساب",
  emojitoanimasi: "تحريك_إيموجي", emoji2sticker: "إيموجي_ملصق", emojitoimage: "إيموجي_صورة",
  e2i: "إيموجي_متحرك", fakebankjago: "شعار_بنك_مزيف", fakeff: "شعار_فري_فاير",
  fakeffduo: "شعار_فري_فاير_ثنائي", fakeimgios: "واجهة_آيفون_مزيفة", imgios: "واجهة_آيفون",
  mlfake: "شعار_لعبة_مزيف", gtawasted: "صورة_هزيمة", evil: "مؤشر_الشر",
  kpopers: "محبو_كيبوب", hungry: "مؤشر_الجوع", lazy: "مؤشر_الكسل",
  ceksisaumur: "توقع_العمر", ceksocmed: "فحص_الحسابات_الاجتماعية", bsmp: "لعبة_بي_إس_إم_بي",
  suitpvp: "حجر_ورقة_مقص_تنافسي", rps: "حجر_ورقة_مقص", tebakgd: "تخمين_جي_دي",
  tgd: "لعبة_تي_جي_دي", tp: "تخمين_سريع", tictactoemp: "إكس_أو_متعدد",
  tiktaktomp: "إكس_أو_جماعي", tictactoev2: "إكس_أو_مطور", tttv2: "إكس_أو_تكتيكي",
  xov2: "إكس_أو_مميز", delppgc: "حذف_صورة_المجموعة", linkgc: "رابط_دعوة_المجموعة",
  setnamagrup: "اسم_المجموعة", setppgroup: "صورة_المجموعة", setgrouprules: "قواعد_المجموعة",
  addfiledb: "إضافة_ملف_للقاعدة", dbadd: "حفظ_في_القاعدة", addenergiall: "طاقة_للجميع",
  aicontroll: "إعداد_الذكاء", fiturdariapi: "ميزة_الخدمة", cekschedule: "فحص_المواعيد",
  delfiledb: "حذف_ملف_القاعدة", getfiledb: "جلب_ملف_القاعدة", dbget: "جلب_بيانات_القاعدة",
  ambildb: "استعادة_القاعدة", joingroup: "انضمام_لمجموعة", logerr: "سجل_الأخطاء",
  resetdb: "إعادة_ضبط_القاعدة", defaultlimitreset: "ضبط_الحد_الافتراضي", resetbotrules: "ضبط_قواعد_البوت",
  channelwl: "قائمة_القنوات_المسموحة", setgetplugin: "ضبط_الإضافة", getpluginvariant: "نمط_الإضافة",
  setfotobot: "صورة_البوت_البديلة", statsapi: "إحصاءات_الخدمة", cekapi: "فحص_الخدمة",
  swgcv2all: "تحديث_عام", installtemanebula: "تثبيت_ثيم_السديم", installtemastellar: "تثبيت_ثيم_النجوم",
  savekontak: "حفظ_جهات_الاتصال", savecontact: "حفظ_جهة_اتصال", stoppushkontak: "إيقاف_نشر_الاتصالات",
  gdleaderboard: "متصدرو_جي_دي", objgdsearch: "بحث_أغراض_جي_دي", searchobjgd: "بحث_عنصر_جي_دي",
  ffstalk: "فحص_فري_فاير", gdweekly: "أسبوع_جي_دي", levelgd: "مستوى_جي_دي",
  deteksiwajah: "كشف_الوجه", dnslookup: "فحص_النطاق", pdftoimg: "تحويل_ملف_صورة",
  qrcustom: "رمز_مخصص", reactchch2: "تفاعل_القناة", reactchannelv3: "تفاعل_قناة_مميز",
  chreactv3: "تفاعل_قناة_ثان", giftomp4: "تحويل_صورة_متحركة", txt2qr: "نص_إلى_رمز",
  texttoqr: "رمز_من_نص", togif: "صورة_متحركة", toimage: "صورة_ثابتة", tomp3: "تحويل_صوت",
  fakeffduo: "فريفاير_ثنائي", bsmp: "بيسمب", suitpvp: "لعبة_مقص_تنافسية",
  tgd: "لعبة_تيجي_دي", objgdsearch: "بحث_أغراض_لعبة", searchobjgd: "بحث_عنصر_لعبة",
  tiktok: "فيديو_تيك_توك", setownername: "تعديل_اسم_المالك", restart: "إعادة_تشغيل_بوت",
  stopsemuajadibot: "إيقاف_مؤقت", kirimfile: "ملف_مرفق", addcoin: "عملات_ممنوحة", bratnime: "ملصق_أنمي_آخر",
  nonaktif: "غير_مفعّل", ask: "اسأل_المساعد", quotesticker: "اقتباس_ملصق",
};

const DISAMBIGUATION = {
  "إيقاف_ميزة": "تعطيل_ميزة", "ايقاف_ميزة": "تشغيل_ميزة_قديم",
  "إيقاف_الروابط": "تعطيل_الروابط", "ايقاف_الروابط": "وقف_الروابط",
  "إيقاف_السب": "تعطيل_السب", "ايقاف_السب": "وقف_السب",
  warning: "تحذير", weekly: "مكافأة_أسبوعية", "أنمي": "صور_أنمي", اغنية: "مقطع_غنائي",
  نصيحه: "نصيحة_يومية", riddles: "فوازير", whoami: "تعريفي", quiz: "مسابقة_ثقافية",
  الالقاب: "قائمة_ألقاب", مساعده: "شرح_الأوامر", اذكار: "ذكر_يومي", اية: "آية_قرآنية",
  "قائمة الاقسام": "أقسام_البوت", addfile: "إضافة_ملف_جديد", sipv: "إعداد_الخادم",
  "اضف_صوره": "حفظ_صورة", "اضف_صورة": "إضافة_صورة", "أضف_صورة": "إرفاق_صورة",
  stop: "إيقاف_البوت", "اذاعه_فرعي": "بث_فرعي", "أوقات_الصلاة": "مواقيت_الصلاة",
  "ازالة_خلفيه": "تنظيف_الخلفية", tools: "أدوات_إضافية", chess: "مباراة_شطرنج",
  setownername: "تعديل_اسم_المالك", reboot: "إعادة_تشغيل_نسخة", stopsemuajadibot: "إيقاف_مؤقت",
  kirimfile: "ملف_مرفق", ffstalk: "حساب_فريفاير", addkoin: "إضافة_عملات", animebrat: "ملصق_أنمي_رسمي",
};

const WORDS = {
  add: "إضافة", del: "حذف", delete: "حذف", remove: "إزالة", set: "ضبط", get: "جلب", check: "فحص", cek: "فحص", lihat: "عرض",
  show: "عرض", list: "قائمة", create: "إنشاء", make: "إنشاء", send: "إرسال", upload: "رفع", download: "تحميل", play: "تشغيل",
  search: "بحث", find: "بحث", convert: "تحويل", edit: "تعديل", backup: "نسخ", restore: "استعادة", restart: "إعادة_تشغيل",
  random: "عشوائي", guess: "تخمين", tebak: "تخمين", reply: "رد", pin: "تثبيت", lock: "قفل", open: "فتح", close: "إغلاق",
  group: "المجموعة", grup: "المجموعة", member: "عضو", anggota: "أعضاء", user: "مستخدم", owner: "المالك", admin: "مشرف", bot: "البوت",
  file: "ملف", files: "ملفات", folder: "مجلد", link: "رابط", url: "رابط", image: "صورة", img: "صورة", foto: "صورة", photo: "صورة",
  video: "فيديو", audio: "صوت", voice: "صوت", music: "موسيقى", song: "أغنية", sticker: "ملصق", stiker: "ملصق", anime: "أنمي",
  game: "لعبة", games: "ألعاب", quiz: "مسابقة", question: "سؤال", time: "وقت", date: "تاريخ", weather: "الطقس", prayer: "الصلاة",
  welcome: "ترحيب", goodbye: "مغادرة", rules: "قوانين", name: "اسم", nickname: "لقب", tag: "إشارة", ai: "ذكاء", features: "الميزات",
  status: "حالة", info: "معلومات", help: "مساعدة", speed: "سرعة", truth: "صراحة", dare: "جرأة", joke: "نكتة", quote: "اقتباس",
  advice: "نصيحة", luck: "حظ", money: "مال", coin: "عملة", balance: "رصيد", level: "مستوى", energy: "طاقة", limit: "حد",
  true: "صحيح", false: "خطأ", command: "أمر", text: "نص", teks: "نص", caption: "تعليق", message: "رسالة", pesan: "رسالة",
  number: "رقم", name1: "الاسم_الأول", name2: "الاسم_الثاني", amount: "كمية", target: "مستهدف", code: "رمز", option: "خيار",
  type: "نوع", title: "عنوان", description: "وصف", city: "مدينة", media: "وسائط", replymedia: "رد_على_وسائط", someone: "شخص",
  seseorang: "شخص", atau: "أو", dan: "و", dengan: "مع", untuk: "لـ", dari: "من", baru: "جديد", kategori: "قسم", ganti: "غيّر",
  menjadi: "إلى", teks: "نص", gambar: "صورة", stiker: "ملصق", audio: "صوت", nama: "اسم", kode: "رمز", hari: "يوم", versi: "نسخة",
  otomatis: "تلقائي", fitur: "ميزة", berisi: "يحتوي", mendapatkan: "يحصل", mengubah: "يغيّر", buat: "أنشئ", buatkan: "أنشئ",
  membuat: "إنشاء", menggunakan: "باستخدام", mendapatkan: "جلب", memulai: "بدء", menampilkan: "عرض", melihat: "عرض", memeriksa: "فحص",
  berhasil: "بنجاح", gagal: "فشل", tidak: "لا", ditemukan: "موجود", dengan: "مع", reply: "الرد", all: "الكل", buy: "شراء", sell: "بيع",
  join: "انضمام", leave: "مغادرة", start: "بدء", stop: "إيقاف", on: "تشغيل", off: "إيقاف", verified: "موثّق", unlimited: "بلا_حد",
  mediafire: "ميديافاير", youtube: "يوتيوب", tiktok: "تيك_توك", whatsapp: "واتساب", html: "إتش_تي_إم_إل", js: "جافاسكريبت",
  jpg: "صورة", jpeg: "صورة", mp4: "فيديو", mp3: "صوت", api: "الخدمة", ip: "عنوان_الشبكة", jid: "معرّف_واتساب",
  emoji: "رمز_تعبيري", keyword: "كلمة_مفتاحية", style: "نمط", test: "اختبار", command: "أمر", text1: "النص_الأول",
  text2: "النص_الثاني", prefix1: "البادئة_الأولى", prefix2: "البادئة_الثانية", thumbnail: "صورة_مصغرة", label: "عنوان",
};

const ACTION_PREFIXES = /^(?:يستخدم|يعالج|يعرض|عرض|إنشاء|تحقق|جار|جاري)_/u;
const LATIN_ALLOW = new Set(["QR", "PDF", "OCR", "GIF", "MP3", "URL", "HD"]);

const USAGE_FIXES = {
  groupinfo: "", revoke: "", mention: "", features: "<رقم أو اسم الميزة>", ميزات: "<رقم أو اسم الميزة>", gpanel: "<رقم أو اسم الميزة>",
  summarize: "<نص أو رد على رسالة>", tr: "<اللغة|النص>", codeai: "<سؤال برمجي>", vision: "(بالرد على صورة)",
  clear_memory: "", ask: "<سؤال>", characters: "", بوت: "<سؤال>", إيرن: "<سؤال>", eren: "<سؤال>", imagine: "<وصف الصورة>",
  إيتاتشي: "<سؤال>", itachi: "<سؤال>", لوفي: "<سؤال>", luffy: "<سؤال>", مارين: "<سؤال>", ميكاسا: "<سؤال>", mikasa: "<سؤال>",
  اوبن: "<سؤال>", openai: "<سؤال>", موساشي: "<سؤال>", musashi: "<سؤال>", بومني: "<سؤال>", pomni: "<سؤال>",
  fbdl: "<رابط فيديو>", mf: "<رابط ملف>", اسبوتي: "<رابط أو اسم مقطع>", سبوتيفاي: "<رابط أو اسم مقطع>", spotify: "<رابط أو اسم مقطع>",
  سبوتي: "<رابط أو اسم مقطع>", threads: "<رابط منشور>", tdl: "<رابط منشور>", tt: "<رابط فيديو>", douyin: "<رابط فيديو>",
  ttmp3: "<رابط فيديو>", xdl: "<رابط منشور>", ytmp3: "<اسم مقطع أو رابط>", ytmp4: "<اسم مقطع أو رابط>",
  mention: "", compliment: "@عضو", quote: "", advice: "", luck: "", waifu: "", card: "", fun: "", riddle: "", memory: "",
  connect4: "", c4: "", country: "", eye: "", fox: "", جواب: "<الإجابة>", answer: "<الإجابة>", قناة: "", طلاق: "", بيحبني: "",
  بيكرهني: "", بيكراش: "", لينك: "", link: "", الرابط: "", زواج: "", سكريبت: "", سورس: "", sc: "", متوفر: "",
  حذف_لقب: "<اسم أو رد على العضو>", لقب: "<اسم اللقب>", الألقاب: "", الالقاب: "", تشخيص: "", تشخيص_الاستقبال: "",
  تشخيص_الطلبات: "", إعادة_محاولة_الطلبات: "", معلومات: "", info: "", botinfo: "", حالة: "", مواقيت: "<مدينة>", صلاة: "<مدينة>",
  prayer: "<مدينة>", اوقات_الصلاة: "<مدينة>", أوقات_الصلاة: "<مدينة>", مواقيت_الصلاة: "<مدينة>", مدينتي: "", setcity: "<مدينة>",
  اذكار: "", أذكار: "", ذكر: "", dhikr: "", دعاء: "", dua: "", اية: "", آية: "", quran: "", botpp: "(بالرد على صورة)",
  ارفعني: "", انضم: "<رابط دعوة>", ادخل: "<رابط دعوة>", اخرج: "", كود: "", getcode: "", cat: "<مسار الملف>", web: "<عبارة البحث>",
  wikipedia: "<عبارة البحث>", brat: "<نص>", attp: "<نص>", ttp: "<نص>", qc: "<نص | اسم القائل>", mybot: "", reconnect_sub: "",
  max_subs: "<عدد البوتات>", sub_blacklist: "<رقم الهاتف>", editimage: "(بالرد على صورة)", fancy: "<نص>", fileinfo: "(بالرد على ملف)",
  image2url: "(بالرد على صورة أو فيديو)", image2url2: "(بالرد على صورة أو فيديو)", enhance: "(بالرد على صورة)", resize: "(بالرد على صورة)",
  circle: "(بالرد على صورة)", cartoon: "(بالرد على صورة)", comic: "(بالرد على صورة)", merge_images: "(بالرد على الصورتين)", كلمات: "<اسم الأغنية>",
  lyrics: "<اسم الأغنية>", readviewonce: "(بالرد على رسالة عرض لمرة واحدة)", vv: "(بالرد على رسالة وسائط)", shorturl: "<رابط>", shorten: "<رابط>",
  fetch: "<رابط آمن>", voicelist: "", checkvoice: "<اسم الصوت>",
  قوانين: "", تعيين_قوانين: "<نص القوانين>", حذف_قوانين: "", تعيين_ترحيب: "<نص الترحيب>", حذف_ترحيب: "",
  انذاراتي: "", warns: "", warnings: "", الانذارات: "", my: "", سرقة: "", steal: "<عضو>",
};

const DESCRIPTION_FIXES = {
  compress_video: "يضغط الفيديو الذي ترد عليه لتقليل حجمه مع الحفاظ على جودة مناسبة.",
  speed_video: "يغيّر سرعة الفيديو الذي ترد عليه وفق معامل السرعة الذي تحدده.",
  fbdl: "ينزّل فيديو فيسبوك عند إرسال رابطه المباشر.",
  mf: "ينزّل الملف من ميديافاير عند إرسال رابطه.",
  ytmp3: "يبحث عن مقطع في يوتيوب أو ينزّله صوتاً من الاسم أو الرابط.",
  ytmp4: "يبحث عن مقطع في يوتيوب أو ينزّله فيديو من الاسم أو الرابط.",
  vision: "يحلّل الصورة التي ترد عليها ويجيب عن سؤالك عنها.",
  mention: "يعرض قائمة أعضاء المجموعة ومشرفيها مع الإشارة إليهم.",
  image2url: "يرفع الصورة أو الفيديو الذي ترد عليه ويعيد رابطه المباشر.",
  image2url2: "يرفع الصورة أو الفيديو الذي ترد عليه إلى خدمة بديلة ويعيد الرابط.",
};

function transliterate(token) {
  const map = { a: "ا", b: "ب", c: "ك", d: "د", e: "ي", f: "ف", g: "ج", h: "ه", i: "ي", j: "ج", k: "ك", l: "ل", m: "م", n: "ن", o: "و", p: "ب", q: "ق", r: "ر", s: "س", t: "ت", u: "و", v: "ف", w: "و", x: "كس", y: "ي", z: "ز" };
  return [...String(token).toLowerCase()].map(char => map[char] || "").join("");
}

function fromKey(key) {
  const known = NAME_FIXES[key] || DISAMBIGUATION[key];
  if (known) return known;
  const parts = String(key).replace(/([a-z])([A-Z])/g, "$1 $2").replace(/\d+/g, " ").split(/[^\p{L}]+/u).filter(Boolean);
  const translated = parts.map(part => /[\u0600-\u06ff]/u.test(part) ? part : WORDS[part.toLowerCase()] || transliterate(part)).filter(Boolean);
  return translated.slice(-3).join("_") || "أمر";
}

function normalizeName(key, value, used) {
  let name = DISAMBIGUATION[key] || NAME_FIXES[key] || String(value || "").trim();
  name = name.replace(/[\s-]+/gu, "_").replace(/_[0-9٠-٩۰-۹]+$/u, "").replace(/[0-9٠-٩۰-۹]+$/u, "").replace(/_+/gu, "_").replace(/^_|_$/gu, "");
  if (!/[\u0600-\u06ff]/u.test(name) || /[A-Za-z]/u.test(name) || name.split("_").filter(Boolean).length > 3 || ACTION_PREFIXES.test(name)) name = fromKey(key);
  if (ACTION_PREFIXES.test(name)) name = name.replace(ACTION_PREFIXES, "");
  let normalized = normalizeArabic(name);
  if (!name || !/[\u0600-\u06ff]/u.test(name)) name = fromKey(key);
  normalized = normalizeArabic(name);
  if (used.has(normalized)) {
    const keyWords = fromKey(key).split("_");
    const baseWords = name.split("_").slice(0, 2);
    const discriminator = keyWords.find(word => !baseWords.some(base => normalizeArabic(base) === normalizeArabic(word)));
    name = [...baseWords, discriminator || keyWords.at(-1) || "أمر"].slice(0, 3).join("_");
    normalized = normalizeArabic(name);
  }
  if (used.has(normalized)) {
    name = fromKey(key).split("_").slice(0, 3).join("_");
    normalized = normalizeArabic(name);
  }
  if (!name || used.has(normalized)) return "";
  used.add(normalized);
  return name;
}

function translateLatin(text) {
  const phrases = [
    [/\batau\s+reply\s+pesan\s+seseorang\b/giu, "أو بالرد على رسالة"],
    [/\bor\s+reply\s+(?:to\s+)?(?:a\s+)?message\b/giu, "أو بالرد على رسالة"],
    [/\breply\s+media\b/giu, "بالرد على الوسائط"],
    [/\btext\s+to\s+speech\b/giu, "تحويل النص إلى كلام"],
    [/\bmedia\s+fire\b/giu, "ميديافاير"],
    [/\bتيك_توك\s+صوت\b/giu, "صوت تيك توك"],
  ];
  let out = String(text || "");
  for (const [pattern, replacement] of phrases) out = out.replace(pattern, replacement);
  out = out.replace(/\bV([1-9])\s*[-–]\s*V([1-9])\b/giu, (_, a, b) => `النسخ ${a} إلى ${b}`)
    .replace(/\bV([1-9])\b/giu, (_, n) => `النسخة ${n}`)
    .replace(/\b--verified\b/giu, "موثّق")
    .replace(/\b--unlimited\b/giu, "بلا حد")
    .replace(/@[A-Za-z][\w-]*/gu, "@عضو")
    .replace(/\.(?:jpg|jpeg|png|webp)\b/giu, " صورة")
    .replace(/\.(?:mp4|mov|mkv)\b/giu, " فيديو")
    .replace(/\.(?:mp3|ogg|wav)\b/giu, " صوت");
  return out.replace(/[A-Za-z][A-Za-z0-9_-]*/gu, token => {
    if (LATIN_ALLOW.has(token.toUpperCase())) return token.toUpperCase();
    const lower = token.toLowerCase();
    return WORDS[lower] || transliterate(token) || "";
  }).replace(/\s{2,}/gu, " ").trim();
}

function cleanUsage(key, ar, value) {
  let usage = String(value || "").trim();
  usage = usage.replace(/^\.?\S+/u, `.${ar}`)
    .replace(/\s+atau\s+/giu, " أو ")
    .replace(/\b(?:reply|balas)\s+(?:pesan|media|foto|gambar|someone|seseorang)\b/giu, "بالرد على رسالة")
    .replace(/\bcaption\b/giu, "تعليق")
    .replace(/\btext\s*\d*\b/giu, "نص")
    .replace(/\b(?:image|photo|foto|gambar)\b/giu, "صورة")
    .replace(/\b(?:video|audio|sound)\b/giu, "وسائط")
    .replace(/\b(?:user|member|target|tag|nama|name)\b/giu, "عضو")
    .replace(/\s+\[(?:--)?[A-Za-z][^\]]*\]/gu, "");
  usage = translateLatin(usage);
  return usage || `.${ar}`;
}

function inferInputUsage(key, entry, currentUsage) {
  const usage = String(currentUsage || "").trim();
  const argsText = usage.replace(/^\.?\S+/u, "").trim();
  if (argsText) return usage;
  if (!entry.sourceFile) return usage;
  const sourcePath = path.isAbsolute(entry.sourceFile) ? entry.sourceFile : path.join(root, entry.sourceFile);
  const source = fs.readFileSync(sourcePath, "utf8").replace(/\/\*[\s\S]*?\*\//gu, " ").replace(/^[\t ]*\/\/.*$/gmu, " ");
  const readsQuoted = /\bm\.quoted\b|\bquoted\.(?:download|mimetype|message)\b|quotedMessage/iu.test(source);
  const mediaRequired = readsQuoted && /(?:mimetype|imageMessage|videoMessage|audioMessage|stickerMessage|download\s*\(|downloadMedia|\.media\b)/iu.test(source);
  if (mediaRequired) return `.${entry.ar} (بالرد على صورة أو فيديو)`;
  if (readsQuoted) return `.${entry.ar} (بالرد على الرسالة)`;

  const readsInput = /\bargs\b|\bm\.text\b|\btext\s*=|\bcaption\b|\bquery\b|\binput\b/iu.test(source);
  if (!readsInput) return usage;
  if (/\b(?:url|link|https?)\b|(?:tiktok|youtube|facebook|instagram|download|mediafire)/iu.test(source) && /(?:download|تحميل|downloaders)/iu.test(`${entry.category || ""} ${source.slice(0, 4000)}`)) {
    return `.${entry.ar} <رابط>`;
  }
  if (/\b(?:mentionedJid|participant|target|userJid|number|phone)\b|@tag/iu.test(source)) return `.${entry.ar} <عضو>`;
  if (/\b(?:amount|quantity|count|limit|level|energy|coin|exp|number|parseInt|Number\()\b/iu.test(source)) return `.${entry.ar} <رقم>`;
  return `.${entry.ar} <نص>`;
}

function makeExample(ar, usage, category) {
  const args = String(usage || "").replace(/^\.?\S+\s*/u, "").trim();
  if (!args) return `.${ar}`;
  if (/بداية.*نهاية|بدء.*انتهاء/u.test(args)) return `.${ar} 0 15`;
  if (/رابط/u.test(args)) return `.${ar} https://example.com`;
  if (/بالرد على/u.test(args) || /صورة|فيديو|صوت/u.test(args)) return `.${ar} (بالرد على الوسائط)`;
  if (/عدد|رقم|كمية|مبلغ/u.test(args)) return `.${ar} 5`;
  if (/نص|اسم|مدينة|سؤال|كلمة/u.test(args)) return `.${ar} مثال للاستخدام`;
  if (/مدة|وقت/u.test(args)) return `.${ar} 00:00:05`;
  return `.${ar} ${args.replace(/[<>\[\]]/gu, "").replace(/\s+/gu, " ").slice(0, 48)}`;
}

function improveDescription(key, entry) {
  if (DESCRIPTION_FIXES[key]) return DESCRIPTION_FIXES[key];
  let desc = translateLatin(entry.desc || "");
  if (!desc || /يحمّل أو يعالج|يعالج .* من الرابط|يعالج .* الوارد|ينفذ الأمر المطلوب|ينفذ هذا الأمر/iu.test(desc)) {
    const noun = String(entry.ar || fromKey(key)).replace(/_/gu, " ");
    const category = String(entry.category || "").toLowerCase();
    const templates = {
      downloads: `ينزّل ${noun} عند إرسال رابط صالح.`, download: `ينزّل ${noun} عند إرسال رابط صالح.`,
      ai: `ينفّذ ${noun} باستخدام الذكاء الاصطناعي وفق النص المرسل.`,
      games: `يبدأ ${noun} في المجموعة ويتابع إجابات المشاركين.`, game: `يبدأ ${noun} في المجموعة ويتابع إجابات المشاركين.`,
      sticker: `ينشئ ${noun} من الصورة أو النص الذي ترسله.`, tools: `يعالج ${noun} باستخدام المدخلات أو الوسائط المرفقة.`,
      admin: `يدير ${noun} داخل المجموعة وفق صلاحيتك.`, admins: `يدير ${noun} داخل المجموعة وفق صلاحيتك.`,
      group: `يعرض أو يغيّر ${noun} في المجموعة.`, owner: `ينفّذ ${noun} في إعدادات نسخة البوت.`,
    };
    desc = templates[category] || `ينفّذ ${noun} وفق المدخلات الموضحة في طريقة الاستخدام.`;
  }
  desc = translateLatin(desc);
  if (!/[.؟!]$/u.test(desc)) desc += ".";
  return desc;
}

function isAssetKey(key) {
  return /\.(?:mp4|jpe?g|png|webp|gif|svg|woff2?)$/iu.test(key) || /^ganti-itsuki-/iu.test(key);
}

for (const file of catalogFiles) {
  const fullPath = path.join(systemDir, file);
  const data = JSON.parse(fs.readFileSync(fullPath, "utf8"));
  const oldCommands = data.commands || {};
  const commands = {};
  const used = new Set();
  let renamed = 0, translated = 0, removedAssets = 0;

  for (const [key, rawEntry] of Object.entries(oldCommands)) {
    if (ALIAS_KEYS_TO_SKIP.has(key)) continue;
    if (isAssetKey(key)) { removedAssets++; continue; }
    const entry = { ...rawEntry };
    const originalName = entry.ar || "";
    entry.ar = normalizeName(key, originalName, used);
    if (entry.ar !== originalName) renamed++;
    entry.desc = improveDescription(key, entry);
    const forcedArgs = Object.prototype.hasOwnProperty.call(USAGE_FIXES, key) ? USAGE_FIXES[key] : null;
    const inferred = forcedArgs === null ? inferInputUsage(key, entry, entry.usage || `.${entry.ar}`) : `.${entry.ar}${forcedArgs ? ` ${forcedArgs}` : ""}`;
    entry.usage = cleanUsage(key, entry.ar, inferred);
    entry.example = makeExample(entry.ar, entry.usage, entry.category);
    entry.original ||= key;
    if (entry.desc !== rawEntry.desc || entry.usage !== rawEntry.usage) translated++;
    commands[key] = entry;
  }

  data.commands = commands;
  if (file === "commandCatalog.json") data.stats = { ...(data.stats || {}), commands: Object.keys(commands).length };
  if (file === "commandCatalog.ai.json") data.count = Object.keys(commands).length;
  fs.writeFileSync(fullPath, JSON.stringify(data, null, 2), "utf8");
  console.log(`${file}: ${Object.keys(commands).length} مدخل · ${renamed} اسم مُراجع · ${translated} وصف/استخدام مُعرّب محلياً · ${removedAssets} مفتاح ملف مستبعد`);
}
