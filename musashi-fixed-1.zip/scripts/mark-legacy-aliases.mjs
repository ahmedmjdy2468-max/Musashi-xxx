import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { normalizeArabic } from '../system/normalizeArabic.js';

const require = createRequire(import.meta.url);
const files = new Map();
function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (['node_modules', '.git', 'session', 'tmp', 'temp'].includes(entry.name)) continue;
    const file = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(file);
    else if (entry.isFile() && file.endsWith('.js')) files.set(file.replaceAll('\\', '/').toLowerCase(), file);
  }
}
walk('plugins_legacy');

const catalogs = ['system/commandCatalog.json', 'system/commandCatalog.ai.json'];
const data = catalogs.map(file => ({ file, root: JSON.parse(fs.readFileSync(file, 'utf8')) }));
const primaryByFile = new Map();
for (const [normalizedFile, file] of files) {
  try {
    delete require.cache[require.resolve(path.resolve(file))];
    const mod = require(path.resolve(file));
    const plugin = mod?.default ?? mod;
    const config = plugin?.config || plugin?.pluginConfig || {};
    const primary = config.name || plugin?.name || plugin?.command?.[0] || config.command?.[0] || config.alias?.[0] || plugin?.alias?.[0] || '';
    if (primary) primaryByFile.set(normalizedFile, String(primary));
  } catch {}
}

let marked = 0;
let filesWithoutPrimary = 0;
for (const catalog of data) {
  for (const [key, entry] of Object.entries(catalog.root.commands || {})) {
    const source = String(entry.sourceFile || '').replaceAll('\\', '/').toLowerCase();
    if (!source.startsWith('plugins_legacy/')) continue;
    const primary = primaryByFile.get(source);
    if (!primary) { filesWithoutPrimary++; continue; }
    if (normalizeArabic(key) === normalizeArabic(primary)) continue;
    const canonical = Object.entries(catalog.root.commands)
      .find(([candidate, other]) => normalizeArabic(candidate) === normalizeArabic(primary) && String(other.sourceFile || '').replaceAll('\\', '/').toLowerCase() === source)?.[1];
    if (!canonical) continue;
    entry.aliasOf = primary;
    entry.hiddenForAudience = true;
    entry.ar = canonical.ar || entry.ar || '';
    entry.desc = canonical.desc || entry.desc || '';
    marked++;
  }
}
for (const { file, root } of data) fs.writeFileSync(file, JSON.stringify(root, null, 2) + '\n', 'utf8');
console.log(`مرادفات legacy أُخفيت وربطت باسمها الأساسي: ${marked}`);
console.log(`سجلات تعذر ربطها باسم أساسي: ${filesWithoutPrimary}`);
