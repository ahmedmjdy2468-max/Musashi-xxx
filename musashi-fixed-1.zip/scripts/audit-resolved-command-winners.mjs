import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import { registerLegacyPlugins } from '../system/legacy/loader.js';
import { normalizeArabic } from '../system/normalizeArabic.js';

const require = createRequire(import.meta.url);
const root = process.cwd();
const registry = [];
const rows = [];
const failures = [];

async function* walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (['node_modules', '.git', 'session', 'tmp', 'temp'].includes(entry.name)) continue;
    const file = path.join(dir, entry.name);
    if (entry.isDirectory()) yield* walk(file);
    else if (entry.isFile() && file.endsWith('.js')) yield file;
  }
}

function getNames(mod) {
  const base = mod?.default ?? mod;
  return [...new Set([base?.command, base?.config?.command, base?.config?.name, base?.config?.alias, base?.alias]
    .flatMap(value => Array.isArray(value) ? value : [value])
    .filter(value => typeof value === 'string').map(value => value.trim()).filter(Boolean))];
}

for await (const file of walk(path.join(root, 'plugins'))) {
  try {
    const mod = await import(pathToFileURL(file).href);
    const command = getNames(mod);
    if (command.length) registry.push({ command, filePath: file });
  } catch (error) {
    failures.push({ file: path.relative(root, file).replaceAll('\\', '/'), error: error?.message || String(error) });
  }
}

const client = {
  registerCommand(item) { registry.push(item); },
  getAllCommands() { return registry; },
  getCommand(name) {
    const key = normalizeArabic(name);
    return registry.find(item => [].concat(item.command || []).some(candidate => normalizeArabic(candidate) === key)) || null;
  },
};
const legacyStats = await registerLegacyPlugins(client, { dir: './plugins_legacy', logger: { log() {}, warn() {}, error() {} } });

const manifest = fs.readFileSync('docs/COMMAND-CONFLICTS-RESOLVED-SOURCE.txt', 'utf8');
for (const line of manifest.split(/\r?\n/)) {
  const match = line.match(/^حُذف:\s*(.*?)\s*←\s*(.*)$/u);
  if (!match) continue;
  const loserFile = match[1].trim().replaceAll('\\', '/');
  for (const name of match[2].split(',').map(value => value.trim()).filter(Boolean)) {
    const winner = client.getCommand(name);
    const winnerFile = winner?.filePath ? path.relative(root, winner.filePath).replaceAll('\\', '/') : '';
    if (!winnerFile) failures.push({ file: loserFile, error: `لا يوجد فائز dispatch مسجل للاسم ${name}` });
    rows.push({ name, winner: winnerFile || '(غير مسجل)', loser: loserFile });
  }
}

const report = [
  '# تدقيق الأسماء المتعارضة بعد الحسم',
  '',
  'الفائز مستخرج بعد تحميل handlers الأصلية وتسجيل legacy عبر loader الإنتاجي. كل صف أدناه يربط الاسم بالمعالج الفائز فعلياً وبالمعالج الذي أزيل منه الاسم المتجاوز.',
  '',
  '| الاسم | المعالج الفائز فعلياً | المعالج المتجاوز الذي حُذف منه الاسم |',
  '|---|---|---|',
  ...rows.map(row => `| ${row.name} | ${row.winner} | ${row.loser} |`),
  '',
  `الأسماء التي حُسمت في سجل الجولة السابقة: ${rows.length}.`,
  `تعارضات legacy المتبقية في loader: ${legacyStats.conflicts || 0}.`,
  `أسماء بلا فائز مسجل/أخطاء تحميل: ${failures.length}.`,
];
for (const failure of failures) report.push(`- ${failure.file}: ${failure.error}`);
fs.writeFileSync('docs/AUDIT-COMMAND-WINNERS.md', report.join('\n') + '\n');
for (const row of rows) console.log(`${row.name}\tالفائز=${row.winner}\tالمتجاوز=${row.loser}`);
console.log(`أسماء سابقة حُسمت مع فائز فعلي: ${rows.length}`);
console.log(`تعارضات legacy باقية: ${legacyStats.conflicts || 0}`);
console.log(`أسماء بلا فائز أو أخطاء تحميل: ${failures.length}`);
console.log('التقرير: docs/AUDIT-COMMAND-WINNERS.md');
process.exit(failures.length ? 1 : 0);
