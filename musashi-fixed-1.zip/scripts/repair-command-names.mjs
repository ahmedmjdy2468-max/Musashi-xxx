import fs from 'node:fs';
const rules=JSON.parse(fs.readFileSync('scripts/name-rules.json','utf8'));
const brandNames=JSON.parse(fs.readFileSync('scripts/brand-names.json','utf8'));
const known=new Set([...rules.knownWords,...Object.values(brandNames),...(rules.approvedProperNames||[])].map(x=>String(x).normalize('NFKC').replace(/[\u064B-\u065F\u0670\u06D6-\u06ED]/g,'').replace(/[أإآٱ]/g,'ا').replace(/ى/g,'ي').replace(/ة/g,'ه').toLowerCase()));
const changed=[];
for(const path of ['system/commandCatalog.json','system/commandCatalog.ai.json']){
 const d=JSON.parse(fs.readFileSync(path,'utf8'));
 for(const [key,e] of Object.entries(d.commands||{})){
  let n=e.ar||'';
  if(rules.overrides[key])n=rules.overrides[key];
  else if(n){const parts=n.split(/[_\s-]+/u).filter(Boolean),seen=new Set(),dedup=parts.filter(x=>{const k=x.normalize('NFKC').toLowerCase();if(seen.has(k))return false;seen.add(k);return true});if(dedup.length!==parts.length)n=dedup.join('_');if(dedup.some(x=>/[\u0600-\u06ff]/u.test(x)&&!known.has(x.normalize('NFKC').replace(/[\u064B-\u065F\u0670\u06D6-\u06ED]/g,'').replace(/[أإآٱ]/g,'ا').replace(/ى/g,'ي').replace(/ة/g,'ه').toLowerCase()))){const rule=rules.prefixes.find(x=>key.toLowerCase().startsWith(x.prefix));const suffix=rule?rules.suffixTranslations?.[key.toLowerCase().slice(rule.prefix.length)]:null;if(suffix)n=`${rule.arabic}_${suffix}`}}
  e.ar=n;
 }
 fs.writeFileSync(path,JSON.stringify(d,null,2)+'\n');
}
