import { readdir, readFile, writeFile } from "node:fs/promises";
import { extname, join } from "node:path";
import { normalizeArabic } from "../system/normalizeArabic.js";

const ROOT = process.cwd();
const underDevPath = join(ROOT, "src/data/underdev.json");
const registry = JSON.parse(await readFile(underDevPath, "utf8"));
const pluginNames = new Set((registry.plugins || []).map(name => String(name).toLowerCase()));

function balancedRange(source, open, left, right) {
  let depth = 0, quote = "", escape = false, line = false, block = false;
  for (let i = open; i < source.length; i++) {
    const c = source[i], next = source[i + 1];
    if (line) { if (c === "\n") line = false; continue; }
    if (block) { if (c === "*" && next === "/") { block = false; i++; } continue; }
    if (quote) {
      if (escape) { escape = false; continue; }
      if (c === "\\") { escape = true; continue; }
      if (c === quote) quote = "";
      continue;
    }
    if (c === "/" && next === "/") { line = true; i++; continue; }
    if (c === "/" && next === "*") { block = true; i++; continue; }
    if (c === "'" || c === '"' || c === "`") { quote = c; continue; }
    if (c === left) depth++;
    if (c === right && --depth === 0) return source.slice(open, i + 1);
  }
  return "";
}

function arrayAt(source, start) {
  let i = start;
  while (/\s/u.test(source[i] || "")) i++;
  if (source[i] !== "[") return [];
  const array = balancedRange(source, i, "[", "]");
  return [...array.matchAll(/(['"])([^'"\r\n]+)\1/gu)].map(match => match[2].trim()).filter(Boolean);
}

function configNames(source) {
  const names = [];
  const assign = /\b(?:const|let|var)\s+(?:pluginConfig|config)\s*=\s*\{/gu;
  for (const match of source.matchAll(assign)) {
    const open = match.index + match[0].lastIndexOf("{");
    const object = balancedRange(source, open, "{", "}");
    if (!object) continue;
    for (const property of ["name", "command", "alias"]) {
      const pattern = new RegExp(`\\b${property}\\s*:\\s*`, "gu");
      for (const item of object.matchAll(pattern)) {
        const start = item.index + item[0].length;
        const values = arrayAt(object, start);
        if (values.length) names.push(...values);
        else {
          const rest = object.slice(start);
          const single = rest.match(/^(['"])([^'"\r\n]+)\1/u);
          if (single) names.push(single[2].trim());
        }
      }
    }
  }
  return names;
}

function sourceCommandNames(source) {
  const code = source.replace(/\/\*[\s\S]*?\*\//gu, " ").replace(/^[\t ]*\/\/.*$/gmu, " ");
  const names = [];
  const patterns = [
    /\b(?:handler|plugin|cmd|command)\.command\s*=\s*\[([\s\S]*?)\]/gu,
    /\bcommand\s*:\s*\[([\s\S]*?)\]/gu,
  ];
  for (const pattern of patterns) {
    for (const match of code.matchAll(pattern)) {
      for (const item of match[1].matchAll(/(['"])([^'"\r\n]+)\1/gu)) names.push(item[2].trim());
    }
  }
  return names;
}

async function* walk(dir) {
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    if (["node_modules", ".git", "session", "tmp"].includes(entry.name)) continue;
    const file = join(dir, entry.name);
    if (entry.isDirectory()) yield* walk(file);
    else if (entry.isFile() && extname(entry.name).toLowerCase() === ".js") yield file;
  }
}

const nativeNames = new Set();
for await (const file of walk(join(ROOT, "plugins"))) {
  for (const name of sourceCommandNames(await readFile(file, "utf8"))) nativeNames.add(normalizeArabic(name));
}

const commands = new Set();
for await (const file of walk(join(ROOT, "plugins_legacy"))) {
  const source = await readFile(file, "utf8");
  const basename = file.split(/[\\/]/u).pop().replace(/\.js$/iu, "").toLowerCase();
  if (!pluginNames.has(basename)) continue;
  for (const name of configNames(source)) commands.add(name);
  for (const name of sourceCommandNames(source)) commands.add(name);
  commands.add(basename);
}

const catalog = JSON.parse(await readFile(join(ROOT, "system/commandCatalog.json"), "utf8")).commands || {};
for (const [key, entry] of Object.entries(catalog)) {
  const source = String(entry.sourceFile || "").replaceAll("\\", "/");
  const basename = source.split("/").pop()?.replace(/\.js$/iu, "").toLowerCase();
  if (!pluginNames.has(basename)) continue;
  commands.add(key);
  if (entry.ar) commands.add(entry.ar);
}

const filtered = [...commands]
  .map(name => String(name).trim())
  .filter(Boolean)
  .filter(name => !nativeNames.has(normalizeArabic(name)))
  .sort((a, b) => a.localeCompare(b, "ar"));

registry.commands = [...new Set(filtered)];
await writeFile(underDevPath, JSON.stringify(registry, null, 2) + "\n", "utf8");
console.log(`أسماء أوامر قيد التعريب: ${registry.commands.length}`);
console.log(`مرادفات أُبقيت لمعالجات plugins الأصلية: ${commands.size - registry.commands.length}`);
