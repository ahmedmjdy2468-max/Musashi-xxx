import "./system/loadEnv.js";
import { Client } from '#meowsab';
import { group, access, handleReceptionJoinRequest } from "./system/control.js";
import { getBotSettings, bindInstanceOwnerOnReady } from "./system/config.js";
import { IDENTITY, DEVELOPER, OFFICIAL_CHANNEL } from "./system/theme.js";
import UltraDB from "./system/UltraDB.js";
import sub from './sub.js';
import { handleReceptionMessage } from "./system/reception.js";
import { cleanupOldTempFiles, getCacheStats } from "./system/downloadManager.js";
import { registerLegacyPlugins } from "./system/legacy/loader.js";
import { initLegacyDatabase } from "./system/legacy/database.js";
import { registerArabicAliases } from "./system/arabicAliases.js";
import { registerCatalogAliases } from "./system/catalog.js";
import { installSendGuard } from "./system/sendGuard.js";
import { attachBotDiscoveryRecorder } from "./system/botDiscovery.js";

/* =========== Database ========== */
if (!global.db) {
    global.db = new UltraDB();
}

// 🔎 تحقق مبكر برسالة واضحة بدل انهيار غامض على منصات الاستضافة
let settings;
try {
    settings = getBotSettings();
} catch (error) {
    console.error("╔══════════════════════════════════════════════════╗");
    console.error("║  [MUSASHI] خطأ في الإعدادات — البوت لم يبدأ       ║");
    console.error("╚══════════════════════════════════════════════════╝");
    console.error("السبب:", error?.message || error);
    console.error("الحل: تأكد من وجود ملف .env بجانب index.js ويحتوي:");
    console.error("  BOT_PHONE_NUMBER=968xxxxxxxx");
    console.error("  OWNER_PHONE_NUMBER=968xxxxxxxx");
    process.exit(1);
}

// Restore persisted dynamic owner if already bound on this instance
if (global.db.settings?.ownerJid && global.db.settings?.ownerLocked) {
    settings.ownerJid = global.db.settings.ownerJid;
    settings.ownerPhoneNumber = global.db.settings.ownerPhone || settings.ownerJid.split('@')[0];
    settings.ownerName = global.db.settings.ownerName || settings.ownerName;
    if (global.db.settings.ownerLid) {
        settings.ownerLid = global.db.settings.ownerLid;
    }
} else {
    // Initialize default persisted owner from settings on first run
    global.db.settings.ownerJid = settings.ownerJid;
    global.db.settings.ownerPhone = settings.ownerPhoneNumber;
    if (settings.ownerLid) {
        global.db.settings.ownerLid = settings.ownerLid;
    }
    global.db.settings.ownerName = settings.ownerName;
    global.db.settings.ownerLocked = true;
}

const extraOwners = Array.isArray(global.db.settings?.owners) ? global.db.settings.owners : [];

/* =========== Performance Monitoring ========== */
const startTime = Date.now();
let messageCount = 0;
let errorCount = 0;
const commandTimes = new Map();

function recordCommandTime(command, duration) {
    const times = commandTimes.get(command) || [];
    times.push(duration);
    if (times.length > 100) times.shift();
    commandTimes.set(command, times);
}

function getAvgCommandTime(command) {
    const times = commandTimes.get(command);
    if (!times || !times.length) return 0;
    return times.reduce((a, b) => a + b, 0) / times.length;
}

function getMemoryUsage() {
    const used = process.memoryUsage();
    return {
        rss: Math.round(used.rss / 1024 / 1024),
        heapTotal: Math.round(used.heapTotal / 1024 / 1024),
        heapUsed: Math.round(used.heapUsed / 1024 / 1024),
        external: Math.round(used.external / 1024 / 1024),
    };
}

function getUptime() {
    return Date.now() - startTime;
}

/* =========== Periodic Cleanup ========== */
// Clean up temp download files every 30 minutes
setInterval(() => {
    try {
        const cleaned = cleanupOldTempFiles(30);
        if (cleaned > 0) {
            console.log(`[MUSASHI] Cleaned up ${cleaned} old temp files`);
        }
    } catch {}
}, 30 * 60 * 1000).unref?.();

/* =========== Client ========== */
const client = new Client({
  phoneNumber: settings.botPhoneNumber,
  prefix: [".", "/", "!"],
  fromMe: false, 
  owners: [
    {
      name: settings.ownerName,
      jid: settings.ownerJid,
      ...(settings.ownerLid ? { lid: settings.ownerLid } : {})
    },
    ...extraOwners
  ],
  settings: { noWelcome: false },
  commandsPath: './plugins'
});

// Wrap event handlers with error isolation so one failing feature doesn't crash the bot
const originalOnGroupEvent = client.onGroupEvent.bind(client);
client.onGroupEvent = (handler) => {
    return originalOnGroupEvent(async (ctx, event, eventType) => {
        try {
            messageCount++;
            return await handler(ctx, event, eventType);
        } catch (e) {
            errorCount++;
            console.error(`[MUSASHI] Group event error (${eventType}):`, e?.message || e);
        }
    });
};

const originalOnCommandAccess = client.onCommandAccess.bind(client);
client.onCommandAccess = (handler) => {
    return originalOnCommandAccess(async (msg, checkType, time) => {
        try {
            return await handler(msg, checkType, time);
        } catch (e) {
            errorCount++;
            console.error(`[MUSASHI] Access check error (${checkType}):`, e?.message || e);
        }
    });
};

const originalOnMessage = client.onMessage.bind(client);
client.onMessage = (handler) => {
    return originalOnMessage(async (message) => {
        try {
            return await handler(message);
        } catch (e) {
            errorCount++;
            console.error(`[MUSASHI] Message handler error:`, e?.message || e);
        }
    });
};

client.onGroupEvent(group);
client.onCommandAccess(access);
client.onMessage(handleReceptionMessage);

/* =========== Config ========== */
const { config } = client;
config.info = { 
  nameBot: IDENTITY.botName,
  officialBotName: IDENTITY.officialBotName,
  shortName: IDENTITY.shortName,
  developer: DEVELOPER,
  developerName: DEVELOPER.name,
  developerDisplayName: DEVELOPER.displayName,
  developerPhone: DEVELOPER.phone,
  developerJid: DEVELOPER.jid,
  developerLid: DEVELOPER.lid,
  signature: IDENTITY.signature,
  nameChannel: settings.channelName || OFFICIAL_CHANNEL.name,
  idChannel: settings.channelJid || OFFICIAL_CHANNEL.jid,
  urls: {
    repo: process.env.BOT_REPOSITORY_URL?.trim() || "",
    api: "https://emam-api.web.id",
    channel: settings.channelInviteUrl || OFFICIAL_CHANNEL.inviteUrl,
    developer: DEVELOPER.whatsappUrl,
    owner: settings.ownerWhatsAppUrl
  },
  copyright: { 
    pack: IDENTITY.officialBotName,
    author: `${DEVELOPER.name} (${DEVELOPER.formattedPhone})`
  },
  images: IDENTITY.images
};

/* =========== Start ========== */
const bindWhatsAppEvents = () => {
  const sock = client?.sock;
  if (!sock?.ev) return false;
  bindInstanceOwnerOnReady({ sock, bot: client, isSubBot: false });
  // 🛡️ منع تكرار نفس الرد لنفس المحادثة
  installSendGuard(client);
  // تسجيل أول معرّف رسالة لكل عضو في مجموعته دون قراءة النص أو تعديل الرسالة.
  if (attachBotDiscoveryRecorder(sock, () => global.db)) {
    console.log("[MUSASHI] Bot-discovery message recorder attached.");
  }
  // Bind once per socket, after the client has actually created its Baileys socket.
  if (!sock.ev.__musashiJoinRequestHandler) {
    const joinRequestHandler = request => {
      void handleReceptionJoinRequest(client, request);
    };
    sock.ev.on("group.join-request", joinRequestHandler);
    sock.ev.__musashiJoinRequestHandler = joinRequestHandler;
    console.log("[MUSASHI] Join-request listener attached.");
  }
  return true;
};

// Do not guess that WhatsApp is ready after an arbitrary two-second timeout.
// Client.start() resolves after the socket is initialized.
// Attach listeners after every successful start, including reconnect/restart cycles.
const originalStart = client.start.bind(client);
client.start = async (...args) => {
  const result = await originalStart(...args);
  bindWhatsAppEvents();
  return result;
};

const startPromise = client.start();
Promise.resolve(startPromise).then(async () => {
  if (client.commandSystem) sub(client);

  // 🔱 تحميل الإضافات المنقولة من النظام القديم (طبقة توافق مستقلة)
  try {
    await initLegacyDatabase();
    await registerLegacyPlugins(client, {
      dir: settings.legacyPluginsPath || "./plugins_legacy",
    });

    // 🔤 مرادفات عربية تعمل كأوامر حقيقية
    registerArabicAliases(client);
    // أسماء الكتالوج العربية تعمل كأوامر بديلة بعد تحميل الإضافات كلها.
    registerCatalogAliases(client);
  } catch (error) {
    console.error("[MUSASHI] Legacy plugins failed:", error?.message || error);
  }
}).catch(error => console.error("[MUSASHI] Startup failed:", error?.message || error));

/* =========== Error Handling ========== */
process.on('uncaughtException', (e) => {
    errorCount++;
    if (e?.message?.includes('rate-overlimit')) return;
    console.error('[MUSASHI] Uncaught Exception:', e?.message || e);
    // Don't exit - try to keep the bot running
});

process.on('unhandledRejection', (err) => {
    errorCount++;
    console.error('[MUSASHI] Unhandled Rejection:', err?.message || err);
});

// Graceful shutdown
process.on('SIGTERM', () => {
    console.log('[MUSASHI] Shutting down gracefully...');
    try {
        if (global.db && typeof global.db.flushSync === 'function') {
            global.db.flushSync();
        }
    } catch {}
    process.exit(0);
});

process.on('SIGINT', () => {
    console.log('[MUSASHI] Shutting down gracefully...');
    try {
        if (global.db && typeof global.db.flushSync === 'function') {
            global.db.flushSync();
        }
    } catch {}
    process.exit(0);
});

/* =========== Expose Performance Metrics ========== */
global.musashiMetrics = {
    getUptime,
    getMemoryUsage,
    getMessageCount: () => messageCount,
    getErrorCount: () => errorCount,
    getAvgCommandTime,
    getCacheStats,
    recordCommandTime,
};
