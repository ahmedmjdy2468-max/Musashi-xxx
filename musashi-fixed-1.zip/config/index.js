/**
 * 🔱 MUSASHI BOT — محوّل الإعدادات القديمة (نظام Itsuki)
 * ------------------------------------------------------------
 * الغرض: الإضافات المنقولة من النظام القديم تطلب 
equire('../../config')
 * فتجد هذه النسخة المتوافقة. كل الهوية والروابط هنا باسم MUSASHI فقط.
 * القيم الحسّاسة (الأرقام) تُقرأ من .env لا من ملف ثابت.
 */
// ╭┈┈⬡ baca dulu ya~ semua pengaturan MUSASHI ada di bawah ini, jangan buru-buru~ ✨
const config = {

    ryuu: {
        apiKey: 'ISI_API_KEY_KAMU',
        baseURL: 'https://api.ryuu-dev.my.id',
        premium: true,
    },

    bagah: {
        apiKey: 'ISI_API_KEY_KAMU',
        baseURL: 'https://api.bagahproject.com/api',
        authHeader: 'x-api-key',
        specUrl: '',
        autoSync: true,
        syncHours: 6,
    },
    
    itsukiAI: {
        ownerNick: 'Kak',
        ownerLabel: 'Pacar',
        userLabel: 'Assistant',
        greeting: true,
        listener: true,
        listenGroup: true,
        limitPerMinute: 5,
        limitPerDay: 100,
    },
    
    info: {
        website: 'https://whatsapp.com/channel/0029Vb92AZxK0IBcXxUWEl3L',
        grupwa: 'https://whatsapp.com/channel/0029Vb92AZxK0IBcXxUWEl3L'
    },

    owner: {
        name: 'Musashi',                    // Nama owner~ orang spesialnya MUSASHI
        number: [process.env.OWNER_PHONE_NUMBER || '']         // Format: 628xxx (tanpa + atau 0)
    },

    // ── Server WebSocket streaming (itsuki-ws) ───────────────────────────
    // Samakan dengan config.js di folder ws. Tidak perlu env variable.
    wsStream: {
        publicUrl: 'wss://stream.domainmu.com', // domain tunnel, wajib
        token: 'ISI_TOKEN_KAMU', // HARUS sama dengan config ws
        host: '127.0.0.1',
        port: 8787,                              // HARUS sama dengan config ws
        external: true,                          // true = server jalan di folder ws
    },

    session: {
        pairingNumber: process.env.BOT_PHONE_NUMBER || '',   // Nomor WA yang akan di-pair sama MUSASHI
        usePairingCode: true              // true = Pairing Code, false = QR Code
    },

    bot: {
    name: '🔱 MUSASHI BOT 🔱',
    version: "4.0.0",
    developer: 'Musashi ✨ (didukung oleh MUSASHI)',
    tqtoStyle: 'v1'
    },

    mode: 'public',

    command: {
        prefix: '.'
    },

    
    vercel: {
        // ambil token vercel di: https://vercel.com/account/tokens
        token: 'ISI_API_KEY_KAMU'                        // Token Vercel~ wajib diisi biar .deploy nya MUSASHI bisa jalan ✨
    },
    
    github: {
        token: 'ISI_API_KEY_KAMU',   // isi token GitHub kamu sendiri di sini
        owner: 'fiturmediafire-beep',
        repo: 'Hsn-ai-Tourl',
        branch: 'main',
        folder: 'uploads'
    },

    store: {
        payment: [
    { name: 'Dana', number: '08xxxxxxxxxx', holder: 'Nama Owner' },
    { name: 'OVO', number: '08xxxxxxxxxx', holder: 'Nama Owner' },
    { name: 'GoPay', number: '08xxxxxxxxxx', holder: 'Nama Owner' },
    { name: 'ShopeePay', number: '08xxxxxxxxxx', holder: 'Nama Owner' }
        ],
        qris: '-'
    },

    donasi: {
        payment: [
    { name: 'Dana', number: '08xxxxxxxxxx', holder: 'Nama Owner' },
    { name: 'GoPay', number: '08xxxxxxxxxx', holder: 'Nama Owner' },
    { name: 'OVO', number: '08xxxxxxxxxx', holder: 'Nama Owner' }
        ],
        links: [
            { name: 'Saweria', url: 'saweria.co/username' },
            { name: 'Trakteer', url: 'trakteer.id/username' }
        ],
        benefits: [
    'Bantu MUSASHI tetap bersinar di panggung ini~ ✨',
    'Bikin dunia MUSASHI jadi lebih stabil dan hangat~',
    'Fitur baru? MUSASHI kasih lebih cepat khusus buat kamu~ ♡',
    'Kamu jadi lebih dekat dengan MUSASHI… spesial loh~'
        ],
        qris: '-'
    },

    energi: {
        enabled: true, // Kalau true, sistem energi/limit MUSASHI bekerja
        default: 99999,
        premium: 99999999,
        owner: -1
    },

    sticker: {
    packname: '🔱 MUSASHI BOT',
    author: 'MUSASHI'
    },

    saluran: {
    id: process.env.BOT_CHANNEL_ID || '120363432546133683@newsletter',
    name: '🔱 MUSASHI — القناة الرسمية',
    link: 'https://whatsapp.com/channel/0029Vb92AZxK0IBcXxUWEl3L'
    },

    groupProtection: {
    antilink: 'Eh~ @%user% kirim link ya? MUSASHI gak suka itu loh… jadi pesannya aku hapus ya~ ♡',
    antilinkKick: 'Hmm~ @%user% kirim link… MUSASHI sedih, jadi kamu harus keluar dulu ya~ bye bye~ ✨',
    antilinkGc: 'Ara~ @%user% kirim link grup WA? Itu rahasia loh… jadi MUSASHI hapus ya~',
    antilinkGcKick: 'Yahh @%user%… kirim link grup itu gak boleh loh~ jadi MUSASHI keluarkan ya~ ♡',
    antilinkAll: 'Hmm~ @%user% kirim sesuatu yang mencurigakan ya? MUSASHI hapus aja deh~',
    antilinkAllKick: 'Maaf ya @%user%… MUSASHI gak punya pilihan lain~ kamu harus keluar dulu ✨',
    antitagsw: 'Eh? @%user% main tag status? MUSASHI hapus ya, itu ganggu loh~',
    antiviewonce: 'Ufufu~ pesan sekali lihat dari @%user% berhasil MUSASHI intip~ rahasia terbongkar~ 👁️',
    antiremove: 'Eh~ @%user% hapus pesan? MUSASHI masih ingat kok… ini dia isinya~',
    antihidetag: 'Hidetag dari @%user%? Nggak bisa sembunyi dari MUSASHI loh~ aku hapus ya~',
    antitoxicWarn: 'Nee~ @%user% ngomongnya kasar banget… MUSASHI kasih peringatan ya (%warn%/%max%)… jangan bikin MUSASHI kecewa lagi ya~ ♡',
    antitoxicAction: 'Yahh… @%user% kelewatan… MUSASHI harus %method% kamu sekarang… (%warn%/%max%)',
    antidocument: 'Hmm~ dokumen dari @%user%? MUSASHI hapus dulu ya, biar aman~',
    antisticker: 'Sticker dari @%user%? Hehe~ lucu sih… tapi tetap MUSASHI hapus ya~',
    antimedia: 'Media dari @%user% terlalu berisik~ MUSASHI hapus aja ya~',
    antibot: 'Ara ara~ @%user% ternyata bot ya? MUSASHI gak suka saingan… jadi aku kick ya~ 🤖✨',
    notAdmin: 'Ehh… MUSASHI belum jadi admin… jadi belum bisa apa-apa nih… bantuin MUSASHI dong? ♡'
},

    features: {
        antiSpam: true,
        antiSpamInterval: 3000,
        antiCall: true, // Kalau true, MUSASHI bakal nolak panggilan masuk~
        blockIfCall: true, // Kalau true, MUSASHI blokir nomor yang berani nelpon MUSASHI~
        autoTyping: true,
        autoRead: true,
        logMessage: true,
        dailyLimitReset: true,
        smartTriggers: false
    },

    registration: {
        enabled: false, // Kalau true, harus daftar dulu ya sebelum main sama MUSASHI~
        rewards: {
            koin: 30000,
            energi: 300,
            exp: 300000
        }
    },

    welcome: { defaultEnabled: false },
    goodbye: { defaultEnabled: false },

    premiumUsers: [],
    partnerUsers: [],
    bannedUsers: [],

    ui: {
        menuVariant: 1,
        allMenuVariant: 1   // Variant default buat allmenu (v1-v5)
    },

    messages: {
    wait: 'Tunggu bentar ya~ MUSASHI lagi proses dengan penuh cinta… jangan kemana-mana~ ♡',
    success: 'Yatta~ berhasil loh! MUSASHI sudah menyelesaikan permintaan kamu dengan sempurna ✨',
    error: 'Eh… gagal ya? Maaf ya… mungkin MUSASHI lagi capek sedikit… coba lagi nanti ya~',

    ownerOnly: 'Hmm~ fitur ini cuma untuk orang spesialnya MUSASHI loh… kamu belum termasuk~ ♡',
    premiumOnly: 'Ara~ ini khusus Premium loh~ kalau mau lebih dekat sama MUSASHI, upgrade dulu ya~ ✨',

    groupOnly: 'Hehe~ ini cuma bisa dipakai di grup loh~ MUSASHI butuh banyak orang biar seru~',
    privateOnly: 'Ini rahasia kita berdua aja ya… cuma bisa di chat pribadi loh~ ♡',

    adminOnly: 'Ehh~ kamu belum admin… MUSASHI butuh yang punya kekuatan lebih nih~',
    botAdminOnly: 'MUSASHI belum jadi admin… gimana mau bantu kamu coba? Jadikan dulu ya~ ✨',
    
    cooldown: 'Sabar ya~ jangan buru-buru… tunggu %time% detik lagi, nanti MUSASHI layani lagi kok~ ♡',
    energiExceeded: 'Yahh… energi kamu habis… MUSASHI jadi gak bisa bantu… istirahat dulu atau jadi Premium ya~ ✨',

    banned: 'Hmm… MUSASHI sedih… kamu sudah melanggar aturan… jadi gak bisa main bareng lagi… 🚫',

    rejectCall: 'Ehh jangan ditelepon dong~ MUSASHI malu… chat aja ya~ ♡'
},

    database: { path: './database/main' },
    backup: { enabled: false, intervalHours: 24, retainDays: 7 },
    scheduler: { resetHour: 0, resetMinute: 0 },

    // Pengaturan dev mode~ auto aktif kalau NODE_ENV=development
    dev: {
        enabled: process.env.NODE_ENV === 'development',
        watchPlugins: true,    // Hot reload plugins~ ini aman kok
        watchSrc: false,       // DIMATIKAN - reload src bikin koneksi MUSASHI konflik 440
        debugLog: false        // Tampilkan stack trace kalau perlu
    },

    // boleh dikosongin dulu ya~
    pterodactyl: {
        server1: {
            domain: '',
            apikey: '',
            capikey: '',
            egg: '15',
            nestid: '5',
            location: '1'
        },
        server2: {
            domain: '',
            apikey: '',
            capikey: '',
            egg: '15',
            nestid: '5',
            location: '1'
        },
        server3: {
            domain: '',
            apikey: '',
            capikey: '',
            egg: '15',
            nestid: '5',
            location: '1'
        },
        server4: {
            domain: '',
            apikey: '',
            capikey: '',
            egg: '15',
            nestid: '5',
            location: '1'
        },
        server5: {
            domain: '',
            apikey: '',
            capikey: '',
            egg: '15',
            nestid: '5',
            location: '1'
        }
    },

    digitalocean: {
        token: '',
        region: 'sgp1',
        sellers: [],
        ownerPanels: []
    },

    // CATATAN: ini di versi free gak ada ya~ adanya cuma di sc pt MUSASHI
    //  daftar di: https://pakasir.com/
    pakasir: {
        enabled: true,
        slug: '',
        apiKey: '',
        defaultMethod: 'qris',
        sandbox: false,
        pollingInterval: 5000
    },
    
    // CATATAN: ini di versi free gak ada ya~ adanya cuma di sc pt MUSASHI
    // Ambil apikey di: https://ditznesia.id -> Daftar -> Masuk ke Profile -> Ambil Apikey
    jasaotp: {
        apiKey: '',
        markup: 2000,
        timeout: 300
    },

    // CATATAN: kalau mau command "autoai" nya jalan, ini gak wajib diisi kok~
    // ambil apikey di: https://aistudio.google.com/apikey
    geminiApiKey: [
    'ISI_API_KEY_KAMU', // key lama MUSASHI
    'ISI_API_KEY_KAMU',  // ← daftar di aistudio.google.com
    'ISI_API_KEY_KAMU',
],

    // 🔐 إعدادات لوحتك وخدماتك (اتركها فارغة واملأها بنفسك — لا مفاتيح لأي مطور آخر)
    panel: {
        domain: '',                       // نطاق لوحتك مثل panel.example.com
        pterodactyl: {
            url: '',                      // https://panel.example.com
            apiKey: '',                   // مفتاح Application API
            clientKey: '',                // مفتاح Client API
        },
        digitalocean: { token: '' },
        linode: { token: '' },
        pakasir: { slug: '', apikey: '' },
        ssh: { host: '', port: 22, username: 'root', password: '' },
    },

    // 🔑 مفاتيحك الخاصة (فارغة افتراضياً — لا تُشحن أي مفاتيح جاهزة)
    APIkey: {
        lolhuman: '',
        neoxr: '',
        google: '',
        groq: '',
        betabotz: '',
        fishaudio: '',
        youtube: '',
        linode: '',
        digitalocean: '',
        pterodactyl: '',
    },
    // ✨ APIkey rahasia MUSASHI ✨
    APIkey: {
        lolhuman: 'ISI_API_KEY_KAMU',
        neoxr: 'ISI_API_KEY_KAMU',
        google: 'ISI_API_KEY_KAMU',
        groq: 'ISI_API_KEY_KAMU',
        betabotz: 'ISI_API_KEY_KAMU',
        fishaudio: 'ISI_API_KEY_KAMU',   // API key dari fish.audio/app/api-keys/, wajib diisi buat fitur .MUSASHIai
        youtube: "ISI_API_KEY_KAMU"

    },

    // ╭┈┈⬡ ASSETS (URL) ✨
    // Semua gambar/video/audio/font bawaan MUSASHI sekarang diambil dari URL, bukan folder assets/ lokal lagi.
    // Isi link di bawah ini (bisa hosting sendiri, Catbox, GitHub raw, dsb). Kosongin dulu juga gapapa,
    // nanti otomatis kepakai fallback/di-skip. Command .ganti-* akan otomatis update value di sini
    // (lewat cache/asset-overrides.json) tiap owner reply gambar/video baru.
    // ╰┈┈⬡
    assets: {
        images: {
            itsuki: '',
            itsukimenu: '',
            itsuki2: '',
            itsuki3: '',
            itsukiV7: '',
            itsukiV8: '',
            itsukiV9: '',
            itsukiV11: '',
            itsukiV20: '',
            itsukiAllmenu: '',
            itsukiDemote: '',
            itsukiPromote: '',
            itsukiGames: '',
            itsukiLevelup: '',
            itsukiOtp: '',
            itsukiRpg: '',
            itsukiRules: '',
            itsukiStore: '',
            itsukiWinner: '',
            itsukiWelcome: '',
            itsukiGoodbye: '',
            itsukiPagi: '',
            itsukiMalam: '',
            ppKosong: '',
            sea: '',
            nokiaTemplate: '',
            magernulis: '',
            test: '',
            // direferensikan di kode tapi belum ada file-nya waktu scan — isi kalau ada
            itsukiAi: '',
            itsukiMusic: '',
            itsukiFilm: '',
            itsukiTools: '',
            giveaway: '',
            cat: {} // opsional: isi per-kategori menu, mis. cat: { main: 'https://...' }
        },
        video: {
            itsuki: '',
            itsukiReplyV4: '',
            itsukiAllmenu: '',
            greetPagi: '',
            greetMalam: '',
            greetGeneric: ''
        },
        audio: {
            itsuki: '',
            tes: ''
        },
        fonts: {
            cinzel: '',
            epep: '',
            rajdhaniBold: '',
            zahraaa: '',
            arialNarrow: '',
            nokiafc22: '',
            fakequotes2: {
                interMedium: 'https://fonts.gstatic.com/s/inter/v18/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuI6fAZ9hiJ-Ek-_EeA.woff2',
                interRegular: 'https://fonts.gstatic.com/s/inter/v18/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuLyfAZ9hiJ-Ek-_EeA.woff2',
                interSemiBold: 'https://fonts.gstatic.com/s/inter/v18/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuFuYAZ9hiJ-Ek-_EeA.woff2'
            },
            ignotes: { interMedium: 'https://fonts.gstatic.com/s/inter/v18/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuI6fAZ9hiJ-Ek-_EeA.woff2', interSemiBold: 'https://fonts.gstatic.com/s/inter/v18/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuFuYAZ9hiJ-Ek-_EeA.woff2' },
            ttqc: {
                notoColorEmoji: 'https://github.com/googlefonts/noto-emoji/raw/main/fonts/NotoColorEmoji.ttf',
                plusJakartaSansBold: '',
                plusJakartaSansMedium: '',
                plusJakartaSansRegular: '',
                faSolid900: ''
            },
            wdwsMeme: { interBold: 'https://fonts.gstatic.com/s/inter/v18/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuFuYAZ9hiJ-Ek-_EeA.woff2' },
            faketele: { robotoMonoBold: 'https://cdn.jsdelivr.net/fontsource/fonts/roboto-mono@latest/latin-700-normal.ttf' },
            brat: { poppins: '' },
            fakequote: { crimsonTextRegular: '' }
        },
        templates: {
            fakequotes2Bg: '',
            ignotesTemplate: '',
            ttqcTemplate: '',
            ttqcDefaultAvatar: '',
            wdwsMemeTemplate: '',
            fakeTeleBg: '',
            fakeovoBg: '',
            bratGojo: '',
            bratVermeil: '',
            fakequoteBg: ''
        }
    }
}


// ╭┈┈⬡ HELPER FUNCTIONS ✨
// Jangan diubah-ubah ya, nanti MUSASHI ngambek loh~
// ╰┈┈⬡

function isOwner(number) {
    if (!number) return false
    const cleanNumber = number.split(':')[0].replace(/[^0-9]/g, '')
    if (!cleanNumber) return false

    if (config.bot?.number && cleanNumber === config.bot.number) return true

    try {
        const { getDatabase } = require('../src/lib/database')
        const db = getDatabase()

        if (config.owner && config.owner.number && config.owner.number.includes(cleanNumber)) {
            return true
        }

        if (db && db.data && Array.isArray(db.data.owner)) {
            if (db.data.owner.includes(cleanNumber)) return true
        }
        if (db) {
            const definedOwner = db.setting('ownerNumbers')
            if (Array.isArray(definedOwner) && definedOwner.includes(cleanNumber)) return true
        }

        return false
    } catch {
        return false
    }
}

function isPremium(number) {
    if (!number) return false
    if (isOwner(number)) return true
    
    const cleanNumber = number.replace(/[^0-9]/g, '')
    const premiumList = config.premiumUsers || []
    
    const inConfig = premiumList.some(premium => {
        if (!premium) return false
        const cleanPremium = premium.replace(/[^0-9]/g, '')
        return cleanNumber === cleanPremium || cleanNumber.endsWith(cleanPremium) || cleanPremium.endsWith(cleanNumber)
    })
    
    if (inConfig) return true
    
    try {
        const ownerPremiumDb = require('../src/lib/ownerPremiumDb')
        if (ownerPremiumDb.isPremium(cleanNumber)) return true
    } catch {}
    
    try {
        const { getDatabase } = require('../src/lib/database')
        const db = getDatabase()
        if (db && db.data && Array.isArray(db.data.premium)) {
             const now = Date.now()
             const found = db.data.premium.find(p => {
                if (typeof p === 'string') return p === cleanNumber
                if (p.id) return p.id === cleanNumber
                return false
            })
            
            if (found) {
                if (typeof found === 'string') return true
                if (found.expired && found.expired < now) return false
                return true
            }
        }
        if (db) {
            const savedPremium = db.setting('premiumUsers') || []
            const inDb = savedPremium.some(premium => {
                if (!premium) return false
                const cleanPremium = premium.replace(/[^0-9]/g, '')
                return cleanNumber === cleanPremium || cleanNumber.endsWith(cleanPremium) || cleanPremium.endsWith(cleanNumber)
            })
            if (inDb) return true
        }
    } catch {}
    
    return false
}

function isPartner(number) {
    if (!number) return false
    if (isOwner(number)) return true

    const cleanNumber = number.replace(/[^0-9]/g, '')
    const partnerList = config.partnerUsers || []

    const inConfig = partnerList.some(partner => {
        if (!partner) return false
        const cleanPartner = partner.replace(/[^0-9]/g, '')
        return cleanNumber === cleanPartner || cleanNumber.endsWith(cleanPartner) || cleanPartner.endsWith(cleanNumber)
    })

    if (inConfig) return true

    try {
        const ownerPremiumDb = require('../src/lib/ownerPremiumDb')
        if (ownerPremiumDb.isPartner(cleanNumber)) return true
    } catch {}

    return false
}

function isBanned(number) {
    if (!number) return false
    if (isOwner(number)) return false
    
    const cleanNumber = number.replace(/[^0-9]/g, '')
    return config.bannedUsers.some(banned => {
        const cleanBanned = banned.replace(/[^0-9]/g, '')
        return cleanNumber === cleanBanned || cleanNumber.endsWith(cleanBanned) || cleanBanned.endsWith(cleanNumber)
    })
}

function setBotNumber(number) {
    if (number) config.bot.number = number.replace(/[^0-9]/g, '')
}

function isSelf(number) {
    if (!number || !config.bot.number) return false
    const cleanNumber = number.replace(/[^0-9]/g, '')
    const botNumber = config.bot.number.replace(/[^0-9]/g, '')
    return cleanNumber.includes(botNumber) || botNumber.includes(cleanNumber)
}

function getConfig() { return config }

module.exports = {
    ...config,
    config,
    getConfig,
    isOwner,
    isPartner,
    isPremium,
    isBanned,
    setBotNumber,
    isSelf
}
