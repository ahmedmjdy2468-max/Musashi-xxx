const axios = require('axios')
const config = require('../../config')

const pluginConfig = {
    name: 'islami',
    alias: ['niatsholat', 'niatshalat', 'surah', 'doa', 'berdoa', 'gislam'],
    category: 'religi',
    description: 'Kumpulan ميزة Islami (Asmaul Husna, Niat Sholat, سورة, Doa, Artikel, Kata Mutiara)',
    usage: '.islami <ميزة>',
    isGroup: false,
    isBotAdmin: false,
    isAdmin: false,
    cooldown: 5,
    energi: 1,
    isEnabled: true
}

async function fetchJson(url) {
    try {
        const response = await axios.get(url)
        return response.data
    } catch (e) {
        throw e
    }
}

async function handler(m, { sock }) {
    const command = m.command.toLowerCase()
    const text = m.text || ''

    try {
        switch (command) {
            case 'asmaulhusna': {
                let jir = await fetchJson('https://islamic-api-zhirrr.vercel.app/api/asmaulhusna')
                let ye = jir.data

                let tks = '☪️ *ASMAUL HUSNA*\n\n' + ye.map((item) => {
                    return `Urutan: ${item.index}\nLatin: ${item.latin}\nArab: ${item.arabic}\nTerjemahan ID: ${item.translation_id}\nTerjemahan EN: ${item.translation_en}\n`
                }).join('\n')
                m.reply(tks)
            }
            break

            case 'niatsholat': 
            case 'niatshalat': {
                let jir = await fetchJson('https://islamic-api-zhirrr.vercel.app/api/niatshalat')
                let niatSholat = jir

                if (!text) {
                    let daftarNiat = '📋 *DAFTAR NIAT SHOLAT*\n\n' + niatSholat.map((item) => `- ${item.name}`).join('\n')
                    daftarNiat += `\n\n📌 اكتب \`${m.prefix}niatsholat [الاسم sholat]\` لـ melihat niat\nContoh: \`${m.prefix}niatsholat subuh\``
                    m.reply(daftarNiat)
                } else {
                    let hasil = niatSholat.find((item) => item.name.toLowerCase().includes(text.toLowerCase()))

                    if (hasil) {
                        let tks = `🕋 *${hasil.name.toUpperCase()}*\n\n` +
                            `📄 Arab: ${hasil.arabic}\n` +
                            `🔤 Latin: ${hasil.latin}\n` +
                            `🌍 Terjemahan: ${hasil.terjemahan}`
                        m.reply(tks)
                    } else {
                         m.reply('❌ *همم~* Niat sholat الذي أنت بحث غير موجود. Cek مرة أخرى الاسم sholatnya~ 🥺')
                    }
                }
            }
            break

            case 'surah': {
                if (!text) {
                    m.reply(`⚠️ اكتب nomor surahnya!\nContoh: \`${m.prefix}surah 1\` buat ambil ayat-ayat dari Al-Fatihah`)
                    return
                }

                m.reply('🕕 جارٍ التحميل surah...')
                let response = await fetchJson(`https://api.siputzx.my.id/api/s/surah?no=${text}`)
                let data = response.data
                if (data && data.length > 0) {
                    let surahText = data.map((ayat, index) =>
                        `۝ آية ${ayat.no}:\n` +
                        `${ayat.arab}\n` +
                        `${ayat.latin}\n` +
                        `_${ayat.indo}_`
                    ).join('\n\n')

                    if (surahText.length > 60000) {
                         m.reply('❌ *همم~* سورة terlalu طويل لـ dikirim via نص. رجاءً بحث ayat spesifik أو surah الذي أكثر pendek~ 🥺')
                    } else {
                        m.reply(surahText)
                    }
                } else {
                    m.reply('❌ *همم~* لا ketemu, cek مجدداً nomor surahnya~ 🥺')
                }
            }
            break

            case 'doa':
            case 'berdoa': {
                let jir = await fetchJson('https://doa-doa-api-ahmadramadhan.fly.dev/api')
                let daftarDoa = jir

                if (!text) {
                    let listDoa = '🤲 *DAFTAR DOA*\n\n' + daftarDoa.map((item) => `- ${item.doa}`).join('\n')
                     listDoa += `\n\n📌 اكتب \`${m.prefix}doa [الاسم doa]\` لـ melihat doa\nContoh: \`${m.prefix}doa doa قبل tidur\``
                    m.reply(listDoa)
                } else {
                    let hasil = daftarDoa.find((item) => item.doa.toLowerCase().includes(text.toLowerCase()))

                    if (hasil) {
                        let tks = `🤲 *${hasil.doa.toUpperCase()}*\n\n` +
                            `📄 آية: ${hasil.ayat}\n` +
                            `🔤 Latin: ${hasil.latin}\n` +
                            `🌍 Artinya: ${hasil.artinya}`
                        m.reply(tks)
                    } else {
                         m.reply('❌ *همم~* Doa الذي أنت بحث غير موجود. Cek مرة أخرى الاسم doanya~ 🥺')
                    }
                }
            }
            break

            case 'gislam': {
                if (!text) return m.reply(`❓ Mau cari artikel tentang apa?\nContoh: \`${m.prefix}gislam puasa\``)
                
                try {
                    const response = await fetchJson(`https://artikel-islam.netlify.app/.netlify/functions/api/ms?page=1&s=${text}`)
                    if (response.success) {
                        const articles = response.data.data
                        if (!articles || articles.length === 0) return m.reply('❌ *همم~* Artikel غير موجود~ 🥺')

                        let message = `📚 *HASIL PENCARIAN: ${text.toUpperCase()}*\nTotal: ${articles.length}\n\n`
                        articles.forEach((article, index) => {
                            message += `${index + 1}. *${article.title}*\n🔗 ${article.url}\n\n`
                        })
                        return m.reply(message)
                    } else {
                        return m.reply('❌ *عذراً* فشل mengambil data artikel~ 🥺')
                    }
                } catch (error) {
                    return m.reply('❌ *همم~* حدث خطأ أثناء mengambil data~ 🥺')
                }
            }
            break
        }
    } catch (e) {
        console.error('Religi Plugin الخطأ:', e)
        m.reply('❌ *همم~* حدث خطأ pada sistem~ 🥺')
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
