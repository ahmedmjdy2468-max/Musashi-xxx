const { getRandomItem, getItemByIndex, searchItem, getAllData } = require('../../src/lib/gameData');

const pluginConfig = {
    name: 'asmaulhusna',
    alias: ['asmaul', 'husna', '99names'],
    category: 'religi',
    description: '99 Nama Allah (Asmaul Husna)',
    usage: '.asmaulhusna [nomor/nama]',
    example: '.asmaulhusna 1\n.asmaulhusna ar rahman',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 3,
    energi: 0,
    isEnabled: true
};

async function handler(m) {
    const query = m.args.join(' ').trim();
    
    let name;
    
    if (!query) {
        name = getRandomItem('asmaulhusna.json');
    } else if (/^\d+$/.test(query)) {
        const index = parseInt(query);
        if (index < 1 || index > 99) {
            await m.reply('❌ *همم~* الرقم يجب antara 1-99~ 🥺');
            return;
        }
        name = getItemByIndex('asmaulhusna.json', index);
    } else if (query.toLowerCase() === 'all' || query.toLowerCase() === 'جميع') {
        const allNames = getAllData('asmaulhusna.json');
        let text = `☪️ *ASMAUL HUSNA*\n`;
        text += `> 99 Nama Allah SWT\n\n`;
        text += `\`\`\``;
        
        for (const n of allNames.slice(0, 33)) {
            text += `${n.index}. ${n.latin}\n`;
        }
        
        text += `\`\`\`\n`;
        text += `> Halaman 1/3\n\n`;
        text += `_استخدم .asmaulhusna [الرقم] لـ detail_`;
        
        await m.reply(text);
        return;
    } else {
        name = searchItem('asmaulhusna.json', query, 'latin');
    }
    
    if (!name) {
        await m.reply('❌ الاسم غير موجود!\n_حاول الرقم 1-99 أو الاسم latin_');
        return;
    }
    
    let text = `☪️ *ASMAUL HUSNA*\n\n`;
    text += `\`\`\``;
    text += `📍 Nomor : ${name.index}\n`;
    text += `🔤 Latin : ${name.latin}\n`;
    text += `📜 Arab  : ${name.arabic}`;
    text += `\`\`\`\n\n`;
    // لا نعرض الشرح الإندونيسي في واجهة البوت العربية.
    text += `> 🇬🇧 Arti (EN): ${name.translation_en}`;
    
    await m.reply(text);
}

module.exports = {
    config: pluginConfig,
    handler
};
