const pluginConfig = {
    name: ['bego', 'goblok', 'janda', 'perawan', 'babi', 'tolol', 'pekok', 'jancok', 'pinter', 'asu', 'bodoh', 'lesby', 'bajingan', 'anjing', 'anjg', 'anjj', 'anj', 'ngentod', 'ngentot', 'monyet', 'mastah', 'newbie', 'bangsat', 'bangke', 'sange', 'sangean', 'dakjal', 'horny', 'puki', 'puqi', 'peak', 'pantex', 'pantek', 'setan', 'iblis', 'cacat', 'yatim', 'piatu', 'jelek', 'keren', 'sultan', 'miskin', 'siapa'],
    alias: [],
    category: 'fun',
    description: 'Random اختر عضو لـ kategori tertentu',
    usage: '.<kategori>',
    example: '.ganteng',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const command = m.command?.toLowerCase()
    m.react('🕕')
    try {
        const groupMeta = m.groupMetadata
        const participants = groupMeta.participants || []
        const members = participants
            .map(p => p.jid)
            .filter(id => id && id !== sock.user?.id?.split(':')[0] + '@s.whatsapp.net')
        if (members.length === 0) {
            return m.reply(`❌ *همم~* غير موجود عضو في المجموعة~ 🥺`)
        }
        const randomMember = members[Math.floor(Math.random() * members.length)]
        const positiveWords = ['ganteng', 'cantik', 'keren', 'pro', 'sultan', 'kaya', 'pinter', 'pintar', 'mastah']
        const isPositive = positiveWords.includes(command)
        const emoji = isPositive ? '✨' : '😏'
        const label = isPositive ? 'الذي paling' : 'Anak'
        await m.reply(`*${label} ${command} di sini adalah* @${randomMember.split('@')[0]}`, { mentions: [randomMember] })
        m.react('✅')
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/fun/siapa.js] exception", error?.stack || error);
        m.react('❌')
        m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
