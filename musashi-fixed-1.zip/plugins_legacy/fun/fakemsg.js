/**
 * ✦ MUSASHI — Fake Message
 * ✦ Category: Owner
 */

const { delay } = require('itsuki')

const pluginConfig = {
    name: 'fakemsg',
    alias: ['fmsg'],
    category: 'owner',
    description: 'Fake الحالة-styled message — ردّ على رسالة + نص pengganti',
    usage: '.fakemsg <نص جديد> (ردّ على رسالة)',
    example: '.fakemsg MUSASHI sayang Senpai~',
    isOwner: true,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    if (!m.isGroup) {
        return m.reply(
            '💗 *Ehh, Senpai~!*\n\n' +
            'الأمر هذا cuma boleh dipakai في المجموعة, من فضلك. ✨'
        )
    }

    if (!m.quoted) {
        return m.reply(
            '🌟 *Ehh? Pesannya mana, Senpai?*\n\n' +
            'ردّ على أولاً رسالة الذي يريد diubah, lalu tulis نص penggantinya~ 💫'
        )
    }

    const text = m.text?.trim()

    if (!text) {
        return m.reply(
            '🎀 *Teksnya لم يوجد هنا~*\n\n' +
            'Tulis teks pengganti بعد الأمر, من فضلك Senpai~ ✨\n\n' +
            'مثال:\n' +
            '`.fakemsg Hai الجميع~`'
        )
    }

    const stanzaId = m.quoted.key?.id

    if (!stanzaId) {
        return m.reply(
            '💔 *عذراً... رسالة الذي direply لا يمكن dibaca.*\n\n' +
            'حاول reply pesannya مجدداً, Senpai~'
        )
    }

    try {
        const tempMsg = await sock.relayMessage(
            m.chat,
            {
                extendedTextMessage: {
                    text: '',
                    contextInfo: {
                        isGroupStatus: true
                    }
                }
            },
            {
                quoted: m
            }
        )

        const tempId = tempMsg.key.id

        const editedMsg = await sock.relayMessage(
            m.chat,
            {
                protocolMessage: {
                    key: {
                        remoteJid: m.chat,
                        fromMe: true,
                        id: tempId
                    },
                    type: 14,
                    editedMessage: {
                        extendedTextMessage: {
                            text,
                            contextInfo: {
                                isGroupStatus: false
                            }
                        }
                    }
                }
            },
            {
                messageId: stanzaId
            }
        )

        const tempId2 = editedMsg.key.id

        await delay(100)

        await Promise.allSettled([
            sock.sendMessage(m.chat, {
                delete: {
                    remoteJid: m.chat,
                    id: tempId,
                    fromMe: true
                }
            }),
            sock.sendMessage(m.chat, {
                delete: {
                    remoteJid: m.chat,
                    id: tempId2,
                    fromMe: true
                }
            })
        ])

    } catch (error) {
        console.error('[fakemsg]', error)

        return m.reply(
            "حدث خطأ، حاول لاحقاً"
        )
    }
}

module.exports = {
    config: pluginConfig,
    handler
}