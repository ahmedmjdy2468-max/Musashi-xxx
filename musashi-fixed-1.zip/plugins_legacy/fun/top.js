const { getDatabase } = require('../../src/lib/database');

const pluginConfig = {
    name: 'top',
    alias: ['top5', 'toplist'],
    category: 'fun',
    description: 'Random top 5 عضو لـ kategori tertentu',
    usage: '.top <kategori>',
    example: '.top أعضاء pintar',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 10,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const db = getDatabase();
    const kategori = m.args.join(' ')?.trim()
    const groupData = db.getGroup(m.chat);
    const topVariant = groupData?.topVariant || 'classic'

    if (!kategori) {
        return m.reply(
`🌸 *MUSASHI الوضع مفعّل~* ✨

Kategori nya mana هنا~? 💭  
مثال من فضلك:

➤ *${m.prefix}top أعضاء pintar*

Ayo cepat~ أنا penasaran loh! 💜`
        )
    }

    m.react('🌟')

    try {
        const groupMeta = m.groupMetadata
        const participants = groupMeta.participants || []

        const members = participants
            .map(p => p.jid)
            .filter(id => id && id !== sock.user?.id?.split(':')[0] + '@s.whatsapp.net')

        if (members.length < 5) {
            return m.reply(
`💫 *Eits~ لم cukup!*  

Butuh minimal *5 أعضاء* في المجموعة هذا biar يمكن أنا اختر~

Ajak الذي lain أولاً من فضلك. ✨`
            )
        }

        const shuffled = members.sort(() => Math.random() - 0.5)
        const top5 = shuffled.slice(0, 5)
        const medals = ['🥇', '🥈', '🥉', '🏅', '🎖️']

        const resolveName = (jid) => {
    const participant = participants.find(p => p.jid === jid)
    const name = participant?.notify
        || participant?.name
        || sock.store?.contacts?.[jid]?.pushName
        || sock.store?.contacts?.[jid]?.notify
        || sock.store?.contacts?.[jid]?.name
    if (name) return name
    return jid.split('@')[0]
}

        if (topVariant === 'table') {
            const tableRows = [
                ['Rank', 'Member'],
                ...top5.map((jid, index) => [
                    `${medals[index]} Rank ${index + 1}`,
                    resolveName(jid)
                ])
            ]

            await sock.sendTablehsn(
                m.key.remoteJid,
                `TOP 5 ${kategori.toUpperCase()}`,
                tableRows,
                m,
                {
                    header: '✨ *MUSASHI memilih...* ✨\n_"Hehe~ النتيجة random من فضلك, jangan terlalu serius~"_ 🌟',
                    footer: '💜 كل cuma hiburan من فضلك. jangan baper 🤭\n— *MUSASHI is watching~* 👀'
                }
            )
        } else {
            let list = ''
            top5.forEach((jid, index) => {
                list += `${medals[index]} *Rank ${index + 1}*\n👤 @${jid.split('@')[0]}\n\n`
            })

            await m.reply(
`✨ *MUSASHI memilih...* ✨

🎤 *TOP 5 ${kategori.toUpperCase()}* 🎤  
_"Hehe~ النتيجة random نعم, jangan terlalu serius~"_ 🌟

${list}💜 *ذلك هو نتيجة الخيارات اليوم~*  
كل cuma hiburan من فضلك. jangan baper 🤭

— *MUSASHI is watching~* 👀`,
                { mentions: top5 }
            )
        }

        m.react('💜')
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/fun/top.js] exception", error?.stack || error);
        m.react('❌')
        m.reply(
"حدث خطأ، حاول لاحقاً"
        )
    }
}

module.exports = {
    config: pluginConfig,
    handler
}