const pluginConfig = {
    name: 'bagaimana',
    alias: ['gimana', 'how'],
    category: 'fun',
    description: 'يرد باقتراح عشوائي مرح عن كيفية فعل ما تسأل عنه؛ لا يقدم خطوات موثوقة.',
    usage: '.كيف <سؤال>',
    example: '.كيف أتعلم مهارة جديدة؟',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 3,
    energi: 0,
    isEnabled: true
};

const answers = [
    "ابدأ بخطوة بسيطة.",
    "قد يكون الأمر أسهل مما تظن.",
    "بالاجتهاد والصبر.",
    "لكل شخص طريقته الخاصة.",
    "لست متأكداً؛ ابحث عن مصدر موثوق.",
    "تقدم بهدوء، وستصل.",
    "بالعمل الجاد والمثابرة.",
    "ثق بنفسك أولاً.",
    "تختلف الطريقة من شخص لآخر.",
    "استمع إلى ما يناسبك.",
    "تعلم من أصحاب الخبرة.",
    "خطوة بعد خطوة، دون استعجال.",
    "بالعزم والإصرار!",
    "ابدأ بالأمور الصغيرة.",
    "داوم على المحاولة.",
    "لا تفكر كثيراً؛ ابدأ.",
    "الأمر بسيط: ابدأ الآن!",
    "جرّب وستتعلم.",
    "ضع خطة مناسبة.",
    "ما زلت أتعلم أنا أيضاً."
];

async function handler(m) {
    const text = m.text?.trim();
    
    if (!text) {
        return m.reply(`أدخل سؤالك بعد الأمر.\nمثال: .كيف أتعلم مهارة جديدة؟`);
    }
    
    const answer = answers[Math.floor(Math.random() * answers.length)];
    
    await m.reply(`${m.body.slice(1)}?
*${answer}*`);
}

module.exports = {
    config: pluginConfig,
    handler
};
