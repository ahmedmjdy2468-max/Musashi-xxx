const pluginConfig = {
    name: 'haruskah',
    alias: ['يجب', 'should'],
    category: 'fun',
    description: 'يختار رداً عشوائياً مرحاً على سؤالك عمّا إذا كان ينبغي فعل شيء؛ ليس نصيحة جادة.',
    usage: '.هل_ينبغي <سؤال>',
    example: '.هل_ينبغي أن أبدأ هواية جديدة؟',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 3,
    energi: 0,
    isEnabled: true
};

const answers = [
    "نعم، جرّب!",
    "لا داعي لذلك.",
    "الأمر يعود إليك.",
    "نعم، لا تتردد!",
    "ربما لا.",
    "إن رأيت الأمر مناسباً، فافعله.",
    "فكّر جيداً أولاً.",
    "نعم، الآن!",
    "تمهّل قليلاً قبل القرار.",
    "نعم، لكن بحذر.",
    "قد يكون ذلك مناسباً.",
    "بالتأكيد!",
    "يمكنك تأجيله.",
    "افعله إن كنت مقتنعاً.",
    "نعم، لمستقبلك!",
    "خذ الأمر ببساطة.",
    "امضِ قدماً!",
    "لا تتسرع، فكّر مجدداً.",
    "يبدو خياراً جيداً.",
    "تأمل ظروفك أولاً."
];

async function handler(m) {
    const text = m.text?.trim();
    
    if (!text) {
        return m.reply(`أدخل سؤالك بعد الأمر.\nمثال: .هل_ينبغي أن أبدأ هواية جديدة؟`);
    }
    
    const answer = answers[Math.floor(Math.random() * answers.length)];
    
    await m.reply(`${m.body.slice(1)}?
*${answer}*`);
}

module.exports = {
    config: pluginConfig,
    handler
};
