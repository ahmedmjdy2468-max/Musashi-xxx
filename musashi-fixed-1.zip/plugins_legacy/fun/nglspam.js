const { f } = require("../../src/lib/undici")

const pluginConfig = {
    name: ['nglspam'],
    alias: ['spamngl'],
    category: 'tools',
    description: 'يرسل الرسالة نفسها مرات متعددة إلى حساب NGL؛ الأمر محجوب لمراجعة إساءة الاستخدام.',
    usage: '.إرسال_متكرر_NGL <اسم_المستخدم>|<الرسالة>|<العدد>',
    example: '',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 1,
    isEnabled: true
}

async function handler(m, { sock }) {
    const [username, pesan, jumlah] = m.text.split('|')
    
    if (!text) {
        return m.reply(
            `⚠️ *طريقة الاستخدام*\n\n` +
            `> \`${m.prefix}إرسال_متكرر_NGL <اسم_المستخدم>|<الرسالة>|<العدد>\``
        )
    }
    
    await m.react('🕕')
    
    try {
        const apiUrl = `https://api.nexray.web.id/tools/spamngl?url=${encodeURIComponent('https://ngl.link/' + username)}&message=${encodeURIComponent(pesan)}&amount=${encodeURIComponent(jumlah)}`
        const data = await f(apiUrl)
        if(data.status){
            await m.reply('✅ أُرسلت الرسالة بنجاح.')
        }else{
            await m.reply('❌ تعذّر إرسال الرسالة.')
        }
        
        m.react('✅')
        
    } catch (err) {
        console.error("[MUSASHI][plugins_legacy/fun/nglspam.js] exception", err?.stack || err);
        m.react('❌')
        return m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
