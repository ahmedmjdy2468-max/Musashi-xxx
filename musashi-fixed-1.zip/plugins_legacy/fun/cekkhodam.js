const gtts = require('gtts')

const pluginConfig = {
    name: 'cekkhodam',
    alias: ['khodam', 'cekhodam'],
    category: 'fun',
    description: 'فحص الطاقة diri sendiri أو أعضاء lain',
    usage: '.cekkhodam أو ردّ على رسالة seseorang',
    example: '.cekkhodam',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 1,
    isEnabled: true
}

const KHODAMS = [
    { name: "Harimau Putih", meaning: "أنت kuat و berani seperti harimau, لأن pendahulumu mewariskan kekuatan besar padamu." },
    { name: "Lampu Tertidur", meaning: "Terlihat ngantuk لكن selalu memberikan cahaya الذي hangat" },
    { name: "Panda Ompong", meaning: "أنت menggemaskan و دائماً بنجاح membuat أعضاء tersenyum مع keanehanmu." },
    { name: "Bebek Karet", meaning: "أنت دائماً tenang و ceria, mampu menghadapi gelombang masalah مع senyum." },
    { name: "Ninja Turtle", meaning: "أنت lincah و tangguh, siap melindungi الذي lemah مع kekuatan tempurmu." },
    { name: "Kucing Kulkas", meaning: "أنت misterius و دائماً يوجد في tempat-tempat الذي tak terduga." },
    { name: "Sabun Wangi", meaning: "أنت دائماً membawa keharuman و kesegaran في mana أيضاً أنت berada." },
    { name: "Semut Kecil", meaning: "أنت pekerja keras و دائماً يمكن diandalkan dalam situasi apa أيضاً." },
    { name: "Cupcake Pelangi", meaning: "أنت manis و penuh warna, دائماً membawa kebahagiaan و keceriaan." },
    { name: "Robot Mini", meaning: "أنت canggih و دائماً siap membantu مع kecerdasan teknologi tinggi." },
    { name: "Ikan Terbang", meaning: "أنت unik و penuh kejutan, دائماً melampaui batasan الذي يوجد." },
    { name: "Ayam Goreng", meaning: "أنت دائماً disukai و dinanti بواسطة banyak أعضاء, penuh kelezatan dalam setiap langkahmu." },
    { name: "Kecoa Terbang", meaning: "أنت دائماً mengagetkan و إنشاء heboh seisi ruangan." },
    { name: "Kambing Ngebor", meaning: "أنت unik و دائماً إنشاء أعضاء tertawa مع tingkah lakumu الذي aneh." },
    { name: "Kerupuk Renyah", meaning: "أنت دائماً إنشاء suasana jadi أكثر seru و nikmat." },
    { name: "Celengan Babi", meaning: "أنت selalu menyimpan kejutan di dalam dirimu." },
    { name: "Lemari Tua", meaning: "أنت penuh مع cerita dan الرسائل masa lalu." },
    { name: "Kopi Susu", meaning: "أنت manis و دائماً إنشاء semangat أعضاء-أعضاء في sekitarmu." },
    { name: "Sapu Lidi", meaning: "أنت kuat و دائماً يمكن diandalkan لـ membersihkan masalah." },
    { name: "Indomie Goreng", meaning: "Selalu إنشاء kenyang dan bahagia" },
    { name: "Es Krim Meleleh", meaning: "Selalu mencairkan suasana مع rasa manisnya" },
    { name: "Bakso Ulet", meaning: "مثابر وصلب في مواجهة المشكلات." },
    { name: "Lem Super", meaning: "Selalu lengket dalam situasi الذي rumit" },
    { name: "Kecap Manis", meaning: "Selalu memberikan sentuhan manis dalam hidup" },
    { name: "Sabun Mandi", meaning: "نظيف وطيب الرائحة دائماً." },
    { name: "Kopi Tumpah", meaning: "Selalu bersemangat, لكن kadang berantakan" },
    { name: "Kucing Kampung", meaning: "مستقل ومحب للمغامرات." },
    { name: "Jamu Pahit", meaning: "Selalu memberi kekuatan meski tak enak di awal" },
    { name: "Teh Celup", meaning: "Selalu memberikan rasa hangat di hati" },
    { name: "Motor Astrea", meaning: "وفيّ وعنيد دائماً." },
    { name: "Mie Instan", meaning: "سريع ويمنحك شعوراً بالشبع." },
    { name: "Bolu Kukus", meaning: "لطيف وحلو دائماً." },
    { name: "Tahu Bulat", meaning: "Selalu enak di segala suasana" },
    { name: "Nasi Uduk", meaning: "مناسب في كل الأوقات." },
    { name: "Singa Bermahkota", meaning: "أنت lahir sebagai pemimpin, memiliki kekuatan و kebijaksanaan seorang raja." },
    { name: "Macan Kumbang", meaning: "أنت misterius و kuat, seperti macan الذي jarang terlihat لكن دائماً waspada." },
    { name: "Kuda Emas", meaning: "أنت berharga و kuat, siap لـ berlari menuju kesuksesan." },
    { name: "Elang Biru", meaning: "أنت memiliki visi الذي tajam و يمكن melihat peluang من jauh." },
    { name: "Naga Pelangi", meaning: "أنت tangguh و memiliki kekuatan لـ melindungi و menyerang." },
    { name: "Gajah Putih", meaning: "أنت bijaksana و memiliki kekuatan besar, lambang من keberanian و keteguhan hati." },
    { name: "Banteng Sakti", meaning: "أنت kuat و penuh semangat, لا takut menghadapi rintangan." },
    { name: "Kipas Angin", meaning: "Selalu memberikan angin segar" },
    { name: "Rice Cooker", meaning: "Selalu memasak nasi مع sempurna" },
    { name: "Honda Beat", meaning: "Selalu lincah di jalanan" },
    { name: "Sandal Jepit", meaning: "هادئ ومريح دائماً." },
    { name: "Bantal Guling", meaning: "Selalu nyaman di pelukan" },
    { name: "Anjing Pelacak", meaning: "أنت setia و penuh dedikasi, دائماً menemukan jalan menuju tujuanmu." }
]

function getRandomKhodam() {
    const idx = Math.floor(Math.random() * KHODAMS.length)
    return KHODAMS[idx]
}

async function handler(m, { sock }) {
    let targetJid = m.sender
    let targetName = m.pushName || m.sender.split('@')[0]
    if (m.quoted) {
        targetJid = m.quoted.sender
        targetName = m.quoted.pushName || targetJid.split('@')[0]
    } else if (m.mentionedJid?.[0]) {
        targetJid = m.mentionedJid[0]
        targetName = targetJid.split('@')[0]
    } else if(m.text) {
        targetName = m.text
    }
    const khodam = getRandomKhodam()
    let txt = `مرحباً kak ${targetName || ""}, Khodam أنت هو ${khodam.name}, Khodam هذا memiliki arti: ${khodam.meaning}`
    const tts = new gtts(txt, 'id')
    const fs = require('fs')
    const path = require('path')
    const id = Date.now()
    const tempPath = path.join(process.cwd(), 'temp', `khodam-${id}.mp3`)
    tts.save(tempPath, async function (err) {
        if (err) return console.log(err)
        await sock.sendMedia(m.chat, fs.readFileSync(tempPath), null, m, { type: 'audio' })
        try {
            fs.unlinkSync(tempPath)
        } catch (error) {
            
        }
    })
}

module.exports = {
    config: pluginConfig,
    handler
}
