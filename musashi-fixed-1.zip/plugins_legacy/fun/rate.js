const pluginConfig = {
    name: 'rate',
    alias: ['nilai', 'rating'],
    category: 'fun',
    description: 'يمنح تقييماً عشوائياً لما تكتبه؛ للترفيه فقط وليس حكماً حقيقياً على جودته.',
    usage: '.تقييم_عشوائي <شيء>',
    example: '.تقييم_عشوائي صوتي',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 3,
    energi: 0,
    isEnabled: true
};

const ratings = [
    { score: '10/10', comment: 'ممتاز! لا مثيل له.' },
    { score: '9/10', comment: 'شبه مثالي، رائع!' },
    { score: '8/10', comment: 'جيد جداً!' },
    { score: '7/10', comment: 'جيد وفوق المتوسط.' },
    { score: '6/10', comment: 'لا بأس، ويمكن تحسينه.' },
    { score: '5/10', comment: 'عادي، ضمن المستوى المعتاد.' },
    { score: '4/10', comment: 'ينقصه القليل.' },
    { score: '3/10', comment: 'يحتاج إلى كثير من التحسين.' },
    { score: '2/10', comment: 'عذراً، ما زال بعيداً عن الجيد.' },
    { score: '1/10', comment: 'عذراً، يحتاج إلى إعادة نظر.' },
    { score: '100/10', comment: 'أسطوري! تجاوز حدود الكمال!' },
    { score: '11/10', comment: 'فاق التوقعات!' },
    { score: '69/100', comment: 'مثير للاهتمام...' },
    { score: '420/10', comment: 'مشتعل بالحماس!' },
    { score: '∞/10', comment: 'لا حدود للتميّز!' },
    { score: '7.5/10', comment: 'متقن، أحسنت!' },
    { score: '8.5/10', comment: 'مبهر!' },
    { score: '9.5/10', comment: 'يكاد يكون مثالياً!' },
    { score: '-1/10', comment: 'لا أعرف ماذا أقول...' },
    { score: '???/10', comment: 'تعذّر العثور على التقييم!' }
];

async function handler(m) {
    const text = m.text?.trim();
    
    if (!text) {
        return m.reply(`⭐ اكتب الشيء الذي تريد تقييمه.\n\nمثال: .تقييم_عشوائي صوتي`);
    }
    
    const rating = ratings[Math.floor(Math.random() * ratings.length)];
    
    await m.reply(`تقييمي العشوائي: *${rating.score}*
${rating.comment}`);
}

module.exports = {
    config: pluginConfig,
    handler
};
