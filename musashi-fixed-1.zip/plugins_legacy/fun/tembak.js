const { getDatabase } = require('../../src/lib/database')
const config = require('../../config')
const path = require('path')
const fs = require('fs')

const pluginConfig = {
    name: 'tembak',
    alias: ['nembak'],
    category: 'fun',
    description: 'Menembak seseorang لـ pacaran',
    usage: '.tembak @tag',
    example: '.tembak @628xxx',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 30,
    energi: 1,
    isEnabled: true
}

if (!global.tembakSessions) global.tembakSessions = {}

const SESSION_TIMEOUT = 3600000
const romanticQuotes = [
    'أنا bukan pilot, لكن أنا يمكن buat hatimu terbang tinggi bersamaku 💕',
    'أنت tau kenapa أنا suka hujan? لأن hujan ذلك seperti أنت, sejuk في hati 🌧️',
    'أنت adalah alasan kenapa أنا senyum tanpa sebab 😊',
    'Kalau أنت bintang, أنا mau jadi langit الذي selalu nemenin أنت ✨',
    'أنا لا أحتاج GPS, karena hatiku تم nunjuk ke arahmu 💘',
    'أنت tau bedanya أنت sama kopi? Kopi إنشاء melek, أنت إنشاء أنا لا يمكن tidur mikirin أنت ☕',
    'Boleh pinjam hatimu? Janji bakal dijaga selamanya 💖',
    'إذا cinta ذلك هو lagu, أنت هو melodi terindahnya 🎵',
    'أنا أحتاج 3 hal: Matahari, شهر, و أنت. Matahari لـ ظهر, شهر لـ ليل, أنت لـ selamanya 🌙',
    'أنت هو puzzle terakhir الذي kubutuhkan لـ melengkapi hidupku 🧩'
]


function getContextInfo(title = '💘 *ᴛᴇᴍʙᴀᴋ*', body = 'Confess your love!') {
    const saluranId = config.saluran?.id || '120363432546133683@newsletter'
    const saluranName = config.saluran?.name || config.bot?.name || 'MUSASHI'
    
    const contextInfo = {
        forwardingScore: 9999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: saluranId,
            newsletterName: saluranName,
            serverMessageId: 127
        }
    }
    
    
    return contextInfo
}

async function handler(m, { sock }) {
    const db = getDatabase()
    const args = m.args || []
    
    let targetJid = null
    
    if (m.quoted) {
        targetJid = m.quoted.sender
    } else if (m.mentionedJid?.[0]) {
        targetJid = m.mentionedJid[0]
    } else if (args[0]) {
        let num = args[0].replace(/[^0-9]/g, '')
        if (num.length > 5 && num.length < 20) {
            targetJid = num + '@s.whatsapp.net'
        }
    }
    
    if (!targetJid) {
        return m.reply(
            `⚠️ *طريقة الاستخدام*\n\n` +
            `> \`${m.prefix}tembak @tag\`\n\n` +
            `> مثال:\n` +
            `> \`${m.prefix}tembak @628xxx\`\n` +
            `> ردّ على رسالة + \`${m.prefix}tembak\``
        )
    }
    
    if (targetJid === m.sender) {
        return m.reply(`لا يمكن menembak diri sendiri!`)
    }
    
    if (targetJid === m.botNumber) {
        return m.reply(`البوت لا يمكن pacaran!`)
    }
    
    let senderData = db.getUser(m.sender) || {}
    let targetData = db.getUser(targetJid) || {}
    
    if (!senderData.fun) senderData.fun = {}
    if (!targetData.fun) targetData.fun = {}
    
    if (senderData.fun.pasangan) {
        const partnerData = db.getUser(senderData.fun.pasangan)
        if (partnerData?.fun?.pasangan === m.sender) {
            return m.reply(
                `❌ *sᴜᴅᴀʜ ᴘᴜɴʏᴀ ᴘᴀsᴀɴɢᴀɴ*\n\n` +
                `Pasanganmu: @${senderData.fun.pasangan.split('@')[0]}\n` +
                `Putus أولاً sama ${partnerData.name} مع طريقة: \`${m.prefix}putus\``,
                { mentions: [senderData.fun.pasangan] }
            )
        }
    }
    
    if (targetData.fun.pasangan && targetData.fun.pasangan !== m.sender) {
        const targetPartner = db.getUser(targetData.fun.pasangan)
        if (targetPartner?.fun?.pasangan === targetJid) {
            return m.reply(
                `💔 *ᴅɪᴀ sᴜᴅᴀʜ ᴘᴀᴄᴀʀᴀɴ*\n\n` +
                `Pasangannya: @${targetData.fun.pasangan.split('@')[0]}`,
                { mentions: [targetData.fun.pasangan] }
            )
        }
    }
    
    if (targetData.fun.tembakTarget === m.sender || targetData.fun.pasangan === m.sender) {
        senderData.fun.pasangan = targetJid
        targetData.fun.pasangan = m.sender
        
        db.setUser(m.sender, senderData)
        db.setUser(targetJid, targetData)
        
        delete global.tembakSessions[`${m.chat}_${targetJid}`]
        
        await m.react('💕')
        return m.reply(`💕 *CIE CIEE :3*\n\n` +
                `@${m.sender.split('@')[0]} و @${targetJid.split('@')[0]} أصبحا مرتبطين رسمياً !\n\n` +
                `Semoga langgeng yak! 💍`, { mentions: [m.sender, targetJid] })
    }
    
    senderData.fun.tembakTarget = targetJid
    if (!senderData.fun.tembakCount) senderData.fun.tembakCount = 0
    senderData.fun.tembakCount++
    db.setUser(m.sender, senderData)
    
    global.tembakSessions[`${m.chat}_${targetJid}`] = {
        shooter: m.sender,
        target: targetJid,
        chat: m.chat,
        timestamp: Date.now()
    }

    await m.react('💘')

    const sentMsg = await m.reply(`💘 *ADA الذي NEMBAK NIHH*\n\n` +
            `Hei @${targetJid.split('@')[0]} , أنت ditembak بواسطة @${m.sender.split('@')[0]} nichh\n\n` +
            `⏱️ Berlaku *1 الساعة* من الآن\n` +
            `استخدم: \`${m.prefix}شكراً\` / \`${m.prefix}tolak\``,
        { mentions: [targetJid, m.sender] })
    
    if (sentMsg?.key?.id) {
        global.tembakSessions[`${m.chat}_${targetJid}`].messageId = sentMsg.key.id
    }
}

async function answerHandler(m, sock) {
    if (!m.body) return false
    
    const text = m.body.trim().toLowerCase()
    if (text !== 'terima' && text !== 'tolak') return false
    if (!m.quoted) return false
    
    const db = getDatabase()
    
    const allSessions = Object.entries(global.tembakSessions || {}).filter(
        ([key, val]) => val.target === m.sender && val.chat === m.chat
    )
    
    if (allSessions.length === 0) return false
    
    const validSession = allSessions.find(([key, val]) => {
        return Date.now() - val.timestamp < 3600000
    })
    
    if (!validSession) return false
    
    const [sessKey, sessData] = validSession
    
    if (text === 'terima') {
        let shooterData = db.getUser(sessData.shooter) || {}
        let targetData = db.getUser(m.sender) || {}
        
        if (!shooterData.fun) shooterData.fun = {}
        if (!targetData.fun) targetData.fun = {}
        
        shooterData.fun.pasangan = m.sender
        targetData.fun.pasangan = sessData.shooter
        
        db.setUser(sessData.shooter, shooterData)
        db.setUser(m.sender, targetData)
        
        delete global.tembakSessions[sessKey]
        
        await m.react('💕')
        await m.reply(`💕 *WIDIHHHH, CIE CIE DITERIMA* @${sessData.shooter.split('@')[0]}\n\n` +
                `@${m.sender.split('@')[0]} و @${sessData.shooter.split('@')[0]} أصبحا مرتبطين رسمياً\n\n` +
                `بالتوفيق والسعادة الدائمة 💍`, { mentions: [m.sender, sessData.shooter] })
        
        return true
    }
    
    if (text === 'tolak') {
        let shooterData = db.getUser(sessData.shooter) || {}
        let targetData = db.getUser(m.sender) || {}
        
        if (!shooterData.fun) shooterData.fun = {}
        if (!targetData.fun) targetData.fun = {}
        
        delete shooterData.fun.pasangan
        delete shooterData.fun.tembakTarget
        delete targetData.fun.pasangan
        
        db.setUser(sessData.shooter, shooterData)
        db.setUser(m.sender, targetData)
        
        delete global.tembakSessions[sessKey]
        
        await m.react('💔')
        await m.reply(`💔 *للأسف، اصبر* @${sessData.shooter.split('@')[0]}\n\n` +
                `@${m.sender.split('@')[0]} menolak @${sessData.shooter.split('@')[0]} sebagai pacarnya\n\n` +
                `اصبر، لا يزال هناك الكثير غيرها! 😢`, { mentions: [m.sender, sessData.shooter] })
        return true
    }
    
    return false
}

module.exports = {
    config: pluginConfig,
    handler,
    answerHandler
}