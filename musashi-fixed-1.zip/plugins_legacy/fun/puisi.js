const axios = require('axios')
const config = require('../../config')
const { f } = require('../../src/lib/undici')

const NEOXR_APIKEY = config.APIkey?.neoxr || 'Milik-Bot-Itsuki'

const pluginConfig = {
    name: 'puisi',
    alias: ['puisiku', 'sajak'],
    category: 'fun',
    description: 'Random puisi Indonesia',
    usage: '.puisi',
    example: '.puisi',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    m.react('🕕')
    
    try {
        const res = await f(`https://api.neoxr.eu/api/puisi?apikey=${NEOXR_APIKEY}`)
        
        if (!res.status || !res.data?.text) {
            m.react('❌')
            return m.reply(`❌ *عذراً* فشل mengambil puisi~ 🥺`)
        }
        
        const text = res.data.text
        await m.reply(text)
        m.react('✅')
        
    } catch (err) {
        console.error("[MUSASHI][plugins_legacy/fun/puisi.js] exception", err?.stack || err);
        m.react('❌')
        return m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
