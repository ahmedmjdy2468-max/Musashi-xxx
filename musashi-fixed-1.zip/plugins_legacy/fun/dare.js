const { getRandomItem } = require('../../src/lib/gameData');

const pluginConfig = {
    name: "",
    alias: ['dareq', 'tantang'],
    category: 'fun',
    description: 'Random tantangan dare',
    usage: '.dare',
    example: '.dare',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 3,
    energi: 0,
    isEnabled: true
};

async function handler(m) {
    const challenge = getRandomItem('dare.json');
    
    if (!challenge) {
        await m.reply('❌ *همم~* Data غير متاح~ 🥺');
        return;
    }
    
    await m.reply(`\`\`\`${challenge}\`\`\``);
}

module.exports = {
    config: pluginConfig,
    handler
};
