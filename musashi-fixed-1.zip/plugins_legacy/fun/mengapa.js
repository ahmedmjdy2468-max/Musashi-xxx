const pluginConfig = {
    name: 'mengapa',
    alias: ['kenapa', 'why'],
    category: 'fun',
    description: 'يرد بسبب عشوائي مرح على سؤالك؛ الإجابة ليست تفسيراً علمياً موثوقاً.',
    usage: '.لماذا <سؤال>',
    example: '.لماذا السماء زرقاء؟',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 3,
    energi: 0,
    isEnabled: true
};

const answers = [
    "لعلها صدفة!",
    "سؤال جميل، ولا أعرف جوابه.",
    "هكذا تسير الأمور أحياناً.",
    "ربما لأن الظروف اجتمعت هكذا.",
    "لا أعلم؛ ابحث في مصدر موثوق.",
    "لأن هذا ما حدث اليوم!",
    "قد يكون الأمر مصادفة.",
    "العالم مليء بالأسرار.",
    "يصعب شرح ذلك.",
    "ربما للكون أسبابه الخاصة.",
    "وأنا أتساءل مثلك!",
    "قد يكون هذا هو التفسير الأبسط.",
    "سؤال جيد، لكن جوابه غير واضح لي.",
    "لكل شيء جانب مميز.",
    "ربما توجد أسباب عدة.",
    "أحتاج وقتاً للتفكير في ذلك.",
    "لأنها تبدو منطقية!",
    "هذا أول ما خطر ببالي.",
    "قد تكون الأمور مترابطة.",
    "ها أنا أفكر في السؤال أيضاً!"
];

async function handler(m) {
    const text = m.text?.trim();
    
    if (!text) {
        return m.reply(`أدخل سؤالك بعد الأمر.\nمثال: .لماذا السماء زرقاء؟`);
    }
    
    const answer = answers[Math.floor(Math.random() * answers.length)];
    
    await m.reply(`${m.body.slice(1)}?\n*${answer}*`);
}

module.exports = {
    config: pluginConfig,
    handler
};
