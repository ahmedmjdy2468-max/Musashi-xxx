const pluginConfig = {
    name: 'dimana',
    alias: ['where', 'mana'],
    category: 'fun',
    description: 'يرد بمكان عشوائي على سؤالك؛ الإجابة للتسلية وليست تحديداً حقيقياً للموقع.',
    usage: '.أين_المكان <سؤال>',
    example: '.أين_المكان أين وضعت مفاتيحي؟',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 3,
    energi: 0,
    isEnabled: true
};

const answers = [
    "بالقرب منك!",
    "بعيداً من هنا.",
    "في مكان لم تتوقعه.",
    "في قلبك.",
    "في مكان قريب.",
    "لعلها في الغرفة.",
    "هناك، في الخارج.",
    "في مكان مألوف لك.",
    "في مكان جميل.",
    "خلف الباب.",
    "إلى يسارك.",
    "أمام عينيك!",
    "بعيداً جداً، ربما في بلد آخر.",
    "بين رسائلك الكثيرة.",
    "في كل مكان!",
    "في العالم الافتراضي.",
    "في عالم الأحلام.",
    "في مكان سرّي.",
    "يصعب وصف موقعه.",
    "في مكان قد يسعدك."
];

async function handler(m) {
    const text = m.text?.trim();
    
    if (!text) {
        return m.reply(`أدخل سؤالك بعد الأمر.\nمثال: .أين_المكان أين وضعت مفاتيحي؟`);
    }
    
    const answer = answers[Math.floor(Math.random() * answers.length)];
    
    await m.reply(`${m.body.slice(1)}?
*${answer}*`);
}

module.exports = {
    config: pluginConfig,
    handler
};
