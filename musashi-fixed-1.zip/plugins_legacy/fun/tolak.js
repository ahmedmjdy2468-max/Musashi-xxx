const { getDatabase } = require('../../src/lib/database')
const config = require('../../config')
const path = require('path')
const fs = require('fs')

const pluginConfig = {
    name: 'tolak',
    alias: ['reject', 'no', 'gaktau'],
    category: 'fun',
    description: 'Menolak tembakan dari seseorang',
    usage: '.tolak @tag',
    example: '.tolak @628xxx',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}


const rejectionQuotes = [
    'Sabar نعم, الذي أكثر baik بالتأكيد datang! 🌟',
    'لم jodoh ليس berarti لا يوجد jodoh 💪',
    'Move on! Banyak ikan di laut! 🐟',
    'الذي sabar نعم, cinta sejati سوف datang 💕',
    'Jangan patah semangat, تبقى semangat! 🔥',
    'Penolakan adalah awal dari keberhasilan 💪',
    'ما زلنا banyak فرصة di luar sana! ✨',
    'Yakin ما زال يوجد الذي أكثر cocok buat أنت! 🌈'
]

function getContextInfo(title = '💔 *ᴛᴏʟᴀᴋ*', body = 'Rejected!') {
    const saluranId = config.saluran?.id || '120363432546133683@newsletter'
    const saluranName = config.saluran?.name || config.bot?.name || 'MUSASHI'
    
    const contextInfo = {
        forwardingScore: 9999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: saluranId,
            newsletterName: saluranName,
            serverMessageId: 127
        }
    }
    
    
    return contextInfo
}

async function handler(m, { sock }) {
    const db = getDatabase()
    
    let shooterJid = null
    
    if (m.quoted) {
        shooterJid = m.quoted.sender
    } else if (m.mentionedJid?.[0]) {
        shooterJid = m.mentionedJid[0]
    }
    
    if (!shooterJid) {
        const sessions = global.tembakSessions || {}
        const mySession = Object.entries(sessions).find(
            ([key, val]) => val.target === m.sender && val.chat === m.chat
        )
        
        if (mySession) {
            shooterJid = mySession[1].shooter
        }
    }
    
    if (!shooterJid) {
        return m.reply(
            `⚠️ *طريقة الاستخدام*\n\n` +
            `> ردّ على رسالة tembakan + \`${m.prefix}tolak\`\n` +
            `> أو \`${m.prefix}tolak @tag\``
        )
    }
    
    if (shooterJid === m.sender) {
        return m.reply(`❌ *عذراً* ✦\n\n> لا يمكن menolak diri sendiri~ 🥺`)
    }
    
    if (shooterJid === m.botNumber) {
        return m.reply(`❌ *عذراً* ✦\n\n> البوت لا لديه hati لـ تم الرفض~ 🥺`)
    }
    
    let shooterData = db.getUser(shooterJid) || {}
    let myData = db.getUser(m.sender) || {}
    
    if (!shooterData.fun) shooterData.fun = {}
    if (!myData.fun) myData.fun = {}
    
    if (shooterData.fun.pasangan !== m.sender && shooterData.fun.tembakTarget !== m.sender) {
        return m.reply(
            `❌ *لا ᴍᴇɴᴇᴍʙᴀᴋ*\n\n` +
            `> @${shooterJid.split('@')[0]} لا يخبرك بمشاعره`,
            { mentions: [shooterJid] }
        )
    }
    
    delete shooterData.fun.pasangan
    delete shooterData.fun.tembakTarget
    delete myData.fun.pasangan
    
    if (!shooterData.fun.ditolakCount) shooterData.fun.ditolakCount = 0
    shooterData.fun.ditolakCount++
    
    db.setUser(shooterJid, shooterData)
    db.setUser(m.sender, myData)
    
    const sessionKey = `${m.chat}_${m.sender}`
    if (global.tembakSessions?.[sessionKey]) {
        delete global.tembakSessions[sessionKey]
    }
    
    const quote = rejectionQuotes[Math.floor(Math.random() * rejectionQuotes.length)]
    
    await m.react('💔')
    const ctx = getContextInfo('💔 *ᴅɪᴛᴏʟᴀᴋ*', 'Move on!')
    ctx.mentionedJid = [m.sender, shooterJid]
    
    await m.reply(`💔 *للأسف، اصبر* @${shooterJid.split('@')[0]}\n\n` +
                `@${m.sender.split('@')[0]} menolak @${shooterJid.split('@')[0]} sebagai pacarnya\n\n` +
                `اصبر، لا يزال هناك الكثير غيرها! 😢`, { mentions: [m.sender, shooterJid] })
}

module.exports = {
    config: pluginConfig,
    handler
}