const pluginConfig = {
    name: 'kapan',
    alias: ['when'],
    category: 'fun',
    description: 'يرد بموعد عشوائي مرح على سؤالك؛ لا يتنبأ بالمستقبل.',
    usage: '.متى <سؤال>',
    example: '.متى سأبدأ إجازتي؟',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 3,
    energi: 0,
    isEnabled: true
};

const answers = [
    "ربما غداً!",
    "لعل ذلك يحدث العام المقبل.",
    "بعد ثلاثة أيام!",
    "ما زال الوقت مبكراً.",
    "في لحظة غير متوقعة!",
    "عندما يحين الوقت المناسب.",
    "الشهر المقبل!",
    "لا أعلم؛ المهم أن تتحلى بالصبر.",
    "قريباً!",
    "ربما بعد عشر سنوات.",
    "ليس قبل وقت طويل.",
    "حين تلتقيان إن كان ذلك مقدّراً.",
    "يصعب التنبؤ بذلك.",
    "الأسبوع المقبل!",
    "كلما اجتهدت أكثر، اقترب موعده.",
    "عندما تتهيأ الظروف.",
    "في أقرب فرصة.",
    "حين تكون مستعداً.",
    "خلال أيام قليلة!",
    "عندما يحين الوقت الملائم لك."
];

async function handler(m) {
    const text = m.text?.trim();
    
    if (!text) {
        return m.reply(`أدخل سؤالك بعد الأمر.\nمثال: .متى سأبدأ إجازتي؟`);
    }
    
    const answer = answers[Math.floor(Math.random() * answers.length)];
    
    await m.reply(`${m.body.slice(1)}?\n*${answer}*`);
}

module.exports = {
    config: pluginConfig,
    handler
};
