const config = require('../../config')

const pluginConfig = {
    name: 'confess',
    alias: ['confession', 'menfess', 'anonim'],
    category: 'fun',
    description: 'أرسل رسالة anonim ke seseorang',
    usage: '.confess الرقم|رسالة',
    example: '.confess 6281234567890|مرحباً, أنا suka أنت!',
    isOwner: false,
    isPremium: true,
    isGroup: false,
    isPrivate: false,
    cooldown: 60,
    energi: 1,
    isEnabled: true
}

if (!global.confessData) global.confessData = new Map()

async function handler(m, { sock }) {
    const input = m.fullArgs?.trim() || m.text?.trim()
    
    if (!input || !input.includes('|')) {
        return m.reply(
            `💌 *ᴀɴᴏɴʏᴍᴏᴜs ᴄᴏɴꜰᴇss*\n\n` +
            `> أرسل رسالة anonim ke seseorang!\n\n` +
            `╭┈┈⬡「 📋 *طريقة الاستخدام* 」\n` +
            `┃ Format:\n` +
            `┃ \`${m.prefix}confess الرقم|رسالة\`\n` +
            `┃\n` +
            `┃ مثال:\n` +
            `┃ \`${m.prefix}confess 6281234567890|مرحباً أنت!\`\n` +
            `╰┈┈┈┈┈┈┈┈⬡\n\n` +
            `> ⚠️ Identitasmu akan dirahasiakan!`
        )
    }
    
    const [rawNumber, ...messageParts] = input.split('|')
    const message = messageParts.join('|').trim()
    
    if (!rawNumber || !message) {
        return m.reply(`❌ الصيغة خطأ!\n\n> استخدم: \`${m.prefix}confess الرقم|رسالة\``)
    }
    
    let targetNumber = rawNumber.trim().replace(/[^0-9]/g, '')
    
    if (targetNumber.startsWith('0')) {
        targetNumber = '62' + targetNumber.slice(1)
    }
    
    if (targetNumber.length < 10 || targetNumber.length > 15) {
        return m.reply(`❌ *همم~* الرقم غير صالح.~ 🥺`)
    }
    
    const targetJid = targetNumber + '@s.whatsapp.net'
    
    const senderNumber = m.sender.split('@')[0]
    if (targetNumber === senderNumber) {
        return m.reply(`❌ *عذراً* لا يمكن إرسال confess إلى diri sendiri~ 🥺`)
    }
    
    try {
        const [onWa] = await sock.onWhatsApp(targetNumber)
        if (!onWa?.exists) {
            return m.reply(`❌ *همم~* Nomor \`${targetNumber}\` غير مسجل في واتساب~ 🥺`)
        }
    } catch (e) {}
    
    if (message.length < 5) {
        return m.reply(`❌ *همم~* الرسالة terlalu pendek! الحد الأدنى 5 حرفاً~ 🥺`)
    }
    
    if (message.length > 1000) {
        return m.reply(`❌ *همم~* الرسالة terlalu طويل! الحد الأقصى 1000 حرفاً~ 🥺`)
    }

    const confessText = 
        `💌 *ᴀᴅᴀ الرسالة ᴅᴀʀɪ sᴇsᴇᴏʀᴀɴɢ ɴɪᴄʜʜ*\n\n` +
        `「 📨 *الرسالة: ᴅᴀʀɪ sᴇsᴇᴏʀᴀɴɢ* 」\n` +
        ` 💕 *ɪsɪ الرسالة:*\n` +
        `\`\`\`${message}\`\`\`\n` +
        `> 🔒 _Identitas pengirim dirahasiakan_\n` +
        `> 💬 _ردّ على رسالة هذا لـ membalas!_`
    
    try {
        const sentMsg = await sock.sendMessage(targetJid, {
            text: confessText,
            contextInfo: {
                forwardingScore: 99,
                isForwarded: true,
            }
        })
        
        global.confessData.set(sentMsg.key.id, {
            senderJid: m.sender,
            senderChat: m.chat,
            targetJid: targetJid,
            createdAt: Date.now()
        })
        
        setTimeout(() => {
            global.confessData.delete(sentMsg.key.id)
        }, 24 * 60 * 60 * 1000)
        
        await m.reply(
            `✅ *ᴄᴏɴꜰᴇss ᴛᴇʀᴋɪʀɪᴍ!*\n\n` +
            `> الرسالة dikirim ke: \`${targetNumber}\`\n` +
            `> Identitasmu terjaga aman! 🔒\n\n` +
            `> 💬 إذا هو membalas, balasannya سوف dikirim إلى sini!`
        )
        
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/fun/confess.js] exception", error?.stack || error);
        await m.reply("حدث خطأ، حاول لاحقاً")
    }
}

async function replyHandler(m, { sock }) {
    if (!m.quoted) return false
    
    const quotedId = m.quoted?.id || m.quoted?.key?.id
    if (!quotedId) return false
    
    const confessInfo = global.confessData.get(quotedId)
    if (!confessInfo) return false
    
    if (m.sender !== confessInfo.targetJid) return false
    
    const replyMessage = m.body?.trim()
    if (!replyMessage) return false
    
    const saluranId = config.saluran?.id || '120363432546133683@newsletter'
    const saluranName = config.saluran?.name || config.bot?.name || 'MUSASHI'
    
    const replyText = 
        `💌 *ʙᴀʟᴀsᴀɴ ᴅᴀʀɪ ᴏʀᴀɴɢ ʏᴀɴɢ ᴋᴀᴍᴜ ᴄᴏɴꜰᴇss!*\n\n` +
        `「 📨 *ʙᴀʟᴀsᴀɴ* 」\n` +
        ` 💕 *ɪsɪ الرسالة:*\n` +
        `\`\`\`${replyMessage}\`\`\`\n` +
        `> 🔒 _Identitas تبقى dirahasiakan_`
    
    try {
        await sock.sendMessage(confessInfo.senderChat, {
            text: replyText,
            contextInfo: {
                forwardingScore: 9999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: saluranId,
                    newsletterName: saluranName,
                    serverMessageId: 127
                }
            }
        })
        
        await sock.sendMessage(m.chat, {
            text: `✅ Balasanmu telah terkirim secara anonim!`
        })
        
        global.confessData.delete(quotedId)
        
        return true
    } catch (error) {
        return false
    }
}

module.exports = {
    config: pluginConfig,
    handler,
    replyHandler
}
