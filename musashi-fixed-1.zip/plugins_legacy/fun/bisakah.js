const pluginConfig = {
    name: 'bisakah',
    alias: ['يمكن'],
    category: 'fun',
    description: 'يرد باحتمال عشوائي مرح على سؤالك عن إمكانية شيء؛ لا يقيّم قدرتك فعلياً.',
    usage: '.هل_أستطيع <سؤال>',
    example: '.هل_أستطيع تعلم اليابانية؟',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 3,
    energi: 0,
    isEnabled: true
};

const answers = [
    "بالتأكيد! ثق بنفسك.",
    "قد يكون الأمر صعباً.",
    "نعم، بالتوفيق!",
    "ربما لا هذه المرة.",
    "ممكن إذا بذلت جهداً.",
    "بالتأكيد، لا تستسلم!",
    "قد يكون صعباً، لكن جرّبه.",
    "نعم، أنت قادر!",
    "لعل الإجابة لا.",
    "جرّب وأثبت ذلك!",
    "لست متأكداً.",
    "نعم، واصل المحاولة!",
    "إن لم تنجح، فجرّب طريقة أخرى.",
    "ثق بقدراتك!",
    "قد يحتاج الأمر إلى جهد إضافي.",
    "بالتأكيد تستطيع!",
    "تحتاج إلى تدريب أكثر.",
    "لا تقلل من قدراتك.",
    "حاول مرة أخرى لاحقاً.",
    "أنا أؤمن بقدرتك!"
];

async function handler(m) {
    const text = m.text?.trim();
    
    if (!text) {
        return m.reply(`أدخل سؤالك بعد الأمر.\nمثال: .هل_أستطيع تعلم اليابانية؟`);
    }
    
    const answer = answers[Math.floor(Math.random() * answers.length)];
    
    await m.reply(`${m.body.slice(1)}?
*${answer}*`);
}

module.exports = {
    config: pluginConfig,
    handler
};
