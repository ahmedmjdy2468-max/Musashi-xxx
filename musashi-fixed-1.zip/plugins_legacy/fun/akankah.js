const pluginConfig = {
    name: 'akankah',
    alias: ['akan', 'will'],
    category: 'fun',
    description: 'يرد بتوقع عشوائي مرح على سؤالك عمّا قد يحدث؛ لا يتنبأ بالمستقبل.',
    usage: '.هل_سيحدث <سؤال>',
    example: '.هل_سيحدث أن أنجح؟',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 3,
    energi: 0,
    isEnabled: true
};

const answers = [
    "نعم، ربما يحدث!",
    "قد لا يحدث.",
    "ربما يحدث، وربما لا.",
    "إن شاء الله يتحقق.",
    "يصعب التنبؤ بذلك.",
    "لعل ذلك يحدث!",
    "قد لا يحدث الآن.",
    "سيحدث إن بذلت جهداً.",
    "قد يتحقق يوماً ما.",
    "لا أظن ذلك حالياً.",
    "نعم، انتظر قليلاً.",
    "لست متأكداً.",
    "هناك احتمال جيد.",
    "احتماله ضعيف.",
    "أظن أنه سيحدث!",
    "ربما عليك تجربة طريق آخر.",
    "سيحتاج الأمر إلى وقت.",
    "إن شاء الله!",
    "إن كان مناسباً لك، فربما يحدث.",
    "سيحدث في الوقت الملائم."
];

async function handler(m) {
    const text = m.text?.trim();
    
    if (!text) {
        return m.reply(`أدخل سؤالك بعد الأمر.\nمثال: .هل_سيحدث أن أنجح؟`);
    }
    
    const answer = answers[Math.floor(Math.random() * answers.length)];
    
    await m.reply(`${m.body.slice(1)}?
*${answer}*`);
}

module.exports = {
    config: pluginConfig,
    handler
};
