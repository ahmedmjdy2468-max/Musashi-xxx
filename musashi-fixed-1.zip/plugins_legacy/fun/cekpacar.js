const { getDatabase } = require('../../src/lib/database')

const pluginConfig = {
    name: 'cekpacar',
    alias: ['pacar', 'pasangan', 'gebetan'],
    category: 'fun',
    description: 'يفحص الحالة العاطفية لشخص ما.',
    usage: '.cekpacar أو .cekpacar @tag',
    example: '.cekpacar',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 10,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const db = getDatabase()
    const args = m.args || []
    let targetJid = m.sender
    let isOther = false
    if (m.quoted) {
        targetJid = m.quoted.sender
        isOther = true
    } else if (m.mentionedJid?.[0]) {
        targetJid = m.mentionedJid[0]
        isOther = true
    } else if (args[0]) {
        let num = args[0].replace(/[^0-9]/g, '')
        if (num.length > 5 && num.length < 20) {
            targetJid = num + '@s.whatsapp.net'
            isOther = true
        }
    }
    
    const userData = db.getUser(targetJid) || {}
    
    if (!userData.fun?.pasangan) {
        const nama = isOther ? `@${targetJid.split('@')[0]}` : 'أنت'
        await m.react('💔')
        return m.reply(
            `💔 *الحالة ʜᴜʙᴜɴɢᴀɴ*\n\n` +
            `*${nama}* لا لديه pasangan.\n` +
            `TIP: بحث pasangan أولاً مع \`${m.prefix}tembak @tag\``,
            { mentions: isOther ? [targetJid] : [] }
        )
    }
    
    const partnerJid = userData.fun.pasangan
    const partnerData = db.getUser(partnerJid) || {}
    const isMutual = partnerData.fun?.pasangan === targetJid
    const nama = isOther ? `@${targetJid.split('@')[0]}` : 'أنت'
    if (isMutual) {
        await m.react('💕')
        await m.reply(
            `💕 *الحالة ʜᴜʙᴜɴɢᴀɴ*\n\n` +
            `*${nama}* جارٍ pacaran مع @${partnerJid.split('@')[0]}! 🥳`,
            { mentions: [targetJid, partnerJid] }
        )
    } else {
        await m.react('💭')
        await m.reply(
            `💭 *الحالة ʜᴜʙᴜɴɢᴀɴ*\n\n` +
            `*${nama}* مجدداً pdkt sama @${partnerJid.split('@')[0]}\n` +
            `الحالة: *Digantung* 😅\n\n` +
            `Menunggu jawaban...`,
            { mentions: [targetJid, partnerJid] }
        )
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
