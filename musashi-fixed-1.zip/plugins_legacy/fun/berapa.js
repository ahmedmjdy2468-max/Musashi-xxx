const pluginConfig = {
    name: 'berapa',
    alias: ['howmuch', 'howmany'],
    category: 'fun',
    description: 'يرد بإجابة عشوائية مرحة عن الكمية التي تسأل عنها؛ الإجابة للتسلية وليست معلومة مؤكدة.',
    usage: '.كم_العدد <سؤال>',
    example: '.كم_العدد كم كتاباً أحتاج؟',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 3,
    energi: 0,
    isEnabled: true
};

const answers = [
    "واحد فقط!",
    "سبعة، وربما أكثر.",
    "اثنا عشر تقريباً.",
    "واحد وعشرون!",
    "تسعة وتسعون.",
    "مئة كاملة!",
    "خمسون تقريباً.",
    "خمسة وعشرون.",
    "ألف، لا أقل!",
    "خمسة فقط.",
    "سبعة عشر.",
    "ثمانية وثمانون.",
    "ثلاثة وثلاثون.",
    "لا شيء؛ هذه إجابتي المعتادة.",
    "عدد كبير جداً!",
    "عدد قليل.",
    "لا يمكن حصره!",
    "لعلها عشرة تقريباً.",
    "أكثر مما تتوقع!",
    "لا أعلم، دعنا نجرّب حظنا."
];

async function handler(m) {
    const text = m.text?.trim();
    
    if (!text) {
        return m.reply(`أدخل سؤالك بعد الأمر.\nمثال: .كم_العدد كم كتاباً أحتاج؟`);
    }
    
    const answer = answers[Math.floor(Math.random() * answers.length)];
    
    await m.reply(`${m.body.slice(1)}?
*${answer}*`);
}

module.exports = {
    config: pluginConfig,
    handler
};
