const pluginConfig = {
    name: 'coba',
    alias: ['try'],
    category: 'fun',
    description: 'يخمن حالتك أو ما قد يشغل بالك بإجابة عشوائية مرحة؛ للتسلية فقط.',
    usage: '.خمّن_حالتي <سؤال>',
    example: '.خمّن_حالتي ماذا أفكر الآن؟',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 3,
    energi: 0,
    isEnabled: true
};

const answers = [
    'أظنك تفكر في الطعام مرة أخرى!',
    'يبدو أنك تشعر بالملل.',
    'أخمن أنك سعيد الآن!',
    'ربما تشعر بالحيرة قليلاً.',
    'أظنك تشتاق إلى شخص ما.',
    'يبدو أنك مسترخٍ اليوم.',
    'أخمن أنك تتصفح هاتفك منذ وقت طويل.',
    'ربما تشعر بالملل مرة أخرى؟',
    'أظنك ترغب في التنزه!',
    'يبدو أنك تحتاج إلى بعض الترفيه.',
    'أعتقد أنك سعيد الآن!',
    'أخمن أنك شديد الفضول!',
    'ربما تستلقي وتستريح الآن.',
    'أظنك تفكر في شخص مميز.',
    'هل تريد التحدث عما يشغلك؟',
    'يبدو أنك ترغب في لعب لعبة!',
    'ربما تستمع إلى الموسيقى الآن.',
    'أخمن أنك في غرفتك.',
    'يبدو أنك تنتظر شيئاً ما.',
    'أظنك تحتاج إلى رفيق تتحدث معه!'
];

async function handler(m) {
    const text = m.text?.trim();
    
    if (!text) {
        return m.reply(`🎯 اكتب سؤالاً بعد الأمر.\n\nمثال: .خمّن_حالتي ماذا أفكر الآن؟`);
    }
    
    const answer = answers[Math.floor(Math.random() * answers.length)];
    
    await m.reply(`${m.body.slice(1)}?
*${answer}*`);
}

module.exports = {
    config: pluginConfig,
    handler
};
