/**
 * إنهاء العلاقة المسجلة بين عضوين
 */

const { getDatabase } = require('../../src/lib/database')

const pluginConfig = {
    name: 'putus',
    alias: ['breakup', 'cerai'],
    category: 'fun',
    description: 'ينهي الارتباط المسجل بينك وبين شريكك في بيانات البوت داخل المجموعة.',
    usage: '.إنهاء_علاقة',
    example: '.إنهاء_علاقة',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 60,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const db = getDatabase()
    let senderData = db.getUser(m.sender) || {}
    if (!senderData.fun) senderData.fun = {}
    if (!senderData.fun.pasangan) {
        await m.react('❌')
        return m.reply(
            `❌ لا يوجد شريك مسجل لك.\n\n` +
            `سجّل ارتباطاً أولاً باستخدام \`${m.prefix}إطلاق_قلب @عضو\`.`
        )
    }
    const exPartner = senderData.fun.pasangan
    let exData = db.getUser(exPartner) || {}
    delete senderData.fun.pasangan
    if (exData.fun?.pasangan === m.sender) {
        delete exData.fun.pasangan
        db.setUser(exPartner, exData)
    }
    db.setUser(m.sender, senderData)
    await m.react('💔')
    await m.reply(
        `💔 *انتهى الارتباط*\n\n` +
        `انتهى الارتباط المسجل بين @${m.sender.split('@')[0]} و@${exPartner.split('@')[0]}.\n\n` +
        `نتمنى لكما التوفيق. 🙏`,
        { mentions: [m.sender, exPartner] }
    )
}

module.exports = {
    config: pluginConfig,
    handler
}
