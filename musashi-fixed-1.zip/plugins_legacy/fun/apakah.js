const pluginConfig = {
    name: 'apakah',
    alias: ['apa'],
    category: 'fun',
    description: 'يرد عشوائياً بنعم أو لا على السؤال الذي تكتبه؛ للتسلية فقط.',
    usage: '.توقع_نعم_أم_لا <سؤال>',
    example: '.توقع_نعم_أم_لا هل سأنجح؟',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 3,
    energi: 0,
    isEnabled: true
};

const answers = [
    'نعم، بالتأكيد!',
    'لا، على الأرجح لا.',
    'ربما؛ جرّب مرة أخرى لاحقاً.',
    'أظن أن الإجابة نعم.',
    'لست متأكداً، لكن ذلك ممكن.',
    'بالتأكيد! بنسبة 100٪!',
    'هذا مستبعد.',
    'ربما، من يدري؟',
    'أعتقد ذلك.',
    'يبدو أن الإجابة لا.',
    'بالتأكيد، لمَ لا؟',
    'لا أعلم؛ اسأل شخصاً آخر.',
    'نعم، بكل تأكيد!',
    'همم... يبدو أن الإجابة لا.',
    'أنا واثق أنها نعم!',
    'احتمال ذلك ضعيف جداً.',
    'ربما، لكن لا ترفع سقف توقعاتك.',
    'نعم، بالتوفيق!',
    'لا، عذراً.',
    'ممكن! واصل المحاولة!'
];

async function handler(m) {
    const text = m.text?.trim();
    
    if (!text) {
        return m.reply(`❓ اكتب سؤالك بعد الأمر.\n\nمثال: .توقع_نعم_أم_لا هل سأنجح؟`);
    }
    
    const answer = answers[Math.floor(Math.random() * answers.length)];
    
    await m.reply(`${m.body.slice(1)}?
*${answer}*`);
}

module.exports = {
    config: pluginConfig,
    handler
};
