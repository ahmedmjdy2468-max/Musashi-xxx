const fs = require('fs')
const path = require('path')
const { getDatabase } = require('../../src/lib/database')
const { getGroupMode } = require('../group/botmode')

const pluginConfig = {
    name: 'savekontak',
    alias: ['svkontak', 'savecontact'],
    category: 'pushkontak',
    description: 'حفظ جميع جهات اتصال المجموعة في ملف VCF',
    usage: '.savekontak <namakontak>',
    example: '.savekontak CustomerList',
    isOwner: true,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 30,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const db = getDatabase()
    const groupMode = getGroupMode(m.chat, db)
    
    if (groupMode !== 'pushkontak') {
        return m.reply(`❌ *الوضع غير مناسب*\n\n> فعّل وضع الإرسال الجماعي أولاً\n\n\`${m.prefix}botmode pushkontak\``)
    }
    
    const namaKontak = m.text?.trim()
    if (!namaKontak) {
        return m.reply(`📥 *حفظ جهات الاتصال*\n\n> اكتب اسماً لجهة الاتصال\n\n\`مثال: ${m.prefix}savekontak CustomerList\``)
    }
    
    m.react('📥')
    
    try {
        const metadata = m.groupMetadata
        const participants = metadata.participants
            .map(p => p.jid || p.id)
            .filter(id => id !== sock.user.id.split(':')[0] + '@s.whatsapp.net')
        
        if (participants.length === 0) {
            m.react('❌')
            return m.reply(`❌ *عذراً* ✦\n\n> لا توجد جهات اتصال لحفظها~ 🥺`)
        }
        
        const vcardContent = participants.map((contact, index) => {
            const phone = contact.split('@')[0]
            return [
                'BEGIN:VCARD',
                'VERSION:3.0',
                `FN:${namaKontak} - ${index + 1}`,
                `TEL;type=CELL;type=VOICE;waid=${phone}:+${phone}`,
                'END:VCARD',
                ''
            ].join('\n')
        }).join('')
        
        const tmpDir = path.join(process.cwd(), 'tmp')
        if (!fs.existsSync(tmpDir)) {
            fs.mkdirSync(tmpDir, { recursive: true })
        }
        
        const vcfPath = path.join(tmpDir, `${namaKontak}_${Date.now()}.vcf`)
        fs.writeFileSync(vcfPath, vcardContent, 'utf8')
        
        await sock.sendMessage(m.sender, {
            document: fs.readFileSync(vcfPath),
            fileName: `${namaKontak}_${participants.length}kontak.vcf`,
mimetype: 'text/vcard',
            caption: `📥 *ᴋᴏɴᴛᴀᴋ ᴅɪsɪᴍᴘᴀɴ*\n\n> الاسم: \`${namaKontak}\`\n> الإجمالي: \`${participants.length}\` kontak\n> المجموعة: \`${metadata.subject}\``
        }, { quoted: m })
        
        fs.unlinkSync(vcfPath)
        
        m.react('✅')
        
        if (m.chat !== m.sender) {
            await m.reply(`✅ *ᴋᴏɴᴛᴀᴋ ᴅɪsɪᴍᴘᴀɴ*\n\n> الملف VCF dikirim ke private chat\n> الإجمالي: \`${participants.length}\` kontak`)
        }
        
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/pushkontak/savekontak.js] exception", error?.stack || error);
        m.react('❌')
        m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
