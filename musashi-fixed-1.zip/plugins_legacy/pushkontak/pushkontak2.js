const fs = require('fs')
const path = require('path')
const { getDatabase } = require('../../src/lib/database')
const { getGroupMode } = require('../group/botmode')

const pluginConfig = {
    name: 'pushkontak2',
    alias: ['puskontak2', 'push2'],
    category: 'pushkontak',
    description: 'إرسال رسالة باسم جهة اتصال إلى كل أعضاء المجموعة',
    usage: '.pushkontak2 <رسالة>|<namakontak>',
    example: '.pushkontak2 مرحباً!|TokoBaru',
    isOwner: true,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 10,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const db = getDatabase()
    const groupMode = getGroupMode(m.chat, db)
    
    if (groupMode !== 'pushkontak') {
        return m.reply(`❌ *الوضع غير مناسب*\n\n> فعّل وضع الإرسال الجماعي أولاً\n\n\`${m.prefix}botmode pushkontak\``)
    }
    
    const input = m.text?.trim()
    if (!input || !input.includes('|')) {
        return m.reply(`📢 *الإرسال الجماعي 2*\n\n> الصيغة: الرسالة|اسم_الجهة\n\n\`مثال: ${m.prefix}pushkontak2 مرحباً بالجميع!|TokoBaru\``)
    }
    
    const [text, namaKontak] = input.split('|').map(s => s.trim())
    
    if (!text || !namaKontak) {
        return m.reply(`❌ *عذراً* ✦\n\n> صيغة خاطئة. استخدم: الرسالة|اسم_الجهة~ 🥺`)
    }
    
    if (global.statuspush) {
        return m.reply(`❌ *فشل*\n\n> الإرسال الجماعي يعمل الآن. اكتب \`${m.prefix}stoppush\` لإيقافه.`)
    }
    
    m.react('📢')
    
    try {
        const metadata = m.groupMetadata
        const participants = metadata.participants
            .map(p => p.jid || p.id)
            .filter(id => id !== sock.user.id.split(':')[0] + '@s.whatsapp.net')
            .filter(id => !id.includes(m.sender))
        
        if (participants.length === 0) {
            m.react('❌')
            return m.reply(`❌ *عذراً* ✦\n\n> لا يوجد أعضاء يمكن الإرسال إليهم~ 🥺`)
        }
        
        const jedaPush = db.setting('jedaPush') || 5000
        
        await m.reply(
            `📢 *الإرسال الجماعي 2*\n\n` +
            `╭┈┈⬡「 📋 *التفاصيل* 」\n` +
            `┃ 📝 الرسالة: \`${text.substring(0, 50)}${text.length > 50 ? '...' : ''}\`\n` +
            `┃ 👤 ɴᴀᴍᴀ: \`${namaKontak}\`\n` +
            `┃ 👥 الهدف: \`${participants.length}\` عضو\n` +
            `┃ ⏱️ الفاصل: \`${jedaPush}ms\`\n` +
            `╰┈┈⬡\n\n` +
            `> Memulai push مع kontak...`
        )
        
        global.statuspush = true
        let successCount = 0
        let failedCount = 0
        
        function randomKode(length) {
            const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
            let result = ''
            for (let i = 0; i < length; i++) {
                result += chars.charAt(Math.floor(Math.random() * chars.length))
            }
            return result
        }
        
        for (const member of participants) {
            if (global.stoppush) {
                delete global.stoppush
                delete global.statuspush
                
                await m.reply(
                    `⏹️ *ᴘᴜsʜ ᴅɪʜᴇɴᴛɪᴋᴀɴ*\n\n` +
                    `> ✅ نجح: \`${successCount}\`\n` +
                    `> ❌ فشل: \`${failedCount}\``
                )
                return
            }
            
            try {
                const memberNumber = member.split('@')[0]
                const kodeUnik = randomKode(6)
                const pesan = `${text}\n\n#${kodeUnik}`
                
                const vcard = `BEGIN:VCARD
VERSION:3.0
FN:${namaKontak} - ${memberNumber}
TEL;type=CELL;type=VOICE;waid=${memberNumber}:+${memberNumber}
END:VCARD`
                
                await sock.sendMessage(member, { text: pesan })
                
                await sock.sendMessage(member, {
                    contacts: {
                        displayName: namaKontak,
                        contacts: [{
                            displayName: namaKontak,
                            vcard: vcard
                        }]
                    }
                })
                
                successCount++
            } catch (err) {
                failedCount++
            }
            
            await new Promise(resolve => setTimeout(resolve, jedaPush))
        }
        
        delete global.statuspush
        
        m.react('✅')
        await m.reply(
            `✅ *ᴘᴜsʜ sᴇʟᴇsᴀɪ*\n\n` +
            `╭┈┈⬡「 📊 *النتيجة* 」\n` +
            `┃ ✅ نجح: \`${successCount}\`\n` +
            `┃ ❌ فشل: \`${failedCount}\`\n` +
            `┃ 📊 الإجمالي: \`${participants.length}\`\n` +
            `╰┈┈⬡`
        )
        
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/pushkontak/pushkontak2.js] exception", error?.stack || error);
        delete global.statuspush
        m.react('❌')
        m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
