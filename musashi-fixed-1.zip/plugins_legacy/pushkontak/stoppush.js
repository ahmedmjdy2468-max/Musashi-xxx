const { getDatabase } = require('../../src/lib/database')
const { getGroupMode } = require('../group/botmode')

const pluginConfig = {
    name: 'stoppush',
    alias: ['stoppushkontak', 'stoppus'],
    category: 'pushkontak',
    description: 'للمالك: يوقف عملية إرسال جهات الاتصال الجارية.',
    usage: '.إيقاف_إرسال_جهات_الاتصال',
    example: '.إيقاف_إرسال_جهات_الاتصال',
    isOwner: true,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 0,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    if (!global.statuspush) {
        return m.reply(`❌ لا توجد عملية إرسال جهات اتصال قيد التنفيذ.`)
    }
    
    global.stoppush = true
    
    m.react('⏹️')
    await m.reply(`⏹️ *إيقاف إرسال جهات الاتصال*\n\n> جارٍ إيقاف عملية الإرسال...`)
}

module.exports = {
    config: pluginConfig,
    handler
}
