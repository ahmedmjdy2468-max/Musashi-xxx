const fs = require('fs')
const path = require('path')
const { getDatabase } = require('../../src/lib/database')
const { getGroupMode } = require('../group/botmode')

const pluginConfig = {
    name: 'pushkontak',
    alias: ['puskontak', 'push'],
    category: 'pushkontak',
    description: 'إرسال رسالة إلى كل أعضاء المجموعة مع حفظ جهات الاتصال في ملف VCF',
    usage: '.pushkontak <رسالة>',
    example: '.pushkontak مرحباً بالجميع!',
    isOwner: true,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 10,
    energi: 0,
    isEnabled: true
}

function createSerial(len) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
    let r = ''
    for (let i = 0; i < len; i++) r += chars.charAt(Math.floor(Math.random() * chars.length))
    return r
}

function buildVcf(contacts) {
    return contacts.map(jid => {
        const num = jid.split('@')[0]
        return [
            'BEGIN:VCARD',
            'VERSION:3.0',
            `FN:WA[${createSerial(2)}] ${num}`,
            `TEL;type=CELL;type=VOICE;waid=${num}:+${num}`,
            'END:VCARD',
            ''
        ].join('\n')
    }).join('')
}

async function handler(m, { sock }) {
    const db = getDatabase()
    const groupMode = getGroupMode(m.chat, db)

    if (groupMode !== 'pushkontak') {
        return m.reply(`❌ *الوضع غير مناسب*\n\n> فعّل وضع الإرسال الجماعي أولاً\n\n\`${m.prefix}botmode pushkontak\``)
    }

    const text = m.text?.trim()
    if (!text) {
        return m.reply(`📢 *الإرسال الجماعي*\n\n> اكتب الرسالة التي تريد إرسالها\n\n\`مثال: ${m.prefix}pushkontak مرحباً بالجميع!\``)
    }

    if (global.statuspush) {
        return m.reply(`❌ *فشل*\n\n> الإرسال الجماعي يعمل الآن. اكتب \`${m.prefix}stoppush\` لإيقافه.`)
    }

    m.react('📢')

    try {
        const metadata = m.groupMetadata
        const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net'
        const participants = metadata.participants
            .map(p => p.jid || p.id)
            .filter(id => id !== botId)
            .filter(id => !id.includes(m.sender))

        if (participants.length === 0) {
            m.react('❌')
            return m.reply(`❌ *عذراً* ✦\n\n> لا يوجد أعضاء يمكن الإرسال إليهم~ 🥺`)
        }

        const jedaPush = db.setting('jedaPush') || 5000

        await m.reply(
            `📢 *الإرسال الجماعي*\n\n` +
            `╭┈┈⬡「 📋 *التفاصيل* 」\n` +
            `┃ 📝 الرسالة: \`${text.substring(0, 50)}${text.length > 50 ? '...' : ''}\`\n` +
            `┃ 👥 الهدف: \`${participants.length}\` عضو\n` +
            `┃ ⏱️ الفاصل: \`${jedaPush}ms\`\n` +
            `┃ 📊 الوقت المتوقع: \`${Math.ceil((participants.length * jedaPush) / 60000)} دقيقة\`\n` +
            `┃ 💾 حفظ تلقائي: \`مفعّل (VCF)\`\n` +
            `╰┈┈⬡\n\n` +
            `> جارٍ بدء الإرسال...`
        )

        global.statuspush = true
        let successCount = 0
        let failedCount = 0
        const savedContacts = []

        for (const member of participants) {
            if (global.stoppush) {
                delete global.stoppush
                delete global.statuspush

                await m.reply(
                    `⏹️ *ᴘᴜsʜ ᴅɪʜᴇɴᴛɪᴋᴀɴ*\n\n` +
                    `> ✅ نجح: \`${successCount}\`\n` +
                    `> ❌ فشل: \`${failedCount}\`\n` +
                    `> ⏸️ المتبقي: \`${participants.length - successCount - failedCount}\``
                )

                if (savedContacts.length > 0) {
                    await sendVcfToOwner(sock, m.sender, savedContacts, metadata.subject)
                }
                return
            }

            try {
                const kodeUnik = createSerial(6)
                const pesan = `${text}\n\n#${kodeUnik}`

                await sock.sendMessage(member, { text: pesan })
                savedContacts.push(member)
                successCount++
            } catch (err) {
                failedCount++
            }

            await new Promise(resolve => setTimeout(resolve, jedaPush))
        }

        delete global.statuspush

        if (savedContacts.length > 0) {
            await sendVcfToOwner(sock, m.sender, savedContacts, metadata.subject)
        }

        m.react('✅')
        await m.reply(
            `✅ *ᴘᴜsʜ sᴇʟᴇsᴀɪ*\n\n` +
            `╭┈┈⬡「 📊 *النتيجة* 」\n` +
            `┃ ✅ نجح: \`${successCount}\`\n` +
            `┃ ❌ فشل: \`${failedCount}\`\n` +
            `┃ 📊 الإجمالي: \`${participants.length}\`\n` +
            `┃ 💾 ᴋᴏɴᴛᴀᴋ: \`${savedContacts.length} حفظه\`\n` +
            `╰┈┈⬡`
        )

    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/pushkontak/pushkontak.js] exception", error?.stack || error);
        delete global.statuspush
        m.react('❌')
        m.reply("حدث خطأ، حاول لاحقاً")
    }
}

async function sendVcfToOwner(sock, ownerJid, contacts, groupName) {
    try {
        const vcfDir = path.join(process.cwd(), 'tmp')
        if (!fs.existsSync(vcfDir)) fs.mkdirSync(vcfDir, { recursive: true })

        const vcfPath = path.join(vcfDir, `pushkontak_${Date.now()}.vcf`)
        const vcfContent = buildVcf(contacts)
        fs.writeFileSync(vcfPath, vcfContent, 'utf8')

        await sock.sendMessage(ownerJid, {
            document: fs.readFileSync(vcfPath),
            fileName: `Kontak_${groupName || 'Group'}_${contacts.length}.vcf`,
mimetype: 'text/vcard',
            caption: `💾 *ᴀᴜᴛᴏ-حفظ جهات الاتصال*\n\n> الإجمالي: \`${contacts.length}\` kontak\n> المجموعة: \`${groupName || 'Unknown'}\`\n\n> _Import ملف هذا إلى HP لـ menyimpan كل kontak._`
        })

        try { fs.unlinkSync(vcfPath) } catch {}
    } catch (e) {}
}

module.exports = {
    config: pluginConfig,
    handler
}
