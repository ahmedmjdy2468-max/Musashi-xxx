const { getDatabase } = require('../../src/lib/database')

const pluginConfig = {
    name: "",
    alias: ['setdelay', 'jeda'],
    category: 'pushkontak',
    description: 'Atur delay لـ pushkontak/jpm',
    usage: '.setjeda <push/jpm> <ms>',
    example: '.setjeda push 5000',
    isOwner: true,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const db = getDatabase()
    const args = m.args
    
    const currentJedaPush = db.setting('jedaPush') || 5000
    const currentJedaJpm = db.setting('jedaJpm') || 5000
    
    if (args.length < 2) {
        return m.reply(
            `⏱️ *sᴇᴛ الفاصل*\n\n` +
            `╭┈┈⬡「 📋 *الإعدادات الحالية* 」\n` +
            `┃ 📤 الفاصل ᴘᴜsʜ: \`${currentJedaPush}ms\`\n` +
            `┃ 📢 الفاصل ᴊᴘᴍ: \`${currentJedaJpm}ms\`\n` +
            `╰┈┈⬡\n\n` +
            `*طريقة الاستخدام:*\n` +
            `> \`${m.prefix}setjeda push 5000\`\n` +
            `> \`${m.prefix}setjeda jpm 6000\`\n\n` +
            `> _1 ثانية = 1000ms_`
        )
    }
    
    const target = args[0].toLowerCase()
    const value = parseInt(args[1])
    
    if (!['push', 'jpm'].includes(target)) {
        return m.reply(`❌ *فشل*\n\n> الخيارات: \`push\` أو \`jpm\``)
    }
    
    if (isNaN(value) || value < 1000) {
        return m.reply(`❌ *عذراً* ✦\n\n> أدخل رقماً minimal 1000 (1 ثانية)~ 🥺`)
    }
    
    if (value > 60000) {
        return m.reply(`❌ *عذراً* ✦\n\n> الحد الأقصى 60000 (1 دقيقة)~ 🥺`)
    }
    
    if (target === 'push') {
        db.setting('jedaPush', value)
        m.react('✅')
        return m.reply(`✅ *الفاصل ᴘᴜsʜ ᴅɪᴜʙᴀʜ*\n\n> Jeda: \`${value}ms\` (${value/1000} ثانية)`)
    }
    
    if (target === 'jpm') {
        db.setting('jedaJpm', value)
        m.react('✅')
        return m.reply(`✅ *الفاصل ᴊᴘᴍ ᴅɪᴜʙᴀʜ*\n\n> Jeda: \`${value}ms\` (${value/1000} ثانية)`)
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
