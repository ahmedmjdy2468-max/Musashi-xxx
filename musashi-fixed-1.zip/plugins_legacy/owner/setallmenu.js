// ============================================================
// setallmenu.js — + V6 & V7
// ============================================================

const config = require('../../config')
const { getDatabase } = require('../../src/lib/database')
const { generateWAMessageFromContent, proto } = require('itsuki')

const pluginConfig = {
    name: 'setallmenu',
    alias: ['allmenuvariant', 'allmenustyle', 'setam'],
    category: 'owner',
    description: 'Mengatur variant tampilan allmenu',
    usage: '.setallmenu <v1-v7>',
    example: '.setallmenu v2',
    isOwner: true,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 3,
    energi: 0,
    isEnabled: true
}

const VARIANTS = {
    v1: { id: 1, name: 'Simple Text',        desc: 'النص biasa tanpa صورة, cocok لـ perangkat low-end' },
    v2: { id: 2, name: 'Image + Interactive', desc: 'viewOnce image header + limited_time_offer + tombol kembali ke menu' },
    v3: { id: 3, name: 'Location Header',    desc: 'viewOnce location header (thumbnail 300x300) + newsletter contextInfo, tanpa tombol' },
    v4: { id: 4, name: 'Carousel Kategori',  desc: 'Setiap kategori jadi card carousel sendiri مع الصورة + list الأمر + quick_reply' },
    v5: { id: 5, name: 'Location + Order Quoted', desc: 'viewOnce location header + وهمية order quoted + tombol channel, menu الرئيسية, dan owner' },
    v6: { id: 6, name: 'Location + Cuaca Real-time', desc: 'Header location langsung (bukan quoted) مع cuaca real-time di address, tanpa tombol — paling minimalis' },
    v7: { id: 7, name: 'Footer sebagai isi',  desc: 'Sapaan singkat di body, daftar الأمر lengkap dipindah ke footer biar keliatan ringkas' }
}

async function handler(m, { sock, db }) {
    const args = m.args || []
    const variant = args[0]?.toLowerCase()

    if (variant) {
        const selected = VARIANTS[variant]
        if (!selected) {
            await m.reply(
                `✦ *Kon-MUSASHI~* ✦\n\n` +
                `همم~ \`${variant}\` ليست نسخة معروفة 🌸\n` +
                `استخدم: \`v1\` s/d \`v${Object.keys(VARIANTS).length}\` نعم Kak~`
            )
            return
        }

        db.setting('allMenuVariant', selected.id)
        await db.save()

        await m.reply(
            `✦ *ᴀʟʟالقائمة ᴅɪᴘᴇʀʙᴀʀᴜɪ~* ✦\n\n` +
            `Yay~ MUSASHI تم غيّر tampilan allmenu-nya! ⭐\n\n` +
            `> 📋 *V${selected.id} — ${selected.name}*\n` +
            `> _${selected.desc}_\n\n` +
            `_Semoga daftarnya makin rapi من فضلك Kak~ 💕_`
        )
        return
    }

    const current = db.setting('allMenuVariant') || config.ui?.allMenuVariant || 2

    const rows = Object.entries(VARIANTS).map(([key, val]) => ({
        title: `${key.toUpperCase()}${val.id === current ? ' ✓' : ''} — ${val.name}`,
        description: val.desc,
        id: `${m.prefix}setallmenu ${key}`
    }))

    const bodyText =
        `✦ *sᴇᴛ ᴀʟʟالقائمة ᴠᴀʀɪᴀɴᴛ* ✦\n\n` +
        `أهلاً بك *${m.pushName}*! 🌟\n` +
        `في sini MUSASHI يمكن atur tampilan القائمة كل القائمة~\n\n` +
        `> النسخة النشطة: *V${current}*\n` +
        `> _${VARIANTS[`v${current}`]?.name || 'Unknown'}_\n\n` +
        `> اختر النسخة من القائمة أدناه 💕`

    try {
        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                    interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                        body: proto.Message.InteractiveMessage.Body.fromObject({ text: bodyText }),
                        footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: config.bot?.name || 'MUSASHI' }),
                        header: proto.Message.InteractiveMessage.Header.fromObject({
                            title: '📋 AllMenu Variant',
                            subtitle: `${Object.keys(VARIANTS).length} نسخة متاحة`,
                            hasMediaAttachment: false
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                            buttons: [{
                                name: 'single_select',
                                buttonParamsJson: JSON.stringify({
                                    title: '📋 ᴘɪʟɪʜ ᴠᴀʀɪᴀɴᴛ',
                                    sections: [{ title: 'ᴅᴀꜰᴛᴀʀ ᴠᴀʀɪᴀɴᴛ ᴀʟʟالقائمة', rows }]
                                })
                            }]
                        }),
                        contextInfo: {
                            mentionedJid: [m.sender],
                            forwardingScore: 9999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.saluran?.id || '120363432546133683@newsletter',
                                newsletterName: config.saluran?.name || config.bot?.name || 'MUSASHI',
                                serverMessageId: 127
                            }
                        }
                    })
                }
            }
        }, { userJid: m.sender, quoted: m })

        await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
    } catch {
        let txt = `✦ *sᴇᴛ ᴀʟʟالقائمة ᴠᴀʀɪᴀɴᴛ* ✦\n\nKon-MUSASHI~! 🌟 النسخة النشطة: *V${current}*\n\n`
        for (const [key, val] of Object.entries(VARIANTS)) {
            const mark = val.id === current ? ' ✓' : ''
            txt += `> *${key.toUpperCase()}*${mark} — _${val.desc}_\n`
        }
        txt += `\n_استخدم: \`.setallmenu v1\` dst._`
        await m.reply(txt)
    }
}

module.exports = { config: pluginConfig, handler }