const fs = require('fs')
const path = require('path')

const pluginConfig = {
    name: 'disableplugin',
    alias: ['dplugin', 'plugindisable', 'offplugin'],
    category: 'owner',
    description: 'Menonaktifkan plugin tertentu',
    usage: '.disableplugin <nama_plugin>',
    example: '.disableplugin sticker',
    isOwner: true,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 3,
    energi: 0,
    isEnabled: true
}

function findPluginFile(pluginName) {
    const pluginsDir = path.join(process.cwd(), 'plugins')
    const categories = fs.readdirSync(pluginsDir).filter(f => {
        return fs.statSync(path.join(pluginsDir, f)).isDirectory()
    })
    
    for (const category of categories) {
        const categoryPath = path.join(pluginsDir, category)
        const files = fs.readdirSync(categoryPath).filter(f => f.endsWith('.js'))
        
        for (const file of files) {
            try {
                const filePath = path.join(categoryPath, file)
                const plugin = require(filePath)
                
                if (!plugin.config) continue
                
                const name = Array.isArray(plugin.config.name) 
                    ? plugin.config.name[0] 
                    : plugin.config.name
                    
                const aliases = plugin.config.alias || []
                
                if (name === pluginName || aliases.includes(pluginName)) {
                    return { filePath, plugin, category, file }
                }
            } catch {}
        }
    }
    
    return null
}

async function handler(m, { sock }) {
    const args = m.args || []
    const pluginName = args[0]?.toLowerCase()
    
    if (!pluginName) {
        return m.reply(
            `🔌 *ᴅɪsᴀʙʟᴇ الإضافة*\n\n` +
            `> أدخل الاسم plugin الذي يريد تم إيقافه\n\n` +
            `*مثال:*\n` +
            `> \`${m.prefix}disableplugin sticker\`\n` +
            `> \`${m.prefix}disableplugin tiktok\``
        )
    }
    
    const found = findPluginFile(pluginName)
    
    if (!found) {
        return m.reply(`❌ *همم~* Plugin *${pluginName}* غير موجود~ 🥺`)
    }
    
    const { filePath, plugin, category, file } = found
    
    if (plugin.config.isEnabled === false) {
        return m.reply(`⚠️ *Eh eh~* Plugin *${pluginName}* تم تم إيقافه~ 🌸`)
    }
    
    try {
        let content = fs.readFileSync(filePath, 'utf-8')
        
        content = content.replace(
            /isEnabled:\s*true/i,
            'isEnabled: false'
        )
        
        fs.writeFileSync(filePath, content)
        
        delete require.cache[require.resolve(filePath)]
        
        await m.reply(
            `✅ *الإضافة ᴅɪsᴀʙʟᴇᴅ*\n\n` +
            `╭┈┈⬡「 📋 *التفاصيل* 」\n` +
            `┃ 📦 Plugin: *${plugin.config.name}*\n` +
            `┃ 📁 Category: *${category}*\n` +
            `┃ 📄 ملف: *${file}*\n` +
            `┃ 🔴 الحالة: *Disabled*\n` +
            `╰┈┈⬡\n\n` +
            `> إعادة تشغيل البوت أو استخدم hot reload لـ apply.`
        )
        
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/owner/disableplugin.js] exception", error?.stack || error);
        await m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
