const itsukiAI = require('../../src/lib/itsukiAI')

const pluginConfig = {
    name: 'aicontroll',
    alias: ['aictrl'],
    category: 'owner',
    description: 'Panel Itsuki AI: nyala/mati, المجموعة, akses folder, tulis ملف (خاص بالمالك)',
    usage: '.aicontroll الحالة | on|off | listen on|off | المجموعة on|off | tools on|off | dir [folder] | baca <ملف> | tulis <ملف> (ردّ على code) | konfirmasi | reset',
    example: '.aicontroll dir plugins',
    isOwner: true,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 2,
    energi: 0,
    isEnabled: true
}

const onoff = (v) => (v ? 'AKTIF' : 'NONAKTIF')
const isOO = (v) => v === 'on' || v === 'off'

function statusText(c, p) {
    return [
        'الحالة Itsuki AI',
        `- Aktif            : ${onoff(c.enabled)}`,
        `- Dipanggil nama   : ${onoff(c.listen)}`,
        `- Balas في المجموعة    : ${onoff(c.group)}`,
        `- Akses folder AI  : ${onoff(c.tools)}`,
        '- Otak             : Gemini via RyuuApi',
        '- Batas user       : 20 الرسائل per hari',
        '',
        'Perintah:',
        `${p}aicontroll on / off`,
        `${p}aicontroll listen on / off`,
        `${p}aicontroll المجموعة on / off`,
        `${p}aicontroll tools on / off`,
        `${p}aicontroll dir [folder]`,
        `${p}aicontroll baca <ملف>`,
        `${p}aicontroll tulis <ملف> (reply code)`,
        `${p}aicontroll konfirmasi`,
        `${p}aicontroll reset`,
    ].join('\n')
}

const ITSUKI_AD_TITLE = 'AICONTROLL'
const ITSUKI_AD_BODY = 'Itsuki AI • Panel Kontrol'

// Balasan teks dengan extended text (thumbnail dari config.assets.images.itsukimenu)
async function sendExtText(sock, m, text) {
    const cfg = require('../../config')
    const thumb = cfg.assets?.images?.itsukimenu
    if (!sock || !thumb) return m.reply(text)
    return sock.sendMessage(
        m.chat,
        {
            text,
            contextInfo: {
                externalAdReply: {
                    title: ITSUKI_AD_TITLE,
                    body: ITSUKI_AD_BODY,
                    thumbnailUrl: thumb,
                    sourceUrl: thumb,
                    mediaType: 1,
                    renderLargerThumbnail: false,
                    showAdAttribution: false
                }
            }
        },
        { quoted: m }
    )
}

async function handler(m, { sock } = {}) {
    const reply = (text) => sendExtText(sock, m, text)

    const p = m.prefix || '.'
    const args = m.args || []
    const sub = (args[0] || 'status').toLowerCase()
    const a1 = (args[1] || '').toLowerCase()
    const rest = args.slice(1).join(' ').trim()

    try {
        if (sub === 'status') return reply(statusText(itsukiAI.getControl(), p))

        // Edit gambar: .aicontroll edit <url https> | <prompt>
        if (sub === 'edit') {
            const body = (args.slice(1).join(' ') || '').trim()
            const [urlPart, ...promptParts] = body.split('|').map(x => x.trim())
            const prompt = promptParts.join(' | ').trim()
            if (!/^https:\/\//i.test(urlPart || '') || !prompt) {
                return reply(`استخدام: ${p}aicontroll تعديل <url https> | <وصف>\nContoh: ${p}aicontroll تعديل https://example.com/a.jpg | تعديل jadi gaya retro`)
            }
            if (!sock) return reply('فشل: الاتصال البوت غير متاح.')
            await m.react('🎨')
            const image = await itsukiAI.editImage(urlPart, prompt)
            await sock.sendMessage(m.chat, { image, caption: `🎨 ${prompt.slice(0, 200)}` }, { quoted: m })
            return m.react('✅')
        }

        if (sub === 'on' || sub === 'off') {
            itsukiAI.setControl({ enabled: sub === 'on' })
            return reply(`Itsuki AI: ${onoff(sub === 'on')}`)
        }
        if (sub === 'listen' && isOO(a1)) {
            itsukiAI.setControl({ listen: a1 === 'on' })
            return reply(`Dipanggil nama: ${onoff(a1 === 'on')}`)
        }
        if (sub === 'المجموعة' && isOO(a1)) {
            itsukiAI.setControl({ group: a1 === 'on' })
            return reply(`Balas في المجموعة: ${onoff(a1 === 'on')}`)
        }
        if (sub === 'tools' && isOO(a1)) {
            itsukiAI.setControl({ tools: a1 === 'on' })
            return reply(`Akses folder AI: ${onoff(a1 === 'on')}`)
        }

        if (sub === 'dir') {
            const { rel, items } = itsukiAI.listDir(rest || '.')
            if (!items.length) return reply(`Folder ${rel} kosong.`)
            return reply(`*${rel}* (${items.length} item)\n` + items.join('\n'))
        }

        if (sub === 'baca') {
            if (!rest) return reply(`Pakai: ${p}aicontroll baca <path ملف>`)
            const { rel, total, head } = itsukiAI.readFileHead(rest)
            return reply(`*${rel}* (${total} baris, 60 pertama)\n\`\`\`\n${head}\n\`\`\``)
        }

        if (sub === 'tulis') {
            if (!rest) return reply(`استخدام: ردّ على kode, lalu ${p}aicontroll tulis <path ملف.js>`)
            let code = ''
            if (m.quoted?.isDocument) {
                const buf = await m.quoted.download()
                code = buf ? buf.toString('utf8') : ''
            } else {
                code = m.quoted?.text || m.quoted?.body || ''
            }
            const r = itsukiAI.prepareWrite(m.sender, rest, code)
            return reply(
                `Siap menulis *${r.rel}* (${r.lines} baris).\n` +
                `اكتب ${p}aicontroll konfirmasi dalam 2 دقيقة لـ menyimpan. Backup otomatis dibuat.`
            )
        }

        if (sub === 'konfirmasi') {
            const r = itsukiAI.confirmWrite(m.sender)
            return reply(`الملف حفظه: ${r.rel}` + (r.backup ? `\nBackup: ${r.backup}` : '') + `\nRestart bot agar صالح.`)
        }

        if (sub === 'reset') {
            const n = itsukiAI.resetAll()
            const jumlah = typeof n === 'object' ? n.riwayat : n
            return reply(`Riwayat Itsuki direset (${jumlah} percakapan). الإعدادات لا berubah.`)
        }
    } catch (err) {
        console.error("[MUSASHI][plugins_legacy/owner/aicontroll.js] exception", err?.stack || err);
        return reply("حدث خطأ، حاول لاحقاً")
    }

    return reply(statusText(itsukiAI.getControl(), p))
}

module.exports = { config: pluginConfig, handler }
