const { getDatabase } = require('../../src/lib/database')

const pluginConfig = {
    name: 'cmdvn',
    alias: ['voicecommand', 'vncmd'],
    category: 'owner',
    description: 'يشغّل أو يوقف تنفيذ الأوامر عند نطق اسمها في رسالة صوتية؛ للمالك فقط.',
    usage: '.أوامر_صوتية <تشغيل/إيقاف>',
    example: '.أوامر_صوتية تشغيل',
    isOwner: true,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 3,
    energi: 0,
    isEnabled: true
}

async function handler(m) {
    const db = getDatabase()
    const args = m.args || []
    const subCmd = args[0]?.toLowerCase()
    const enable = ['on', 'تشغيل', 'تفعيل'].includes(subCmd)
    const disable = ['off', 'إيقاف', 'ايقاف', 'تعطيل'].includes(subCmd)

    const current = db.setting('cmdVn') || false

    if (!subCmd || subCmd === 'status') {
        return m.reply(
            `🎤 *الأوامر الصوتية*\n\n` +
            `> الحالة: *${current ? '✅ مفعّلة' : '❌ متوقفة'}*\n\n` +
            `> \`${m.prefix}أوامر_صوتية تشغيل\` — تفعيلها\n` +
            `> \`${m.prefix}أوامر_صوتية إيقاف\` — إيقافها\n\n` +
            `عند تفعيلها، أرسل رسالة صوتية تتضمن اسم أمر. يعتمد التنفيذ على دقة تحويل الصوت إلى نص.`
        )
    }

    if (enable) {
        db.setting('cmdVn', true)
        return m.reply(
            `✅ فُعّلت الأوامر الصوتية.\n\n` +
            `> أرسل رسالة صوتية تتضمن اسم الأمر المطلوب.`
        )
    }

    if (disable) {
        db.setting('cmdVn', false)
        return m.reply(`🔕 أُوقفت الأوامر الصوتية. يمكنك استخدام الأوامر النصية كالمعتاد.`)
    }

    return m.reply(`❌ استخدم \`${m.prefix}أوامر_صوتية تشغيل\` أو \`${m.prefix}أوامر_صوتية إيقاف\`.`)
}

module.exports = {
    config: pluginConfig,
    handler
}
