const fs = require('fs')
const path = require('path')

const pluginConfig = {
    name: 'غيّر-itsuki.mp3',
    alias: ['gantiitsukiaudio', 'setitsukiaudio'],
    category: 'owner',
    description: 'Ganti audio itsuki.mp3',
    usage: '.غيّر-itsuki.mp3 (ردّ على/أرسل صوت)',
    example: '.غيّر-itsuki.mp3',
    isOwner: true,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const isAudio = m.type === 'audioMessage' || (m.quoted && m.quoted.type === 'audioMessage')
    
    if (!isAudio) {
        return m.reply(`🎵 *ɢᴀɴᴛɪ ʜsɴᴀɪ.طاقة3*\n\n> أرسل/ردّ على صوت لـ mengganti\n> Key: config.assets.صوت.itsuki`)
    }
    
    try {
        let buffer
        if (m.quoted && m.quoted.isMedia) {
            buffer = await m.quoted.download()
        } else if (m.isMedia) {
            buffer = await m.download()
        }
        
        if (!buffer) {
            return m.reply(`❌ *عذراً* فشل mendownload audio~ 🥺`)
        }
        
        const { uploadAndSetAsset } = require('../../src/lib/assetManager')
        const url = await uploadAndSetAsset('audio.itsuki', buffer, 'itsuki.mp3')
        
        m.reply(`✅ *نجح*\n\n> Audio itsuki.mp3 telah diganti\n> Link جديد: ${url}`)
        
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/owner/غيّر-itsuki-mp3.js] exception", error?.stack || error);
        m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
