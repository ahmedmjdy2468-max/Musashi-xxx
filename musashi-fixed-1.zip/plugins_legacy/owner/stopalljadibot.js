const { stopAllJadibots, getActiveJadibots } = require('../../src/lib/jadibotManager')

const pluginConfig = {
    name: 'stopalljadibot',
    alias: ['stopsemuajadibot', 'killalljadibots'],
    category: 'owner',
    description: 'للمالك: يوقف جميع نسخ البوت الفرعية النشطة ويحفظ جلساتها.',
    usage: '.إيقاف_البوتات_الفرعية',
    example: '.إيقاف_البوتات_الفرعية',
    isOwner: true,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const active = getActiveJadibots()

    if (active.length === 0) {
        return m.reply(`❌ لا توجد نسخ فرعية نشطة لإيقافها.`)
    }

    m.react('🕕')

    try {
        const stopped = await stopAllJadibots()

        m.react('✅')

        const names = stopped.map(id => `@${id}`).join(', ')

        await sock.sendMessage(m.chat, {
            text: `🛑 *أُوقفت النسخ الفرعية*\n\n` +
                `> 📊 عدد النسخ التي أُوقفت: *${stopped.length}*\n` +
                `> 💾 حُفظت الجلسات.\n\n` +
                `النسخ التي أُوقفت: ${names}\n\n` +
                `> يمكنك تشغيل النسخ مجدداً لاحقاً.`,
            mentions: stopped.map(id => id + '@s.whatsapp.net')
        }, { quoted: m })
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/owner/stopalljadibot.js] exception", error?.stack || error);
        m.react('❌')
        await m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
