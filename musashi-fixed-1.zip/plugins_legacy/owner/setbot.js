const fs = require('fs')
const path = require('path')

const pluginConfig = {
    name: 'set-bot',
    alias: ['botset', 'ubahbot', 'setv'],
    category: 'owner',
    description: '👗 Ganti kostum (nama/mode/versi) MUSASHI biar makin fresh!',
    usage: '.set-bot <name/mode/version> <teks>',
    example: '.set-bot version 2.3.0',
    isOwner: true,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock, config }) {
    const args = m.args || []
    const type = args[0]?.toLowerCase()
    const value = args.slice(1).join(' ')

    // Menu bantuan jika input kosong atau salah
    if (!type || !value) {
        return m.reply(
`🌸 *MUSASHI - Config Editor* 🌸

مرحباً Senpai! يريد تعديل identitasku نعم? Hehe~ 🤭
استخدم الصيغة: \`${m.prefix}${pluginConfig.name} <tipe> <القيمة>\`

✨ *القائمة الذي يمكن diubah:*
1. 📛 \`name\` — Ganti الاسم البوت
2. 🆙 \`version\` — Ganti versi البوت
3. 🔓 \`mode\` — Ganti mode (public / self)

💡 *مثال:*
- \`${m.prefix}set-البوت name MUSASHI v2\`
- \`${m.prefix}set-البوت version 2.3.5\`
- \`${m.prefix}set-البوت mode self\`

Jangan حتى خطأ نعم, لاحقاً أنا bingung! 💕`)
    }

    const configPath = path.join(process.cwd(), 'config.js')
    
    try {
        let content = fs.readFileSync(configPath, 'utf8')
        let successMsg = ''

        if (type === 'name') {
            // Regex khusus mencari "name" di dalam object "bot"
            content = content.replace(/(bot:\s*{[\s\S]*?name:\s*['"])(.*?)(['"])/, `$1${value}$3`)
            config.bot.name = value
            successMsg = `🌟 Yay! Panggil أنا *${value}* الآن نعم, Senpai~ Hehe! 😘`
        } 
        else if (type === 'version') {
            // Regex khusus mencari "version" di dalam object "bot"
            content = content.replace(/(bot:\s*{[\s\S]*?version:\s*['"])(.*?)(['"])/, `$1${value}$3`)
            config.bot.version = value
            successMsg = `🆙 انتهى! الآن أنا تم versi *${value}*. Makin canggih kan? ✨`
        } 
        else if (type === 'mode') {
            const modeVal = value.toLowerCase()
            if (!['public', 'self'].includes(modeVal)) {
                return m.reply('🌸 Uh-oh~ Pilihannya cuma يوجد `public` أو `self` نعم, Senpai! 😅')
            }
            content = content.replace(/(mode:\s*['"])(.*?)(['"])/, `$1${modeVal}$3`)
            config.mode = modeVal
            successMsg = `💫 Oke! الآن أنا mode *${modeVal}*. Fokus إلى Senpai فقط هنا~ 💖`
        } 
        else {
            return m.reply('😅 Tipe ذلك لا يوجد في list, Senpai~ حاول cek مرة أخرى deh! 🌟')
        }

        // Simpan perubahan ke file config.js secara permanen
        fs.writeFileSync(configPath, content)
        
        // Kirim pesan sukses
        m.reply(successMsg)

    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/owner/setbot.js] exception", error?.stack || error);
        m.reply(
"حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}