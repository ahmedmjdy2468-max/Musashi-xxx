const { getDatabase } = require('../../src/lib/database')

const pluginConfig = {
    name: 'delexp',
    alias: ['kurangexp', 'removeexp', 'delxp'],
    category: 'owner',
    description: 'ينقص نقاط الخبرة من رصيدك أو رصيد العضو المحدد؛ للمالك فقط.',
    usage: '.إنقاص_الخبرة <العدد> [@عضو]',
    example: '.إنقاص_الخبرة 5000 @عضو',
    isOwner: true,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 3,
    energi: 0,
    isEnabled: true
}

function formatNumber(num) {
    if (num >= 1000000000) return (num / 1000000000).toFixed(2) + ' مليار'
    if (num >= 1000000) return (num / 1000000).toFixed(2) + ' مليون'
    if (num >= 1000) return (num / 1000).toFixed(2) + ' ألف'
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.')
}

function extractTarget(m) {
    if (m.quoted) return m.quoted.sender
    if (m.mentionedJid?.length) return m.mentionedJid[0]
    return null
}

async function handler(m) {
    const db = getDatabase()
    const args = m.args
    const numArg = args.find(a => !isNaN(a) && !a.startsWith('@'))
    const amount = parseInt(numArg) || 0
    let targetJid = extractTarget(m)

    if (!targetJid && amount > 0) targetJid = m.sender

    if (!targetJid || amount <= 0) {
        return m.reply(
            `⭐ *إنقاص نقاط الخبرة*\n\n` +
            `> \`.إنقاص_الخبرة <العدد>\` - من رصيدك\n` +
            `> \`.إنقاص_الخبرة <العدد> @عضو\` - من رصيد عضو\n\n` +
            `\`مثال: ${m.prefix}إنقاص_الخبرة 5000\``
        )
    }

    if (amount <= 0) return m.reply('❌ يجب أن تكون الكمية أكبر من صفر.')

    const user = db.getUser(targetJid)
    if (!user) return m.reply('❌ لا يوجد سجل لهذا المستخدم في قاعدة البيانات.')

    const newExp = db.updateExp(targetJid, -amount)
    m.react('✅')
    await m.reply(
        `✅ *خُصمت نقاط الخبرة*\n\n` +
        `╭┈┈⬡「 📋 *التفاصيل* 」\n` +
        `┃ 👤 العضو: @${targetJid.split('@')[0]}\n` +
        `┃ ➖ الخصم: *-${formatNumber(amount)}*\n` +
        `┃ ⭐ الرصيد المتبقي: *${formatNumber(newExp)}*\n` +
        `╰┈┈⬡`,
        { mentions: [targetJid] }
    )
}

module.exports = { config: pluginConfig, handler }
