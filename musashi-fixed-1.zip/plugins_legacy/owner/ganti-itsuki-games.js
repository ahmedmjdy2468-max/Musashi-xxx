const fs = require('fs')
const path = require('path')

const pluginConfig = {
    name: 'غيّر-itsuki-games.jpg',
    alias: ['gantigames', 'setitsukigames'],
    category: 'owner',
    description: 'Ganti صورة itsuki-games.jpg (thumbnail games)',
    usage: '.غيّر-itsuki-games.jpg (ردّ على/أرسل صورة)',
    example: '.غيّر-itsuki-games.jpg',
    isOwner: true,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const isImage = m.isImage || (m.quoted && m.quoted.type === 'imageMessage')
    
    if (!isImage) {
        return m.reply(`🖼️ *ɢᴀɴᴛɪ ʜsɴᴀɪ-اللعبةs.ᴊᴘɢ*\n\n> أرسل/ردّ على صورة لـ mengganti\n> Key: config.assets.images.itsukiGames`)
    }
    
    try {
        let buffer
        if (m.quoted && m.quoted.isMedia) {
            buffer = await m.quoted.download()
        } else if (m.isMedia) {
            buffer = await m.download()
        }
        
        if (!buffer) {
            return m.reply(`❌ *انتبه*\n\n> تعذّر تنزيل الصورة... أعد المحاولة 🥺`)
        }
        
        const { uploadAndSetAsset } = require('../../src/lib/assetManager')
        const url = await uploadAndSetAsset('images.itsukiGames', buffer, 'itsuki-games.jpg')
        
        m.reply(`✅ *نجح*\n\n> صورة itsuki-games.jpg قد diganti\n> رابط جديد: ${url}`)
        
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/owner/غيّر-itsuki-games.js] exception", error?.stack || error);
        m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
