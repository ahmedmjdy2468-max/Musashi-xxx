const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const config = require('../../config');
const { getDatabase } = require('../../src/lib/database');
const { generateWAMessageFromContent, generateWAMessage, jidNormalizedUser } = require('itsuki');

const pluginConfig = {
    name: 'srt',
    alias: ['shufflereplythumb', 'shufflereply'],
    category: 'owner',
    description: 'النظام Shuffle ردّ على Thumb (SRT) لـ ردّ على random image في كل نسخة',
    usage: '.srt on',
    example: '.srt on',
    isOwner: true,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 0,
    energi: 0,
    isEnabled: true
};

if (!global.srtSession) {
    global.srtSession = {};
}

const SHUFFLE_DIR = path.join(process.cwd(), 'data', 'shuffle');

function countShuffleImages() {
    if (!fs.existsSync(SHUFFLE_DIR)) return 0;
    const files = fs.readdirSync(SHUFFLE_DIR);
    return files.filter(f => f.endsWith('.jpg') || f.endsWith('.png') || f.endsWith('.jpeg')).length;
}

async function handler(m, { sock, args = [] }) {
    try {
        const db = getDatabase();
        const action = args[0]?.toLowerCase();

        if (!action) {
            await m.reply(
                `╭┈┈⬡ *sɪsᴛᴇᴍ sʀᴛ* ⬡\n` +
                `┊ أهلاً بك *${m.pushName}*! 🌸\n` +
                `┊ النظام *Shuffle ردّ على Thumb* إنشاء الرد البوت استخدام thumbnail acak من koleksi صورة الذي أنت حفظ sendiri.\n` +
                `┊\n` +
                `┊ *.srt on* — aktifin shuffle secara global\n` +
                `┊ *.srt off* — matiin, balik ke thumbnail default\n` +
                `┊ *.srt c* — mulai sesi capture الصورة جديد\n` +
                `┊ *.srt d* — tutup sesi capture\n` +
                `┊ *.srt list* — liat كل koleksi tersimpan\n` +
                `┊ *.srt del* — حذف صورة (ردّ على خطأ satu من list)\n` +
                `╰┈┈┈┈┈┈┈┈⬡`
            );
            return;
        }

        if (action === 'on') {
            db.setting('srtEnabled', true);
            await m.reply(
                `╭┈┈⬡ *sʀᴛ ᴀᴋᴛɪғ* ⬡\n` +
                `┊ Yay~ ميزة SRT تم nyala global! ⭐\n` +
                `┊ كل نسخة ردّ على الذي لديه thumbnail الآن bakal nampilin صورة acak من folder shuffle نعم Kak~\n` +
                `╰┈┈┈┈┈┈┈┈⬡`
            );
        }
        else if (action === 'off') {
            db.setting('srtEnabled', false);
            await m.reply(
                `╭┈┈⬡ *sʀᴛ ɴᴏɴᴀᴋᴛɪғ* ⬡\n` +
                `┊ Oke~ shuffle thumbnail dimatiin. Balasan البوت balik استخدام صورة default bawaan MUSASHI مرة أخرى~ 🌙\n` +
                `╰┈┈┈┈┈┈┈┈⬡`
            );
        }
        else if (action === 'c' || action === 'capture') {
            global.srtSession[m.chat] = { sender: m.sender, count: 0 };
            const totalImages = countShuffleImages();
            await m.reply(
                `╭┈┈⬡ *sᴇsɪ ᴄᴀᴘᴛᴜʀᴇ ᴅɪᴍᴜʟᴀɪ* ⬡\n` +
                `┊ Kirimin صورة satu-satu إلى chat هذا نعم Kak, لاحقاً MUSASHI simpen otomatis إلى database shuffle~ 📸\n` +
                `┊\n` +
                `┊ Total صورة tersimpan saat هذا: *${totalImages}*\n` +
                `┊ Udah انتهى أرسل? اكتب \`${m.prefix}srt d\` buat nutup sesinya~\n` +
                `╰┈┈┈┈┈┈┈┈⬡`
            );
        }
        else if (action === 'd' || action === 'done') {
            if (!global.srtSession[m.chat] || global.srtSession[m.chat].sender !== m.sender) {
                return m.reply(
                    `╭┈┈⬡ *ᴋᴏɴ-ᴀɪ~* ⬡\n` +
                    `┊ أنت لا مرة أخرى في dalam sesi capture مفعّل deh Kak~ 🌸\n` +
                    `╰┈┈┈┈┈┈┈┈⬡`
                );
            }
            const count = global.srtSession[m.chat].count;
            delete global.srtSession[m.chat];
            const totalImages = countShuffleImages();
            await m.reply(
                `╭┈┈⬡ *sᴇsɪ ᴄᴀᴘᴛᴜʀᴇ sᴇʟᴇsᴀɪ* ⬡\n` +
                `┊ Sesinya تم MUSASHI tutup~ ✅\n` +
                `┊ صورة جديد ditambahin sesi هذا: *${count}*\n` +
                `┊ Total keseluruhan di sistem: *${totalImages}*\n` +
                `╰┈┈┈┈┈┈┈┈⬡`
            );
        }
        else if (action === 'list') {
            if (!fs.existsSync(SHUFFLE_DIR)) return m.reply(
                `╭┈┈⬡ *ᴋᴏsᴏɴɢ* ⬡\n` +
                `┊ لم يوجد صورة tersimpan sama مرة. حاول capture أولاً استخدام \`${m.prefix}srt c\` نعم~\n` +
                `╰┈┈┈┈┈┈┈┈⬡`
            );
            const files = fs.readdirSync(SHUFFLE_DIR).filter(f => f.endsWith('.jpg') || f.endsWith('.png') || f.endsWith('.jpeg'));
            if (files.length === 0) return m.reply(
                `╭┈┈⬡ *ᴋᴏsᴏɴɢ* ⬡\n` +
                `┊ Folder shuffle ما زال kosong هنا Kak, capture أولاً gih~\n` +
                `╰┈┈┈┈┈┈┈┈⬡`
            );

            await m.reply(
                `╭┈┈⬡ *ᴅᴀғᴛᴀʀ ɢᴀᴍʙᴀʀ sʀᴛ* ⬡\n` +
                `┊ MUSASHI nemu *${files.length}* صورة tersimpan, مرة أخرى nyusun album-nya أولاً نعم Kak, انتظر bentar~ 💕\n` +
                `╰┈┈┈┈┈┈┈┈⬡`
            );

            try {
                const opener = generateWAMessageFromContent(
                    m.chat,
                    {
                        messageContextInfo: { messageSecret: crypto.randomBytes(32) },
                        albumMessage: {
                            expectedImageCount: files.length,
                            expectedVideoCount: 0,
                        },
                    },
                    {
                        userJid: jidNormalizedUser(sock.user.id),
                        quoted: m,
                        upload: sock.waUploadToServer,
                    }
                );

                await sock.relayMessage(opener.key.remoteJid, opener.message, {
                    messageId: opener.key.id,
                });

                for (let i = 0; i < files.length; i++) {
                    const imgPath = path.join(SHUFFLE_DIR, files[i]);
                    const imgBuffer = fs.readFileSync(imgPath);

                    const msg = await generateWAMessage(opener.key.remoteJid, { image: imgBuffer }, {
                        upload: sock.waUploadToServer,
                    });

                    msg.message.messageContextInfo = {
                        messageSecret: crypto.randomBytes(32),
                        messageAssociation: {
                            associationType: 1,
                            parentMessageKey: opener.key,
                        },
                    };

                    await sock.relayMessage(msg.key.remoteJid, msg.message, {
                        messageId: msg.key.id,
                    });
                }
            } catch (albumErr) {
                console.error('SRT Album الخطأ:', albumErr);
                return m.reply(
                    `╭┈┈⬡ *ᴇʀʀᴏʀ* ⬡\n` +
                    `┊ Waduh, فشل إنشاء album الصورة Kak~ 😢\n` +
                    `╰┈┈┈┈┈┈┈┈⬡`
                );
            }
        }
        else if (action === 'del' || action === 'delete') {
            const isImage = m.isImage || (m.quoted && m.quoted.isImage);
            if (!isImage) {
                return m.reply(
                    `╭┈┈⬡ *ᴄᴀʀᴀ ʜᴀᴘᴜs* ⬡\n` +
                    `┊ 1. اكتب \`${m.prefix}srt list\` buat liat koleksinya\n` +
                    `┊ 2. ردّ على خطأ satu صورة من album ذلك استخدام \`${m.prefix}srt del\`\n` +
                    `╰┈┈┈┈┈┈┈┈⬡`
                );
            }

            await m.react('🕕');
            let buffer;
            try {
                if (m.quoted && m.quoted.isImage) {
                    buffer = await m.quoted.download();
                } else if (m.isImage) {
                    buffer = await m.download();
                }
            } catch (e) {
                return m.reply(
                    `╭┈┈⬡ *ᴇʀʀᴏʀ* ⬡\n` +
                    `┊ فشل download الصورة buat حُذفت, Kak~\n` +
                    `╰┈┈┈┈┈┈┈┈⬡`
                );
            }

            if (buffer) {
                const hash = crypto.createHash('md5').update(buffer).digest('hex').substring(0, 10);
                const filename = `srt_${hash}.jpg`;
                const filepath = path.join(SHUFFLE_DIR, filename);

                if (fs.existsSync(filepath)) {
                    fs.unlinkSync(filepath);
                    await m.reply(
                        `╭┈┈⬡ *نجح* ⬡\n` +
                        `┊ صورة تم حُذفت من database shuffle~ ✅\n` +
                        `╰┈┈┈┈┈┈┈┈⬡`
                    );
                } else {
                    await m.reply(
                        `╭┈┈⬡ *غير موجود* ⬡\n` +
                        `┊ صورة هذا لا cocok sama الذي يوجد في database (أو تم kehapus duluan)~\n` +
                        `╰┈┈┈┈┈┈┈┈⬡`
                    );
                }
            }
            await m.react('✅');
        }
        else {
            await m.reply(
                `╭┈┈⬡ *لا ᴅɪᴋᴇɴᴀʟ* ⬡\n` +
                `┊ الأمر lanjutan "${action}" لا MUSASHI kenal deh~\n` +
                `╰┈┈┈┈┈┈┈┈⬡`
            );
        }

    } catch (error) {
        console.error('SRT الخطأ:', error);
        await m.reply('❌ *همم~* حدث خطأ pada sistem SRT~ 🥺');
    }
}

async function srtAnswerHandler(m, sock) {
    if (!global.srtSession) return false;
    const session = global.srtSession[m.chat];
    if (!session || session.sender !== m.sender) return false;

    if (m.isCommand) return false;

    const isImage = m.isImage || (m.quoted && m.quoted.isImage);
    if (!isImage) return false;

    try {
        await m.react('🕕');
        let buffer;
        if (m.quoted && m.quoted.isImage) {
            buffer = await m.quoted.download();
        } else if (m.isImage) {
            buffer = await m.download();
        }

        if (buffer) {
            if (!fs.existsSync(SHUFFLE_DIR)) fs.mkdirSync(SHUFFLE_DIR, { recursive: true });

            const hash = crypto.createHash('md5').update(buffer).digest('hex').substring(0, 10);
            const filename = `srt_${hash}.jpg`;
            const filepath = path.join(SHUFFLE_DIR, filename);

            if (fs.existsSync(filepath)) {
                await m.reply('⚠️ صورة الذي sama تم يوجد في database~');
            } else {
                fs.writeFileSync(filepath, buffer);
                session.count++;
                await m.reply(
                    `╭┈┈⬡ *ᴛᴇʀsɪᴍᴘᴀɴ* ⬡\n` +
                    `┊ صورة بنجاح diamankan~ ✅\n` +
                    `┊ Total ditambahin sesi هذا: *${session.count}*\n` +
                    `╰┈┈┈┈┈┈┈┈⬡`
                );
            }
        }
        await m.react('✅');
        return true;
    } catch (e) {
        await m.react('❌');
        await m.reply('❌ *عذراً* تعذّر التنزيل و menyimpan صورة~ 🥺');
        return true;
    }
}

module.exports = {
    config: pluginConfig,
    handler,
    srtAnswerHandler
};