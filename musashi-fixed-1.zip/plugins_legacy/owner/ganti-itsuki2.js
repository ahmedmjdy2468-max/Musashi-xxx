const fs = require('fs')
const path = require('path')

const pluginConfig = {
    name: 'غيّر-itsuki2.jpg',
    alias: ['gantiitsuki2', 'setitsuki2'],
    category: 'owner',
    description: 'Ganti صورة itsuki2.jpg',
    usage: '.غيّر-itsuki2.jpg (ردّ على/أرسل صورة)',
    example: '.غيّر-itsuki2.jpg',
    isOwner: true,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const isImage = m.isImage || (m.quoted && m.quoted.type === 'imageMessage')
    
    if (!isImage) {
        return m.reply(`🖼️ *ɢᴀɴᴛɪ ʜsɴᴀɪ2.ᴊᴘɢ*\n\n> أرسل/ردّ على صورة لـ mengganti\n> Key: config.assets.images.itsuki2`)
    }
    
    try {
        let buffer
        if (m.quoted && m.quoted.isMedia) {
            buffer = await m.quoted.download()
        } else if (m.isMedia) {
            buffer = await m.download()
        }
        
        if (!buffer) {
            return m.reply(`❌ *انتبه*\n\n> تعذّر تنزيل الصورة... أعد المحاولة 🥺`)
        }
        
        const { uploadAndSetAsset } = require('../../src/lib/assetManager')
        const url = await uploadAndSetAsset('images.itsuki2', buffer, 'itsuki2.jpg')
        
        m.reply(`✅ *نجح*\n\n> صورة itsuki2.jpg قد diganti\n> رابط جديد: ${url}`)
        
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/owner/غيّر-itsuki2.js] exception", error?.stack || error);
        m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
