const { stopSchedulerByName, getFullSchedulerStatus } = require('../../src/lib/scheduler');
const { stopSholatScheduler } = require('../../src/lib/sholatScheduler');
const { getDatabase } = require('../../src/lib/database');

const pluginConfig = {
    name: 'stopschedule',
    alias: ['stopscheduler', 'schedstop', 'pauseschedule'],
    category: 'owner',
    description: 'Menghentikan scheduler tertentu أو كل',
    usage: '.stopschedule <nama|all>',
    example: '.stopschedule sholat',
    isOwner: true,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 3,
    energi: 0,
    isEnabled: true
};

async function handler(m, { sock, args }) {
    try {
        const target = args[0]?.toLowerCase();
        
        if (!target) {
            const helpText = `🛑 *sᴛᴏᴘ sᴄʜᴇᴅᴜʟᴇʀ*

*Usage:*
\`.stopschedule <الاسم>\`

*Available schedulers:*
• \`limitreset\` - Daily الحد Reset
• \`groupschedule\` - المجموعة Schedule
• \`sewa\` - Sewa Checker
• \`messages\` - Scheduled Messages
• \`sholat\` - Sholat Scheduler
• \`all\` - كل scheduler

*Example:*
\`.stopschedule sholat\`
\`.stopschedule all\``;
            
            await m.reply(helpText);
            return;
        }
        
        if (target === 'sholat') {
            const db = getDatabase();
            const wasEnabled = db.setting('autoSholat');
            
            if (!wasEnabled) {
                await m.reply(`ℹ️ Sholat Scheduler تم dalam keadaan متوقف`);
                return;
            }
            
            stopSholatScheduler();
            db.setting('autoSholat', false);
            
            await m.reply(`🛑 *sᴄʜᴇᴅᴜʟᴇʀ ᴅɪʜᴇɴᴛɪᴋᴀɴ*

> Scheduler: *Sholat Scheduler*
> الحالة: ❌ Dihentikan

_استخدم \`.startschedule sholat\` لـ mengaktifkan kembali_`);
            return;
        }
        
        if (target === 'all') {
            stopSholatScheduler();
            const db = getDatabase();
            db.setting('autoSholat', false);
        }
        
        const result = stopSchedulerByName(target);
        
        if (result.stopped) {
            await m.reply(`🛑 *sᴄʜᴇᴅᴜʟᴇʀ ᴅɪʜᴇɴᴛɪᴋᴀɴ*

> Scheduler: *${result.name}*
> الحالة: ❌ Dihentikan

_استخدم \`.startschedule ${target}\` لـ mengaktifkan kembali_`);
        } else {
            await m.reply(`❌ Scheduler غير موجود أو تم متوقف

استخدم \`.stopschedule\` لـ melihat القائمة scheduler`);
        }
    } catch (error) {
        console.error('[StopSchedule Error]', error);
        await m.reply("حدث خطأ، حاول لاحقاً");
    }
}

module.exports = {
    config: pluginConfig,
    handler
};
