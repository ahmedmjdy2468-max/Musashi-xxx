const config = require('../../config')
const { getDatabase } = require('../../src/lib/database')

const pluginConfig = {
    name: 'autojoingc',
    alias: ['autojoin', 'autojoingroup'],
    category: 'owner',
    description: 'Auto join المجموعة من رابط الذي terdeteksi في chat',
    usage: '.autojoingc on/off',
    example: '.autojoingc on',
    isOwner: true,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 3,
    energi: 0,
    isEnabled: true
}

const GROUP_LINK_REGEX = /chat\.whatsapp\.com\/([a-zA-Z0-9]{18,24})/gi

async function handler(m, { sock }) {
    try {
        const db = getDatabase()
        const arg = (m.args?.[0] || '').toLowerCase()

        if (!arg || !['on', 'off'].includes(arg)) {
            const current = db.setting('autoJoinGc') || false
            return m.reply(
                `🔗 *ᴀᴜᴛᴏ ᴊᴏɪɴ ɢʀᴏᴜᴘ* ★\n\n` +
                `ne ne~ هذا ميزة buat أنا otomatis masuk المجموعة من رابط الذي kedetect نعم~\n\n` +
                `╭┈┈⬡「 📋 *الحالة* 」\n` +
                `┃ ${current ? '✅ lagi aktif nih~ ehehe~' : '❌ lagi off nih, mau dinyalain? 😏'}\n` +
                `╰┈┈┈┈┈┈┈┈⬡\n\n` +
                `> \`${m.prefix}autojoingc on\` — aktifkan ★\n` +
                `> \`${m.prefix}autojoingc off\` — nonaktifkan\n\n` +
                `_yappari إذا يريد أنا join otomatis, tinggal bilang on فقط ne~ 💜_`
            )
        }

        const enabled = arg === 'on'
        db.setting('autoJoinGc', enabled)
        await db.save()

        await m.reply(
            enabled
                ? `✅ *ᴀᴜᴛᴏ ᴊᴏɪɴ* ᴅɪᴀᴋᴛɪғᴋᴀɴ ★\n\n> ii ne~ أنا bakal otomatis masuk المجموعة إذا يوجد رابط kedetect نعم~ 💜\n> _daijoubu, serahin فقط sama أنا ehehe~_`
                : `❌ *ᴀᴜᴛᴏ ᴊᴏɪɴ* ᴅɪɴᴏɴᴀᴋᴛɪғᴋᴀɴ\n\n> mou~ yaudah أنا istirahat أولاً dari auto join نعم.\n> _kalau أحتاج مجدداً tinggal bilang فقط ne~ 🌸_`
        )
    } catch (error) {
        console.error('AutoJoinGc Plugin الخطأ:', error)
        await m.reply("حدث خطأ، حاول لاحقاً")
    }
}

async function autoJoinDetector(m, sock) {
    try {
        const db = getDatabase()
        if (!db?.ready) return false
        if (!db.setting('autoJoinGc')) return false
        if (!m.body) return false

        const matches = [...m.body.matchAll(GROUP_LINK_REGEX)]
        if (!matches.length) return false

        let joined = 0
        for (const match of matches) {
            const code = match[1]
            try {
                const result = await sock.groupAcceptInvite(code)
                if (result) joined++
            } catch (e) {
                const msg = e.message || String(e)
                if (msg.includes('already') || msg.includes('participant')) {
                    await m.reply(`⚠️ hee~ أنا تم يوجد في المجموعة ذلك kok ne~ 😏`)
                } else if (msg.includes('expired') || msg.includes('revoked')) {
                    await m.reply(`❌ mou~ linknya تم expired أو revoked هنا~\n\n> _sabishii~ لا يمكن masuk deh 🌸_`)
                } else {
                    await m.reply(`❌ *فشل ᴍᴀsᴜᴋ المجموعة* ★\n\n> iya da~ يوجد خطأ الوقت حاول join~\n> ${msg}\n\n_mou~ عذراً نعم ne~ 😳_`)
                }
            }
        }

        return joined > 0
    } catch (error) {
        console.error('AutoJoinDetector الخطأ:', error)
        return false
    }
}

module.exports = {
    config: pluginConfig,
    handler,
    autoJoinDetector
}