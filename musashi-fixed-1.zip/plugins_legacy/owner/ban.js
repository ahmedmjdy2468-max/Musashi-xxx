const config = require('../../config')
const { getDatabase } = require('../../src/lib/database')

const pluginConfig = {
    name: 'ban',
    alias: ['addban', 'block'],
    category: 'owner',
    description: 'Memblokir user dari menggunakan bot',
    usage: '.ban <nomor/@tag>',
    example: '.ban 6281234567890',
    isOwner: true,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 3,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    let targetNumber = ''
    
    if (m.quoted) {
        targetNumber = m.quoted.sender?.replace(/[^0-9]/g, '') || ''
    } else if (m.mentionedJid?.length) {
        targetNumber = m.mentionedJid[0]?.replace(/[^0-9]/g, '') || ''
    } else if (m.args[0]) {
        targetNumber = m.args[0].replace(/[^0-9]/g, '')
    }
    
    if (!targetNumber) {
        return m.reply(`🚫 *ʙᴀɴ مستخدم*\n\n> أدخل الرقم أو tag user\n\n\`مثال: ${m.prefix}ban 6281234567890\``)
    }
    
    if (targetNumber.startsWith('0')) {
        targetNumber = '62' + targetNumber.slice(1)
    }
    
    if (config.isOwner(targetNumber)) {
        return m.reply(`❌ *عذراً* ✦\n\n> لا يمكن ban owner~ 🥺`)
    }
    
    if (config.isBanned(targetNumber)) {
        return m.reply(`❌ *فشل*\n\n> الرقم \`${targetNumber}\` تم dibanned`)
    }
    
    config.bannedUsers.push(targetNumber)
    
    const db = getDatabase()
    db.setting('bannedUsers', config.bannedUsers)
    
    m.react('🚫')
    
    await m.reply(
        `🚫 *مستخدم ᴅɪʙᴀɴɴᴇᴅ*\n\n` +
        `╭┈┈⬡「 📋 *التفاصيل* 」\n` +
        `┃ 📱 ɴᴏᴍᴏʀ: \`${targetNumber}\`\n` +
        `┃ 🚫 الحالة: \`Banned\`\n` +
        `┃ 📊 الإجمالي: \`${config.bannedUsers.length}\` مستخدم\n` +
        `╰┈┈⬡`
    )
}

module.exports = {
    config: pluginConfig,
    handler
}
