const fs = require('fs')
const path = require('path')

const pluginConfig = {
    name: 'غيّر-itsuki-levelup.jpg',
    alias: ['gantiitsukilevelup', 'setitsukilevelup'],
    category: 'owner',
    description: 'Ganti صورة itsuki-levelup.jpg',
    usage: '.غيّر-itsuki-levelup.jpg (ردّ على/أرسل صورة)',
    example: '.غيّر-itsuki-levelup.jpg',
    isOwner: true,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const isImage = m.isImage || (m.quoted && m.quoted.type === 'imageMessage')
    if (!isImage) return m.reply(`🖼️ *ɢᴀɴᴛɪ Itsuki-LEVELUP.JPG*\n\n> أرسل/ردّ على صورة لـ mengganti\n> Key: config.assets.images.itsukiLevelup`)
    try {
        let buffer = m.quoted && m.quoted.isMedia ? await m.quoted.download() : await m.download()
        if (!buffer) return m.reply('❌ *انتبه*\n\n> تعذّر تنزيل الصورة... أعد المحاولة 🥺')
        const { uploadAndSetAsset } = require('../../src/lib/assetManager')
        const url = await uploadAndSetAsset('images.itsukiLevelup', buffer, 'itsuki-levelup.jpg')
        m.reply(`✅ *نجح*\n\n> صورة itsuki-levelup.jpg قد diganti\n> رابط جديد: ${url}`)
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/owner/غيّر-itsuki-levelup.js] exception", error?.stack || error);
        m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}