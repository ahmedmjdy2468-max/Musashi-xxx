const { getDatabase } = require('../../src/lib/database')

const pluginConfig = {
    name: 'settqto',
    alias: ['settq', 'tqtoset'],
    category: 'owner',
    description: 'للمالك: يحفظ اختياراً بين نمطين لعرض قائمة الأعضاء في إعدادات البوت.',
    usage: '.نمط_قائمة_الأعضاء <1/2>',
    example: '.نمط_قائمة_الأعضاء 2',
    isOwner: true,
    cooldown: 3
}

const VARIANTS = {
    v1: { id: 1, name: 'النمط المزخرف', desc: 'قائمة نصية بتنسيق مزخرف (افتراضي)' },
    v2: { id: 2, name: 'النمط الجدولي', desc: 'عرض الأعضاء في جدول' }
}

async function handler(m, { db }) {
    const database = db || await getDatabase()
    const args = m.args || []
    const rawVariant = args[0]?.toLowerCase()
    const variant = rawVariant === '1' ? 'v1' : rawVariant === '2' ? 'v2' : rawVariant

    if (variant) {
        const selected = VARIANTS[variant]

        if (!selected) {
            return m.reply('❌ اختيار غير صالح. استخدم 1 أو 2.')
        }

        database.setting('tqtoVariant', selected.id)
        await database.save()

        return m.reply(
            `✅ حُدّث نمط قائمة الأعضاء إلى *${selected.id}*\n\n` +
            `> *${selected.name}*\n` +
            `> _${selected.desc}_`
        )
    }

    const current = database.setting('tqtoVariant') || 1

    let txt = `🎨 *نمط قائمة الأعضاء*\n\n`
    txt += `> النمط النشط: *${current}*\n`
    txt += `> _${VARIANTS[`v${current}`]?.name}_\n\n`

    for (const [key, val] of Object.entries(VARIANTS)) {
        const mark = val.id === current ? ' ✓' : ''
        txt += `• النمط ${val.id}${mark} — ${val.desc}\n`
    }

    txt += `\nالاستخدام: .نمط_قائمة_الأعضاء 1 أو 2`

    return m.reply(txt)
}

module.exports = {
    config: pluginConfig,
    handler
}
