const { getDatabase } = require('../../src/lib/database')
const { f } = require('../../src/lib/undici')

const pluginConfig = {
    name: 'broadcast',
    alias: ['bc', 'bcgc', 'bcall', 'bcuser', 'bcprem', 'stopbc'],
    category: 'owner',
    description: 'Broadcast رسالة إلى كل المجموعة / user / premium',
    usage: '.bc <رسالة> | .bcgc <رسالة> | .bcuser <رسالة> | .bcprem <رسالة>',
    example: '.bc مرحباً كل! البوت update نعم~',
    isOwner: true,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

// State untuk stop broadcast
const bcState = {
    running: false,
    shouldStop: false,
    progress: 0,
    total: 0,
    type: ''
}

const AI = {
    ok:      (msg) => `✨ *${msg}*\n\n> يسعدني مساعدتك 💖`,
    err:     (msg) => `💔 *حدث خطأ ما!*\n\n> ${msg}\n\n> لا تستسلم، ما زلت هنا! ✨`,
    warn:    (msg) => `🌸 *انتبه أولاً!*\n\n> ${msg}`,
    loading: (msg) => `⏳ *Sabar نعم.*\n\n> ${msg} 💫`,
}

const delay = ms => new Promise(res => setTimeout(res, ms))

async function handler(m, { sock }) {
    const db = getDatabase()
    const cmd = m.command.toLowerCase()

    // ── STOP BROADCAST ───────────────────────────────────────────────────────
    if (cmd === 'stopbc') {
        if (!bcState.running) {
            return m.reply(AI.warn('غير موجود broadcast الذي قيد التنفيذ~'))
        }
        bcState.shouldStop = true
        m.react('🛑')
        return m.reply(
            `🛑 *ʙʀᴏᴀᴅᴄᴀsᴛ ᴅɪsᴛᴏᴘ*\n\n` +
            `> Progress: *${bcState.progress}/${bcState.total}* terkirim\n` +
            `> Type: *${bcState.type}*\n\n` +
            `> MUSASHI تم hentiin broadcast-nya نعم. 🌸`
        )
    }

    // ── GUARD: jangan jalankan 2 BC sekaligus ────────────────────────────────
    if (bcState.running) {
        return m.reply(
            AI.warn(
                `Broadcast قيد التنفيذ هنا~\n\n` +
                `> Progress: *${bcState.progress}/${bcState.total}*\n` +
                `> Type: *${bcState.type}*\n\n` +
                `> استخدم \`${m.prefix}stopbc\` لـ menghentikan`
            )
        )
    }

    // ── PARSE TARGET ─────────────────────────────────────────────────────────
    // bcgc  → hanya grup
    // bcuser → hanya user (private/terdaftar di db)
    // bcprem → hanya premium
    // bc / bcall → semua grup + user
    const isGcOnly   = cmd === 'bcgc'
    const isUserOnly = cmd === 'bcuser'
    const isPremOnly = cmd === 'bcprem'
    const isAll      = ['bc', 'bcall'].includes(cmd)

    // ── AMBIL ISI PESAN ──────────────────────────────────────────────────────
    const text = m.text?.trim() || ''
    const hasMedia = !!(m.quoted?.isImage || m.quoted?.isVideo || m.quoted?.isDocument)
    const hasCaption = !!text

    if (!text && !hasMedia) {
        return m.reply(
            `📣 *ʙʀᴏᴀᴅᴄᴀsᴛ القائمة*\n\n` +
            `╭┈┈⬡「 📋 *طريقة الاستخدام* 」\n` +
            `┃ ◦ \`${m.prefix}bc <رسالة>\` — كل (GC+المستخدم)\n` +
            `┃ ◦ \`${m.prefix}bcgc <رسالة>\` — فقط المجموعة\n` +
            `┃ ◦ \`${m.prefix}bcuser <رسالة>\` — فقط المستخدم\n` +
            `┃ ◦ \`${m.prefix}bcprem <رسالة>\` — فقط Premium\n` +
            `┃ ◦ Reply الوسائط + caption أيضاً يمكن~\n` +
            `╰┈┈⬡\n\n` +
            `╭┈┈⬡「 ⚙️ *ᴋᴏɴᴛʀᴏʟ* 」\n` +
            `┃ ◦ \`${m.prefix}stopbc\` — Stop broadcast aktif\n` +
            `╰┈┈⬡\n\n` +
            `> _Delay antar الرسائل: 2 ثانية biar aman نعم. 🌸_`
        )
    }

    // ── KUMPULKAN TARGET JIDS ─────────────────────────────────────────────────
    let targets = []

    try {
        if (isGcOnly || isAll) {
            // Ambil semua grup dari sock
            const chats = await sock.groupFetchAllParticipating()
            const gcJids = Object.keys(chats || {})
            targets.push(...gcJids.map(jid => ({ jid, label: 'المجموعة' })))
        }

        if (isUserOnly || isAll) {
            const users = db.data.users || {}
            const userJids = Object.keys(users).filter(j => j.endsWith('@s.whatsapp.net'))
            targets.push(...userJids.map(jid => ({ jid, label: 'user' })))
        }

        if (isPremOnly) {
            const prems = db.data.premium || []
            for (const p of prems) {
                const num = typeof p === 'string' ? p : p.id
                if (num) targets.push({ jid: num + '@s.whatsapp.net', label: 'premium' })
            }
        }
    } catch (e) {
        console.error("[MUSASHI][plugins_legacy/owner/broadcast.js] exception", e?.stack || e);
        return m.reply("حدث خطأ، حاول لاحقاً")
    }

    // Deduplicate
    const seen = new Set()
    targets = targets.filter(t => {
        if (seen.has(t.jid)) return false
        seen.add(t.jid)
        return true
    })

    if (targets.length === 0) {
        return m.reply(AI.warn(`غير موجود target ditemukan لـ tipe *${cmd}* هنا~`))
    }

    // ── KONFIRMASI AWAL ───────────────────────────────────────────────────────
    m.react('📣')
    await m.reply(
        `📣 *ᴍᴜʟᴀɪ ʙʀᴏᴀᴅᴄᴀsᴛ~* 🌸\n\n` +
        `╭┈┈⬡「 📋 *ɪɴꜰᴏ* 」\n` +
        `┃ 🎯 الهدف: *${targets.length}* tujuan\n` +
        `┃ 📝 ᴛɪᴘᴇ: *${cmd.toUpperCase()}*\n` +
        `┃ ⏱️ ᴅᴇʟᴀʏ: *2 ثانية/رسالة*\n` +
        `┃ ⏳ ᴇsᴛ: *~${Math.ceil(targets.length * 2 / 60)} دقيقة*\n` +
        `╰┈┈⬡\n\n` +
        `> _اكتب \`${m.prefix}stopbc\` لـ berhenti نعم~ 💖_`
    )

    // ── BUILD PESAN ───────────────────────────────────────────────────────────
    const footer = `\n\n_— 🌸 MUSASHI Bot_`
    const fullText = text + footer

    // Download media kalau ada
    let mediaBuffer = null
    let mediaMimetype = null
    if (hasMedia) {
        try {
            mediaBuffer = await m.quoted.download()
            mediaMimetype = m.quoted.mimetype || ''
        } catch {}
    }

    // ── LOOP BROADCAST ────────────────────────────────────────────────────────
    bcState.running    = true
    bcState.shouldStop = false
    bcState.progress   = 0
    bcState.total      = targets.length
    bcState.type       = cmd

    let successCount = 0
    let failCount    = 0

    for (const { jid, label } of targets) {
        if (bcState.shouldStop) break

        try {
            if (mediaBuffer) {
                const isVideo = mediaMimetype.startsWith('video/')
                const isDoc   = mediaMimetype.startsWith('application/')

                if (isVideo) {
                    await sock.sendMessage(jid, {
                        video: mediaBuffer,
                        caption: hasCaption ? fullText : footer.trim(),
                        mimetype: mediaMimetype
                    })
                } else if (isDoc) {
                    await sock.sendMessage(jid, {
                        document: mediaBuffer,
                        caption: hasCaption ? fullText : footer.trim(),
                        mimetype: mediaMimetype,
                        fileName: m.quoted.fileName || 'ملف'
                    })
                } else {
                    // default image
                    await sock.sendMessage(jid, {
                        image: mediaBuffer,
                        caption: hasCaption ? fullText : footer.trim()
                    })
                }
            } else {
                await sock.sendMessage(jid, { text: fullText })
            }
            successCount++
        } catch {
            failCount++
        }

        bcState.progress++

        // Progress update setiap 10 pesan
        if (bcState.progress % 10 === 0) {
            await m.reply(
                `📊 *ᴘʀᴏɢʀᴇss ʙᴄ*\n\n` +
                `> ✅ Terkirim: *${successCount}*\n` +
                `> ❌ فشل: *${failCount}*\n` +
                `> 📦 الإجمالي: *${bcState.progress}/${bcState.total}*\n\n` +
                `> _Sabar نعم. MUSASHI مجدداً kerja keras! 💪✨_`
            )
        }

        await delay(2000)
    }

    // ── SELESAI ───────────────────────────────────────────────────────────────
    bcState.running    = false
    bcState.shouldStop = false

    const stopped = bcState.shouldStop
    m.react('✅')

    return m.reply(
        `${stopped ? '🛑' : '✅'} *ʙʀᴏᴀᴅᴄᴀsᴛ ${stopped ? 'ᴅɪsᴛᴏᴘ' : 'sᴇʟᴇsᴀɪ'}~* 🌸\n\n` +
        `╭┈┈⬡「 📊 *ʀᴇᴋᴀᴘ* 」\n` +
        `┃ ✅ ᴛᴇʀᴋɪʀɪᴍ: *${successCount}*\n` +
        `┃ ❌ فشل: *${failCount}*\n` +
        `┃ 📦 الإجمالي: *${bcState.progress}/${targets.length}*\n` +
        `┃ 📝 ᴛɪᴘᴇ: *${cmd.toUpperCase()}*\n` +
        `╰┈┈⬡\n\n` +
        `> _Ai تم broadcast الجميع من فضلك senpai~ 💖_`
    )
}

module.exports = {
    config: pluginConfig,
    handler
}