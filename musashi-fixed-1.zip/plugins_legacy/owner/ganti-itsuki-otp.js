const fs = require('fs')
const path = require('path')

const pluginConfig = {
    name: 'غيّر-itsuki-otp.jpg',
    alias: ['gantiitsukiotp', 'setitsukiotp'],
    category: 'owner',
    description: 'Ganti صورة itsuki-otp.jpg',
    usage: '.غيّر-itsuki-otp.jpg (ردّ على/أرسل صورة)',
    example: '.غيّر-itsuki-otp.jpg',
    isOwner: true,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const isImage = m.isImage || (m.quoted && m.quoted.type === 'imageMessage')
    if (!isImage) return m.reply(`🖼️ *ɢᴀɴᴛɪ Itsuki-OTP.JPG*\n\n> أرسل/ردّ على صورة لـ mengganti\n> Key: config.assets.images.itsukiOtp`)
    try {
        let buffer = m.quoted && m.quoted.isMedia ? await m.quoted.download() : await m.download()
        if (!buffer) return m.reply('❌ *انتبه*\n\n> تعذّر تنزيل الصورة... أعد المحاولة 🥺')
        const { uploadAndSetAsset } = require('../../src/lib/assetManager')
        const url = await uploadAndSetAsset('images.itsukiOtp', buffer, 'itsuki-otp.jpg')
        m.reply(`✅ *نجح*\n\n> صورة itsuki-otp.jpg قد diganti\n> رابط جديد: ${url}`)
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/owner/غيّر-itsuki-otp.js] exception", error?.stack || error);
        m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}