const fs = require('fs')
const path = require('path')

const pluginConfig = {
    name: 'غيّر-namadev',
    alias: ['setnamadev', 'setnamedev', 'gantideveloper'],
    category: 'owner',
    description: 'للمالك: يغيّر اسم المطور المحفوظ في إعدادات البوت.',
    usage: '.تغيير_اسم_المطور <الاسم الجديد>',
    example: '.تغيير_اسم_المطور اسم المطور',
    isOwner: true,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock, config }) {
    const newName = m.args.join(' ')
    
    if (!newName) {
        return m.reply(`👨‍💻 *تغيير اسم المطور*\n\nالاسم الحالي: *${config.bot?.developer || '-'}*\n\nالاستخدام: \`${m.prefix}تغيير_اسم_المطور <الاسم الجديد>\``)
    }
    
    try {
        const configPath = path.join(process.cwd(), 'config.js')
        let configContent = fs.readFileSync(configPath, 'utf8')
        
        configContent = configContent.replace(
            /developer:\s*['"]([^'"]*)['"]/,
            `developer: '${newName}'`
        )
        
        fs.writeFileSync(configPath, configContent)
        
        config.bot.developer = newName
        
        m.reply(`✅ حُفظ اسم المطور الجديد: *${newName}*`)
        
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/owner/غيّر-namadev.js] exception", error?.stack || error);
        m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
