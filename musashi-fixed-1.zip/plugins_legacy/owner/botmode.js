const config = require('../../config')
const { getDatabase } = require('../../src/lib/database')

const pluginConfig = {
    name: "",
    alias: [],
    category: 'owner',
    description: 'Mengatur mode bot (md/cpanel/store/pushkontak/all)',
    usage: '.botmode <mode> [--autoorder]',
    example: '.botmode store --autoorder',
    isOwner: true,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 3,
    energi: 0,
    isEnabled: true
}

const VALID_MODES = ['md', 'cpanel', 'store', 'pushkontak', 'all']

const MODE_DESCRIPTIONS = {
    md: 'الوضع default, جميع الميزة kecuali panel/store/pushkontak',
    cpanel: 'الوضع panel, main + group + sticker + owner + tools + panel',
    store: 'الوضع store, main + group + sticker + owner + store',
    pushkontak: 'الوضع pushkontak, main + group + sticker + owner + pushkontak',
    all: 'الوضع full, SEMUA الميزة dari جميع mode يمكن diakses'
}

async function handler(m, { sock }) {
    const db = getDatabase()
    const args = m.args || []
    const mode = (args[0] || '').toLowerCase()
    const flags = args.slice(1).map(f => f.toLowerCase())
    const isAutoorder = false
    
    const globalMode = db.setting('botMode') || 'md'
    const groupData = m.isGroup ? (db.getGroup(m.chat) || {}) : {}
    const groupMode = groupData.botMode || null
    
    if (!mode) {
        const autoorderStatus = groupData.storeConfig?.autoorder ? '✅ ON' : '❌ OFF'
        let txt = `╭┈┈⬡「 🤖 *ʙᴏᴛ ᴍᴏᴅᴇ* 」
┃ ㊗ ɢʟᴏʙᴀʟ: *${globalMode.toUpperCase()}*
${m.isGroup ? `┃ ㊗ ɢʀᴜᴘ: *${(groupMode || 'INHERIT').toUpperCase()}*\n` : ''}${m.isGroup && (groupMode === 'store' || (!groupMode && globalMode === 'store')) ? `┃ ㊗ ᴀᴜᴛᴏᴏʀᴅᴇʀ: *${autoorderStatus}*\n` : ''}╰┈┈⬡

╭┈┈⬡「 📋 *ᴀᴠᴀɪʟᴀʙʟᴇ ᴍᴏᴅᴇs* 」
`
        const currentMode = m.isGroup ? (groupMode || globalMode) : globalMode
        for (const [key, desc] of Object.entries(MODE_DESCRIPTIONS)) {
            const isActive = key === currentMode ? ' ✅' : ''
            txt += `┃ ㊗ *${key.toUpperCase()}*${isActive}\n`
            txt += `┃   ${desc}\n`
        }
        txt += `╰┈┈⬡

*ꜰʟᴀɢ sᴛᴏʀᴇ:*
> \`${m.prefix}botmode store\` - Manual order
> \`${m.prefix}botmode store --autoorder\` - Auto payment

> \`${m.prefix}botmode md\` → الوضع default
> \`${m.prefix}botmode all\` → كل ميزة`
        
        await m.reply(txt)
        return
    }
    
    if (!VALID_MODES.includes(mode)) {
        return m.reply(
            `❌ *ᴍᴏᴅᴇ لا ᴠᴀʟɪᴅ*\n\n` +
            `> الوضع متاح: \`${VALID_MODES.join(', ')}\``
        )
    }
    
    console.log('[Botmode] Debug:', { args: m.args, mode, flags, isAutoorder })
    
    if (m.isGroup) {
        const newGroupData = {
            ...groupData,
            botMode: mode
        }
        
        if (mode === 'store') {
            newGroupData.storeConfig = {
                ...(groupData.storeConfig || {}),
                autoorder: isAutoorder,
                products: groupData.storeConfig?.products || []
            }
        }
        
        db.setGroup(m.chat, newGroupData)
    } else {
        db.setting('botMode', mode)
    }
    
    db.save()
    m.react('✅')
    
    let extraInfo = ''
    if (mode === 'store' && m.isGroup) {
        if (isAutoorder) {
            try {
                const pakasir = require('../../src/lib/pakasir')
                if (!pakasir.isEnabled()) {
                    extraInfo = `\n\n⚠️ *Pakasir غير مهيأ!*\n> Set di config.js: pakasir.slug & pakasir.apiKey`
                } else {
                    extraInfo = `\n\n✅ *Autoorder aktif!*\n> الدفع otomatis via Pakasir`
                }
            } catch {
                extraInfo = `\n\n⚠️ *Pakasir module not found*`
            }
        } else {
            extraInfo = `\n\n📋 *الوضع اليدوي*\n> المشرف يلزم confirm order manual`
        }
    }
    
    await m.reply(
        `✅ *ᴍᴏᴅᴇ ᴅɪᴜʙᴀʜ*\n\n` +
        `> الوضع: *${mode.toUpperCase()}*\n` +
        `> ${MODE_DESCRIPTIONS[mode]}\n` +
        (mode === 'store' && m.isGroup ? `> Autoorder: *${isAutoorder ? 'ON' : 'OFF'}*` : '') +
        extraInfo +
        `\n\n` +
        (m.isGroup ? `> _الوضع المجموعة ini أيضاً diubah._` : `> _الوضع global diubah._`)
    )
    
    console.log(`[BotMode] Changed to ${mode.toUpperCase()} by ${m.pushName} (${m.sender})`)
}

module.exports = {
    config: pluginConfig,
    handler,
    VALID_MODES,
    MODE_DESCRIPTIONS
}
