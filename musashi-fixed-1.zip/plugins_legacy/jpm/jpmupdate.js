const { getDatabase } = require("../../src/lib/database");
const timeHelper = require("../../src/lib/timeHelper");
const { fetchGroupsSafe } = require("../../src/lib/jpmHelper");
const config = require("../../config");
const fs = require("fs");

const pluginConfig = {
  name: "jpmupdate",
  alias: ["updatejpm", "broadcastupdate", "shareupdate"],
  category: "jpm",
  description: "أرسل update/changelog إلى كل المجموعة",
  usage: ".jpmupdate <versi> | <changelog>",
  example: ".jpmupdate v2.0 | ميزة جديد:\\n- Quiz Battle\\n- Confession",
  isOwner: true,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 60,
  energi: 0,
  isEnabled: true,
};

async function handler(m, { sock }) {
  const db = getDatabase();

  if (global.statusjpm) {
    return m.reply(
      `❌ *فشل*\n\n> JPM قيد التنفيذ. اكتب \`${m.prefix}stopjpm\` لإيقافه.`,
    );
  }

  let input = m.text?.trim();

  if (!input) {
    return m.reply(
      `📢 *JPM UPDATE (PENGUMUMAN)*\n\n` +
        `أرسل معلومة update / changelog إلى seluruh المجموعة!\n\n` +
        `*FORMAT PENGGUNAAN:*\n` +
        `• \`.jpmupdate <versi> | <isi changelog>\`\n\n` +
        `*مثال:*\n` +
        `> \`.jpmupdate v3.0 | ✨ ميزة Baru:\\n- JPM Hidetag\\n- النظام AFK Baru\\n- Perbaikan bug system\`\n\n` +
        `_(Note: استخدم \\n لـ membuat baris جديد/enter)_`
    );
  }

  let version = config.bot?.version || "v1.0";
  let changelog = input;

  if (input.includes("|")) {
    const parts = input.split("|");
    version = parts[0].trim();
    changelog = parts.slice(1).join("|").trim();
  }

  if (!changelog) {
    return m.reply(`❌ *همم~* Changelog لا boleh kosong~ 🥺`);
  }

  await m.react("🕕");

  try {
    const allGroups = await fetchGroupsSafe(sock);
    let groupIds = Object.keys(allGroups);

    const blacklist = db.setting("jpmBlacklist") || [];
    const blacklistedCount = groupIds.filter((id) =>
      blacklist.includes(id),
    ).length;
    groupIds = groupIds.filter((id) => !blacklist.includes(id));

    if (groupIds.length === 0) {
      await m.react("❌");
      return m.reply(
        `❌ *فشل*\n\n> لا توجد مجموعات مطابقة${blacklistedCount > 0 ? ` (${blacklistedCount} المجموعة في-blacklist)` : ""}`,
      );
    }

    const jedaJpm = db.setting("jedaJpm") || 5000;
    const botName = config.bot?.name || "Itsuki Nakano";
    const saluranId = config.saluran?.id || '120363432546133683@newsletter';
    const saluranName = config.saluran?.name || botName;

    const dateStr = timeHelper.formatDate("DD MMMM YYYY");

    const updateMessage =
      `🚀 *UPDATE !! | ${version}*\n\n` +
      `📅 *Tanggal:* ${dateStr}\n\n` +
      `*CHANGELOG:*\n` +
      `${changelog}\n\n` +
      `*CATATAN TERBARU:*\n` +
      `> 💡 اكتب *${m.prefix}القائمة* لـ mengeksplorasi ميزة-ميزة هذا.\n` +
      `> 📢 _شكراً لك telah menggunakan ${botName}_`;

    await m.reply(
      `📢 *ᴊᴘᴍ ᴜᴘᴅᴀᴛᴇ*\n\n` +
        `╭┈┈⬡「 📋 *التفاصيل* 」\n` +
        `┃ 🏷️ ᴠᴇʀsɪ: \`${version}\`\n` +
        `┃ 👥 الهدف: \`${groupIds.length}\` المجموعة\n` +
        `┃ ⏱️ الفاصل: \`${jedaJpm}ms\`\n` +
        `┃ 📊 الوقت المتوقع: \`${Math.ceil((groupIds.length * jedaJpm) / 60000)} دقيقة\`\n` +
        `╰┈┈⬡\n\n` +
        `> Memulai broadcast update...`,
    );

    global.statusjpm = true;
    let successCount = 0;
    let failedCount = 0;

    for (const groupId of groupIds) {
      if (global.stopjpm) {
        delete global.stopjpm;
        delete global.statusjpm;

        await m.reply(
          `⏹️ *ᴊᴘᴍ ᴜᴘᴅᴀᴛᴇ ᴅɪʜᴇɴᴛɪᴋᴀɴ*\n\n` +
            `> ✅ نجح: \`${successCount}\`\n` +
            `> ❌ فشل: \`${failedCount}\`\n` +
            `> ⏸️ المتبقي: \`${groupIds.length - successCount - failedCount}\``,
        );
        return;
      }

      try {
        await sock.sendMessage(groupId, {
          text: updateMessage,
          contextInfo: {
            forwardingScore: 9999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: saluranId,
              newsletterName: saluranName,
              serverMessageId: 127,
            },
          },
        });
        successCount++;
      } catch {
        failedCount++;
      }

      await new Promise((resolve) => setTimeout(resolve, jedaJpm));
    }

    global.statusjpm = false;
    global.stopjpm = false;

    await m.react("✅");
    await m.reply(
      `✅ *ᴊᴘᴍ ᴜᴘᴅᴀᴛᴇ sᴇʟᴇsᴀɪ!*\n\n` +
        `╭┈┈⬡「 📊 *ʀᴇsᴜʟᴛ* 」\n` +
        `┃ ✅ نجاح: ${successCount}\n` +
        `┃ ❌ فشل: ${failedCount}\n` +
        `┃ 📊 الإجمالي: ${groupIds.length}\n` +
        `╰┈┈┈┈┈┈┈┈⬡`,
    );
  } catch (error) {
        console.error("[MUSASHI][plugins_legacy/jpm/jpmupdate.js] exception", error?.stack || error);
    global.statusjpm = false;
    global.stopjpm = false;
    await m.react("❌");
    await m.reply("حدث خطأ، حاول لاحقاً");
  }
}

module.exports = {
  config: pluginConfig,
  handler,
};