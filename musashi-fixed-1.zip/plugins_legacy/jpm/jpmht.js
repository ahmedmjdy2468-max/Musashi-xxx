const { getDatabase } = require('../../src/lib/database')
const { getGroupMode } = require('../group/botmode')
const { fetchGroupsSafe } = require('../../src/lib/jpmHelper')
const fs = require('fs')
const { config } = require('../../config')


const pluginConfig = {
    name: 'jpmht',
    alias: ['jpmhidetag'],
    category: 'jpm',
    description: 'أرسل رسالة إلى كل المجموعة مع hidetag',
    usage: '.jpmht <رسالة>',
    example: '.jpmht مرحباً بالجميع!',
    isOwner: true,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 30,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const db = getDatabase()
    
    if (m.isGroup) {
        const groupMode = getGroupMode(m.chat, db)
        if (groupMode !== 'md') {
            return m.reply(`❌ *الوضع غير مناسب*\n\n> البث الجماعي متاح في وضع MD فقط\n\n\`${m.prefix}botmode md\``)
        }
    }
    
    const text = m.fullArgs?.trim() || m.text?.trim()
    if (!text) {
        return m.reply(
            `📢 *JPM HIDETAG (JASA رسالة MASSAL)*\n\n` +
            `النظام broadcast otomatis إلى seluruh المجموعات التي terdaftar مع tag كل عضو (hidetag).\n\n` +
            `*PENGGUNAAN:*\n` +
            `• *${m.prefix}jpmht <رسالة>* — Mengirim JPM hidetag نص biasa\n` +
            `• *${m.prefix}jpmht (ردّ على صورة/فيديو)* — Mengirim JPM hidetag مع الوسائط\n\n` +
            `*مثال:*\n` +
            `> \`${m.prefix}jpmht مرحباً بالجميع! لا تنسَ cek channel kita من فضلك.\``
        )
    }
    
    if (global.statusjpm) {
        return m.reply(`❌ *فشل*\n\n> JPM قيد التنفيذ. اكتب \`${m.prefix}stopjpm\` لإيقافه.`)
    }
    
    m.react('📢')
    
    try {
        let mediaBuffer = null
        let mediaType = null
        const qmsg = m.quoted || m
        
        if (qmsg.isImage) {
            try {
                mediaBuffer = await qmsg.download()
                mediaType = 'image'
            } catch (e) {}
        } else if (qmsg.isVideo) {
            try {
                mediaBuffer = await qmsg.download()
                mediaType = 'video'
            } catch (e) {}
        }
        
        const allGroups = await fetchGroupsSafe(sock)
        let groupIds = Object.keys(allGroups)
        
        const blacklist = db.setting('jpmBlacklist') || []
        const blacklistedCount = groupIds.filter(id => blacklist.includes(id)).length
        groupIds = groupIds.filter(id => !blacklist.includes(id))
        
        if (groupIds.length === 0) {
            m.react('❌')
            return m.reply(`❌ *فشل*\n\n> لا توجد مجموعات مطابقة${blacklistedCount > 0 ? ` (${blacklistedCount} المجموعة في-blacklist)` : ''}`)
        }
        
        const jedaJpm = db.setting('jedaJpm') || 5000
        
        await m.reply(
            `📢 *ᴊᴘᴍ ʜɪᴅᴇᴛᴀɢ*\n\n` +
            `╭┈┈⬡「 📋 *التفاصيل* 」\n` +
            `┃ 📝 الرسالة: \`${text.substring(0, 50)}${text.length > 50 ? '...' : ''}\`\n` +
            `┃ 📷 ᴍᴇᴅɪᴀ: \`${mediaBuffer ? mediaType : 'Tidak'}\`\n` +
            `┃ 👥 الهدف: \`${groupIds.length}\` المجموعة\n` +
            `┃ ⏱️ الفاصل: \`${jedaJpm}ms\`\n` +
            `╰┈┈⬡\n\n` +
            `> Memulai JPM hidetag...`
        )
        
        global.statusjpm = true
        let successCount = 0
        let failedCount = 0
        
        for (const groupId of groupIds) {
            if (global.stopjpm) {
                delete global.stopjpm
                delete global.statusjpm
                
                await m.reply(
                    `⏹️ *ᴊᴘᴍ ᴅɪʜᴇɴᴛɪᴋᴀɴ*\n\n` +
                    `> ✅ نجح: \`${successCount}\`\n` +
                    `> ❌ فشل: \`${failedCount}\``
                )
                return
            }
            
            try {
                const groupData = allGroups[groupId]
                const mentions = groupData.participants.map(p => p.id || p.jid).filter(Boolean)
                const contextInfo = {
                    mentionedJid: mentions,
                    forwardingScore: 9999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.saluran?.id,
                        newsletterName: config.saluran?.name,
                        serverMessageId: 127
                    },
}
                if (mediaBuffer) {
                    await sock.sendMessage(groupId, {
                        [mediaType]: mediaBuffer,
                        caption: text,
                        mentions: mentions,
                        contextInfo: contextInfo
                    })
                } else {
                    await sock.sendMessage(groupId, { 
                        text: text,
                        mentions: mentions,
                        contextInfo: contextInfo
                    })
                }
                successCount++
            } catch (err) {
                failedCount++
            }
            
            await new Promise(resolve => setTimeout(resolve, jedaJpm))
        }
        
        delete global.statusjpm
        
        m.react('✅')
        await m.reply(
            `✅ *ᴊᴘᴍ ʜɪᴅᴇᴛᴀɢ sᴇʟᴇsᴀɪ*\n\n` +
            `╭┈┈⬡「 📊 *النتيجة* 」\n` +
            `┃ ✅ نجح: \`${successCount}\`\n` +
            `┃ ❌ فشل: \`${failedCount}\`\n` +
            `┃ 📊 الإجمالي: \`${groupIds.length}\`\n` +
            `╰┈┈⬡`
        )
        
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/jpm/jpmht.js] exception", error?.stack || error);
        delete global.statusjpm
        m.react('❌')
        m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}