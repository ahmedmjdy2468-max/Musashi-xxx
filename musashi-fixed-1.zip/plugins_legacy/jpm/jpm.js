const { getDatabase } = require('../../src/lib/database')
const { getGroupMode } = require('../group/botmode')
const { fetchGroupsSafe } = require('../../src/lib/jpmHelper')
const config = require('../../config')
const fs = require('fs')


const pluginConfig = {
    name: 'jpm',
    alias: ['jasher', 'jaser'],
    category: 'jpm',
    description: 'أرسل رسالة إلى كل المجموعة (JPM)',
    usage: '.jpm <رسالة>',
    example: '.jpm مرحباً بالجميع!',
    isOwner: true,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 30,
    energi: 0,
    isEnabled: true
}

function getContextInfo(title = '📢 ᴊᴘᴍ', body = 'خدمة الرسائل الجماعية') {
    const saluranId = config.saluran?.id || '120363432546133683@newsletter'
    const saluranName = config.saluran?.name || config.bot?.name || 'Itsuki Nakano'
    
    const contextInfo = {
        forwardingScore: 9999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: saluranId,
            newsletterName: saluranName,
            serverMessageId: 127
        }
    }
    
    
    return contextInfo
}

async function handler(m, { sock }) {
    const db = getDatabase()
    
    if (m.isGroup) {
        const groupMode = getGroupMode(m.chat, db)
        if (groupMode !== 'md') {
            return m.reply(`❌ *الوضع غير مناسب*\n\n> البث الجماعي متاح في وضع MD فقط\n\n\`${m.prefix}botmode md\``)
        }
    }
    
    const text = m.fullArgs?.trim() || m.text?.trim()
    if (!text) {
        return m.reply(
            `📢 *JPM (JASA رسالة MASSAL)*\n\n` +
            `Sistem broadcast otomatis ke seluruh المجموعات التي terdaftar.\n\n` +
            `*PENGGUNAAN:*\n` +
            `• *${m.prefix}jpm <رسالة>* — Mengirim JPM نص biasa\n` +
            `• *${m.prefix}jpm (ردّ على صورة/فيديو)* — Mengirim JPM مع الوسائط\n\n` +
            `*ميزات أخرى:*\n` +
            `• *${m.prefix}jpmht* — بث بنمط الإخفاء (منشن الجميع عضو)\n` +
            `• *${m.prefix}autojpm* — Auto JPM مع interval otomatis\n` +
            `• *${m.prefix}setdelayjpm* — Mengatur jeda pengiriman per المجموعة\n` +
            `• *${m.prefix}stopjpm* — لإيقاف عملية البث قيد التنفيذ\n\n` +
            `*مثال:*\n` +
            `> \`${m.prefix}jpm مرحباً بالجميع! هذه رسالة تلقائية من المالك.\``
        )
    }
    
    if (global.statusjpm) {
        return m.reply(`❌ *فشل*\n\n> JPM قيد التنفيذ. اكتب \`${m.prefix}stopjpm\` لإيقافه.`)
    }
    
    m.react('📢')
    
    try {
        let mediaBuffer = null
        let mediaType = null
        const qmsg = m.quoted || m
        
        if (qmsg.isImage) {
            try {
                mediaBuffer = await qmsg.download()
                mediaType = 'image'
            } catch (e) {}
        } else if (qmsg.isVideo) {
            try {
                mediaBuffer = await qmsg.download()
                mediaType = 'video'
            } catch (e) {}
        }
        
        const allGroups = await fetchGroupsSafe(sock)
        let groupIds = Object.keys(allGroups)
        
        const blacklist = db.setting('jpmBlacklist') || []
        const blacklistedCount = groupIds.filter(id => blacklist.includes(id)).length
        groupIds = groupIds.filter(id => !blacklist.includes(id))
        
        if (groupIds.length === 0) {
            m.react('❌')
            return m.reply(`❌ *فشل*\n\n> لا توجد مجموعات مطابقة${blacklistedCount > 0 ? ` (${blacklistedCount} المجموعة في-blacklist)` : ''}`)
        }
        
        const jedaJpm = db.setting('jedaJpm') || 5000
        
        await sock.sendMessage(m.chat, {
            text: `📢 *ᴊᴘᴍ*\n\n` +
                `╭┈┈⬡「 📋 *التفاصيل* 」\n` +
                `┃ 📝 الرسالة: \`${text.substring(0, 50)}${text.length > 50 ? '...' : ''}\`\n` +
                `┃ 📷 ᴍᴇᴅɪᴀ: \`${mediaBuffer ? mediaType : 'Tidak'}\`\n` +
                `┃ 👥 الهدف: \`${groupIds.length}\` المجموعة\n` +
                `┃ ⏱️ الفاصل: \`${jedaJpm}ms\`\n` +
                `┃ 📊 الوقت المتوقع: \`${Math.ceil((groupIds.length * jedaJpm) / 60000)} دقيقة\`\n` +
                `╰┈┈⬡\n\n` +
                `> Memulai JPM ke جميع المجموعة...`,
            contextInfo: getContextInfo('📢 ᴊᴘᴍ', 'Sending...')
        }, { quoted: m })
        
        global.statusjpm = true
        let successCount = 0
        let failedCount = 0
        
        const contextInfo = getContextInfo('📢 ᴊᴘᴍ', config.bot?.name || 'Itsuki')
        
        for (const groupId of groupIds) {
            if (global.stopjpm) {
                delete global.stopjpm
                delete global.statusjpm
                
                await sock.sendMessage(m.chat, {
                    text: `⏹️ *ᴊᴘᴍ ᴅɪʜᴇɴᴛɪᴋᴀɴ*\n\n` +
                        `╭┈┈⬡「 📊 *الحالة* 」\n` +
                        `┃ ✅ نجح: \`${successCount}\`\n` +
                        `┃ ❌ فشل: \`${failedCount}\`\n` +
                        `┃ ⏸️ sɪsᴀ: \`${groupIds.length - successCount - failedCount}\`\n` +
                        `╰┈┈⬡`,
                    contextInfo: getContextInfo('⏹️ ᴅɪʜᴇɴᴛɪᴋᴀɴ')
                }, { quoted: m })
                return
            }
            
            try {
                if (mediaBuffer) {
                    await sock.sendMedia(groupId, mediaBuffer, text, null, {
                        type: mediaType,
                        contextInfo: {
                            forwardingScore: 99,
                            isForwarded: true
                        }
                    })
                } else {
                    await sock.sendText(groupId, text, null, {
                        contextInfo: {
                            forwardingScore: 99,
                            isForwarded: true
                        }
                    })
                }
                successCount++
            } catch (err) {
                failedCount++
            }
            
            await new Promise(resolve => setTimeout(resolve, jedaJpm))
        }
        
        delete global.statusjpm
        
        m.react('✅')
        await sock.sendMessage(m.chat, {
            text: `✅ *ᴊᴘᴍ sᴇʟᴇsᴀɪ*\n\n` +
                `╭┈┈⬡「 📊 *النتيجة* 」\n` +
                `┃ ✅ نجح: \`${successCount}\`\n` +
                `┃ ❌ فشل: \`${failedCount}\`\n` +
                `┃ 📊 الإجمالي: \`${groupIds.length}\`\n` +
                `╰┈┈⬡`,
            contextInfo: getContextInfo('✅ sᴇʟᴇsᴀɪ', `${successCount}/${groupIds.length}`)
        }, { quoted: m })
        
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/jpm/jpm.js] exception", error?.stack || error);
        delete global.statusjpm
        m.react('❌')
        m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}