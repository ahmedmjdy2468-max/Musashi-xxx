const pluginConfig = {
    name: 'stopjpm',
    alias: ['stopjasher', 'stopjaser'],
    category: 'jpm',
    description: 'يوقف عملية إرسال البث الجماعي الجارية.',
    usage: '.إيقاف_البث',
    example: '.إيقاف_البث',
    isOwner: true,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 0,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    if (!global.statusjpm) {
        return m.reply(`❌ لا توجد عملية بث جماعي قيد التنفيذ.`)
    }
    
    global.stopjpm = true
    
    m.react('⏹️')
    await m.reply(`⏹️ *إيقاف البث الجماعي*\nجارٍ إيقاف عملية الإرسال...`)
}

module.exports = {
    config: pluginConfig,
    handler
}
