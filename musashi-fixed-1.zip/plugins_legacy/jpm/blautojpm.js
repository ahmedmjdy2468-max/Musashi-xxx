const { getDatabase } = require('../../src/lib/database')
const config = require('../../config')

const pluginConfig = {
    name: 'blautojpm',
    alias: ['blacklistautojpm', 'autojpmbl', 'listblautojpm'],
    category: 'jpm',
    description: 'Blacklist المجموعة من Auto JPM',
    usage: '.blautojpm <add/del/list>',
    example: '.blautojpm add',
    isOwner: true,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const db = getDatabase()
    const args = m.args || []
    const action = m.command.includes('list') ? 'list' : (args[0] || '').toLowerCase()
    
    let blacklist = db.setting('autoJpmBlacklist') || []
    
    const saluranId = config.saluran?.id || '120363432546133683@newsletter'
    const saluranName = config.saluran?.name || config.bot?.name || 'Itsuki Nakano'
    
    const contextInfo = {
        forwardingScore: 9999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: saluranId,
            newsletterName: saluranName,
            serverMessageId: 127
        }
    }
    
    if (!action || action === 'list') {
        if (blacklist.length === 0) {
            return m.reply(
                `📋 *ʙʟᴀᴄᴋʟɪsᴛ ᴀᴜᴛᴏ ᴊᴘᴍ*\n\n` +
                `> لم يوجد المجموعات التي في-blacklist\n\n` +
                `*ᴜsᴀɢᴇ:*\n` +
                `> \`${m.prefix}blautojpm add\` - Blacklist المجموعة هذا\n` +
                `> \`${m.prefix}blautojpm del\` - Hapus dari blacklist`
            )
        }
        
        let txt = `📋 *ʙʟᴀᴄᴋʟɪsᴛ ᴀᴜᴛᴏ ᴊᴘᴍ*\n\n`
        txt += `> الإجمالي: *${blacklist.length}* المجموعة\n\n`
        
        const isThisBlacklisted = blacklist.includes(m.chat)
        txt += `> المجموعة هذا: *${isThisBlacklisted ? '✅ Blacklisted' : '❌ Tidak'}*\n\n`
        txt += `*ᴜsᴀɢᴇ:*\n`
        txt += `> \`${m.prefix}blautojpm add\` - Blacklist المجموعة هذا\n`
        txt += `> \`${m.prefix}blautojpm del\` - Hapus dari blacklist`
        
        return m.reply(txt)
    }
    
    if (action === 'add') {
        const jids = args.length > 1 ? args.slice(1).join('').split(',').filter(j => j.includes('@g.us')) : [m.chat]
        if (jids.length === 0 || !jids[0].includes('@g.us')) {
            return m.reply(`❌ *همم~* الصيغة JID المجموعة غير صالح أو البوت لا في dalam المجموعة~ 🥺`)
        }

        let added = 0
        let duplicate = 0
        
        for (const targetGroup of jids) {
            if (!blacklist.includes(targetGroup)) {
                blacklist.push(targetGroup)
                added++
            } else {
                duplicate++
            }
        }
        db.setting('autoJpmBlacklist', blacklist)
        await db.save()
        
        m.react('✅')
        return m.reply(
            `✅ *ʙʟᴀᴄᴋʟɪsᴛ ᴀᴜᴛᴏ ᴊᴘᴍ*\n\n` +
            `> نجح ditambah: \`${added}\` المجموعة\n` +
            `> تم يوجد: \`${duplicate}\` المجموعة\n` +
            `> Total blacklist: \`${blacklist.length}\` المجموعة\n\n` +
            `_المجموعة-المجموعة هذا لا سوف menerima Auto JPM مرة أخرى._`
        )
    }
    
    if (action === 'del' || action === 'remove' || action === 'hapus') {
        const jids = args.length > 1 ? args.slice(1).join('').split(',').filter(j => j.includes('@g.us')) : [m.chat]
        if (jids.length === 0 || !jids[0].includes('@g.us')) {
            return m.reply(`❌ *همم~* الصيغة JID المجموعة غير صالح أو البوت لا في dalam المجموعة~ 🥺`)
        }

        let removed = 0
        
        for (const targetGroup of jids) {
            const index = blacklist.indexOf(targetGroup)
            if (index !== -1) {
                blacklist.splice(index, 1)
                removed++
            }
        }
        
        db.setting('autoJpmBlacklist', blacklist)
        await db.save()
        
        m.react('✅')
        return m.reply(
            `✅ *ᴜɴʙʟᴀᴄᴋʟɪsᴛ ᴀᴜᴛᴏ ᴊᴘᴍ*\n\n` +
            `> تم الحذف بنجاح: \`${removed}\` المجموعة\n` +
            `> Sisa blacklist: \`${blacklist.length}\` المجموعة\n\n` +
            `_المجموعة-المجموعة هذا سوف menerima Auto JPM مرة أخرى._`
        )
    }
    
    return m.reply(`❌ *همم~* Action غير صالح. استخدم: \`add\`, \`del\`, أو \`list\``)
}

module.exports = {
    config: pluginConfig,
    handler
}
