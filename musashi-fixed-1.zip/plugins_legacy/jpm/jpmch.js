const { getDatabase } = require('../../src/lib/database')
const { getGroupMode } = require('../group/botmode')
const config = require('../../config')
const { getBinaryNodeChild } = require('itsuki')

const fs = require('fs')

const pluginConfig = {
    name: 'jpmch',
    alias: ['jpmchannel'],
    category: 'jpm',
    description: 'أرسل رسالة إلى كل القناة WhatsApp',
    usage: '.jpmch <رسالة>',
    example: '.jpmch مرحباً بالجميع!',
    isOwner: true,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 30,
    energi: 0,
    isEnabled: true
}

/**
 * Fetch semua channel yang di-subscribe (dari inibaileysnya)
 * @param {Object} sock - Socket Baileys
 * @returns {Promise<Object>} Daftar channel
 */
async function fetchAllSubscribedChannels(sock) {
    const data = {}
    const encoder = new TextEncoder()
    const queryIds = ['6388546374527196']
    
    for (const queryId of queryIds) {
        try {
            const result = await sock.query({
                tag: 'iq',
                attrs: {
                    id: sock.generateMessageTag(),
                    type: 'get',
                    xmlns: 'w:mex',
                    to: '@s.whatsapp.net',
                },
                content: [
                    {
                        tag: 'query',
                        attrs: { 'query_id': queryId },
                        content: encoder.encode(JSON.stringify({
                            variables: {}
                        }))
                    }
                ]
            })
            const child = getBinaryNodeChild(result, 'result')
            if (!child?.content) continue
            const parsed = JSON.parse(child.content.toString())
            const newsletters = parsed?.data?.['xwa2_newsletter_subscribed'] 
                || parsed?.data?.['newsletter_subscribed']
                || parsed?.data?.['subscribed']
                || []
            
            if (newsletters.length > 0) {

                for (const ch of newsletters) {
                    if (ch.id) {
                        data[ch.id] = {
                            id: ch.id,
                            name: ch.thread_metadata?.name?.text || ch.name || 'Unknown',
                            subscribers: ch.thread_metadata?.subscribers_count || 0
                        }
                    }
                }
                break
            }
        } catch (e) {

            continue
        }
    }
    
    return data
}

async function handler(m, { sock }) {
    const db = getDatabase()
    
    if (m.isGroup) {
        const groupMode = getGroupMode(m.chat, db)
        if (groupMode !== 'md') {
            return m.reply(`❌ *الوضع غير مناسب*\n\n> البث الجماعي متاح في وضع MD فقط\n\n\`${m.prefix}botmode md\``)
        }
    }
    
    const text = m.fullArgs?.trim() || m.text?.trim()
    if (!text) {
        return m.reply(
            `📢 *JPM القناة (JASA رسالة MASSAL)*\n\n` +
            `النظام broadcast otomatis إلى seluruh القناة WhatsApp الذي mensubscribe البوت هذا.\n\n` +
            `*PENGGUNAAN:*\n` +
            `• *${m.prefix}jpmch <رسالة>* — Mengirim JPM نص إلى القناة\n` +
            `• *${m.prefix}jpmch (reply الصورة/video)* — Mengirim JPM الوسائط ke channel\n\n` +
            `*مثال:*\n` +
            `> \`${m.prefix}jpmch مرحباً كل, ikuti update terbaru نحن!\``
        )
    }
    
    if (global.statusjpm) {
        return m.reply(`❌ *فشل*\n\n> JPM قيد التنفيذ. اكتب \`${m.prefix}stopjpm\` لإيقافه.`)
    }
    
    m.react('📢')
    
    try {
        let mediaBuffer = null
        let mediaType = null
        const qmsg = m.quoted || m
        
        if (qmsg.isImage) {
            try {
                mediaBuffer = await qmsg.download()
                mediaType = 'image'
            } catch (e) {}
        } else if (qmsg.isVideo) {
            try {
                mediaBuffer = await qmsg.download()
                mediaType = 'video'
            } catch (e) {}
        }
        
        let channels = {}
        try {
            channels = await fetchAllSubscribedChannels(sock)
        } catch (e) {
        console.error("[MUSASHI][plugins_legacy/jpm/jpmch.js] exception", e?.stack || e);
            m.react('❌')
            return m.reply("حدث خطأ، حاول لاحقاً")
        }
        
        const channelIds = Object.keys(channels)
        
        if (channelIds.length === 0) {
            m.react('❌')
            return m.reply(`❌ *عذراً* ✦\n\n> غير موجود القناة الذي ditemukan أو البوت لم subscribe القناة apapun~ 🥺`)
        }

        const jedaJpm = db.setting('jedaJpm') || 5000
        
        await m.reply(
            `📢 *ᴊᴘᴍ ᴄʜᴀɴɴᴇʟ*\n\n` +
            `╭┈┈⬡「 📋 *التفاصيل* 」\n` +
            `┃ 📝 الرسالة: \`${text.substring(0, 50)}${text.length > 50 ? '...' : ''}\`\n` +
            `┃ 📷 ᴍᴇᴅɪᴀ: \`${mediaBuffer ? mediaType : 'Tidak'}\`\n` +
            `┃ 📺 الهدف: \`${channelIds.length}\` channel\n` +
            `┃ ⏱️ الفاصل: \`${jedaJpm}ms\`\n` +
            `╰┈┈⬡\n\n` +
            `> Memulai JPM ke جميع channel...`
        )
        
        global.statusjpm = true
        let successCount = 0
        let failedCount = 0
        
        for (const chId of channelIds) {
            const chName = channels[chId]?.name || chId

            if (global.stopjpm) {
                delete global.stopjpm
                delete global.statusjpm
                
                await m.reply(
                    `⏹️ *ᴊᴘᴍ ᴅɪʜᴇɴᴛɪᴋᴀɴ*\n\n` +
                    `> ✅ نجح: \`${successCount}\`\n` +
                    `> ❌ فشل: \`${failedCount}\``
                )
                return
            }

            let contextInfo = {}
            try {
                contextInfo = {
                    isForwarded: true,
                    forwardingScore: 99,
                    forwardedNewsletterMessageInfo: {
                        newsletterName: config.saluran?.name || config.bot?.name,
                        newsletterJid: config.saluran?.id || '',
                    }
                }
                
            } catch (e) {}
            
            try {
                if (mediaBuffer) {
                    await sock.sendMessage(chId, {
                        [mediaType]: mediaBuffer,
                        caption: text,
                        contextInfo
                    })
                } else {
                    await sock.sendMessage(chId, { text: text, contextInfo })
                }

                successCount++
            } catch (err) {

                failedCount++
            }
            
            await new Promise(resolve => setTimeout(resolve, jedaJpm))
        }
        
        delete global.statusjpm
        
        m.react('✅')
        await m.reply(
            `✅ *ᴊᴘᴍ ᴄʜᴀɴɴᴇʟ sᴇʟᴇsᴀɪ*\n\n` +
            `╭┈┈⬡「 📊 *النتيجة* 」\n` +
            `┃ ✅ نجح: \`${successCount}\`\n` +
            `┃ ❌ فشل: \`${failedCount}\`\n` +
            `┃ 📊 الإجمالي: \`${channelIds.length}\`\n` +
            `╰┈┈⬡`
        )
        
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/jpm/jpmch.js] exception", error?.stack || error);
        delete global.statusjpm
        m.react('❌')
        m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}