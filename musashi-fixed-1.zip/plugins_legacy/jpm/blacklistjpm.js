const { getDatabase } = require('../../src/lib/database')
const config = require('../../config')
const fs = require("fs")
const path = require('path')
const pluginConfig = {
    name: 'blacklistjpm',
    alias: ['bljpm', 'jpmbl', 'jpmblacklist', 'listblacklistjpm'],
    category: 'jpm',
    description: 'Blacklist المجموعة من JPM مع interactive buttons',
    usage: '.blacklistjpm',
    example: '.blacklistjpm',
    isOwner: true,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const db = getDatabase()
    const args = m.text.split(' ') || []
    const action = args[0]
    let blacklist = db.setting('jpmBlacklist') || []
    
    if (action === 'add' && args.length > 1) {
        const jids = args.slice(1).join('').split(',').filter(j => j.includes('@g.us'))
        if (jids.length === 0) return m.reply(`❌ *همم~* Format JID المجموعة غير صالح! (يجب mengandung @g.us)~ 🥺`)
        
        let added = 0
        let duplicate = 0
        
        for (const targetGroup of jids) {
            if (!blacklist.includes(targetGroup)) {
                blacklist.push(targetGroup)
                added++
            } else {
                duplicate++
            }
        }
        
        db.setting('jpmBlacklist', blacklist)
        m.react('🚫')
        
        return m.reply(
            `🚫 *ᴅɪᴛᴀᴍʙᴀʜᴋᴀɴ ᴋᴇ ʙʟᴀᴄᴋʟɪsᴛ*\n\n` +
            `> نجح ditambah: \`${added}\` المجموعة\n` +
            `> تم يوجد: \`${duplicate}\` المجموعة\n` +
            `> Total blacklist: \`${blacklist.length}\` المجموعة\n\n` +
            `_المجموعة-المجموعة هذا لا سوف menerima JPM مرة أخرى._`
        )
    }
    
    if (action === 'del' || action === 'remove' || action === 'hapus') {
        if (args.length > 1) {
            const jids = args.slice(1).join('').split(',').filter(j => j.includes('@g.us'))
            if (jids.length === 0) return m.reply(`❌ *همم~* Format JID المجموعة غير صالح! (يجب mengandung @g.us)~ 🥺`)
            
            let removed = 0
            
            for (const targetGroup of jids) {
                const index = blacklist.indexOf(targetGroup)
                if (index !== -1) {
                    blacklist.splice(index, 1)
                    removed++
                }
            }
            
            db.setting('jpmBlacklist', blacklist)
            m.react('✅')
            
            return m.reply(
                `✅ *ᴅɪʜᴀᴘᴜs ᴅᴀʀɪ ʙʟᴀᴄᴋʟɪsᴛ*\n\n` +
                `> تم الحذف بنجاح: \`${removed}\` المجموعة\n` +
                `> Sisa blacklist: \`${blacklist.length}\` المجموعة`
            )
        }
    }
    
    if (action === 'list') {
        if (blacklist.length === 0) {
            return m.reply(`📋 *ᴊᴘᴍ ʙʟᴀᴄᴋʟɪsᴛ*\n\n> غير موجود المجموعات التي di-blacklist`)
        }
        
        let listText = `📋 *ᴊᴘᴍ ʙʟᴀᴄᴋʟɪsᴛ*\n\n> الإجمالي: \`${blacklist.length}\` المجموعة\n\n`
        
        for (let i = 0; i < blacklist.length; i++) {
            const groupId = blacklist[i]
            try {
                const meta = await sock.groupMetadata(groupId)
                listText += `${i + 1}. ${meta.subject}\n`
            } catch (e) {
                listText += `${i + 1}. Unknown المجموعة\n`
            }
        }
        
        return m.reply(listText)
    }
    
    return m.reply(
        `📢 *JPM BLACKLIST (DAFTAR HITAM)*\n\n` +
        `ميزة هذا digunakan لـ mengecualikan المجموعة-المجموعة tertentu لكي لا dikirimi رسالة Broadcast JPM بواسطة owner.\n\n` +
        `*PENGGUNAAN COMMAND:*\n` +
        `• \`${m.prefix}blacklistjpm list\` — Lihat كل قائمة المجموعات yg diblacklist\n` +
        `• \`${m.prefix}blacklistjpm add <jid1>,<jid2>\` — Tambahkan المجموعة إلى blacklist\n` +
        `• \`${m.prefix}blacklistjpm del <jid1>,<jid2>\` — حذف المجموعة من blacklist\n\n` +
        `*مثال الاستخدام:*\n` +
        `> \`${m.prefix}blacklistjpm add 1203631@g.us, 1203632@g.us\`\n\n` +
        `*STATISTIK SAAT INI:*\n` +
        `> المجموعة diblacklist: \`${blacklist.length}\` المجموعة`
    )
}

module.exports = {
    config: pluginConfig,
    handler
}
