const axios = require('axios')
const config = require('../../config')
const { f } = require('../../src/lib/undici')

const pluginConfig = {
    name: "",
    alias: ['texttoimg'],
    category: 'sticker',
    description: 'ينشئ ملصقاً ثابتاً من النص الذي تدخله.',
    usage: '.نص_إلى_صورة <النص>',
    example: '.نص_إلى_صورة أهلاً بالجميع',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 1,
    isEnabled: true
}

async function handler(m, { sock }) {
    let text = m.text?.trim()
    
    if (!text && m.quoted?.text) {
        text = m.quoted.text.trim()
    }
    
    if (!text) {
        return m.reply(
            `🎨 *ملصق نصي ثابت*\n\n` +
            `اكتب النص الذي تريد تحويله إلى ملصق.\n\n` +
            `مثال: \`${m.prefix}نص_إلى_صورة أهلاً بالجميع\``
        )
    }
    
    if (text.length > 100) {
        return m.reply(`❌ النص طويل جداً. الحد الأقصى 100 حرف.`)
    }
    
    const apikey = config.APIkey?.lolhuman
    if (!apikey) {
        return m.reply(`❌ مفتاح خدمة إنشاء الملصقات غير مضبوط.`)
    }
    
    m.react('🕕')
    
    try {
        const apiUrl = `https://api.lolhuman.xyz/api/ttp?apikey=${apikey}&text=${encodeURIComponent(text)}`
        await sock.sendImageAsSticker(m.chat, apiUrl, m, {
            packname: config.sticker?.packname || 'MUSASHI',
            author: config.sticker?.author || 'Bot'
        })
        m.react('✅')
    } catch (err) {
        console.error("[MUSASHI][plugins_legacy/sticker/ttp.js] exception", err?.stack || err);
        m.react('❌')
        m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
