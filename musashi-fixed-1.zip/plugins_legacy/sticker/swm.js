/**
 * @file plugins/sticker/swm.js
 * @description Plugin untuk mengganti packname dan author pada sticker
 */

const config = require('../../config')
const { addExifToWebp, isAnimatedWebp } = require('../../src/lib/exif')

const pluginConfig = {
    name: 'swm',
    alias: ['stickerwm', 'stickermark', 'colong'],
    category: 'sticker',
    description: 'يغيّر اسم الحزمة واسم المؤلف في الملصق الذي ترد عليه.',
    usage: '.تعديل_حقوق_الملصق <اسم_الحزمة>|<اسم_المؤلف>',
    example: '.تعديل_حقوق_الملصق موساشي|فريق التطوير',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 1,
    isEnabled: true
}

async function handler(m, { sock, config: botConfig }) {
    const quoted = m.quoted
    
    if (!quoted) {
        return m.reply(
`⭐ *تعديل حقوق الملصق*\n\nردّ على ملصق، ثم اكتب اسم الحزمة واسم المؤلف مفصولين بعلامة |.\n\nالاستخدام: \`${m.prefix}تعديل_حقوق_الملصق اسم_الحزمة|اسم_المؤلف\`\nمثال: \`${m.prefix}تعديل_حقوق_الملصق موساشي|فريق التطوير\``
        )
    }

    const isSticker = quoted.type === 'stickerMessage' || quoted.isSticker
    if (!isSticker) {
        return m.reply(`❌ الرسالة التي رددت عليها ليست ملصقاً. ردّ على ملصق ثم أعد المحاولة.`)
    }

    const input = m.text?.trim()
    if (!input) {
        return m.reply(`❌ اكتب اسم الحزمة أو المؤلف بعد الأمر.\nمثال: \`${m.prefix}تعديل_حقوق_الملصق موساشي|فريق التطوير\``)
    }

    let packname, author
    let userProvidedAuthor = false

    if (input.includes('|')) {
        const parts = input.split('|')
        packname = parts[0]?.trim() || botConfig.sticker?.packname || botConfig.bot?.name || 'MUSASHI'
        const authorInput = parts[1]?.trim()
        if (authorInput) {
            author = authorInput
            userProvidedAuthor = true
        } else {
            author = botConfig.sticker?.author || botConfig.owner?.name || 'chan'
        }
    } else {
        packname = input
        author = botConfig.sticker?.author || botConfig.owner?.name || 'chan'
    }
    
    if (packname.length > 50) {
        return m.reply(`❌ اسم الحزمة طويل جداً. يجب ألا يتجاوز 50 حرفاً.`)
    }

    if (userProvidedAuthor && author?.length > 50) {
        return m.reply(`❌ اسم المؤلف طويل جداً. يجب ألا يتجاوز 50 حرفاً.`)
    }

    m.react('⭐')
    
    try {
        const buffer = await quoted.download()
        
        if (!buffer || buffer.length === 0) {
            m.react('💔')
            return m.reply(`❌ تعذّر تنزيل الملصق. حاول مرة أخرى لاحقاً.`)
        }

        const meta = { packname, ...(author ? { author } : {}) }

        // Cek apakah stiker ini animated WebP (GIF stiker)
        const animated = quoted.msg?.isAnimated || isAnimatedWebp(buffer)

        if (animated) {
            // ── Stiker GIF / animated: langsung inject EXIF ke buffer WebP ──
            // Tidak di-re-encode, animasinya tetap utuh
            const stickerBuffer = await addExifToWebp(buffer, meta)

            await sock.sendMessage(m.chat, {
                sticker: stickerBuffer,
                isAnimated: true
            }, { quoted: m })
        } else {
            // ── Stiker gambar biasa ──
            await sock.sendImageAsSticker(m.chat, buffer, m, meta)
        }
        
        m.react('⭐')
        m.reply(`✅ تم تحديث اسم الحزمة واسم المؤلف في الملصق.`)
        

    } catch (error) {
        console.error('[SWM] الخطأ:', error.message)
        m.react('💔')
        m.reply(
"حدث خطأ، حاول لاحقاً"
        )
    }
}

module.exports = {
    config: pluginConfig,
    handler
}