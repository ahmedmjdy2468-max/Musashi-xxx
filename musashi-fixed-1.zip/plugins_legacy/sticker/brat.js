const axios = require('axios')
const config = require('../../config')

const pluginConfig = {
    name: "",
    alias: ['brattext'],
    category: 'sticker',
    description: 'ينشئ ملصق برات من النص الذي تدخله.',
    usage: '.ملصق_برات_نصي <النص>',
    example: '.ملصق_برات_نصي مرحباً بالجميع',
    cooldown: 10,
    energi: 1,
    isEnabled: true
}

async function handler(m, { sock }) {
    const text = m.args.join(' ')
    if (!text) {
        return m.reply(`🖼️ *ملصق برات نصي*\n\nاكتب النص الذي تريد وضعه على الملصق.\n\nمثال: \`${m.prefix}ملصق_برات_نصي مرحباً بالجميع\``)
    }

    m.react('🕕')

    // 🔥 list API (utama + fallback)
    const apis = [
        `https://api.zenzxz.my.id/maker/brat?text=${encodeURIComponent(text)}`,
        `https://api-faa.my.id/faa/brat?text=${encodeURIComponent(text)}`
    ]

    let success = false

    for (let url of apis) {
        try {
            await sock.sendImageAsSticker(m.chat, url, m, {
                packname: config.sticker.packname,
                author: config.sticker.author
            })

            success = true
            break
        } catch (err) {
            console.log('فشل الاتصال بالخدمة:', url)
        }
    }

    if (success) {
        m.react('✅')
    } else {
        m.react('❌')
        m.reply('❌ تعذّر إنشاء الملصق حالياً. حاول مرة أخرى لاحقاً.')
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
