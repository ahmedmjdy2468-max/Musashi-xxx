const axios = require('axios')
const config = require('../../config')
const { f } = require('../../src/lib/undici')

const NEOXR_APIKEY = config.APIkey?.neoxr || 'Milik-Bot-Itsuki'

const pluginConfig = {
    name: "",
    alias: ['attp2', 'attp3'],
    category: 'sticker',
    description: 'ينشئ ملصقاً متحركاً من النص الذي تدخله.',
    usage: '.ملصق_نص_متحرك <النص>',
    example: '.ملصق_نص_متحرك أهلاً بالجميع',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 1,
    isEnabled: true
}

function getRandomColor() {
    const colors = ['FF5733', 'C70039', '900C3F', '581845', '2E86AB', 'A23B72', 'F18F01', 'C73E1D', '3A0CA3', '7209B7', '4361EE', '4CC9F0']
    return colors[Math.floor(Math.random() * colors.length)]
}

async function handler(m, { sock }) {
    let text = m.text?.trim()
    
    if (!text && m.quoted?.text) {
        text = m.quoted.text.trim()
    }
    
    if (!text) {
        return m.reply(
            `🎨 *ملصق نص متحرك*\n\n` +
            `اكتب النص الذي تريد تحويله إلى ملصق.\n\n` +
            `مثال: \`${m.prefix}ملصق_نص_متحرك أهلاً بالجميع\``
        )
    }
    
    if (text.length > 100) {
        return m.reply(`❌ النص طويل جداً. الحد الأقصى 100 حرف.`)
    }
    
    m.react('🕕')
    
    try {
        const color = getRandomColor()
        const url = `https://api.neoxr.eu/api/attp3?text=${encodeURIComponent(text)}&color=${color}&apikey=${NEOXR_APIKEY}`
        
        const data = await f(url)
        
        if (!data?.status || !data?.data?.url) {
            throw new Error('لم تُرجع الخدمة بيانات صالحة')
        }
        
        const stickerUrl = data.data.url
        
        const stickerRes = await f(stickerUrl, 'buffer')
        if (!stickerRes) throw new Error('تعذّر تنزيل الملصق من الخادم')
            
        const { addExifToWebp } = require('../../src/lib/exif')
        let finalSticker = stickerRes
        try {
            finalSticker = await addExifToWebp(stickerRes, {
                packname: config.sticker.packname,
                author: config.sticker.author
            })
        } catch (e) {
            console.log('Exif error:', e)
        }

        await sock.sendMessage(m.chat, { sticker: finalSticker }, { quoted: m })
        m.react('✅')
    } catch (err) {
        console.error("[MUSASHI][plugins_legacy/sticker/attp.js] exception", err?.stack || err);
        m.react('❌')
        m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
