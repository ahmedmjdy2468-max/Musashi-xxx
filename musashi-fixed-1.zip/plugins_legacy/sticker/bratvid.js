const axios = require('axios')
const config = require('../../config')

const pluginConfig = {
    name: 'bratvid',
    alias: ['bratgif', 'bratvideo'],
    category: 'sticker',
    description: 'ينشئ ملصقاً متحركاً من النص الذي تدخله.',
    usage: '.ملصق_برات_متحرك <النص>',
    example: '.ملصق_برات_متحرك مرحباً بالجميع',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 15,
    energi: 1,
    isEnabled: true
}

async function handler(m, { sock }) {
    const text = m.args.join(' ')
    if (!text) {
        return m.reply(`🎬 *ملصق برات متحرك*\n\nاكتب النص الذي تريد وضعه على الملصق.\n\nمثال: \`${m.prefix}ملصق_برات_متحرك مرحباً بالجميع\``)
    }
    
    m.react('🕕')
    
    try {
        const url = `https://api.nexray.web.id/maker/bratvid?text=${encodeURIComponent(text)}`
        await sock.sendVideoAsSticker(m.chat, url, m, {
            packname: config.sticker.packname,
            author: config.sticker.author
        })
        m.react('✅')
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/sticker/bratvid.js] exception", error?.stack || error);
        m.react('❌')
        m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
