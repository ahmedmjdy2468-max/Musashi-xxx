const axios = require('axios')
const config = require('../../config')

const pluginConfig = {
    name: 'bratcewek2',
    alias: ['cewekbrat2', 'bratperempuan2', 'bratgirl2'],
    category: 'sticker',
    description: 'ينشئ الإصدار الثاني من ملصق برات ذي الطابع الأنثوي.',
    usage: '.ملصق_برات_أنثوي_ثان <النص>',
    example: '.ملصق_برات_أنثوي_ثان مرحباً بالجميع',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 1,
    isEnabled: true
}

async function handler(m, { sock }) {
    const text = m.args.join(' ')

    if (!text) {
        return m.reply(
            `🖼️ *ملصق برات بطابع أنثوي، الإصدار الثاني*\n\n` +
            `اكتب النص الذي تريد وضعه على الملصق.\n\n` +
            `مثال: \`${m.prefix}ملصق_برات_أنثوي_ثان مرحباً بالجميع\``
        )
    }

    m.react('🕕')

    try {
        const url = `https://api.theresav.biz.id/maker/bratcewe?text=${encodeURIComponent(text)}&apikey=JpLZ3`

        await sock.sendImageAsSticker(
            m.chat,
            url,
            m,
            {
                packname: config.sticker.packname,
                author: config.sticker.author
            }
        )

        m.react('✅')
    } catch (error) {
        console.error(error)

        m.react('❌')
        m.reply(
            "حدث خطأ، حاول لاحقاً"
        )
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
