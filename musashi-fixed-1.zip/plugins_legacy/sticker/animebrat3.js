const axios = require('axios')
const config = require('../../config')
const { f } = require('../../src/lib/undici')

const pluginConfig = {
    name: 'bratanime3',
    alias: ['animebrat3'],
    category: 'sticker',
    description: 'ينشئ إصداراً ثانياً من الملصق المتحرك بطابع برات وأنمي.',
    usage: '.ملصق_برات_أنمي_متحرك_ثان <النص>',
    example: '.ملصق_برات_أنمي_متحرك_ثان موساشي',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 1,
    isEnabled: true
}

async function handler(m, { sock }) {
    const text = m.args.join(' ')

    if (!text) {
        return m.reply(
            `🖼️ *ملصق برات وأنمي متحرك، الإصدار الثاني*\n\n` +
            `اكتب النص الذي تريد وضعه على الملصق.\n\n` +
            `مثال: \`${m.prefix}ملصق_برات_أنمي_متحرك_ثان موساشي\``
        )
    }

    m.react('🕕')

    try {
        const url = `https://api.theresav.biz.id/maker/bratanime2?text=${encodeURIComponent(text)}&apikey=JpLZ3`

        await sock.sendImageAsSticker(
            m.chat,
            url,
            m,
            {
                packname: config.sticker.packname,
                author: config.sticker.author
            }
        )

        m.react('✅')
    } catch (error) {
        console.error(error)

        m.react('❌')
        m.reply(
            "حدث خطأ، حاول لاحقاً"
        )
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
