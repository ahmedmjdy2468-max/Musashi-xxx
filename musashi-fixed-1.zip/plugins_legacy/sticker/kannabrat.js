const axios = require('axios')
const config = require('../../config')

const pluginConfig = {
    name: 'kannabrat',
    alias: ['kanna', 'kannagen'],
    category: 'sticker',
    description: 'ينشئ ملصقاً لشخصية كانا يحمل النص الذي تدخله.',
    usage: '.ملصق_كانا_برات <النص>',
    example: '.ملصق_كانا_برات مرحباً بالجميع',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 1,
    isEnabled: true
}

async function handler(m, { sock }) {
    let text = m.text?.trim()
    
    if (!text && m.quoted?.text) {
        text = m.quoted.text.trim()
    }
    
    if (!text) {
        return m.reply(
            `🎀 *ملصق كانا*\n\n` +
            `اكتب النص الذي تريد وضعه على الملصق.\n\n` +
            `مثال: \`${m.prefix}ملصق_كانا_برات مرحباً بالجميع\``
        )
    }
    
    if (text.length > 50) {
        return m.reply(`❌ النص طويل جداً. الحد الأقصى 50 حرفاً.`)
    }
    
    const apikey = config.APIkey?.lolhuman
    if (!apikey) {
        return m.reply(`❌ مفتاح خدمة إنشاء الملصقات غير مضبوط.`)
    }
    
    m.react('🎀')
    
    try {
        const apiUrl = `https://api.lolhuman.xyz/api/creator/kannagen?apikey=${apikey}&text=${encodeURIComponent(text)}`
        await sock.sendImageAsSticker(m.chat, apiUrl, m, {
            packname: config.sticker.packname,
            author: config.sticker.author
        })
        m.react('✅')
    } catch (err) {
        console.error("[MUSASHI][plugins_legacy/sticker/kannabrat.js] exception", err?.stack || err);
        m.react('❌')
        m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
