const axios = require('axios')
const config = require('../../config')

const pluginConfig = {
    name: 'bratchika',
    alias: ['chikabrat'],
    category: 'sticker',
    description: 'ينشئ ملصقاً لشخصية تشيكا بأسلوب برات من النص الذي تدخله.',
    usage: '.ملصق_برات_تشيكا <النص>',
    example: '.ملصق_برات_تشيكا مرحباً بالجميع',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 1,
    isEnabled: true
}

async function handler(m, { sock }) {
    const text = m.args.join(' ')

    if (!text) {
        return m.reply(
            `🖼️ *ملصق تشيكا بأسلوب برات*\n\n` +
            `اكتب النص الذي تريد وضعه على الملصق.\n\n` +
            `مثال: \`${m.prefix}ملصق_برات_تشيكا مرحباً بالجميع\``
        )
    }

    m.react('🕕')

    try {
        const mainUrl = `https://kazztzyy.my.id/api/maker/bratchika?text=${encodeURIComponent(text)}`

        await sock.sendImageAsSticker(
            m.chat,
            mainUrl,
            m,
            {
                packname: config.sticker.packname,
                author: config.sticker.author
            }
        )

        m.react('✅')

    } catch (err) {
        try {
            const fallbackUrl = `https://api.theresav.biz.id/maker/bratchika?text=${encodeURIComponent(text)}&apikey=JpLZ3`

            await sock.sendImageAsSticker(
                m.chat,
                fallbackUrl,
                m,
                {
                    packname: config.sticker.packname,
                    author: config.sticker.author
                }
            )

            m.react('✅')

        } catch (error) {
            console.error(error)

            m.react('❌')
            m.reply(
                "حدث خطأ، حاول لاحقاً"
            )
        }
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
