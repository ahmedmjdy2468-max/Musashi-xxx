const axios = require('axios')
const config = require('../../config')

const pluginConfig = {
    name: 'brathd',
    alias: ['brathdsticker', 'brathds'],
    category: 'sticker',
    description: 'ينشئ ملصق برات عالي الدقة من النص الذي تدخله.',
    usage: '.ملصق_برات_عالي_الدقة <النص>',
    example: '.ملصق_برات_عالي_الدقة مرحباً بالجميع',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 1,
    isEnabled: true
}

async function handler(m, { sock }) {
    const text = m.args.join(' ')
    
    if (!text) {
        return m.reply(`🖼️ *ملصق برات عالي الدقة*\n\nاكتب النص الذي تريد وضعه على الملصق.\n\nمثال: \`${m.prefix}ملصق_برات_عالي_الدقة مرحباً بالجميع\``)
    }
    
    m.react('🕕')
    
    try {
        const url = `https://api.nexray.web.id/maker/brathd?text=${encodeURIComponent(text)}`
        await sock.sendImageAsSticker(m.chat, url, m, {
            packname: config.sticker.packname,
            author: config.sticker.author
        })
        m.react('✅')
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/sticker/brathd.js] exception", error?.stack || error);
        m.react('❌')
        m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
