const { config } = require('../../config')
const { generateWAMessageFromContent, proto } = require('itsuki')

const pluginConfig = {
    name: 'smemecode',
    alias: ['sendwmcode'],
    category: 'sticker',
    description: "يرسل رمز استخدام أداة صنع الميم إلى مالك البوت.",
    usage: ".كود_ميمي",
    example: "",
    isOwner: true,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const ownerNumbers = config.owner?.number || []
    const prefix = config.command?.prefix || '.'
    const SECRET_CODE = `--()()++&-&`
    const saluranId = config.saluran?.id || '120363432546133683@newsletter'
    const saluranName = config.saluran?.name || config.bot?.name || 'Itsuki-AI'

    if (!ownerNumbers.length) return m.reply(`⚠️ *Eh eh~* الرقم owner غير موجود في config~ 🌸`)

    const infoText =
        `🔐 *ʜᴏsʜɪɴᴏ ᴀɪ — ᴋᴏᴅᴇ ʀᴀʜᴀsɪᴀ sᴍᴇᴍᴇ*\n\n` +
        `هذا kode rahasia watermark smeme أنت~ 🤫\n` +
        `Jangan kasih tau siapa-siapa نعم. ✨\n\n` +
        `╭┈┈⬡「 🔑 *ᴋᴏᴅᴇ* 」\n` +
        `┃\n` +
        `┃ Kode: \`${SECRET_CODE}\`\n` +
        `┃\n` +
        `╰┈┈⬡\n\n` +
        `╭┈┈⬡「 📋 *طريقة الاستخدام* 」\n` +
        `┃\n` +
        `┃ Format:\n` +
        `┃ \`${prefix}smeme <teks>|<teks> ${SECRET_CODE}<namamu>\`\n` +
        `┃\n` +
        `┃ مثال:\n` +
        `┃ \`${prefix}smeme أنا|Wibu ${SECRET_CODE}Musashi\`\n` +
        `┃\n` +
        `╰┈┈⬡`

    const buttons = [
        {
            name: 'cta_copy',
            buttonParamsJson: JSON.stringify({
                display_text: '📋 Salin Kode',
                copy_code: SECRET_CODE
            })
        }
    ]

    let successCount = 0
    for (const number of ownerNumbers) {
        try {
            const jid = number.includes('@s.whatsapp.net')
                ? number
                : `${number}@s.whatsapp.net`

            const msg = generateWAMessageFromContent(jid, {
                viewOnceMessage: {
                    message: {
                        messageContextInfo: {
                            deviceListMetadata: {},
                            deviceListMetadataVersion: 2
                        },
                        interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                            body: proto.Message.InteractiveMessage.Body.fromObject({
                                text: infoText
                            }),
                            footer: proto.Message.InteractiveMessage.Footer.fromObject({
                                text: `💖 MUSASHI Bot | B-Komachi Production`
                            }),
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                                buttons: buttons
                            }),
                            contextInfo: {
                                mentionedJid: [jid],
                                forwardingScore: 9999,
                                isForwarded: true,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: saluranId,
                                    newsletterName: saluranName,
                                    serverMessageId: 127
                                }
                            }
                        })
                    }
                }
            }, { userJid: jid })

            await sock.relayMessage(jid, msg.message, { messageId: msg.key.id })
            successCount++
            console.log(`✅ [smemecode] Terkirim إلى owner: ${number}`)
        } catch (e) {
            console.warn(`⚠️ [smemecode] فشل أرسل إلى ${number}: ${e.message}`)
        }
    }

    if (successCount > 0) {
        m.react('💌')
        m.reply(`✅ Kode rahasia تم الإرسال بنجاح إلى PM أنت~ 💖`)
    } else {
        m.react('💔')
        m.reply(`💔 فشل أرسل. Cek console نعم~`)
    }
}

module.exports = { config: pluginConfig, handler }