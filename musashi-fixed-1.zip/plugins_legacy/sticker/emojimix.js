const config = require('../../config')
const { f } = require('./../../src/lib/undici')
const pluginConfig = {
    name: 'emojimix',
    alias: ['mixemoji', 'emix'],
    category: 'sticker',
    description: 'يمزج رمزين تعبيريين في ملصق واحد.',
    usage: '.دمج_رمزين_تعبيريين <الرمز_الأول> <الرمز_الثاني>',
    example: '.دمج_رمزين_تعبيريين 😂 🔥',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 1,
    isEnabled: true
}

async function handler(m, { sock }) {
    const text = m.text?.trim()
    
    if (!text) {
        return m.reply(
            `🎭 *دمج الرموز التعبيرية*\n\n` +
            `أرسل رمزين تعبيريين لدمجهما في ملصق واحد.\n\n` +
            `مثال: \`${m.prefix}دمج_رمزين_تعبيريين 😂 🔥\``
        )
    }
    
    const emojiRegex = /\p{Extended_Pictographic}/gu
    const emojis = text.match(emojiRegex)
    
    if (!emojis || emojis.length < 2) {
        return m.reply(`❌ أرسل رمزين تعبيريين على الأقل.\n\nمثال: ${m.prefix}دمج_رمزين_تعبيريين 😂 🔥`)
    }
    
    const emoji1 = emojis[0]
    const emoji2 = emojis[1]
    
    m.react('🕕')
    
    try {
        const apiUrl = `https://tenor.googleapis.com/v2/featured?key=ISI_API_KEY_KAMU&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(emoji1)}_${encodeURIComponent(emoji2)}`
        
        const data = await f(apiUrl)
        
        if (!data.results || data.results.length === 0) {
            return m.reply(`❌ لا تتوفر صورة لهذا الزوج من الرموز التعبيرية. جرّب رمزين آخرين.`)
        }
        
        const imageUrl = data.results[0].url
        
        await sock.sendImageAsSticker(m.chat, imageUrl, m, {
            packname: config.sticker.packname,
            author: config.sticker.author
        })
        
        m.react('✅')
        
    } catch (err) {
        console.error("[MUSASHI][plugins_legacy/sticker/emojimix.js] exception", err?.stack || err);
        m.react('❌')
        m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
