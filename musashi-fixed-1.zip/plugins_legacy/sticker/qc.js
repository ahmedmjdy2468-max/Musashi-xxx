const axios = require('axios')
const config = require('../../config')

const pluginConfig = {
    name: "",
    alias: ['qcstc', 'stcqc', 'qcstic', 'qcstick', 'quotesticker'],
    category: 'sticker',
    description: 'ينشئ ملصق اقتباس بلون خلفية ونص تختارهما.',
    usage: '.ملصق_اقتباس_ملون <اللون> <النص>',
    example: '.ملصق_اقتباس_ملون وردي مرحباً بالجميع!',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 1,
    isEnabled: true
}

const COLORS = {
    pink: '#f68ac9',
    blue: '#6cace4',
    red: '#f44336',
    green: '#4caf50',
    yellow: '#ffeb3b',
    purple: '#9c27b0',
    darkblue: '#0d47a1',
    lightblue: '#03a9f4',
    ash: '#9e9e9e',
    orange: '#ff9800',
    black: '#000000',
    white: '#ffffff',
    teal: '#008080',
    lightpink: '#FFC0CB',
    chocolate: '#A52A2A',
    salmon: '#FFA07A',
    magenta: '#FF00FF',
    tan: '#D2B48C',
    wheat: '#F5DEB3',
    deeppink: '#FF1493',
    fire: '#B22222',
    skyblue: '#00BFFF',
    brightskyblue: '#1E90FF',
    hotpink: '#FF69B4',
    lightskyblue: '#87CEEB',
    seagreen: '#20B2AA',
    darkred: '#8B0000',
    orangered: '#FF4500',
    cyan: '#48D1CC',
    violet: '#BA55D3',
    mossgreen: '#00FF7F',
    darkgreen: '#008000',
    navyblue: '#191970',
    darkorange: '#FF8C00',
    darkpurple: '#9400D3',
    fuchsia: '#FF00FF',
    darkmagenta: '#8B008B',
    darkgray: '#2F4F4F',
    peachpuff: '#FFDAB9',
    darkishgreen: '#BDB76B',
    darkishred: '#DC143C',
    goldenrod: '#DAA520',
    darkishgray: '#696969',
    darkishpurple: '#483D8B',
    gold: '#FFD700',
    silver: '#C0C0C0'
}

const COLOR_ALIASES = {
    'وردي': 'pink', 'زهري': 'pink',
    'أحمر': 'red', 'احمر': 'red',
    'أزرق': 'blue', 'ازرق': 'blue',
    'أخضر': 'green', 'اخضر': 'green',
    'أصفر': 'yellow', 'اصفر': 'yellow',
    'بنفسجي': 'purple', 'أسود': 'black', 'اسود': 'black',
    'أبيض': 'white', 'ابيض': 'white', 'برتقالي': 'orange',
    'بني': 'chocolate', 'رمادي': 'darkgray', 'فضي': 'silver',
    'ذهبي': 'gold', 'سماوي': 'cyan', 'فيروزي': 'teal',
    'أرجواني': 'violet', 'ارجواني': 'violet'
}

const DEFAULT_PP = 'https://files.catbox.moe/nwvkbt.png'

async function getProfilePicture(sock, jid) {
    try {
        return await sock.profilePictureUrl(jid, 'image')
    } catch {
        return DEFAULT_PP
    }
}

async function handler(m, { sock }) {
    const args = m.args || []
    
    if (args.length < 2) {
        const colorList = `${Object.keys(COLOR_ALIASES).join('، ')}؛ أو بالإنجليزية: ${Object.keys(COLORS).join(', ')}`
        return m.reply(
            `💬 *ملصق اقتباس*\n\n` +
            `╭┈┈⬡「 📋 *طريقة الاستخدام* 」\n` +
            `┃ ◦ \`${m.prefix}ملصق_اقتباس_ملون <اللون> <النص>\`\n` +
            `┃ ◦ أو ردّ على رسالة بالأمر \`${m.prefix}ملصق_اقتباس_ملون <اللون>\`\n` +
            `╰┈┈⬡\n\n` +
            `> مثال: \`${m.prefix}ملصق_اقتباس_ملون pink مرحباً بالجميع!\`\n\n` +
            `╭┈┈⬡「 🎨 *الألوان المتاحة* 」\n` +
            `┃ ${colorList}\n` +
            `╰┈┈⬡`
        )
    }
    
    const requestedColor = args[0].toLowerCase()
    const color = COLOR_ALIASES[requestedColor] || requestedColor
    const backgroundColor = COLORS[color]
    
    if (!backgroundColor) {
        return m.reply(`❌ اللون \`${color}\` غير متاح. اختر لوناً من القائمة.`)
    }
    
    let message = args.slice(1).join(' ')
    
    if (m.quoted && !message) {
        message = m.quoted.text || m.quoted.body || ''
    }
    
    if (!message) {
        return m.reply(`❌ اكتب نص الاقتباس أو ردّ على رسالة تحتوي على نص.`)
    }
    
    if (message.length > 80) {
        return m.reply(`❌ يجب ألا يتجاوز نص الاقتباس 80 حرفاً. (طوله الآن: ${message.length})`)
    }
    
    m.react('🕕')
    
    try {
        const username = m.pushName || 'المستخدم'
        const avatar = await getProfilePicture(sock, m.sender)
        
        const json = {
        "messages": [
            {
            "from": {
                "id": Math.floor(Math.random() * 10),
                "first_name": username,
                "last_name": "",
                "name": "",
                "photo": {
                "url": avatar
                }
            },
            "النص": message,
            "entities": [],
            "avatar": true,
            "الوسائط": {
                "url": ""
            },
            "mediaType": "",
            "replyMessage": {
                "name": "",
                "النص": "",
                "entities": [],
                "chatId": Math.floor(Math.random() * 10)
            }
            }
        ],
        "backgroundColor": backgroundColor,
        "width": 512,
        "height": 512,
        "scale": 2,
        "type": "quote",
        "format": "png",
        "emojiStyle": "apple"
        }
        
        const response = await axios.post('https://brat.siputzx.my.id/quoted', json, {
            timeout: 60000,
            responseType: 'arraybuffer'
        })
        
        const buffer = Buffer.from(response.data, 'base64')
        
        await sock.sendImageAsSticker(m.chat, buffer, m, {
            packname: config.sticker?.packname || 'MUSASHI',
            author: config.sticker?.author || 'البوت'
        })
        
        m.react('✅')
        
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/sticker/qc.js] exception", error?.stack || error);
        m.react('❌')
        m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
