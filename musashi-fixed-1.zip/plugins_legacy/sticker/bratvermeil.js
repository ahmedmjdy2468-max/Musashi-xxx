const axios = require('axios')
const config = require('../../config')

const pluginConfig = {
    name: 'bratvermeil',
    alias: ['bratv', 'bratnime'],
    category: 'sticker',
    description: 'ينشئ ملصقاً بتصميم فيرميل من النص الذي ترسله.',
    usage: '.ملصق_فيرميل <النص>',
    example: '.ملصق_فيرميل لا تنسَ تناول الطعام',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 2,
    isEnabled: true
}

async function handler(m, { sock }) {
    const text = m.text?.trim()
    
    if (!text) {
        return m.reply(
            `👿 *ملصق Vermeil*\n\n` +
            `> أرسل النص الذي تريد وضعه على الملصق.\n\n` +
            `> مثال: \`${m.prefix}ملصق_فيرميل لا تنسَ تناول الطعام\``
        )
    }
    
    m.react('🎨')
    
    try {
        const apikey = 'ISI_API_KEY_KAMU'
        const baseUrl = `https://api.cuki.biz.id/api/canvas/brat/bratnime-vermeil?text=${encodeURIComponent(text)}&apikey=${apikey}`
        await sock.sendImageAsSticker(m.chat, baseUrl, m, {
            packname: config.sticker?.packname || 'MUSASHI',
            author: config.sticker?.author || 'Brat Vermeil'
        })
        
        m.react('✅')
        
    } catch (err) {
        console.error('[Brat Vermeil]', err)
        m.react('❌')
        m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
