const { getDatabase } = require('../../src/lib/database')

const pluginConfig = {
    name: 'merchant',
    alias: ['npc', 'toko', 'tokoku'],
    category: 'rpg',
    description: 'Jual beli item ke NPC merchant',
    usage: '.merchant <buy/sell> <item> <qty>',
    example: '.merchant buy potion 5',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

const SHOP_ITEMS = {
    potion: { name: '🧪 Potion', buyPrice: 100, sellPrice: 50, desc: 'Pulihkan 50 HP' },
    manapotion: { name: '💙 Mana Potion', buyPrice: 150, sellPrice: 75, desc: 'Pulihkan 50 Mana' },
    antidote: { name: '💊 Antidote', buyPrice: 80, sellPrice: 40, desc: 'Sembuhkan racun' },
    bread: { name: '🍞 Roti', buyPrice: 30, sellPrice: 15, desc: 'Pulihkan 10 stamina' },
    energydrink: { name: '⚡ Energy Drink', buyPrice: 200, sellPrice: 100, desc: 'Pulihkan 50 stamina' },
    pickaxe: { name: '⛏️ Beliung', buyPrice: 500, sellPrice: 250, desc: 'لـ mining' },
    fishingrod: { name: '🎣 Joran', buyPrice: 400, sellPrice: 200, desc: 'لـ memancing' },
    wood: { name: '🪵 Kayu', buyPrice: 50, sellPrice: 25, desc: 'Material dasar' },
    iron: { name: '🔩 Besi', buyPrice: 80, sellPrice: 40, desc: 'Material logam' },
    leather: { name: '🧶 Kulit', buyPrice: 60, sellPrice: 30, desc: 'Material armor' },
    string: { name: '🧵 Benang', buyPrice: 40, sellPrice: 20, desc: 'Material busur' },
    herb: { name: '🌿 Herba', buyPrice: 70, sellPrice: 35, desc: 'Bahan alchemy' },
    gold: { name: '🪙 Emas', buyPrice: 500, sellPrice: 250, desc: 'Material langka' },
    diamond: { name: '💎 Berlian', buyPrice: 2000, sellPrice: 1000, desc: 'Material mewah' }
}

async function handler(m) {
    const db = getDatabase()
    const user = db.getUser(m.sender)
    
    if (!user.inventory) user.inventory = {}
    
    const args = m.args || []
    const action = args[0]?.toLowerCase()
    const itemKey = args[1]?.toLowerCase()
    const qty = Math.max(1, parseInt(args[2]) || 1)
    
    if (!action || !['buy', 'sell', 'list'].includes(action)) {
        let txt = `🏪 *ᴍᴇʀᴄʜᴀɴᴛ المتجر*\n\n`
        txt += `> تهانينا datang di toko!\n\n`
        txt += `╭┈┈⬡「 📋 *الأمر* 」\n`
        txt += `┃ ${m.prefix}merchant list\n`
        txt += `┃ ${m.prefix}merchant buy <item> <qty>\n`
        txt += `┃ ${m.prefix}merchant sell <item> <qty>\n`
        txt += `╰┈┈┈┈┈┈┈┈⬡\n\n`
        txt += `💰 *الرصيد:* ${(user.koin || 0).toLocaleString()}`
        return m.reply(txt)
    }
    
    if (action === 'list') {
        let txt = `🏪 *ᴅᴀꜰᴛᴀʀ العنصر*\n\n`
        txt += `╭┈┈⬡「 📦 *المتجر* 」\n`
        
        for (const [key, item] of Object.entries(SHOP_ITEMS)) {
            txt += `┃ ${item.name}\n`
            txt += `┃ 💵 Beli: ${item.buyPrice.toLocaleString()}\n`
            txt += `┃ 💰 Jual: ${item.sellPrice.toLocaleString()}\n`
            txt += `┃ 📝 ${item.desc}\n`
            txt += `┃ → \`${key}\`\n`
            txt += `┃\n`
        }
        txt += `╰┈┈┈┈┈┈┈┈⬡`
        
        return m.reply(txt)
    }
    
    if (action === 'buy') {
        if (!itemKey) {
            return m.reply(`❌ Tentukan item!\n\n> مثال: \`${m.prefix}merchant buy potion 5\``)
        }
        
        const item = SHOP_ITEMS[itemKey]
        if (!item) {
            return m.reply(`❌ عنصر غير موجود!\n\n> اكتب \`${m.prefix}merchant list\` لـ melihat القائمة.`)
        }
        
        const totalCost = item.buyPrice * qty
        if ((user.koin || 0) < totalCost) {
            return m.reply(
                `❌ *الرصيد ᴋᴜʀᴀɴɢ*\n\n` +
                `> السعر: ${totalCost.toLocaleString()}\n` +
                `> الرصيد: ${(user.koin || 0).toLocaleString()}`
            )
        }
        
        user.koin -= totalCost
        user.inventory[itemKey] = (user.inventory[itemKey] || 0) + qty
        db.save()
        
        return m.reply(
            `✅ *ᴘᴇᴍʙᴇʟɪᴀɴ نجح*\n\n` +
            `╭┈┈⬡「 🛒 *التفاصيل* 」\n` +
            `┃ 📦 Item: *${item.name}*\n` +
            `┃ 📊 Qty: *${qty}*\n` +
            `┃ 💵 الإجمالي: *-${totalCost.toLocaleString()}*\n` +
            `┃ 💰 المتبقي: *${user.koin.toLocaleString()}*\n` +
            `╰┈┈┈┈┈┈┈┈⬡`
        )
    }
    
    if (action === 'sell') {
        if (!itemKey) {
            return m.reply(`❌ Tentukan item!\n\n> مثال: \`${m.prefix}merchant sell iron 10\``)
        }
        
        const item = SHOP_ITEMS[itemKey]
        if (!item) {
            return m.reply(`❌ *عذراً* عنصر لا يمكن dijual إلى merchant~ 🥺`)
        }
        
        const have = user.inventory[itemKey] || 0
        if (have < qty) {
            return m.reply(
                `❌ *العنصر ᴋᴜʀᴀɴɢ*\n\n` +
                `> Punya: ${have}\n` +
                `> Mau jual: ${qty}`
            )
        }
        
        const totalEarn = item.sellPrice * qty
        user.koin = (user.koin || 0) + totalEarn
        user.inventory[itemKey] -= qty
        if (user.inventory[itemKey] <= 0) delete user.inventory[itemKey]
        db.save()
        
        return m.reply(
            `✅ *ᴘᴇɴᴊᴜᴀʟᴀɴ نجح*\n\n` +
            `╭┈┈⬡「 💰 *التفاصيل* 」\n` +
            `┃ 📦 Item: *${item.name}*\n` +
            `┃ 📊 Qty: *${qty}*\n` +
            `┃ 💵 الإجمالي: *+${totalEarn.toLocaleString()}*\n` +
            `┃ 💰 الرصيد: *${user.koin.toLocaleString()}*\n` +
            `╰┈┈┈┈┈┈┈┈⬡`
        )
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
