
const { getDatabase } = require('../../src/lib/database')
const { addExpWithLevelCheck } = require('../../src/lib/levelHelper')
const { getRpgContextInfo } = require('../../src/lib/contextHelper')

const pluginConfig = {
    name: 'crime',
    alias: ['curi'],
    category: 'rpg',
    description: 'يحاول سرقة المال في لعبة المغامرات؛ قد تنجح أو تُقبض عليك وتُغرّم.',
    usage: '.سرقة_المغامرات',
    example: '.سرقة_المغامرات',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 300,
    energi: 1,
    isEnabled: true
}

async function handler(m, { sock }) {
    const db = getDatabase()
    const user = db.getUser(m.sender)
    
    if (!user.rpg) user.rpg = {}
    
    await m.reply('🦹 *تجري محاولة السرقة...*')
    await new Promise(r => setTimeout(r, 2000))
    
    const successRate = 0.5
    const isSuccess = Math.random() < successRate
    
    if (isSuccess) {
        const stolen = Math.floor(Math.random() * 15000) + 5000
        const expGain = Math.floor(stolen / 20)
        
        user.koin = (user.koin || 0) + stolen
        await addExpWithLevelCheck(sock, m, db, user, expGain)
        
        db.save()
        
        let txt = `✅ *نجحت السرقة*\n\n`
        txt += `> حصلت على *${stolen.toLocaleString('id-ID')} روبية إندونيسية*.\n`
        txt += `> 🚄 الخبرة: *+${expGain}*`
        
        await m.reply(txt)
    } else {
        const fine = Math.floor(Math.random() * 10000) + 5000
        const actualFine = Math.min(fine, user.koin || 0)
        
        user.koin = Math.max(0, (user.koin || 0) - actualFine)
        user.rpg.health = Math.max(0, (user.rpg.health || 100) - 15)
        
        db.save()
        
        let txt = `❌ *فشلت السرقة*\n\n`
        txt += `> 🚔 أُلقي القبض عليك.\n`
        txt += `> 💸 الغرامة: *-${actualFine.toLocaleString('id-ID')} روبية إندونيسية*\n`
        txt += `> ❤️ الصحة: *-15*`
        
        await m.reply(txt)
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
