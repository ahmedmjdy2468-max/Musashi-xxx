
const { getDatabase } = require('../../src/lib/database')
const { addExpWithLevelCheck } = require('../../src/lib/levelHelper')
const { getRpgContextInfo } = require('../../src/lib/contextHelper')

const pluginConfig = {
    name: 'woodcut',
    alias: ['chop', 'nebang', 'kayu'],
    category: 'rpg',
    description: 'يقطع الأشجار للحصول على الخشب ومكافآت أخرى مقابل طاقة.',
    usage: '.woodcut',
    example: '.woodcut',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 60,
    energi: 1,
    isEnabled: true
}

async function handler(m, { sock }) {
    const db = getDatabase()
    const user = db.getUser(m.sender)
    
    if (!user.rpg) user.rpg = {}
    if (!user.inventory) user.inventory = {}
    
    const staminaCost = 15
    user.rpg.stamina = user.rpg.stamina || 100
    
    if (user.rpg.stamina < staminaCost) {
        return m.reply(
            `⚡ *الطاقة غير كافية*\n\n` +
            `> تحتاج إلى ${staminaCost} من الطاقة.\n` +
            `> طاقتك: ${user.rpg.stamina}`
        )
    }
    
    user.rpg.stamina -= staminaCost
    
    await m.reply('🪓 *جارٍ قطع الأشجار...*')
    await new Promise(r => setTimeout(r, 2000))
    
    const drops = [
        { item: 'wood', chance: 70, name: '🪵 خشب', min: 2, max: 5 },
        { item: 'stick', chance: 50, name: '🥢 غصن', min: 1, max: 3 },
        { item: 'apple', chance: 20, name: '🍎 تفاحة', min: 1, max: 2 },
        { item: 'rubber', chance: 10, name: '⚫ مطاط', min: 1, max: 1 }
    ]
    
    let results = []
    for (const drop of drops) {
        if (Math.random() * 100 <= drop.chance) {
            const qty = Math.floor(Math.random() * (drop.max - drop.min + 1)) + drop.min
            user.inventory[drop.item] = (user.inventory[drop.item] || 0) + qty
            results.push({ name: drop.name, qty })
        }
    }
    
    if (results.length === 0) {
        user.inventory['wood'] = (user.inventory['wood'] || 0) + 1
        results.push({ name: '🪵 خشب', qty: 1 })
    }
    
    const expGain = Math.floor(Math.random() * 200) + 50
    const levelResult = await addExpWithLevelCheck(sock, m, db, user, expGain)
    
    db.save()
    
    let txt = `🪓 *اكتمل قطع الأشجار*\n\n`
    txt += `╭┈┈⬡「 📦 *النتيجة* 」\n`
    for (const r of results) {
        txt += `┃ ${r.name}: *+${r.qty}*\n`
    }
    txt += `┃ 🚄 الخبرة: *+${expGain}*\n`
    txt += `┃ ⚡ الطاقة: *-${staminaCost}*\n`
    txt += `╰┈┈┈┈┈┈┈┈⬡`
    
    await m.reply(txt)
}

module.exports = {
    config: pluginConfig,
    handler
}
