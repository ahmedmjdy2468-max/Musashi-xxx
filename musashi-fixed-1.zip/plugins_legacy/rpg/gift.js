const { getDatabase } = require('../../src/lib/database')
const { getRpgContextInfo } = require('../../src/lib/contextHelper')

const pluginConfig = {
    name: 'gift',
    alias: ['kasih', 'hadiah'],
    category: 'rpg',
    description: 'Beri جائزة إلى pasangan لـ meningkatkan love',
    usage: '.gift <item> <jumlah>',
    example: '.gift diamond 1',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 30,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const db = getDatabase()
    const user = db.getUser(m.sender)
    
    if (!user.rpg) user.rpg = {}
    
    if (!user.rpg.spouse) {
        return m.reply(
            `❌ *ʙᴇʟᴜᴍ ᴍᴇɴɪᴋᴀʜ*\n\n` +
            `> أنت غير متزوج بعد!\n` +
            `> Nikah أولاً مع \`.marry @user\``
        )
    }
    
    const args = m.args || []
    const itemKey = args[0]?.toLowerCase()
    const amount = parseInt(args[1]) || 1
    
    if (!itemKey) {
        return m.reply(
            `🎁 *ɢɪꜰᴛ*\n\n` +
            `╭┈┈⬡「 📋 *ᴜsᴀɢᴇ* 」\n` +
            `┃ > اختر عنصر لـ diberikan\n` +
            `┃ > \`.gift diamond 1\`\n` +
            `╰┈┈┈┈┈┈┈┈⬡`
        )
    }
    
    user.inventory = user.inventory || {}
    
    if ((user.inventory[itemKey] || 0) < amount) {
        return m.reply(
            `❌ *العنصر لا ᴄᴜᴋᴜᴘ*\n\n` +
            `> العنصر *${itemKey}* الخاص بك: ${user.inventory[itemKey] || 0}\n` +
            `> Butuh: ${amount}`
        )
    }
    
    const spouseJid = user.rpg.spouse
    const partner = db.getUser(spouseJid)
    
    if (!partner) {
        return m.reply(`❌ *ᴘᴀsᴀɴɢᴀɴ ɴᴏᴛ ꜰᴏᴜɴᴅ*\n\n> Pasangan غير موجود di database!`)
    }
    
    partner.inventory = partner.inventory || {}
    
    user.inventory[itemKey] -= amount
    partner.inventory[itemKey] = (partner.inventory[itemKey] || 0) + amount
    
    user.rpg.love = (user.rpg.love || 0) + (amount * 10)
    if (partner.rpg) partner.rpg.love = (partner.rpg.love || 0) + (amount * 10)
    
    db.save()
    
    let txt = `🎁 *ɢɪꜰᴛ sᴜᴋsᴇs*\n\n`
    txt += `> 💝 أنت memberikan ${amount}x ${itemKey}\n`
    txt += `> 👤 لـ: @${spouseJid.split('@')[0]}\n`
    txt += `> 💕 Love: +${amount * 10}\n\n`
    txt += `> _So sweet! 💖_`
    
    await m.reply(txt, { mentions: [spouseJid] })
}

module.exports = {
    config: pluginConfig,
    handler
}
