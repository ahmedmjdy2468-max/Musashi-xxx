const { getDatabase } = require('../../src/lib/database')
const config = require('../../config')
const path = require('path')
const fs = require('fs')

const pluginConfig = {
    name: 'stamina',
    alias: ['cekstamina'],
    category: 'rpg',
    description: 'Cek و pulihkan stamina',
    usage: '.stamina / .stamina isi',
    example: '.stamina',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

function getContextInfo(title = '⚡ *الطاقة*', body = 'طاقة') {
    const saluranId = config.saluran?.id || '120363432546133683@newsletter'
    const saluranName = config.saluran?.name || config.bot?.name || 'MUSASHI'
    
    const contextInfo = {
        forwardingScore: 9999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: saluranId,
            newsletterName: saluranName,
            serverMessageId: 127
        }
    }
    
    
    return contextInfo
}

function createStaminaBar(current, max) {
    const filled = Math.round((current / max) * 10)
    const empty = 10 - filled
    return '█'.repeat(filled) + '░'.repeat(empty)
}

async function handler(m, { sock }) {
    const db = getDatabase()
    const user = db.getUser(m.sender)
    const args = m.args || []
    
    if (!user.rpg) user.rpg = {}
    user.rpg.stamina = user.rpg.stamina ?? 100
    user.rpg.maxStamina = user.rpg.maxStamina || 100
    
    const subCmd = args[0]?.toLowerCase()
    
    if (subCmd === 'isi' || subCmd === 'restore' || subCmd === 'heal') {
        const potionCost = 5000
        
        if (user.rpg.stamina >= user.rpg.maxStamina) {
            return m.reply(`⚡ *الطاقة ᴘᴇɴᴜʜ*\n\n> Stamina أنت تم penuh!`)
        }
        
        if ((user.koin || 0) < potionCost) {
            return m.reply(
                `❌ *sᴀʟᴅᴏ لا ᴄᴜᴋᴜᴘ*\n\n` +
                `> Biaya: Rp ${potionCost.toLocaleString('id-ID')}\n` +
                `> الرصيد: Rp ${(user.koin || 0).toLocaleString('id-ID')}`
            )
        }
        
        user.koin -= potionCost
        const restored = user.rpg.maxStamina - user.rpg.stamina
        user.rpg.stamina = user.rpg.maxStamina
        
        db.save()
        
        await m.react('⚡')
        return sock.sendMessage(m.chat, {
            text: `⚡ *الطاقة ᴅɪɪsɪ*\n\n` +
                `╭┈┈⬡「 💊 *ʀᴇsᴛᴏʀᴇ* 」\n` +
                `┃ ⚡ Stamina: *+${restored}*\n` +
                `┃ 💵 Biaya: *-Rp ${potionCost.toLocaleString('id-ID')}*\n` +
                `┃ 📊 الآن: *${user.rpg.stamina}/${user.rpg.maxStamina}*\n` +
                `╰┈┈┈┈┈┈┈┈⬡`,
            contextInfo: getContextInfo()
        }, { quoted: m })
    }
    
    const staminaBar = createStaminaBar(user.rpg.stamina, user.rpg.maxStamina)
    
    let txt = `⚡ *الطاقة الحالة*\n\n`
    txt += `╭┈┈⬡「 📊 *ɪɴꜰᴏ* 」\n`
    txt += `┃ ⚡ Stamina: *${user.rpg.stamina}/${user.rpg.maxStamina}*\n`
    txt += `┃ 📊 [${staminaBar}]\n`
    txt += `╰┈┈┈┈┈┈┈┈⬡\n\n`
    txt += `> Isi stamina: \`${m.prefix}stamina isi\` (Rp 5.000)\n`
    txt += `> Stamina pulih otomatis setiap الساعة`
    
    await sock.sendMessage(m.chat, {
        text: txt,
        contextInfo: getContextInfo()
    }, { quoted: m })
}

module.exports = {
    config: pluginConfig,
    handler
}