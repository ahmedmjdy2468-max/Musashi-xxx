const { getDatabase } = require('../../src/lib/database')
const { addExpWithLevelCheck } = require('../../src/lib/levelHelper')

const pluginConfig = {
    name: 'alchemy',
    alias: ['potion', 'brew', 'ramuan'],
    category: 'rpg',
    description: 'اصنع الجرعات من الأعشاب',
    usage: '.alchemy <potion>',
    example: '.alchemy healthpotion',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 60,
    energi: 1,
    isEnabled: true
}

const POTIONS = {
    healthpotion: { name: '❤️ Health Potion', materials: { herb: 3 }, effect: 'Pulihkan 50 HP', exp: 80, result: 'healthpotion' },
    manapotion: { name: '💙 Mana Potion', materials: { herb: 2, flower: 1 }, effect: 'Pulihkan 50 Mana', exp: 90, result: 'manapotion' },
    staminapotion: { name: '⚡ Stamina Potion', materials: { herb: 2, mushroom: 1 }, effect: 'Pulihkan 30 Stamina', exp: 100, result: 'staminapotion' },
    strengthpotion: { name: '💪 Strength Potion', materials: { herb: 3, dragonscale: 1 }, effect: '+20 هجوم (5 دقائق)', exp: 200, result: 'strengthpotion' },
    defensepotion: { name: '🛡️ Defense Potion', materials: { herb: 3, iron: 2 }, effect: '+15 دفاع (5 دقائق)', exp: 180, result: 'defensepotion' },
    luckpotion: { name: '🍀 Luck Potion', materials: { herb: 5, diamond: 1 }, effect: '+30% معدل السقوط (10 دقائق)', exp: 300, result: 'luckpotion' },
    exppotion: { name: '✨ خبرة Potion', materials: { herb: 4, gold: 2 }, effect: '+50% خبرة (15 menit)', exp: 250, result: 'exppotion' },
    antidote: { name: '💊 Antidote', materials: { herb: 2 }, effect: 'Sembuhkan racun', exp: 50, result: 'antidote' },
    elixir: { name: '🧪 Elixir', materials: { herb: 10, diamond: 2, gold: 5 }, effect: 'استعد كل الإحصاءات', exp: 500, result: 'elixir' }
}

async function handler(m, { sock }) {
    const db = getDatabase()
    const user = db.getUser(m.sender)
    
    if (!user.inventory) user.inventory = {}
    if (!user.rpg) user.rpg = {}
    
    const args = m.args || []
    const potionName = args[0]?.toLowerCase()
    
    if (!potionName) {
        let txt = `🧪 *ᴀʟᴄʜᴇᴍʏ - ʙᴜᴀᴛ ᴘᴏᴛɪᴏɴ*\n\n`
        txt += `╭┈┈⬡「 📜 *ʀᴇsᴇᴘ* 」\n`
        
        for (const [key, pot] of Object.entries(POTIONS)) {
            const mats = Object.entries(pot.materials).map(([m, qty]) => `${qty}x ${m}`).join(', ')
            txt += `┃ ${pot.name}\n`
            txt += `┃ 📦 Bahan: ${mats}\n`
            txt += `┃ 💫 Efek: ${pot.effect}\n`
            txt += `┃ → \`${key}\`\n┃\n`
        }
        txt += `╰┈┈┈┈┈┈┈┈⬡\n\n`
        txt += `💡 *نصيحة:* احصل على الأعشاب من المزرعة أو الزنزانة`
        
        return m.reply(txt)
    }
    
    const potion = POTIONS[potionName]
    if (!potion) {
        return m.reply(`❌ Resep غير موجود!\n\n> اكتب \`${m.prefix}alchemy\` لـ melihat القائمة.`)
    }
    
    const missingMaterials = []
    for (const [material, needed] of Object.entries(potion.materials)) {
        const have = user.inventory[material] || 0
        if (have < needed) {
            missingMaterials.push(`${material}: ${have}/${needed}`)
        }
    }
    
    if (missingMaterials.length > 0) {
        return m.reply(
            `❌ *ʙᴀʜᴀɴ ᴋᴜʀᴀɴɢ*\n\n` +
            `> لصناعة ${potion.name}:\n\n` +
            missingMaterials.map(m => `> ❌ ${m}`).join('\n')
        )
    }
    
    await m.react('🧪')
    await m.reply(`🧪 *ᴍᴇʀᴀᴄɪᴋ ${potion.name.toUpperCase()}...*`)
    await new Promise(r => setTimeout(r, 2000))
    
    for (const [material, needed] of Object.entries(potion.materials)) {
        user.inventory[material] -= needed
        if (user.inventory[material] <= 0) delete user.inventory[material]
    }
    
    user.inventory[potion.result] = (user.inventory[potion.result] || 0) + 1
    
    await addExpWithLevelCheck(sock, m, db, user, potion.exp)
    db.save()
    
    await m.react('✅')
    return m.reply(
        `✅ *ᴀʟᴄʜᴇᴍʏ نجح*\n\n` +
        `╭┈┈⬡「 🧪 *النتيجة* 」\n` +
        `┃ 📦 Item: *${potion.name}*\n` +
        `┃ 💫 Efek: *${potion.effect}*\n` +
        `┃ ✨ خبرة: *+${potion.exp}*\n` +
        `╰┈┈┈┈┈┈┈┈⬡`
    )
}

module.exports = {
    config: pluginConfig,
    handler
}
