const { getDatabase } = require('../../src/lib/database')
const { getRpgContextInfo } = require('../../src/lib/contextHelper')

const pluginConfig = {
    name: 'leveluprpg',
    alias: ['lvluprpg', 'rpglevelup'],
    category: 'rpg',
    description: 'يشغّل أو يوقف إشعارات رفع المستوى في نظام المغامرات.',
    usage: '.إشعار_المستوى <تشغيل/إيقاف>',
    example: '.إشعار_المستوى تشغيل',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const db = getDatabase()
    const user = db.getUser(m.sender)
    const args = m.args || []
    const sub = args[0]?.toLowerCase()
    const enabled = ['on', 'تشغيل', 'تفعيل'].includes(sub)
    const disabled = ['off', 'إيقاف', 'ايقاف', 'تعطيل'].includes(sub)
    
    if (!user.settings) user.settings = {}
    
    if (enabled) {
        user.settings.rpgLevelupNotif = true
        db.save()
        return m.reply(
            `✅ *إشعارات المستوى مفعّلة*\n\n` +
            `> ستصلك رسالة عند رفع مستواك في نظام المغامرات.`
        )
    }
    
    if (disabled) {
        user.settings.rpgLevelupNotif = false
        db.save()
        return m.reply(
            `🔕 *إشعارات المستوى متوقفة*`
        )
    }
    
    const status = user.settings.rpgLevelupNotif !== false ? 'مفعّلة ✅' : 'متوقفة ❌'
    return m.reply(
        `🔔 *إشعارات رفع المستوى*\n\n` +
        `> الحالة الحالية: *${status}*\n\n` +
        `╭┈┈⬡「 📋 *طريقة الاستخدام* 」\n` +
        `┃ > \`${m.prefix}إشعار_المستوى تشغيل\` — تفعيل\n` +
        `┃ > \`${m.prefix}إشعار_المستوى إيقاف\` — إيقاف\n` +
        `╰┈┈┈┈┈┈┈┈⬡`
    )
}

module.exports = {
    config: pluginConfig,
    handler
}
