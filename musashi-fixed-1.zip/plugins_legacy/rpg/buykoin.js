const { getDatabase } = require('../../src/lib/database')
const { getRpgContextInfo } = require('../../src/lib/contextHelper')
const config = require('../../config')
const path = require('path')
const fs = require('fs')

const pluginConfig = {
    name: 'buykoin',
    alias: ['belikoin', 'belicoin', 'exptokoin', 'exptocoin'],
    category: 'rpg',
    description: 'Tukar الخبرة menjadi عملة',
    usage: '.buykoin <jumlah>',
    example: '.buykoin 10000',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

const EXP_PER_KOIN = 2

function getContextInfo(title = '💱 *ʙᴜʏ ᴋᴏɪɴ*', body = 'Tukar EXP') {
    const saluranId = config.saluran?.id || '120363432546133683@newsletter'
    const saluranName = config.saluran?.name || config.bot?.name || 'MUSASHI'
    
    const contextInfo = {
        forwardingScore: 9999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: saluranId,
            newsletterName: saluranName,
            serverMessageId: 127
        }
    }
    
    
    return contextInfo
}

async function handler(m, { sock }) {
    const db = getDatabase()
    const user = db.getUser(m.sender)
    
    if (!user.rpg) user.rpg = {}
    
    const args = m.args || []
    const amountStr = args[0]
    
    if (!amountStr) {
        let txt = `💱 *ʙᴜʏ ᴋᴏɪɴ*\n\n`
        txt += `> Tukar EXP menjadi Koin!\n\n`
        txt += `╭┈┈⬡「 📊 *ᴋᴜʀs* 」\n`
        txt += `┃ 💎 ${EXP_PER_KOIN} خبرة = 1 Koin\n`
        txt += `╰┈┈⬡\n\n`
        txt += `╭┈┈⬡「 📋 *sᴀʟᴅᴏᴍᴜ* 」\n`
        txt += `┃ 🚄 خبرة: *${(user.exp || 0).toLocaleString('id-ID')}*\n`
        txt += `┃ 💰 عملة: * ${(user.koin || 0).toLocaleString('id-ID')}*\n`
        txt += `╰┈┈⬡\n\n`
        txt += `> مثال: \`.buykoin 10000\`\n`
        txt += `> سوف menggunakan ${10000 * EXP_PER_KOIN} خبرة لـ 10.000 عملة`
        
        return m.reply(txt)
    }
    
    let koinAmount = 0
    if (amountStr === 'all' || amountStr === 'max') {
        koinAmount = Math.floor((user.exp || 0) / EXP_PER_KOIN)
    } else {
        koinAmount = parseInt(amountStr)
    }
    
    if (!koinAmount || koinAmount <= 0) {
        return m.reply(`❌ *همم~* أدخل كمية عملة الذي صحيح~ 🥺`)
    }
    
    const expNeeded = koinAmount * EXP_PER_KOIN
    
    if ((user.exp || 0) < expNeeded) {
        const maxPossible = Math.floor((user.exp || 0) / EXP_PER_KOIN)
        return m.reply(
            `❌ *الخبرة لا cukup!*\n\n` +
            `> Dibutuhkan: *${expNeeded.toLocaleString('id-ID')} خبرة*\n` +
            `> خبرة الخاص بك: *${(user.exp || 0).toLocaleString('id-ID')} خبرة*\n\n` +
            `> الحد الأقصى: *${maxPossible.toLocaleString('id-ID')} عملة*`
        )
    }
    
    // Use manual user update instead of updateKoin/updateExp to do batch update
    // But since logic was db.setUser, let's stick to update logic here
    const newExp = (user.exp || 0) - expNeeded
    const newKoin = (user.koin || 0) + koinAmount
    
    db.setUser(m.sender, {
        exp: newExp,
        koin: newKoin
    })
    
    await m.react('💱')
    
    let txt = `💱 *ᴛᴜᴋᴀʀ نجح!*\n\n`
    txt += `╭┈┈⬡「 📋 *التفاصيل* 」\n`
    txt += `┃ 🚄 خبرة: *-${expNeeded.toLocaleString('id-ID')}*\n`
    txt += `┃ 💰 عملة: *+${koinAmount.toLocaleString('id-ID')}*\n`
    txt += `╰┈┈⬡\n\n`
    txt += `╭┈┈⬡「 📊 *sᴀʟᴅᴏ sᴇᴋᴀʀᴀɴɢ* 」\n`
    txt += `┃ 🚄 خبرة: *${newExp.toLocaleString('id-ID')}*\n`
    txt += `┃ 💰 عملة: *${newKoin.toLocaleString('id-ID')}*\n`
    txt += `╰┈┈⬡`
    
    await sock.sendMessage(m.chat, {
        text: txt,
        contextInfo: getContextInfo()
    }, { quoted: m })
}

module.exports = {
    config: pluginConfig,
    handler
}