const { getDatabase } = require('../../src/lib/database')

const pluginConfig = {
    name: 'guild',
    alias: ['clan', 'team', 'kelompok'],
    category: 'rpg',
    description: 'Sistem guild/clan',
    usage: '.guild <create/join/leave/info>',
    example: '.guild create DragonSlayers',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const db = getDatabase()
    const user = db.getUser(m.sender)
    
    if (!user.rpg) user.rpg = {}
    
    const args = m.args || []
    const action = args[0]?.toLowerCase()
    const guildName = args.slice(1).join(' ')
    
    const guilds = db.db?.data?.guilds || {}
    
    if (!action || !['create', 'join', 'leave', 'info', 'list', 'members', 'deposit'].includes(action)) {
        let txt = `🏰 *ɢᴜɪʟᴅ sʏsᴛᴇᴍ*\n\n`
        txt += `> تاريخ الانضمام/buat guild لـ bonus!\n\n`
        txt += `╭┈┈⬡「 📋 *الأمر* 」\n`
        txt += `┃ ${m.prefix}guild create <nama>\n`
        txt += `┃ ${m.prefix}guild join <nama>\n`
        txt += `┃ ${m.prefix}guild leave\n`
        txt += `┃ ${m.prefix}guild info\n`
        txt += `┃ ${m.prefix}guild list\n`
        txt += `┃ ${m.prefix}guild members\n`
        txt += `┃ ${m.prefix}guild deposit <amount>\n`
        txt += `╰┈┈┈┈┈┈┈┈⬡\n\n`
        
        if (user.rpg.guildId) {
            const myGuild = guilds[user.rpg.guildId]
            txt += `> 🏰 Guild أنت: *${myGuild?.name || 'Unknown'}*`
        } else {
            txt += `> ⚠️ أنت لم bergabung guild`
        }
        return m.reply(txt)
    }
    
    if (action === 'list') {
        const guildList = Object.values(guilds)
        if (guildList.length === 0) {
            return m.reply(`❌ *همم~* لم يوجد guild! Buat مع \`${m.prefix}guild create <الاسم>\``)
        }
        
        let txt = `🏰 *ᴅᴀꜰᴛᴀʀ ɢᴜɪʟᴅ*\n\n`
        txt += `╭┈┈⬡「 📋 *ɢᴜɪʟᴅs* 」\n`
        for (const g of guildList.slice(0, 10)) {
            txt += `┃ 🏰 *${g.name}*\n`
            txt += `┃ 👥 Member: ${g.members?.length || 0}\n`
            txt += `┃ 💰 Treasury: ${(g.treasury || 0).toLocaleString()}\n`
            txt += `┃\n`
        }
        txt += `╰┈┈┈┈┈┈┈┈⬡`
        return m.reply(txt)
    }
    
    if (action === 'create') {
        if (user.rpg.guildId) {
            return m.reply(`❌ *همم~* أنت تم لديه guild! Leave أولاً~ 🥺`)
        }
        
        if (!guildName || guildName.length < 3) {
            return m.reply(`❌ *همم~* Nama guild minimal 3 حرفاً~ 🥺`)
        }
        
        if (guildName.length > 20) {
            return m.reply(`❌ *همم~* Nama guild maksimal 20 حرفاً~ 🥺`)
        }
        
        const existingGuild = Object.values(guilds).find(g => g.name.toLowerCase() === guildName.toLowerCase())
        if (existingGuild) {
            return m.reply(`❌ *همم~* الاسم guild تم digunakan~ 🥺`)
        }
        
        const createCost = 10000
        if ((user.koin || 0) < createCost) {
            return m.reply(`❌ *همم~* Butuh ${createCost.toLocaleString()} balance لـ membuat guild~ 🥺`)
        }
        
        user.koin -= createCost
        
        const guildId = `guild_${Date.now()}`
        if (!db.db.data.guilds) db.db.data.guilds = {}
        
        db.db.data.guilds[guildId] = {
            id: guildId,
            name: guildName,
            leader: m.sender,
            members: [m.sender],
            treasury: 0,
            level: 1,
            exp: 0,
            createdAt: Date.now()
        }
        
        user.rpg.guildId = guildId
        db.save()
        
        return m.reply(
            `🎉 *ɢᴜɪʟᴅ ᴅɪʙᴜᴀᴛ!*\n\n` +
            `╭┈┈⬡「 🏰 *ɪɴꜰᴏ* 」\n` +
            `┃ 🏰 الاسم: *${guildName}*\n` +
            `┃ 👑 Leader: *أنت*\n` +
            `┃ 💰 Cost: *-${createCost.toLocaleString()}*\n` +
            `╰┈┈┈┈┈┈┈┈⬡`
        )
    }
    
    if (action === 'join') {
        if (user.rpg.guildId) {
            return m.reply(`❌ *همم~* أنت تم لديه guild! Leave أولاً~ 🥺`)
        }
        
        if (!guildName) {
            return m.reply(`❌ Tentukan nama guild!\n\n> مثال: \`${m.prefix}guild join DragonSlayers\``)
        }
        
        const targetGuild = Object.values(guilds).find(g => g.name.toLowerCase() === guildName.toLowerCase())
        if (!targetGuild) {
            return m.reply(`❌ *همم~* Guild غير موجود~ 🥺`)
        }
        
        if (targetGuild.members?.length >= 50) {
            return m.reply(`❌ *همم~* Guild تم penuh! (Max 50 عضو)~ 🥺`)
        }
        
        targetGuild.members = targetGuild.members || []
        targetGuild.members.push(m.sender)
        user.rpg.guildId = targetGuild.id
        db.save()
        
        return m.reply(
            `✅ *ʙᴇʀɢᴀʙᴜɴɢ ɢᴜɪʟᴅ*\n\n` +
            `> تهانينا datang di *${targetGuild.name}*!`
        )
    }
    
    if (action === 'leave') {
        if (!user.rpg.guildId) {
            return m.reply(`❌ *همم~* أنت لا dalam guild~ 🥺`)
        }
        
        const myGuild = guilds[user.rpg.guildId]
        if (!myGuild) {
            user.rpg.guildId = null
            db.save()
            return m.reply(`❌ *همم~* Guild غير موجود, data dibersihkan~ 🥺`)
        }
        
        if (myGuild.leader === m.sender && myGuild.members?.length > 1) {
            return m.reply(`❌ *همم~* أنت هو leader! Transfer kepemimpinan أولاً أو kick كل عضو~ 🥺`)
        }
        
        myGuild.members = (myGuild.members || []).filter(m => m !== m.sender)
        
        if (myGuild.members.length === 0) {
            delete guilds[user.rpg.guildId]
        }
        
        const guildName = myGuild.name
        user.rpg.guildId = null
        db.save()
        
        return m.reply(`✅ *Yatta~* Keluar dari guild *${guildName}*~ ✨`)
    }
    
    if (action === 'info') {
        if (!user.rpg.guildId) {
            return m.reply(`❌ *همم~* أنت لا dalam guild~ 🥺`)
        }
        
        const myGuild = guilds[user.rpg.guildId]
        if (!myGuild) {
            return m.reply(`❌ *همم~* Guild غير موجود~ 🥺`)
        }
        
        return m.reply(
            `🏰 *ɢᴜɪʟᴅ ɪɴꜰᴏ*\n\n` +
            `╭┈┈⬡「 📋 *التفاصيل* 」\n` +
            `┃ 🏰 الاسم: *${myGuild.name}*\n` +
            `┃ 👑 Leader: *${myGuild.leader?.split('@')[0]}*\n` +
            `┃ 👥 Member: *${myGuild.members?.length || 0}/50*\n` +
            `┃ 📊 المستوى: *${myGuild.level || 1}*\n` +
            `┃ 💰 Treasury: *${(myGuild.treasury || 0).toLocaleString()}*\n` +
            `╰┈┈┈┈┈┈┈┈⬡`
        )
    }
    
    if (action === 'members') {
        if (!user.rpg.guildId) {
            return m.reply(`❌ *همم~* أنت لا dalam guild~ 🥺`)
        }
        
        const myGuild = guilds[user.rpg.guildId]
        if (!myGuild) {
            return m.reply(`❌ *همم~* Guild غير موجود~ 🥺`)
        }
        
        const memberList = (myGuild.members || []).map((m, i) => {
            const isLeader = m === myGuild.leader ? ' 👑' : ''
            return `${i + 1}. @${m.split('@')[0]}${isLeader}`
        }).join('\n')
        
        return m.reply(
            `👥 *ɢᴜɪʟᴅ عضوs*\n\n` +
            `🏰 *${myGuild.name}*\n\n` +
            memberList,
            { mentions: myGuild.members }
        )
    }
    
    if (action === 'deposit') {
        if (!user.rpg.guildId) {
            return m.reply(`❌ *همم~* أنت لا dalam guild~ 🥺`)
        }
        
        const myGuild = guilds[user.rpg.guildId]
        if (!myGuild) {
            return m.reply(`❌ *همم~* Guild غير موجود~ 🥺`)
        }
        
        const amount = parseInt(args[1]) || 0
        if (amount < 100) {
            return m.reply(`❌ *همم~* الحد الأدنى deposit 100~ 🥺`)
        }
        
        if ((user.koin || 0) < amount) {
            return m.reply(`❌ *همم~* Balance أقل~ 🥺`)
        }
        
        user.koin -= amount
        myGuild.treasury = (myGuild.treasury || 0) + amount
        db.save()
        
        return m.reply(
            `✅ *ᴅᴇᴘᴏsɪᴛ نجح*\n\n` +
            `> 💰 +${amount.toLocaleString()} ke treasury guild\n` +
            `> 🏰 الإجمالي: ${myGuild.treasury.toLocaleString()}`
        )
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
