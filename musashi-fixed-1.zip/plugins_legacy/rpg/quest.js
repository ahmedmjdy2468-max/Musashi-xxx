const { getDatabase } = require('../../src/lib/database')
const { getRpgContextInfo } = require('../../src/lib/contextHelper')

const pluginConfig = {
    name: 'quest',
    alias: ['misi', 'mission'],
    category: 'rpg',
    description: 'Ambil quest harian لـ reward bonus',
    usage: '.quest',
    example: '.quest',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 0,
    energi: 0,
    isEnabled: true
}

const QUESTS = [
    { id: 'mining5', name: 'Penambang Pemula', desc: 'Mining 5 kali', target: 5, reward: { money: 10000, exp: 1000 } },
    { id: 'fishing5', name: 'Pemancing Handal', desc: 'Fishing 5 kali', target: 5, reward: { money: 8000, exp: 800 } },
    { id: 'adventure3', name: 'Petualang Sejati', desc: 'Adventure 3 kali', target: 3, reward: { money: 15000, exp: 1500 } },
    { id: 'work10', name: 'Pekerja Keras', desc: 'Work 10 kali', target: 10, reward: { money: 20000, exp: 2000 } },
    { id: 'hunt5', name: 'Pemburu Ulung', desc: 'Hunt 5 kali', target: 5, reward: { money: 12000, exp: 1200 } }
]

async function handler(m, { sock }) {
    const db = getDatabase()
    const user = db.getUser(m.sender)
    
    if (!user.rpg) user.rpg = {}
    if (!user.quest) user.quest = {}
    
    const args = m.args || []
    const sub = args[0]?.toLowerCase()
    
    if (sub === 'claim') {
        const questId = args[1]
        if (!questId || !user.quest[questId]) {
            return m.reply(`❌ *المهمة ɴᴏᴛ ꜰᴏᴜɴᴅ*\n\n> Quest غير موجود أو لم diambil!`)
        }
        
        const quest = QUESTS.find(q => q.id === questId)
        if (!quest) {
            return m.reply(`❌ *ɪɴᴠᴀʟɪᴅ المهمة*\n\n> Quest ID غير صالح!`)
        }
        
        if (user.quest[questId].progress < quest.target) {
            return m.reply(
                `❌ *المهمة ʙᴇʟᴜᴍ sᴇʟᴇsᴀɪ*\n\n` +
                `> Progress: ${user.quest[questId].progress}/${quest.target}`
            )
        }
        
        if (user.quest[questId].claimed) {
            return m.reply(`❌ *sᴜᴅᴀʜ ᴅɪᴋʟᴀɪᴍ*\n\n> Quest هذا تم diklaim!`)
        }
        
        user.koin = (user.koin || 0) + quest.reward.money
        user.rpg.exp = (user.rpg.exp || 0) + quest.reward.exp
        user.quest[questId].claimed = true
        
        db.save()
        return m.reply(`✅ *المهمة ᴄʟᴀɪᴍᴇᴅ*\n\n> 🎯 ${quest.name}\n> 💰 Money: +Rp ${quest.reward.money.toLocaleString('id-ID')}\n> 🚄 Exp: +${quest.reward.exp}`)
    }
    
    if (sub === 'take') {
        const questId = args[1]
        const quest = QUESTS.find(q => q.id === questId)
        if (!quest) {
            return m.reply(`❌ *المهمة ɴᴏᴛ ꜰᴏᴜɴᴅ*\n\n> Lihat list: \`.quest\``)
        }
        
        if (user.quest[questId]) {
            return m.reply(`❌ *sᴜᴅᴀʜ ᴅɪᴀᴍʙɪʟ*\n\n> Quest هذا تم diambil!`)
        }
        
        user.quest[questId] = { progress: 0, claimed: false, takenAt: Date.now() }
        db.save()
        return m.reply(`✅ *المهمة ᴅɪᴀᴍʙɪʟ*\n\n> 🎯 ${quest.name}\n> 📝 ${quest.desc}\n> 🎁 Reward: Rp ${quest.reward.money.toLocaleString('id-ID')} + ${quest.reward.exp} Exp`)
    }
    
    let txt = `📜 *المهمة قائمة*\n\n`
    
    for (const quest of QUESTS) {
        const userQuest = user.quest[quest.id]
        let status = '⬜ لم diambil'
        if (userQuest) {
            if (userQuest.claimed) {
                status = '✅ انتهى'
            } else if (userQuest.progress >= quest.target) {
                status = '🎁 يمكن diklaim'
            } else {
                status = `🔄 ${userQuest.progress}/${quest.target}`
            }
        }
        
        txt += `╭┈┈⬡「 🎯 *${quest.name}* 」\n`
        txt += `┃ 📝 ${quest.desc}\n`
        txt += `┃ 🎁 Rp ${quest.reward.money.toLocaleString('id-ID')} + ${quest.reward.exp} Exp\n`
        txt += `┃ 📊 الحالة: ${status}\n`
        txt += `╰┈┈┈┈┈┈┈┈⬡\n\n`
    }
    
    txt += `> Ambil: \`.quest take <id>\`\n`
    txt += `> Claim: \`.quest claim <id>\``
    
    await m.reply(txt)
}

module.exports = {
    config: pluginConfig,
    handler
}
