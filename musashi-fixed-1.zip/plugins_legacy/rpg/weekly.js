const { getDatabase } = require('../../src/lib/database')
const { getRpgContextInfo } = require('../../src/lib/contextHelper')

const pluginConfig = {
    name: 'weekly',
    alias: ['mingguan'],
    category: 'rpg',
    description: 'يطالب بالمكافأة الأسبوعية العشوائية من الخبرة والمال والصناديق؛ مرة كل سبعة أيام.',
    usage: '.مكافأة_أسبوعية',
    example: '.مكافأة_أسبوعية',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 0,
    energi: 0,
    isEnabled: true
}

const WEEKLY_COOLDOWN = 7 * 24 * 60 * 60 * 1000

async function handler(m, { sock }) {
    const db = getDatabase()
    const user = db.getUser(m.sender)
    
    if (!user.cooldowns) user.cooldowns = {}
    const lastWeekly = user.cooldowns.weekly || 0
    const now = Date.now()
    
    if (now - lastWeekly < WEEKLY_COOLDOWN) {
        const remaining = lastWeekly + WEEKLY_COOLDOWN - now
        const days = Math.floor(remaining / (1000 * 60 * 60 * 24))
        const hours = Math.floor((remaining % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
        return m.reply(`🕕 حصلت على مكافأتك الأسبوعية بالفعل.\n> يمكنك المطالبة مجدداً بعد *${days} يوم و${hours} ساعة*.`)
    }
    
    const expReward = Math.floor(Math.random() * 20000) + 10000
    const moneyReward = Math.floor(Math.random() * 50000) + 30000
    const crateReward = Math.floor(Math.random() * 3) + 1
    
    if (!user.rpg) user.rpg = {}
    user.rpg.exp = (user.rpg.exp || 0) + expReward
    user.koin = (user.koin || 0) + moneyReward
    
    if (!user.inventory) user.inventory = {}
    user.inventory.uncommon = (user.inventory.uncommon || 0) + crateReward
    
    user.cooldowns.weekly = now
    db.save()
    
    let txt = `🎊 *وصلت مكافأتك الأسبوعية*\n\n`
    txt += `╭┈┈⬡「 🎁 *المكافآت* 」\n`
    txt += `┃ 🚄 الخبرة: *+${expReward.toLocaleString('id-ID')}*\n`
    txt += `┃ 🪙 المال: *+${moneyReward.toLocaleString('id-ID')} روبية إندونيسية*\n`
    txt += `┃ 🛍️ صندوق غير شائع: *+${crateReward}*\n`
    txt += `╰┈┈┈┈┈┈┈┈⬡\n\n`
    txt += `> يمكنك المطالبة مرة أخرى بعد أسبوع.`
    
    await m.reply(txt)
}

module.exports = {
    config: pluginConfig,
    handler
}
