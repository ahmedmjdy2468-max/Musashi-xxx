const { getDatabase } = require('../../src/lib/database')
const { addExpWithLevelCheck } = require('../../src/lib/levelHelper')
const { getRpgContextInfo } = require('../../src/lib/contextHelper')

// ============================================================
// chan.js — MUSASHI chan Career layer (v2)
// Numpang di sistem RPG yang sudah ada (koin, exp, level, stamina),
// TIDAK bikin currency/level baru. Semua progress chan disimpan
// terpisah di user.rpg.chan supaya tidak bentrok dengan plugin lain.
// Semua fitur baru dipasang sebagai SUBCOMMAND dari .idolku
// (bukan command top-level baru) supaya tidak nambah alias/command
// yang bisa tabrakan dengan 58 file rpg/ dan plugin clan/+game/ lain.
//
// CATATAN PENTING (tolong dicek manual sebelum deploy):
// - Fitur "chan Group" & "Global Ranking" butuh akses ke SEMUA user
//   di database. Kode ini pakai fallback defensif (getAllUsers()) yang
//   nyoba beberapa pola umum (db.getAllUsers(), db.data.users sebagai
//   object atau array). Kalau db kamu punya method resmi buat list
//   semua user, ganti isi getAllUsers() supaya makai itu langsung —
//   biar gak salah asumsi soal struktur internal db kamu.
// - Data grup disimpan di db.data.idolGroups (dibuat otomatis kalau
//   belum ada). Kalau `db.data` bukan object biasa (misal db kamu gak
//   expose `.data`), bagian group/top perlu disesuaikan.
// ============================================================

const pluginConfig = {
    name: 'idolku',
    alias: ['oshi', 'panggung', 'karirai'],
    category: 'rpg',
    description: 'Karir chan ala MUSASHI — stage, rank, showdown, و lainnya',
    usage: '.idolku <profile/stage/rank/showdown/help>',
    example: '.idolku stage school',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 3,
    energi: 0,
    isEnabled: true
}

// ============================================================
// MASTER DATA
// ============================================================

const TIERS = [
    { name: 'Trainee', min: 0, emoji: '🌱' },
    { name: 'Rookie chan', min: 500, emoji: '🎤' },
    { name: 'Rising Star', min: 2000, emoji: '✨' },
    { name: 'Top chan', min: 10000, emoji: '👑' },
    { name: 'Living Legend', min: 50000, emoji: '🌟' }
]

// Concert Tour — beragam lokasi manggung, syarat tier & hadiah beda-beda
const STAGES = {
    school: {
        label: 'School Festival', emoji: '🏫', tierMin: 'Trainee', stamina: 15,
        fans: [30, 90], koin: [100, 300], exp: [20, 50], rareChance: 0.05
    },
    mall: {
        label: 'Mall Event', emoji: '🏢', tierMin: 'Rookie chan', stamina: 25,
        fans: [80, 180], koin: [250, 550], exp: [40, 80], rareChance: 0.08
    },
    city: {
        label: 'City Festival', emoji: '🎪', tierMin: 'Rising Star', stamina: 35,
        fans: [180, 380], koin: [500, 1000], exp: [70, 130], rareChance: 0.12
    },
    dome: {
        label: 'Dome Concert', emoji: '🏟', tierMin: 'Top chan', stamina: 50,
        fans: [400, 800], koin: [1200, 2400], exp: [150, 260], rareChance: 0.16
    },
    worldtour: {
        label: 'World Tour', emoji: '🌍', tierMin: 'Living Legend', stamina: 70,
        fans: [900, 1800], koin: [2800, 5200], exp: [300, 500], rareChance: 0.22
    }
}
const STAGE_ORDER = ['school', 'mall', 'city', 'dome', 'worldtour']

// Random Event — dirol setelah stage/audition/tv/photo selesai
const RANDOM_EVENTS = [
    {
        id: 'viral', label: '🎉 Viral', weight: 8,
        text: 'Konsermu viral di internet!',
        apply: (r) => { r.fansGain = Math.round(r.fansGain * 2.2) + 800 }
    },
    {
        id: 'sponsor', label: '💰 Sponsor', weight: 8,
        text: 'Sebuah perusahaan ingin bekerja sama.',
        apply: (r) => { r.koinGain += 3000 }
    },
    {
        id: 'sakit', label: '😷 Sakit', weight: 10,
        text: 'Suaramu جارٍ أقل fit.',
        apply: (r) => { r.fansGain = Math.round(r.fansGain * 0.8) }
    },
    {
        id: 'hujan', label: '🌧 Hujan', weight: 10,
        text: 'Penonton pulang أكثر cepat.',
        apply: (r) => { r.fansGain = Math.round(r.fansGain * 0.6); r.koinGain = Math.round(r.koinGain * 0.6) }
    },
    {
        id: 'fanproject', label: '💖 Fan Project', weight: 8,
        text: 'Fans membuat project kejutan buat أنت!',
        apply: (r, user) => { r.fansGain += 500; user.rpg.stamina = Math.min(100, user.rpg.stamina + 10) }
    },
    {
        id: 'none', label: null, weight: 56,
        text: null,
        apply: () => {}
    }
]

// Song Collection
const SONGS = {
    starlight: { name: 'Star Light', bonusPerStar: 4 },
    ainomelody: { name: 'MUSASHI no Melody', bonusPerStar: 4 },
    dreamsky: { name: 'Dream Sky', bonusPerStar: 4 }
}

// Costume / chan Shop
const COSTUMES = {
    school_uniform: { name: '🌸 School Uniform', price: 2000, bonusType: 'fans', bonusPercent: 10 },
    princess_dress: { name: '👑 Princess Dress', price: 8000, bonusType: 'performance', bonusPercent: 15 },
    galaxy_idol: { name: '✨ Galaxy chan', price: 25000, bonusType: 'all', bonusPercent: 10 }
}

// Oshi System — buff kecil, dipilih sekali (bisa ganti kapan saja)
const OSHI_LIST = {
    ai: { name: 'MUSASHI', buff: 'fans', percent: 8 },
    ruby: { name: 'Ruby', buff: 'exp', percent: 8 },
    kana: { name: 'Kana', buff: 'performance', percent: 8 },
    akane: { name: 'Akane', buff: 'showdown', percent: 8 }
}

// Gacha
const GACHA_COST = 5000
const GACHA_POOL = [
    { rarity: 'Common', chance: 45, reward: () => ({ type: 'koin', amount: 800, label: '800 Koin' }) },
    { rarity: 'Rare', chance: 30, reward: () => ({ type: 'costume', id: 'school_uniform', label: COSTUMES.school_uniform.name }) },
    { rarity: 'Epic', chance: 17, reward: () => ({ type: 'costume', id: 'princess_dress', label: COSTUMES.princess_dress.name }) },
    { rarity: 'Legendary', chance: 6, reward: () => ({ type: 'costume', id: 'galaxy_idol', label: COSTUMES.galaxy_idol.name }) },
    { rarity: 'Mythic', chance: 2, reward: () => ({ type: 'title', label: 'Legendary Performer (title)' }) }
]

// Achievements
const ACHIEVEMENTS = [
    { id: 'first_stage', label: '🎖 First Stage', desc: 'Main konser pertama.', cond: (u) => u.rpg.chan.totalStages >= 1, fans: 50, koin: 500 },
    { id: 'rising_idol', label: '🎖 Rising chan', desc: '5.000 Fans.', cond: (u) => u.rpg.chan.fans >= 5000, fans: 200, koin: 1000 },
    { id: 'super_idol', label: '🎖 Super chan', desc: '50.000 Fans.', cond: (u) => u.rpg.chan.fans >= 50000, fans: 1000, koin: 5000 },
    { id: 'performer', label: '🎖 Performer', desc: '100 kali konser.', cond: (u) => u.rpg.chan.totalStages >= 100, fans: 500, koin: 3000 },
    { id: 'champion', label: '🎖 Champion', desc: 'Menang showdown 50 kali.', cond: (u) => u.rpg.chan.showdownWins >= 50, fans: 800, koin: 4000 }
]

// Daily Mission pool
const DAILY_MISSION_POOL = [
    { id: 'stage3', label: 'Manggung 3 kali', type: 'stage', target: 3, rewardText: '500 Fans', apply: (u) => { u.rpg.chan.fans += 500 } },
    { id: 'showdown_win1', label: 'Menang showdown', type: 'showdown_win', target: 1, rewardText: '3000 Koin', apply: (u, db, jid) => { db.updateKoin(jid, 3000) } },
    { id: 'audition2', label: 'Audisi 2 kali', type: 'audition', target: 2, rewardText: '100 EXP', apply: null } // exp diberikan lewat addExpWithLevelCheck di caller
]

// ============================================================
// HELPERS
// ============================================================

function getTier(fans) {
    let current = TIERS[0]
    for (const t of TIERS) if (fans >= t.min) current = t
    return current
}
function getTierIndex(tierName) { return TIERS.findIndex(t => t.name === tierName) }
function getNextTier(fans) { return TIERS.find(t => t.min > fans) || null }

function rand(min, max) { return Math.floor(Math.random() * (max - min + 1)) + min }
function todayStr() {
    const d = new Date()
    return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`
}

function ensureIdol(user) {
    if (!user.rpg) user.rpg = {}
    if (user.rpg.stamina === undefined) user.rpg.stamina = 100
    if (!user.rpg.chan) user.rpg.chan = {}
    const chan = user.rpg.chan
    if (chan.fans === undefined) chan.fans = 0
    if (chan.loyalty === undefined) chan.loyalty = 50
    if (!chan.songsOwned) chan.songsOwned = {}       // { starlight: { stars: 1 } }
    if (!chan.costumesOwned) chan.costumesOwned = [] // ids
    if (chan.costumeWorn === undefined) chan.costumeWorn = null
    if (chan.oshi === undefined) chan.oshi = null
    if (!chan.stats) chan.stats = { vocal: 0, dance: 0, performance: 0, charm: 0 }
    if (!chan.achievements) chan.achievements = []
    if (chan.totalStages === undefined) chan.totalStages = 0
    if (chan.showdownWins === undefined) chan.showdownWins = 0
    if (chan.showdownLosses === undefined) chan.showdownLosses = 0
    if (!chan.dailyMission) chan.dailyMission = null
    if (chan.groupName === undefined) chan.groupName = null
    return user
}

function getAllUsers(db) {
    try {
        let raw = null
        if (typeof db.getAllUsers === 'function') raw = db.getAllUsers()
        else if (db.data && db.data.users) raw = db.data.users
        if (!raw) return null
        return Array.isArray(raw) ? raw : Object.values(raw)
    } catch (e) { /* fall through */ }
    return null // null = tidak bisa diakses
}

// Data grup disimpan lewat db.setting() (persisted ke settings.json, sudah
// otomatis kena markDirty tiap kali di-set ulang) supaya beneran tersimpan
// dan gak hilang pas bot restart.
function getGroupStore(db) {
    if (typeof db.setting !== 'function') return null
    let store = db.setting('idolGroups')
    if (!store || typeof store !== 'object') {
        store = {}
        db.setting('idolGroups', store)
    }
    return store
}
function persistGroupStore(db, store) {
    db.setting('idolGroups', store)
}

// Bonus fans dari lagu ter-favorit (paling banyak dipakai) yang dimiliki
function songBonusPercent(chan) {
    let best = 0
    for (const id in chan.songsOwned) {
        const stars = chan.songsOwned[id].stars || 1
        const bonus = stars * (SONGS[id]?.bonusPerStar || 0)
        if (bonus > best) best = bonus
    }
    return best
}

function costumeBonus(chan, type) {
    if (!chan.costumeWorn) return 0
    const c = COSTUMES[chan.costumeWorn]
    if (!c) return 0
    if (c.bonusType === 'all' || c.bonusType === type) return c.bonusPercent
    return 0
}

function oshiBonus(chan, type) {
    if (!chan.oshi) return 0
    const o = OSHI_LIST[chan.oshi]
    if (!o) return 0
    return o.buff === type ? o.percent : 0
}

function applyLoyaltyMultiplier(value, loyalty) {
    // loyalty 0-100, 50 = netral. tiap 10 poin di atas 50 = +2% reward, di bawah = -2%
    const diff = (loyalty - 50) / 10
    return Math.round(value * (1 + diff * 0.02))
}

function rollRandomEvent() {
    const total = RANDOM_EVENTS.reduce((s, e) => s + e.weight, 0)
    let r = Math.random() * total
    for (const ev of RANDOM_EVENTS) {
        if (r < ev.weight) return ev
        r -= ev.weight
    }
    return RANDOM_EVENTS[RANDOM_EVENTS.length - 1]
}

// Terapkan semua bonus (song, costume, oshi, loyalty) ke hasil mentah
function finalizeReward(user, rawFans, rawKoin, rawExp, activityType) {
    const chan = user.rpg.chan
    let fansGain = rawFans
    let koinGain = rawKoin
    let expGain = rawExp

    const bonusPct = songBonusPercent(chan) + costumeBonus(chan, 'fans') + oshiBonus(chan, 'fans')
    fansGain = Math.round(fansGain * (1 + bonusPct / 100))

    const expBonusPct = oshiBonus(chan, 'exp')
    expGain = Math.round(expGain * (1 + expBonusPct / 100))

    fansGain = applyLoyaltyMultiplier(fansGain, chan.loyalty)
    koinGain = applyLoyaltyMultiplier(koinGain, chan.loyalty)

    const result = { fansGain, koinGain, expGain, eventText: null }

    const ev = rollRandomEvent()
    if (ev.id !== 'none') {
        ev.apply(result, user)
        result.eventText = `${ev.label}\n${ev.text}`
    }

    // stat naik dikit sesuai aktivitas
    if (activityType === 'stage') chan.stats.performance += 1
    if (activityType === 'audition') chan.stats.vocal += 1
    if (activityType === 'tv') chan.stats.charm += 1
    if (activityType === 'photo') chan.stats.dance += 1

    return result
}

function checkAchievements(user) {
    const chan = user.rpg.chan
    const unlocked = []
    for (const ach of ACHIEVEMENTS) {
        if (!chan.achievements.includes(ach.id) && ach.cond(user)) {
            chan.achievements.push(ach.id)
            chan.fans += ach.fans
            unlocked.push(ach)
        }
    }
    return unlocked
}

function adjustLoyalty(chan, delta) {
    chan.loyalty = Math.max(0, Math.min(100, chan.loyalty + delta))
}

function ensureDailyMission(user) {
    const chan = user.rpg.chan
    const today = todayStr()
    if (!chan.dailyMission || chan.dailyMission.date !== today) {
        const pick = DAILY_MISSION_POOL[rand(0, DAILY_MISSION_POOL.length - 1)]
        chan.dailyMission = { date: today, id: pick.id, progress: 0, claimed: false }
    }
    return chan.dailyMission
}

function bumpMissionProgress(user, type) {
    const chan = user.rpg.chan
    const dm = ensureDailyMission(user)
    const def = DAILY_MISSION_POOL.find(m => m.id === dm.id)
    if (def && def.type === type && !dm.claimed) {
        dm.progress += 1
    }
}

function achievementText(list) {
    if (!list.length) return ''
    return `\n\n🏅 *ᴀᴄʜɪᴇᴠᴇᴍᴇɴᴛ ᴜɴʟᴏᴄᴋ!*\n` + list.map(a => `${a.label} — ${a.desc} (+${a.fans} fans, +${a.koin} عملة)`).join('\n')
}

// ============================================================
// HANDLER
// ============================================================

async function handler(m, { sock }) {
    const db = getDatabase()
    let user = db.getUser(m.sender) || db.setUser(m.sender)
    user = ensureIdol(user)
    const chan = user.rpg.chan

    const args = m.args || []
    const sub = (args[0] || 'profile').toLowerCase()

    switch (sub) {
        case 'profile':
        case 'p': {
            const tier = getTier(chan.fans)
            const next = getNextTier(chan.fans)
            let txt = `🎙️ *ʜᴏsʜɪɴᴏ ᴀɪ ⋆ ɪᴅᴏʟ ᴘʀᴏғɪʟᴇ*\n\n`
            txt += `╭┈┈⬡「 ${tier.emoji} *${tier.name.toUpperCase()}* 」\n`
            txt += `┃ 👤 ${user.name || m.pushName || 'Unknown'}\n`
            txt += `┃ 💫 Fans: *${chan.fans.toLocaleString()}*\n`
            txt += `┃ 💖 Loyalty: *${chan.loyalty}%*\n`
            txt += `┃ 📈 المستوى: *${user.rpg.level || 1}*\n`
            txt += `┃ ⚡ Stamina: *${user.rpg.stamina}/100*\n`
            txt += `┃ 💰 عملة: *${(user.koin || 0).toLocaleString()}*\n`
            txt += `┃ 👗 Costume: *${chan.costumeWorn ? COSTUMES[chan.costumeWorn].name : '-'}*\n`
            txt += `┃ ⭐ Oshi: *${chan.oshi ? OSHI_LIST[chan.oshi].name : '-'}*\n`
            txt += `┃ 👥 المجموعة: *${chan.groupName || '-'}*\n`
            txt += `┃ 🎤 Vocal ${chan.stats.vocal} 💃 Dance ${chan.stats.dance} ✨ Perf ${chan.stats.performance} 😊 Charm ${chan.stats.charm}\n`
            if (next) {
                txt += `┃ 🎯 Menuju ${next.emoji} ${next.name}: *${(next.min - chan.fans).toLocaleString()}* fans مجدداً\n`
            } else {
                txt += `┃ 🏆 Tier tertinggi tercapai!\n`
            }
            txt += `╰┈┈┈┈┈┈┈┈⬡\n\n`
            txt += `> اكتب \`${m.prefix}idolku help\` buat lihat كل الأمر!`
            return m.reply(txt, { contextInfo: getRpgContextInfo('🎤 MUSASHI chan', 'Career profile') })
        }

        case 'stage':
        case 'manggung': {
            const stageKey = (args[1] || 'school').toLowerCase()
            const stage = STAGES[stageKey]
            if (!stage) {
                return m.reply(`❌ Lokasi لا ketemu. الخيارات: ${STAGE_ORDER.join(', ')}\n> مثال: ${m.prefix}idolku stage mall`)
            }
            const myTierIdx = getTierIndex(getTier(chan.fans).name)
            const reqTierIdx = getTierIndex(stage.tierMin)
            if (myTierIdx < reqTierIdx) {
                return m.reply(`🔒 *ᴛɪᴇʀ ʙᴇʟᴜᴍ ᴄᴜᴋᴜᴘ*\n\n> ${stage.emoji} ${stage.label} أحتاج tier minimal *${stage.tierMin}*.\n> Tier أنت الآن: *${getTier(chan.fans).name}*`)
            }
            if (user.rpg.stamina < stage.stamina) {
                return m.reply(`⚡ *الطاقة ʜᴀʙɪs*\n\n> Butuh ${stage.stamina} stamina buat manggung di ${stage.label}.\n> طاقتك: ${user.rpg.stamina}\n> Istirahat أولاً نعم. (\`.meditation\`)`)
            }

            user.rpg.stamina -= stage.stamina
            await m.reply(`🎤 *sᴇᴅᴀɴɢ ᴍᴀɴɢɢᴜɴɢ ᴅɪ ${stage.label.toUpperCase()}...*`)
            await new Promise(r => setTimeout(r, 2000))

            const rawFans = rand(...stage.fans)
            const rawKoin = rand(...stage.koin)
            const rawExp = rand(...stage.exp)
            const result = finalizeReward(user, rawFans, rawKoin, rawExp, 'stage')

            chan.fans += result.fansGain
            chan.totalStages += 1
            if (result.fansGain > 0) adjustLoyalty(chan, 1)
            if (result.koinGain > 0) db.updateKoin(m.sender, result.koinGain)
            await addExpWithLevelCheck(sock, m, db, user, result.expGain)
            bumpMissionProgress(user, 'stage')
            const unlocked = checkAchievements(user)

            db.setUser(m.sender, { rpg: user.rpg })
            db.save()

            const lines = [
                'Wah, penonton اليوم rame جداً! شكراً شكراً تم semangat~ ✨',
                'Panggung اليوم terasa مميزاً. أنتم الذي إنشاء هذا كل berarti!',
                'Fyuh, capek لكن puas! هذا كل berkat dukungan أنتم~',
                'Sedikit demi sedikit, نحن naik panggung الذي أكثر besar نعم!'
            ]
            const quote = lines[rand(0, lines.length - 1)]

            let txt = `${stage.emoji} *${stage.label.toUpperCase()} ꜱᴇʟᴇꜱᴀɪ*\n\n`
            txt += `╭┈┈⬡「 💫 *النتيجة* 」\n`
            txt += `┃ 💫 Fans: *+${result.fansGain}*\n`
            txt += `┃ 💰 عملة: *+${result.koinGain}*\n`
            txt += `┃ 🚄 Exp: *+${result.expGain}*\n`
            txt += `┃ ⚡ Stamina: *-${stage.stamina}*\n`
            txt += `╰┈┈┈┈┈┈┈┈⬡`
            if (result.eventText) txt += `\n\n📰 *ɪᴅᴏʟ ɴᴇᴡs*\n${result.eventText}`
            txt += `\n\n💬 _"${quote}"_\n> — MUSASHI`
            txt += achievementText(unlocked)
            return m.reply(txt, { contextInfo: getRpgContextInfo('🎤 MUSASHI chan', 'Stage result') })
        }

        case 'audition':
        case 'audisi': {
            const staminaCost = 40
            if (user.rpg.stamina < staminaCost) {
                return m.reply(`⚡ *الطاقة ʜᴀʙɪs*\n\n> Butuh ${staminaCost} stamina buat audisi.\n> طاقتك: ${user.rpg.stamina}\n> Istirahat أولاً نعم. (\`.meditation\`)`)
            }
            user.rpg.stamina -= staminaCost
            await m.reply('🎬 *sᴇᴅᴀɴɢ ᴀᴜᴅɪsɪ...*')
            await new Promise(r => setTimeout(r, 2000))

            const roll = Math.random() * 100
            let tag, rawFans, rawKoin, rawExp
            if (roll <= 10) { tag = 'jackpot'; rawFans = rand(300, 700); rawKoin = rand(1000, 2500); rawExp = rand(100, 250) }
            else if (roll <= 60) { tag = 'pass'; rawFans = rand(100, 250); rawKoin = rand(300, 900); rawExp = rand(50, 130) }
            else { tag = 'fail'; rawFans = rand(0, 20); rawKoin = 0; rawExp = rand(10, 30) }

            const result = finalizeReward(user, rawFans, rawKoin, rawExp, 'audition')
            chan.fans += result.fansGain
            if (result.koinGain > 0) db.updateKoin(m.sender, result.koinGain)
            await addExpWithLevelCheck(sock, m, db, user, result.expGain)
            bumpMissionProgress(user, 'audition')
            const unlocked = checkAchievements(user)

            db.setUser(m.sender, { rpg: user.rpg })
            db.save()

            const messages = {
                jackpot: '🌟 *TALENT SCOUT TERKESAN!* هذا فرصة besar buat أنت!',
                pass: '✅ *LOLOS AUDISI!* Kerja bagus, terus berkembang نعم.',
                fail: '😢 لم rezeki kali هذا... لكن jangan استسلم, حاول مرة أخرى lain الوقت!'
            }

            let txt = `🎬 *ᴀᴜᴅɪsɪ sᴇʟᴇsᴀɪ*\n\n${messages[tag]}\n\n`
            txt += `╭┈┈⬡「 💫 *النتيجة* 」\n`
            txt += `┃ 💫 Fans: *+${result.fansGain}*\n`
            txt += `┃ 💰 عملة: *+${result.koinGain}*\n`
            txt += `┃ 🚄 Exp: *+${result.expGain}*\n`
            txt += `┃ ⚡ Stamina: *-${staminaCost}*\n`
            txt += `╰┈┈┈┈┈┈┈┈⬡`
            if (result.eventText) txt += `\n\n📰 *ɪᴅᴏʟ ɴᴇᴡs*\n${result.eventText}`
            txt += achievementText(unlocked)
            return m.reply(txt, { contextInfo: getRpgContextInfo('🎬 chan Audition', 'Audition result') })
        }

        case 'tv': {
            const staminaCost = 20
            if (user.rpg.stamina < staminaCost) {
                return m.reply(`⚡ Butuh ${staminaCost} stamina buat syuting TV. طاقتك: ${user.rpg.stamina}`)
            }
            user.rpg.stamina -= staminaCost
            const shows = ['Talk Show', 'Variety Show', 'Music Show', 'Radio']
            const show = shows[rand(0, shows.length - 1)]
            const rawFans = rand(60, 250)
            const rawKoin = rand(150, 500)
            const rawExp = rand(30, 70)
            const result = finalizeReward(user, rawFans, rawKoin, rawExp, 'tv')
            chan.fans += result.fansGain
            if (result.koinGain > 0) db.updateKoin(m.sender, result.koinGain)
            await addExpWithLevelCheck(sock, m, db, user, result.expGain)
            const unlocked = checkAchievements(user)
            db.setUser(m.sender, { rpg: user.rpg })
            db.save()

            let txt = `📺 *ᴛᴀᴍᴘɪʟ ᴅɪ ${show.toUpperCase()}*\n\n`
            txt += `┃ 💫 Fans: *+${result.fansGain}*\n┃ 💰 عملة: *+${result.koinGain}*\n┃ 🚄 Exp: *+${result.expGain}*\n┃ ⚡ Stamina: *-${staminaCost}*`
            if (result.eventText) txt += `\n\n📰 *ɪᴅᴏʟ ɴᴇᴡs*\n${result.eventText}`
            txt += achievementText(unlocked)
            return m.reply(txt, { contextInfo: getRpgContextInfo('📺 chan TV Show', show) })
        }

        case 'photo':
        case 'photoshoot': {
            const staminaCost = 15
            if (user.rpg.stamina < staminaCost) {
                return m.reply(`⚡ Butuh ${staminaCost} stamina buat photoshoot. طاقتك: ${user.rpg.stamina}`)
            }
            user.rpg.stamina -= staminaCost
            const roll = Math.random() * 100
            let rawFans, tag
            if (roll <= 15) { tag = 'trending'; rawFans = rand(300, 500) }
            else if (roll <= 75) { tag = 'normal'; rawFans = rand(50, 110) }
            else { tag = 'تعذر'; rawFans = 0 }
            const result = finalizeReward(user, rawFans, 0, 0, 'photo')
            chan.fans += result.fansGain
            const unlocked = checkAchievements(user)
            db.setUser(m.sender, { rpg: user.rpg })
            db.save()

            const msgs = {
                trending: '📸 *TRENDING!* صورة أنت rame dibagikan!',
                normal: '😊 النتيجة الصورة bagus, fans suka~',
                gagal: '😅 Hasilnya أقل oke kali هذا... tenang, gapapa!'
            }
            let txt = `📷 *ᴘʜᴏᴛᴏsʜᴏᴏᴛ*\n\n${msgs[tag]}\n\n┃ 💫 Fans: *+${result.fansGain}*\n┃ ⚡ Stamina: *-${staminaCost}*`
            if (result.eventText) txt += `\n\n📰 *ɪᴅᴏʟ ɴᴇᴡs*\n${result.eventText}`
            txt += achievementText(unlocked)
            return m.reply(txt, { contextInfo: getRpgContextInfo('📷 chan Photoshoot', tag) })
        }

        case 'rank':
        case 'tier': {
            let txt = `🏆 *ᴛɪᴇʀ ɪᴅᴏʟ ʜᴏsʜɪɴᴏ ᴀɪ*\n\n`
            const myFans = chan.fans
            for (const t of TIERS) {
                const mark = getTier(myFans).name === t.name ? '👉' : '  '
                txt += `${mark} ${t.emoji} *${t.name}* — min ${t.min.toLocaleString()} fans\n`
            }
            txt += `\n🎪 *ʟᴏᴋᴀsɪ ᴄᴏɴᴄᴇʀᴛ*\n`
            for (const key of STAGE_ORDER) {
                const s = STAGES[key]
                txt += `${s.emoji} ${s.label} — min tier ${s.tierMin}, ${s.stamina} stamina (\`${m.prefix}idolku stage ${key}\`)\n`
            }
            return m.reply(txt)
        }

        case 'showdown':
        case 'battle': {
            const target = m.mentionedJid?.[0] || m.quoted?.sender
            if (!target) return m.reply(`❌ Tag/reply chan lain buat showdown!\n> مثال: ${m.prefix}idolku showdown @user`)
            if (target === m.sender) return m.reply('❌ لا يمكن showdown lawan diri sendiri~')

            let rival = db.getUser(target) || db.setUser(target)
            rival = ensureIdol(rival)
            const rIdol = rival.rpg.chan

            const myScore = chan.fans + (user.rpg.level || 1) * 50 +
                (chan.stats.vocal + chan.stats.dance + chan.stats.performance + chan.stats.charm) * 15 +
                chan.fans * (oshiBonus(chan, 'showdown') / 100) +
                Math.random() * 200
            const rivalScore = rIdol.fans + (rival.rpg.level || 1) * 50 +
                (rIdol.stats.vocal + rIdol.stats.dance + rIdol.stats.performance + rIdol.stats.charm) * 15 +
                rIdol.fans * (oshiBonus(rIdol, 'showdown') / 100) +
                Math.random() * 200

            const won = myScore > rivalScore
            const bonusFans = won ? rand(30, 90) : rand(0, 15)
            chan.fans += bonusFans
            if (won) { chan.showdownWins += 1; adjustLoyalty(chan, 2) } else { chan.showdownLosses += 1; adjustLoyalty(chan, -3) }
            bumpMissionProgress(user, won ? 'showdown_win' : 'showdown_loss')
            const unlocked = checkAchievements(user)

            db.setUser(m.sender, { rpg: user.rpg })
            db.save()

            let txt = `🎭 *ɪᴅᴏʟ sʜᴏᴡᴅᴏᴡɴ*\n\n`
            txt += `${user.name || 'Kamu'} 🎤 ${chan.stats.vocal}/💃${chan.stats.dance}/✨${chan.stats.performance}/😊${chan.stats.charm}\n`
            txt += `vs\n`
            txt += `${rival.name || 'Rival'} 🎤 ${rIdol.stats.vocal}/💃${rIdol.stats.dance}/✨${rIdol.stats.performance}/😊${rIdol.stats.charm}\n\n`
            txt += won
                ? `🎉 *أنت فاز!* Penonton أكثر memilih أنت ليل هذا.\n💫 Fans: *+${bonusFans}*\n💖 Loyalty +2`
                : `😢 Rival أكثر memukau kali هذا.\n💫 Fans: *+${bonusFans}* (partisipasi)\n💔 Loyalty -3`
            txt += achievementText(unlocked)
            return m.reply(txt, { contextInfo: getRpgContextInfo('🎭 chan Showdown', 'Rival battle') })
        }

        case 'song': {
            const action = (args[1] || 'list').toLowerCase()
            if (action === 'list') {
                let txt = `🎵 *ᴋᴏʟᴇᴋsɪ ʟᴀɢᴜ*\n\n`
                for (const id in SONGS) {
                    const owned = chan.songsOwned[id]
                    const stars = owned ? '★'.repeat(owned.stars) + '☆'.repeat(5 - owned.stars) : 'لم dimiliki'
                    txt += `• *${SONGS[id].name}* — ${owned ? `${stars} (bonus +${owned.stars * SONGS[id].bonusPerStar}% fans)` : stars}\n`
                }
                txt += `\n> ${m.prefix}idolku song learn <nama> — pelajari lagu جديد (gratis, 1x)\n> ${m.prefix}idolku song practice <nama> — naikkan popularitas (أحتاج 10 stamina)`
                return m.reply(txt)
            }
            if (action === 'learn' || action === 'practice') {
                const nameArg = (args.slice(2).join(' ') || args[2] || '').toLowerCase().replace(/\s+/g, '')
                const songId = Object.keys(SONGS).find(id => id === nameArg || SONGS[id].name.toLowerCase().replace(/\s+/g, '') === nameArg)
                if (!songId) return m.reply(`❌ *همم~* Lagu لا ketemu. الخيارات: ${Object.values(SONGS).map(s => s.name).join(', ')} 🥺`)
                if (action === 'learn') {
                    if (chan.songsOwned[songId]) return m.reply('❌ *همم~* Lagu هذا تم أنت pelajari~ 🥺')
                    chan.songsOwned[songId] = { stars: 1 }
                    db.setUser(m.sender, { rpg: user.rpg }); db.save()
                    return m.reply(`✅ *Yatta~* أنت mempelajari *${SONGS[songId].name}*! (★☆☆☆☆)~ ✨`)
                } else {
                    if (!chan.songsOwned[songId]) return m.reply('❌ *همم~* أنت لم mempelajari lagu هذا. استخدام `song learn` أولاً~ 🥺')
                    if (user.rpg.stamina < 10) return m.reply('⚡ Stamina لا cukup buat latihan (أحتاج 10).')
                    if (chan.songsOwned[songId].stars >= 5) return m.reply('✨ Popularitas lagu هذا تم maksimal!')
                    user.rpg.stamina -= 10
                    chan.songsOwned[songId].stars += 1
                    db.setUser(m.sender, { rpg: user.rpg }); db.save()
                    return m.reply(`🎶 Popularitas *${SONGS[songId].name}* naik jadi ★${chan.songsOwned[songId].stars}☆${5 - chan.songsOwned[songId].stars}!`)
                }
            }
            return m.reply(`> ${m.prefix}idolku song list/learn/practice`)
        }

        case 'shop':
        case 'idolshop': {
            let txt = `🛍 *ɪᴅᴏʟ المتجر*\n\n`
            for (const id in COSTUMES) {
                const c = COSTUMES[id]
                const owned = chan.costumesOwned.includes(id) ? ' ✅ dimiliki' : ''
                txt += `${c.name} — ${c.price.toLocaleString()} عملة (bonus ${c.bonusType} +${c.bonusPercent}%)${owned}\n`
            }
            txt += `\n> ${m.prefix}idolku buy <الاسم> — شراء kostum\n> ${m.prefix}idolku wear <الاسم> — استخدام kostum`
            return m.reply(txt)
        }

        case 'buy': {
            const nameArg = (args.slice(1).join(' ') || '').toLowerCase().replace(/\s+/g, '')
            const costumeId = Object.keys(COSTUMES).find(id => id === nameArg || COSTUMES[id].name.toLowerCase().replace(/[^a-z]/g, '').includes(nameArg.replace(/[^a-z]/g, '')))
            if (!costumeId) return m.reply(`❌ *همم~* Kostum لا ketemu. Cek \`${m.prefix}idolku shop\``)
            if (chan.costumesOwned.includes(costumeId)) return m.reply('❌ *همم~* Kostum ini تم أنت لديه~ 🥺')
            const c = COSTUMES[costumeId]
            if ((user.koin || 0) < c.price) return m.reply(`❌ *همم~* عملة أقل. Butuh ${c.price.toLocaleString()}, أنت لديه ${(user.koin || 0).toLocaleString()}~ 🥺`)
            db.updateKoin(m.sender, -c.price)
            chan.costumesOwned.push(costumeId)
            db.setUser(m.sender, { rpg: user.rpg }); db.save()
            return m.reply(`✅ *Yatta~* نجح شراء *${c.name}*! استخدام مع \`${m.prefix}idolku wear ${costumeId}\``)
        }

        case 'wear': {
            const nameArg = (args.slice(1).join(' ') || '').toLowerCase().replace(/\s+/g, '')
            if (!nameArg) return m.reply(`> ${m.prefix}idolku wear <nama kostum>`)
            const costumeId = Object.keys(COSTUMES).find(id => id === nameArg || COSTUMES[id].name.toLowerCase().replace(/[^a-z]/g, '').includes(nameArg.replace(/[^a-z]/g, '')))
            if (!costumeId || !chan.costumesOwned.includes(costumeId)) return m.reply('❌ *همم~* أنت لم لديه kostum itu~ 🥺')
            chan.costumeWorn = costumeId
            db.setUser(m.sender, { rpg: user.rpg }); db.save()
            return m.reply(`👗 الآن أنت memakai *${COSTUMES[costumeId].name}*!`)
        }

        case 'oshi': {
            const nameArg = (args[1] || '').toLowerCase()
            if (!nameArg) {
                let txt = `⭐ *ᴏsʜɪ sʏsᴛᴇᴍ*\n\n`
                for (const id in OSHI_LIST) {
                    const o = OSHI_LIST[id]
                    txt += `${chan.oshi === id ? '👉' : '  '} *${o.name}* — bonus ${o.buff} +${o.percent}%\n`
                }
                txt += `\n> ${m.prefix}idolku oshi <nama> — اختر oshi`
                return m.reply(txt)
            }
            if (!OSHI_LIST[nameArg]) return m.reply(`❌ *همم~* Oshi لا ketemu. الخيارات: ${Object.keys(OSHI_LIST).join(', ')} 🥺`)
            chan.oshi = nameArg
            db.setUser(m.sender, { rpg: user.rpg }); db.save()
            return m.reply(`⭐ Oshi أنت الآن: *${OSHI_LIST[nameArg].name}* (bonus ${OSHI_LIST[nameArg].buff} +${OSHI_LIST[nameArg].percent}%)`)
        }

        case 'gacha': {
            if ((user.koin || 0) < GACHA_COST) return m.reply(`❌ *همم~* عملة أقل. Gacha أحتاج ${GACHA_COST.toLocaleString()} عملة~ 🥺`)
            db.updateKoin(m.sender, -GACHA_COST)
            const roll = Math.random() * 100
            let acc = 0, picked = GACHA_POOL[0]
            for (const p of GACHA_POOL) { acc += p.chance; if (roll <= acc) { picked = p; break } }
            const reward = picked.reward()
            let rewardText = ''
            if (reward.type === 'koin') { db.updateKoin(m.sender, reward.amount); rewardText = `+${reward.amount} koin` }
            else if (reward.type === 'costume') {
                if (!chan.costumesOwned.includes(reward.id)) chan.costumesOwned.push(reward.id)
                rewardText = reward.label
            } else { rewardText = reward.label }
            db.setUser(m.sender, { rpg: user.rpg }); db.save()
            const stars = { Common: '⭐', Rare: '⭐⭐', Epic: '⭐⭐⭐', Legendary: '⭐⭐⭐⭐', Mythic: '⭐⭐⭐⭐⭐' }[picked.rarity]
            return m.reply(`🎰 *ɪᴅᴏʟ ɢᴀᴄʜᴀ*\n\n${stars} *${picked.rarity}*\n🎁 ${rewardText}`)
        }

        case 'mission': {
            const dm = ensureDailyMission(user)
            const def = DAILY_MISSION_POOL.find(m2 => m2.id === dm.id)
            if (args[1] === 'claim') {
                if (dm.claimed) return m.reply('❌ *همم~* مهمة اليوم تم diklaim~ 🥺')
                if (dm.progress < def.target) return m.reply(`❌ *همم~* لم انتهى (${dm.progress}/${def.target})~ 🥺`)
                if (def.apply) def.apply(user, db, m.sender)
                if (def.id === 'audition2') await addExpWithLevelCheck(sock, m, db, user, 100)
                dm.claimed = true
                db.setUser(m.sender, { rpg: user.rpg }); db.save()
                return m.reply(`🎉 اكتملت المهمة! Reward: ${def.rewardText}`)
            }
            let txt = `📅 *ᴅᴀɪʟʏ ᴍɪssɪᴏɴ*\n\n🎯 ${def.label}\n📊 Progress: ${dm.progress}/${def.target}\n🎁 Reward: ${def.rewardText}\n`
            txt += dm.claimed ? '\n✅ تم diklaim.' : `\n> اكتب \`${m.prefix}idolku mission claim\` إذا تم انتهى.`
            return m.reply(txt)
        }

        case 'achievement':
        case 'achv': {
            let txt = `🏅 *ᴀᴄʜɪᴇᴠᴇᴍᴇɴᴛ*\n\n`
            for (const a of ACHIEVEMENTS) {
                const done = chan.achievements.includes(a.id)
                txt += `${done ? '✅' : '⬜'} *${a.label}* — ${a.desc}\n`
            }
            return m.reply(txt)
        }

        case 'group': {
            const groupAction = (args[1] || '').toLowerCase()
            const store = getGroupStore(db)
            if (!store) return m.reply('❌ *لا، * ميزة المجموعة لم يمكن dipakai (database لم support penyimpanan bersama). Hubungi مالك البوت~ 🥺')

            if (groupAction === 'create') {
                const groupName = args.slice(2).join(' ')
                if (!groupName) return m.reply(`> ${m.prefix}idolku group create <الاسم المجموعة>`)
                if (chan.groupName) return m.reply('❌ *همم~* أنت تم tergabung في المجموعة lain. Keluar أولاً~ 🥺')
                if (store[groupName]) return m.reply('❌ *همم~* الاسم المجموعة تم dipakai~ 🥺')
                store[groupName] = { leader: m.sender, members: [m.sender], createdAt: Date.now() }
                chan.groupName = groupName
                persistGroupStore(db, store)
                db.setUser(m.sender, { rpg: user.rpg }); db.save()
                return m.reply(`✅ *Yatta~* المجموعة *${groupName}* تم الإنشاء بنجاح! أنت jadi leader~ ✨`)
            }
            if (groupAction === 'invite') {
                const target = m.mentionedJid?.[0]
                if (!target) return m.reply(`> ${m.prefix}idolku group invite @user`)
                if (!chan.groupName || !store[chan.groupName]) return m.reply('❌ *همم~* أنت لم لديه المجموعة~ 🥺')
                const g = store[chan.groupName]
                if (g.leader !== m.sender) return m.reply('❌ *همم~* Cuma leader الذي يمكن invite~ 🥺')
                if (g.members.length >= 4) return m.reply('❌ *همم~* المجموعة تم penuh (maks 4 أعضاء)~ 🥺')
                if (g.members.includes(target)) return m.reply('❌ *همم~* Orang ini تم jadi member~ 🥺')
                let targetUser = db.getUser(target) || db.setUser(target)
                targetUser = ensureIdol(targetUser)
                if (targetUser.rpg.chan.groupName) return m.reply('❌ *همم~* Orang هذا تم لديه المجموعة lain~ 🥺')
                g.members.push(target)
                targetUser.rpg.chan.groupName = chan.groupName
                persistGroupStore(db, store)
                db.setUser(target, { rpg: targetUser.rpg })
                db.save()
                return m.reply(`✅ *Yatta~* نجح invite إلى المجموعة *${chan.groupName}*~ ✨`)
            }
            if (groupAction === 'leave') {
                if (!chan.groupName || !store[chan.groupName]) return m.reply('❌ *همم~* أنت لا tergabung في المجموعة manapun~ 🥺')
                const g = store[chan.groupName]
                g.members = g.members.filter(id => id !== m.sender)
                if (g.leader === m.sender) {
                    if (g.members.length > 0) g.leader = g.members[0]
                    else delete store[chan.groupName]
                }
                chan.groupName = null
                persistGroupStore(db, store)
                db.setUser(m.sender, { rpg: user.rpg }); db.save()
                return m.reply('✅ *Yatta~* أنت keluar من المجموعة~ ✨')
            }
            // default: info
            if (!chan.groupName || !store[chan.groupName]) {
                return m.reply(`👥 أنت لم لديه المجموعة.\n\n> ${m.prefix}idolku group create <الاسم>\n> ${m.prefix}idolku group invite @user\n> ${m.prefix}idolku group leave`)
            }
            const g = store[chan.groupName]
            let totalFans = 0
            for (const memberId of g.members) {
                const mu = ensureIdol(db.getUser(memberId) || db.setUser(memberId))
                totalFans += mu.rpg.chan.fans
            }
            let txt = `👥 *المجموعة: ${chan.groupName}*\n\n`
            txt += `👑 Leader: @${g.leader.split('@')[0]}\n`
            txt += `👤 Member (${g.members.length}/4): ${g.members.map(id => '@' + id.split('@')[0]).join(', ')}\n`
            txt += `💫 Total Fans المجموعة: *${totalFans.toLocaleString()}*`
            return m.reply(txt, { mentions: [g.leader, ...g.members] })
        }

        case 'top':
        case 'idoltop': {
            const allUsers = getAllUsers(db)
            if (!allUsers) return m.reply('❌ *همم~* Ranking global لم يمكن ditampilkan (database لم expose القائمة كل user)~ 🥺')
            const ranked = allUsers
                .filter(u => u.rpg?.chan?.fans)
                .sort((a, b) => b.rpg.chan.fans - a.rpg.chan.fans)
                .slice(0, 10)
            if (!ranked.length) return m.reply('لم يوجد data ranking.')
            let txt = `🏆 *ᴛᴏᴘ ɪᴅᴏʟ*\n\n`
            ranked.forEach((u, i) => {
                txt += `${i + 1}. ${u.name || 'Unknown'} — ${u.rpg.chan.fans.toLocaleString()} fans\n`
            })
            return m.reply(txt)
        }

        case 'help':
        default: {
            let txt = `🎤 *ʜᴏsʜɪɴᴏ ᴀɪ ⋆ ɪᴅᴏʟ ʀᴘɢ*\n\n`
            txt += `╭┈┈⬡「 📋 *الأمر* 」\n`
            txt += `┃ ${m.prefix}idolku profile — cek profil chan\n`
            txt += `┃ ${m.prefix}idolku stage <lokasi> — manggung (school/mall/city/dome/worldtour)\n`
            txt += `┃ ${m.prefix}idolku audition — audisi high risk high reward\n`
            txt += `┃ ${m.prefix}idolku tv — syuting acara TV\n`
            txt += `┃ ${m.prefix}idolku photo — photoshoot\n`
            txt += `┃ ${m.prefix}idolku rank — lihat tier & lokasi concert\n`
            txt += `┃ ${m.prefix}idolku showdown @user — battle rival chan\n`
            txt += `┃ ${m.prefix}idolku song list/learn/practice — koleksi lagu\n`
            txt += `┃ ${m.prefix}idolku shop — lihat toko kostum\n`
            txt += `┃ ${m.prefix}idolku buy/wear <kostum> — شراء/استخدام kostum\n`
            txt += `┃ ${m.prefix}idolku oshi <nama> — اختر oshi favorit\n`
            txt += `┃ ${m.prefix}idolku gacha — gacha عنصر (5000 عملة)\n`
            txt += `┃ ${m.prefix}idolku mission — daily mission\n`
            txt += `┃ ${m.prefix}idolku achievement — daftar achievement\n`
            txt += `┃ ${m.prefix}idolku group create/invite/leave — chan group\n`
            txt += `┃ ${m.prefix}idolku top — ranking global\n`
            txt += `╰┈┈┈┈┈┈┈┈⬡\n\n`
            txt += `> ميزة هذا numpang في النظام الخبرة/عملة/stamina RPG أنت الذي سابق, لا إنشاء resource جديد.`
            return m.reply(txt)
        }
    }
}

module.exports = {
    config: pluginConfig,
    handler,
    // Diekspor supaya plugin lain (misal autoaiHandler.js) bisa baca info tier
    // chan tanpa duplikasi logic. Menambah export baru, TIDAK mengubah export
    // yang sudah ada (config/handler).
    getTier,
    TIERS
}