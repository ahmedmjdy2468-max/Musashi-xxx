const { getDatabase } = require('../../src/lib/database')

const pluginConfig = {
    name: 'unmute',
    alias: ['unbisukan'],
    category: 'group',
    description: "يلغي كتم المجموعة ويسمح للأعضاء بإرسال الرسائل.",
    usage: ".إلغاء_الكتم",
    example: "",
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    isAdmin: true,
    isBotAdmin: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const db = getDatabase()
    const group = db.getGroup(m.chat) || {}
    const groupName = m.groupMetadata.subject

    if (!group.mute) return m.reply('❌ *همم~* المجموعة لا جارٍ في-mute~ 🥺')

    db.setGroup(m.chat, { ...group, mute: false })
    m.reply(`✅ المجموعة *${groupName}* تم تم إلغاء كتمه بواسطة @${m.sender.split('@')[0]}\n\nSemua عضو الآن يمكن إرسال رسالة.`, { mentions: [m.sender] })
}

module.exports = {
    config: pluginConfig,
    handler
}
