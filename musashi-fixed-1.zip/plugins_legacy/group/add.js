const pluginConfig = {
    name: 'add',
    alias: ['addmember', 'invite'],
    category: 'group',
    description: 'Menambahkan عضو إلى المجموعة (support multiple)',
    usage: '.add <nomor1> [nomor2] [nomor3]... [الرابط_المجموعة]',
    example: '.add 6281234567890 6281234567890',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 0,
    isEnabled: true,
    isAdmin: true,
    isBotAdmin: true
}

async function handler(m, { sock }) {
    const args = m.args || []
    
    if (args.length === 0) {
        return m.reply(
            `👥 *ᴀᴅᴅ عضو*\n\n` +
            `> طريقة الاستخدام:\n` +
            `> 1. في المجموعة: \`${m.prefix}add <الرقم>\`\n` +
            `> 2. Multiple: \`${m.prefix}add <nomor1> <nomor2> ...\`\n` +
            `> 3. Di private: \`${m.prefix}add <nomor> <الرابط_المجموعة>\`\n\n` +
            `> مثال:\n` +
            `> \`${m.prefix}add 6281234567890\`\n` +
            `> \`${m.prefix}add 628123 628456 628789\`\n` +
            `> \`${m.prefix}add 628123 https://chat.whatsapp.com/xxx\`\n\n` +
            `> Syarat:\n` +
            `> - يجب أن يكون البوت مشرفاً في المجموعة المستهدفة\n` +
            `> - يجب أن يكون منفذ الأمر مشرفاً`
        )
    }
    
    let targetGroup = m.isGroup ? m.chat : null
    let targetNumbers = []
    
    for (const arg of args) {
        const linkMatch = arg.match(/chat\.whatsapp\.com\/([a-zA-Z0-9]+)/)
        if (linkMatch) {
            try {
                const groupInfo = await sock.groupGetInviteInfo(linkMatch[1])
                targetGroup = groupInfo.id
            } catch (e) {
                return m.reply(`❌ *عذراً* ✦\n\n> رابط المجموعة غير صالح أو تم expired~ 🥺`)
            }
        } else if (arg.includes('@g.us')) {
            targetGroup = arg
        } else {
            let num = arg.replace(/[^0-9]/g, '')
            if (num.startsWith('0')) {
                num = '62' + num.slice(1)
            }
            if (num.length >= 10) {
                targetNumbers.push(num)
            }
        }
    }
    
    if (targetNumbers.length === 0) {
        return m.reply(`❌ *عذراً* ✦\n\n> أدخل رقماً صالحاً.~ 🥺`)
    }
    
    if (!targetGroup) {
        return m.reply(`❌ *فشل*\n\n> Jalankan في المجموعة أو sertakan رابط المجموعة!\n\n\`${m.prefix}add <الرقم> <الرابط_المجموعة>\``)
    }
    
    try {
        const groupMeta = await sock.groupMetadata(targetGroup)
        const botId = sock.user?.id?.split(':')[0] + '@s.whatsapp.net'
        const botParticipant = groupMeta.participants.find(p => 
            p.id === botId || p.jid === botId || p.id?.includes(sock.user?.id?.split(':')[0])
        )
        
        if (!botParticipant || !['مشرف', 'superadmin'].includes(botParticipant.admin)) {
            return m.reply(`❌ *عذراً* ✦\n\n> البوت ليس مشرفاً في المجموعة *${groupMeta.subject}*~ 🥺`)
        }
        
        if (!m.isGroup) {
            const senderId = m.sender?.split('@')[0]
            const senderParticipant = groupMeta.participants.find(p => 
                p.id?.includes(senderId) || p.jid?.includes(senderId)
            )
            
            if (!senderParticipant || !['مشرف', 'superadmin'].includes(senderParticipant.admin)) {
                return m.reply(`❌ *عذراً* ✦\n\n> أنت لست مشرفاً في المجموعة *${groupMeta.subject}*~ 🥺`)
            }
        }
        
        const validNumbers = []
        const alreadyInGroup = []
        
        for (const num of targetNumbers) {
            const existingMember = groupMeta.participants.find(p => 
                p.id?.includes(num) || p.jid?.includes(num)
            )
            
            if (existingMember) {
                alreadyInGroup.push(num)
            } else {
                validNumbers.push(num + '@s.whatsapp.net')
            }
        }
        
        if (validNumbers.length === 0) {
            return m.reply(`❌ *عذراً* ✦\n\n> كل الرقم تم يوجد في المجموعة~ 🥺`)
        }
        
        m.react('🕕')
        
        const results = await sock.groupParticipantsUpdate(targetGroup, validNumbers, 'add')
        
        let successList = []
        let invitedList = []
        let failedList = []
        
        for (const res of results) {
            const num = res.content?.attrs?.phone_number?.replace('@s.whatsapp.net', '') || ''
            
            if (res.status === '200') {
                successList.push(num)
            } else if (res.status === '408') {
                invitedList.push(num)
            } else {
                failedList.push({ num, status: res.status })
            }
        }
        
        let resultText = `🥗 @${m.sender.split('@')[0]} قد menambahkan عضو إلى المجموعة\n\n`
        
        if (successList.length > 0) {
            resultText += `Ada *${successList.length}* عضو الذي تمت الإضافة بنجاح:\n`
            successList.forEach(n => resultText += `• @${n}\n`)
            resultText += `\n`
        }
        
        if (invitedList.length > 0) {
            resultText += `📨 *و يوجد أيضاً *${invitedList.length}* عضو الذي diundang:*\n`
            invitedList.forEach(n => resultText += `• @${n}\n`)
            resultText += `\n`
        }
        
        if (failedList.length > 0) {
            resultText += `❌ *فشل (${failedList.length}):*\n`
            failedList.forEach(f => resultText += `• @${f.num} (${f.status})\n`)
            resultText += `\n`
        }
        
        if (alreadyInGroup.length > 0) {
            resultText += `⏭️ *sᴜᴅᴀʜ ᴅɪ المجموعة (${alreadyInGroup.length}):*\n`
            alreadyInGroup.forEach(n => resultText += `• @${n}\n`)
        }
        
        m.react(successList.length > 0 || invitedList.length > 0 ? '✅' : '❌')
        await m.reply(resultText, { mentions: [ ...successList.map(n => n + '@s.whatsapp.net'), ...invitedList.map(n => n + '@s.whatsapp.net'), ...failedList.map(f => f.num + '@s.whatsapp.net'), ...alreadyInGroup.map(n => n + '@s.whatsapp.net'), m.sender ] })
        
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/group/add.js] exception", error?.stack || error);
        m.react('❌')
        
        if (error.message?.includes('not-authorized')) {
            await m.reply(`❌ *عذراً* ✦\n\n> البوت لا memiliki izin لـ menambah عضو~ 🥺`)
        } else if (error.message?.includes('forbidden')) {
            await m.reply(`❌ *عذراً* ✦\n\n> البوت لا memiliki akses إلى المجموعة هذا~ 🥺`)
        } else {
            await m.reply("حدث خطأ، حاول لاحقاً")
        }
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
