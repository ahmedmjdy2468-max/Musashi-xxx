const config = require('../../config')

const pluginConfig = {
    name: 'acc',
    alias: ['accall', 'joinrequest', 'reqjoin'],
    category: 'group',
    description: 'يعرض طلبات الانضمام المعلّقة ويقبلها أو يرفضها.',
    usage: '.طلبات_الانضمام <قائمة|قبول|رفض> [الكل|رقم]',
    example: '.طلبات_الانضمام قبول الكل',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    isAdmin: true,
    isBotAdmin: true,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

function formatDate(timestamp) {
    return new Intl.DateTimeFormat('ar', {
        weekday: 'long',
        day: 'numeric',
        month: 'long',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    }).format(new Date(timestamp * 1000))
}

async function handler(m, { sock }) {
    const args = m.args || []
    const requestedSub = args[0]?.toLowerCase()
    const sub = ({ 'قائمة': 'list', 'قبول': 'approve', 'رفض': 'reject' })[requestedSub] || requestedSub
    const requestedOption = args.slice(1).join(' ')?.trim()
    const option = requestedOption === 'الكل' ? 'all' : requestedOption
    const subLabel = ({ list: 'قائمة', approve: 'قبول', reject: 'رفض' })[sub] || 'قائمة'

    if (!sub || !['list', 'approve', 'reject'].includes(sub)) {
        return m.reply(
            `📋 *إدارة طلبات الانضمام*\n\n` +
            `╭┈┈⬡「 📌 *الأمر* 」\n` +
            `┃ ${m.prefix}طلبات_الانضمام قائمة\n` +
            `┃ ${m.prefix}طلبات_الانضمام قبول الكل\n` +
            `┃ ${m.prefix}طلبات_الانضمام رفض الكل\n` +
            `┃ ${m.prefix}طلبات_الانضمام قبول 1|2|3\n` +
            `┃ ${m.prefix}طلبات_الانضمام رفض 1|2|3\n` +
            `╰┈┈┈┈┈┈┈┈⬡`
        )
    }

    await m.react('🕕')

    try {
        const pendingList = await sock.groupRequestParticipantsList(m.chat)

        if (!pendingList?.length) {
            await m.react('📭')
            return m.reply(`📭 لا توجد طلبات انضمام معلّقة.`)
        }

        if (sub === 'list') {
            let text = `📋 *طلبات الانضمام المعلّقة*\n\n`
            text += `> العدد: ${pendingList.length} طلباً\n\n`

            for (let i = 0; i < pendingList.length; i++) {
                const req = pendingList[i]
                const number = req.jid?.split('@')[0] || 'Unknown'
                const method = req.request_method || '-'
                const time = req.request_time ? formatDate(req.request_time) : '-'

                text += `*${i + 1}.* @${number}\n`
                text += `   📱 ${number}\n`
                text += `   📨 ${method}\n`
                text += `   🕐 ${time}\n\n`
            }

            text += `> استخدم \`${m.prefix}طلبات_الانضمام قبول الكل\` أو \`${m.prefix}طلبات_الانضمام رفض الكل\``

            const mentions = pendingList.map(r => r.jid)
            await m.react('📋')
            return m.reply(text, { mentions })
        }

        const action = sub

        if (option === 'all') {
            const jids = pendingList.map(r => r.jid)

            const results = await sock.groupRequestParticipantsUpdate(m.chat, jids, action)

            const success = results.filter(r => r.status === '200' || !r.status || r.status === 200).length
            const failed = results.length - success

            const label = action === 'approve' ? 'مقبولة' : 'مرفوضة'
            await m.react('✅')
            return m.reply(
                `✅ *${label.toUpperCase()} كل*\n\n` +
                `> ✅ نجح: ${success}\n` +
                `> ❌ فشل: ${failed}\n` +
                `> 📊 الإجمالي: ${results.length}`
            )
        }

        const indices = option.split('|').map(n => parseInt(n.trim()) - 1).filter(n => !isNaN(n) && n >= 0 && n < pendingList.length)

        if (!indices.length) {
            await m.react('❌')
            return m.reply(
                `❌ الرقم غير صالح..\n\n` +
                `> استخدم \`${m.prefix}طلبات_الانضمام قائمة\` لعرض القائمة.\n` +
                `> مثال: \`${m.prefix}طلبات_الانضمام ${subLabel} 1|2|3\``
            )
        }

        const targets = indices.map(i => pendingList[i])
        let text = ''
        const label = action === 'approve' ? 'مقبول' : 'مرفوض'
        let successCount = 0

        for (const target of targets) {
            try {
                const result = await sock.groupRequestParticipantsUpdate(m.chat, [target.jid], action)
                const status = result[0]?.status
                const ok = status === '200' || !status || status === 200

                const number = target.jid.split('@')[0]
                text += `${ok ? '✅' : '❌'} ${number} — ${ok ? label : 'فشل تنفيذ العملية.'}\n`
                if (ok) successCount++
            } catch {
                const number = target.jid.split('@')[0]
                text += `❌ ${number} — تعذّر تنفيذ العملية.\n`
            }
        }

        await m.react('✅')
        return m.reply(
            `📋 *النتيجة ${label.toUpperCase()}*\n\n` +
            text + `\n` +
            `> ✅ نجح ${successCount} من أصل ${targets.length}`
        )
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/group/acc.js] exception", error?.stack || error);
        await m.react('❌')
        return m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
