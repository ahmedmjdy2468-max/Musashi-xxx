const config = require('../../config')

const pluginConfig = {
    name: 'cekabsen',
    alias: ['listabsen', 'daftarabsen', 'lihathadir'],
    category: 'group',
    description: 'يعرض أسماء الأعضاء المسجلين في الحضور ووقت بدء التسجيل؛ للمجموعات فقط.',
    usage: '.قائمة_الحضور',
    example: '.قائمة_الحضور',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

if (!global.absensi) global.absensi = {}

async function handler(m, { sock }) {
    const chatId = m.chat

    if (!global.absensi[chatId]) {
        return m.reply(
`╭━━━〔 📋 سجل الحضور 〕━━━⬣
┃ ❌ لا يوجد تسجيل حضور جارٍ.
┃
┃ 💬 اطلب من مشرف بدء تسجيل الحضور.
┃ ✨ استخدم:
┃ ➤ *.بدء_الحضور [الملاحظة]*
╰━━━━━━━━━━━━━━━━⬣`
        )
    }

    const absen = global.absensi[chatId]

    if (!absen.data) absen.data = {}
    if (!absen.peserta) absen.peserta = []

    const moment = require('moment-timezone')
    const now = moment().tz('Asia/Jakarta')

    const dateStr = now.format('dddd, D MMMM YYYY')
    const createdDate = moment(absen.createdAt).tz('Asia/Jakarta')
    const timeStr = createdDate.format('HH:mm:ss')

    // 🔥 LIST PESERTA FULL NAMA WA
    let list = '┃ لا يوجد أعضاء مسجلون حتى الآن.'

    if (absen.peserta.length > 0) {
        const arr = await Promise.all(absen.peserta.map(async (jid, i) => {
            let name = absen.data?.[jid]

            if (!name) {
                try {
                    name = await sock.getName(jid)
                } catch {
                    name = jid.split('@')[0]
                }
            }

            return `┃ ${i + 1}. ${name}`
        }))

        list = arr.join('\n')
    }

    // 🔥 CREATOR NAME FIX
    let creatorName = absen.data?.[absen.createdBy]

    if (!creatorName) {
        try {
            creatorName = await sock.getName(absen.createdBy)
        } catch {
            creatorName = 'المشرف'
        }
    }

    await m.reply(
`╭━━━〔 📋 سجل الحضور 〕━━━⬣
┃ 📋 *قائمة الحضور*
┃
┃ 💖 *الهدف:* ${absen.keterangan}
┃
┣━━━〔 📊 المعلومات 〕━━━⬣
┃ 📅 ${dateStr}
┃ ⏰ وقت البدء: ${timeStr}
┃ 👑 أنشأه: ${creatorName}
┃ 👥 إجمالي الحضور: ${absen.peserta.length} أعضاء
┃
┣━━━〔 📝 المشاركون 〕━━━⬣
${list}
┃
╰━━━〔 🌟 ملاحظة 〕━━━⬣
> ✨ اكتب *${m.prefix}الحضور* لتسجيل حضورك
`
    )
}

module.exports = {
    config: pluginConfig,
    handler
}
