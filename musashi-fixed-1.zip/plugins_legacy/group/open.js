const pluginConfig = {
    name: 'open',
    alias: ['buka', 'opengroup', 'bukagroup'],
    category: 'group',
    description: 'يفتح المجموعة لتتمكن جميع العضوات والأعضاء من إرسال الرسائل.',
    usage: '.فتح_المجموعة',
    example: '.فتح_المجموعة',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 10,
    energi: 0,
    isEnabled: true,
    isAdmin: true,
    isBotAdmin: true
};

async function handler(m, { sock }) {
    try {
        const groupMeta = m.groupMetadata;
        
        if (!groupMeta.announce) {
            await m.reply(
                `⚠️ المجموعة مفتوحة بالفعل.\n\n` +
                `> يمكن لجميع الأعضاء إرسال الرسائل.`
            );
            return;
        }
        
        await sock.groupSettingUpdate(m.chat, 'not_announcement');
        
        const senderNum = m.sender.split('@')[0];
        
        const successMsg = `✅ @${senderNum} فتح المجموعة.\n_يمكن للأعضاء الآن إرسال الرسائل._`;
        
        await m.reply(successMsg, { mentions: [m.sender] });
        
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/group/open.js] exception", error?.stack || error);
        await m.reply(
            "حدث خطأ، حاول لاحقاً"
        );
    }
}

module.exports = {
    config: pluginConfig,
    handler
};
