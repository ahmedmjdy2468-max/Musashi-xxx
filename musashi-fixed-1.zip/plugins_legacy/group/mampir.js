const { findParticipantByNumber } = require('../../src/lib/lidHelper')

const pluginConfig = {
    name: 'mampir',
    alias: ['dateng', 'sayhi'],
    category: 'group',
    description: '🌸 MUSASHI Style - Ajak كل عضو mampir إلى مقطع جديد! (المشرف Only, tag مشرف pengirim)',
    usage: '.mampir <الرابط VT TikTok>',
    example: '.mampir https://vt.tiktok.com/ZSHPuRJLD/',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 10,
    isEnabled: true,
    isAdmin: true,      // ✅ Hanya admin yang bisa pakai
    isBotAdmin: true    // ✅ Bot harus admin untuk mention semua
}

async function handler(m, { sock }) {
    try {
        if (!m.isGroup) return

        // Gunakan pengecekan dari hasil serialize Handler.js
        if (!m.isBotAdmin) return m.reply('⚠️ *Eh eh~* البوت يجب jadi مشرف لـ يمكن mention كل 😝~ 🌸')
        
        // Pengecekan admin pengirim
        if (!m.isAdmin && !m.isOwner) return m.reply('⚠️ Hehe~ cuma مشرف الذي boleh استخدام هذا 😘')

        const link = m.args?.[0]
        if (!link || !link.includes('vt.tiktok.com')) {
            return m.reply('💡 استخدم رابط VT TikTok الذي صحيح نعم~\n✨ مثال: .mampir https://vt.tiktok.com/ZSHPuRJLD/')
        }

        const groupMeta = await sock.groupMetadata(m.chat)
        const mentions = groupMeta.participants.map(u => u.id)
                // Tag admin pengirim
        const adminTag = `@${m.sender.split('@')[0]}`

        // 20+ pesan random MUSASHI style
        const messages = [
            `🌸 Hehe~ Senpai & teman-teman! Yuk mampir lihat مقطع جديد هذا 😘\n${link}\n💌 من مشرف ${adminTag}`,
            `🎀 Oho~ كل! Ada VT fresh هنا, jangan حتى ketinggalan 💖\n${link}\n💌 من مشرف ${adminTag}`,
            `💫 مرحباً جميعاً، يدعوكم موساشي لمشاهدة المقطع الجديد مقطع جديد هنا 🌟\n${link}\n💌 dari مشرف ${adminTag}`,
            `🌟 UwU~ مقطع جديد تم siap! Yuk mampir و senyum معاً 😝\n${link}\n💌 من مشرف ${adminTag}`,
            `💖 مرحباً مرحباً~ Jangan حتى kelewatan VT seru هذا! Hehe 🌸\n${link}\n💌 من مشرف ${adminTag}`,
            `✨ Wahai senpai & teman-teman! مقطع جديد تم tayang, mampir yuk 💕\n${link}\n💌 من مشرف ${adminTag}`,
            `🌈 هناك مقطع جديد الذي lucu جداً هنا, لا تفوتوه! 😘\n${link}\n💌 من مشرف ${adminTag}`,
            `🎀 Omo~ VT fresh من مشرف, siap-siap gemes نعم! 🌸\n${link}\n💌 من مشرف ${adminTag}`,
            `💫 Yuk كل~ MUSASHI ngajak mampir مقطع جديد! 🌟\n${link}\n💌 من مشرف ${adminTag}`,
            `🌟 UwU~ Jangan sampai kelewatan مقطع جديد الذي imut ini 💖\n${link}\n💌 dari مشرف ${adminTag}`,
            `💖 مرحباً الجميع~ هناك مقطع جديد! Senyum أولاً deh 😝\n${link}\n💌 من مشرف ${adminTag}`,
            `🌸 Hehe~ Senpai, مقطع جديد تم hadir! Yuk mampir 💕\n${link}\n💌 من مشرف ${adminTag}`,
            `🎀 Oho~ مقطع جديد siap membuat يوم أنتم أكثر ceria! 😘\n${link}\n💌 من مشرف ${adminTag}`,
            `💫 Halo كل~ Jangan sampai VT ini terlewat نعم 🌟\n${link}\n💌 dari مشرف ${adminTag}`,
            `🌟 UwU~ MUSASHI ngajak كل mampir مقطع جديد 💖\n${link}\n💌 dari مشرف ${adminTag}`,
            `💖 مرحباً senpai & teman-teman~ Ada VT lucu جديد هنا! Hehe 🌸\n${link}\n💌 من مشرف ${adminTag}`,
            `✨ Yuk mampir! مقطع جديد siap إنشاء senyum أنتم lebar 😝\n${link}\n💌 من مشرف ${adminTag}`,
            `🌈 Oho~ Jangan تنسَ mampir lihat VT terbaru! Hehe 💕\n${link}\n💌 من مشرف ${adminTag}`,
            `🎀 Hehe~ VT fresh من مشرف تم online! Yuk cek معاً 🌟\n${link}\n💌 من مشرف ${adminTag}`,
            `💫 مرحباً كل! MUSASHI ngajak mampir مقطع جديد الذي gemesin 😘\n${link}\n💌 من مشرف ${adminTag}`,
            `🌟 UwU~ Senpai jangan sampai ketinggalan VT lucu ini 💖\n${link}\n💌 dari مشرف ${adminTag}`,
            `💖 Hehe~ Yuk mampir, يوجد مقطع جديد الذي super imut هنا! 🌸\n${link}\n💌 من مشرف ${adminTag}`,
            `✨ Hai كل~ لا تفوتوا مقطع جديد الذي seru جداً 😝\n${link}\n💌 dari مشرف ${adminTag}`
        ]

        const randMsg = messages[Math.floor(Math.random() * messages.length)]

         // Tambahkan pengirim ke dalam daftar mention agar tag-nya biru/aktif
        if (!mentions.includes(m.sender)) {
            mentions.push(m.sender)
        }

        // Kirim pesan dengan mentions yang sudah digabung (semua member + pengirim)
        await sock.sendMessage(m.chat, { 
            text: randMsg, 
            mentions: mentions 
        }, { quoted: m })

    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/group/mampir.js] exception", error?.stack || error);
        await m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}