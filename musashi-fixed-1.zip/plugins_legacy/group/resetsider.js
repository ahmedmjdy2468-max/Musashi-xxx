const fs = require('fs')
const path = require('path')

// ===== CONFIG =====
const pluginConfig = {
    name: 'resetsider',
    alias: ['resetsiders', 'startsider', 'mulaisider'],
    category: 'group',
    description: 'يعيد بدء فترة رصد النشاط لمدة سبعة أيام في المجموعة؛ للمشرفين.',
    usage: '.إعادة_فترة_رصد_النشاط',
    cooldown: 10,
    energi: 2,
    isGroup: true,
    isAdmin: true
}

// ===== HANDLER =====
async function handler(m, { sock }) {
    try {
        const jidGrup = m.chat
        const metaGrup = await sock.groupMetadata(jidGrup)
        const namaGrup = metaGrup.subject

        // SIMPAN KE DATABASE
        const DB_PATH = path.join(__dirname, '../../database/other/sider.json')
        let db = {}
        if (fs.existsSync(DB_PATH)) db = JSON.parse(fs.readFileSync(DB_PATH))
        
        db[jidGrup] = {
            groupName: namaGrup,
            startDate: new Date().toISOString(),
            activeUsers: []
        }

        fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2))
        
        // FORMAT PESAN STYLE ITSUKI AI
        let reply = `╭───〔 ✨ *موساشي* 〕───⬡
┃ 🚀 *إعادة ضبط فترة النشاط*
┃
┃ 📛 المجموعة: *${namaGrup}*
┃ ⏱️ مدة الرصد: *7 أيام / 168 ساعة*
┃
┃ ✅ بدأت فترة الرصد الجديدة.
┃ اعرض النتيجة باستخدام *.غير_النشطين*.
┗━━━━━━━━━━━━━━━━━━━━━━━━━⬡

╭───〔 💫 *رصد النشاط* 〕───⬡
┃ ستُحتسب المشاركات خلال الأيام السبعة القادمة.
╰───────────────────────────────⬡`
        
        return m.reply(reply)
        
    } catch (err) {
        console.error('[RESETSIDER ERROR]', err)
        return m.reply('❌ تعذرت إعادة ضبط فترة النشاط.')
    }
}

// ===== EXPORT =====
module.exports = {
    config: pluginConfig,
    handler
}
