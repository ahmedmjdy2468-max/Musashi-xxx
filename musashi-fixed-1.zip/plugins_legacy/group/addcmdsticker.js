const { getQuotedStickerHash, addStickerCommand, listStickerCommands } = require('../../src/lib/stickerCommand')
const { getPlugin } = require('../../src/lib/plugins')

const pluginConfig = {
    name: 'addcmdsticker',
    alias: ['addstickercmd', 'setsticker', 'stickeradd'],
    category: 'group',
    description: 'Jadikan sticker sebagai shortcut الأمر',
    usage: '.addcmdsticker <الأمر> (reply sticker)',
    example: '.addcmdsticker menu',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    isAdmin: false,
    cooldown: 10,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const args = m.args || []
    const commandName = args[0]
    
    // Validasi command name
    if (!commandName) {
        const existingCmds = listStickerCommands()
        
        let txt = `🖼️ *ملصق ᴛᴏ الأمر*\n\n`
        txt += `> ردّ على ملصق + اكتب الأمر الذي يريد dijadikan shortcut.\n\n`
        txt += `*مثال:*\n`
        txt += `> ردّ على ملصق, lalu ketik:\n`
        txt += `> \`.addcmdsticker menu\`\n\n`
        
        if (existingCmds.length > 0) {
            txt += `╭┈┈⬡「 📋 *ᴀᴋᴛɪꜰ* 」\n`
            for (const cmd of existingCmds.slice(0, 10)) {
                txt += `┃ 🖼️ → \`${cmd.command}\`\n`
            }
            if (existingCmds.length > 10) {
                txt += `┃ ... و ${existingCmds.length - 10} lainnya\n`
            }
            txt += `╰┈┈┈┈┈┈┈┈⬡`
        }
        
        return m.reply(txt)
    }
    
    // Validasi reply sticker
    if (!m.quoted) {
        return m.reply('⚠️ *ردّ على ملصق* الذي يريد dijadikan الأمر!')
    }
    
    const stickerHash = getQuotedStickerHash(m)
    if (!stickerHash) {
        return m.reply('⚠️ *Eh eh~* الرسالة الذي في-ردّ على ليس *sticker*~ 🌸')
    }
    
    // Validasi command exists
    const cleanCmd = commandName.toLowerCase().replace(/^\./, '')
    const plugin = getPlugin(cleanCmd)
    
    if (!plugin) {
        return m.reply(
            `❌ الأمر \`${cleanCmd}\` غير موجود!\n\n` +
            `> Pastikan الأمر الذي يريد dijadikan shortcut صحيح.`
        )
    }
    
    // Add sticker command
    const success = addStickerCommand(stickerHash, cleanCmd, m.sender)
    
    if (success) {
        await m.react('✅')
        await m.reply(
            `✅ *ملصق الأمر ᴅɪᴛᴀᴍʙᴀʜᴋᴀɴ*\n\n` +
            `> 🖼️ Sticker → \`.${cleanCmd}\`\n\n` +
            `_أرسل sticker tersebut لـ menjalankan الأمر!_`
        )
    } else {
        await m.reply('❌ *عذراً* فشل menyimpan sticker الأمر~ 🥺')
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
