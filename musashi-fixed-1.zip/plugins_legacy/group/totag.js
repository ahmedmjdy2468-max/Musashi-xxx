const config = require('../../config')

const pluginConfig = {
    name: 'totag',
    alias: ['tagall2', 'mentionall'],
    category: 'group',
    description: 'يعيد توجيه الرسالة التي ترد عليها إلى المجموعة مع الإشارة إلى أعضائها؛ للمشرفين.',
    usage: '.تنبيه_الجميع (بالرد على رسالة)',
    example: '.تنبيه_الجميع',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 30,
    energi: 0,
    isEnabled: true,
    isAdmin: true,
    isBotAdmin: true
}

async function handler(m, { sock }) {
    if (!m.quoted) {
        return m.reply(
            `📢 *تنبيه الجميع*\n\n` +
            `> ردّ على الرسالة التي تريد إعادة توجيهها إلى أعضاء المجموعة، ثم اكتب الأمر.`
        )
    }
    
    m.react('📢')
    
    try {
        const participants = m.groupMembers || []
        
        if (!participants || participants.length === 0) {
            return m.reply(`❌ تعذّر الحصول على قائمة أعضاء المجموعة.`)
        }
        
        const users = participants
            .map(u => u.id || u.jid || u)
            .filter(v => v && v !== sock.user?.jid && v !== sock.user?.id)
        
        await sock.sendMessage(m.chat, {
            forward: m.quoted.fakeObj || m.quoted,
            mentions: users
        })
        
        m.react('✅')
        
    } catch (err) {
        console.error("[MUSASHI][plugins_legacy/group/totag.js] exception", err?.stack || err);
        m.react('❌')
        m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
