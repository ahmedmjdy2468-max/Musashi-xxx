const { getDatabase } = require('../../src/lib/database')
const { getParticipantJid } = require('../../src/lib/lidHelper')

const pluginConfig = {
    name: "",
    alias: ['warning', 'peringatan'],
    category: 'group',
    description: 'Memberi peringatan kepada member',
    usage: '.warn @user <alasan>',
    example: '.warn @user spam',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    isAdmin: true,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

const HISTORY_TTL_MS = 90 * 24 * 60 * 60 * 1000 // 90 hari, ubah kalau mau beda

// ---------- Helpers: durasi ----------
function parseDuration(str) {
    if (!str) return null
    const regex = /(\d+)\s*(y|mo|w|d|h|m|s)/gi
    const unitMs = { y: 31536000000, mo: 2592000000, w: 604800000, d: 86400000, h: 3600000, m: 60000, s: 1000 }
    let total = 0
    let matched = false
    let match
    while ((match = regex.exec(str)) !== null) {
        matched = true
        total += parseInt(match[1]) * unitMs[match[2].toLowerCase()]
    }
    return matched ? total : null
}

function formatDuration(ms) {
    const units = [['tahun', 31536000000], ['bulan', 2592000000], ['minggu', 604800000], ['hari', 86400000], ['jam', 3600000], ['menit', 60000], ['ثانية', 1000]]
    for (const [label, unitMs] of units) {
        if (ms >= unitMs) return `${Math.round(ms / unitMs)} ${label}`
    }
    return `${ms} ms`
}

// ---------- Helpers: warning aktif (lazy expiry, restart-proof) ----------
function getActiveWarnings(list) {
    if (!list) return []
    const now = Date.now()
    return list.filter(w => !w.expireAt || w.expireAt > now)
}

function cleanExpiredUserWarnings(groupData, targetUser) {
    const warnings = groupData.warnings || {}
    const list = warnings[targetUser]
    if (!list) return false
    const active = getActiveWarnings(list)
    if (active.length === list.length) return false
    if (active.length === 0) delete warnings[targetUser]
    else warnings[targetUser] = active
    groupData.warnings = warnings
    return true
}

// ---------- Helpers: arsip histori (auto-hapus setelah TTL) ----------
function cleanExpiredHistory(groupData) {
    const history = groupData.warnHistory || {}
    let changed = false
    const now = Date.now()
    for (const jid of Object.keys(history)) {
        const filtered = history[jid].filter(entry => !entry.expireAt || entry.expireAt > now)
        if (filtered.length !== history[jid].length) changed = true
        if (filtered.length === 0) delete history[jid]
        else history[jid] = filtered
    }
    groupData.warnHistory = history
    return changed
}

function archiveWarnings(groupData, targetUser, action, warningsList) {
    const history = groupData.warnHistory || {}
    const userHistory = history[targetUser] || []
    userHistory.push({
        action,
        warnings: warningsList,
        time: Date.now(),
        expireAt: Date.now() + HISTORY_TTL_MS
    })
    history[targetUser] = userHistory
    groupData.warnHistory = history
}

function isUserIgnored(chat, targetUser) {
    const db = getDatabase()
    const group = db.getGroup(chat) || {}
    const ignored = group.ignoredUsers || {}
    return !!ignored[targetUser]
}

async function handler(m, { sock }) {
    const db = getDatabase()

    let groupData = db.getGroup(m.chat) || {}
    let warnings = groupData.warnings || {}
    const maxWarns = groupData.maxWarnings || 3
    const warnAction = groupData.warnAction || 'kick'

    if (cleanExpiredHistory(groupData)) {
        db.setGroup(m.chat, groupData)
    }

    const args = m.args

    // ---------- Help ----------
    if (!args[0] && !m.quoted && (!m.mentionedJid || m.mentionedJid.length === 0)) {
        return m.reply(
            `⚠️ *النظام WARNING المجموعة*\n\n` +
            `النظام manajemen pelanggaran لـ عضو المجموعة.\n` +
            `Batas Warning: *${maxWarns} kali* (Aksi: *${warnAction === 'ignore' ? 'Diabaikan' : 'Kick Otomatis'}*)\n\n` +
            `*PENGGUNAAN:*\n` +
            `• *${m.prefix}warn @user <alasan>* — Memberi warning\n` +
            `• *${m.prefix}warn max <angka>* — Mengubah batas maksimal warning\n` +
            `• *${m.prefix}warn action <kick/ignore>* — Mengubah aksi saat batas tercapai\n` +
            `• *${m.prefix}warn unignore @user* — Mencabut status diabaikan dari member\n` +
            `• *${m.prefix}warn stats* — Lihat عضو مع warning terbanyak\n` +
            `• *${m.prefix}warn auto* — Atur auto-reduce warning (timed decay)\n` +
            `• *${m.prefix}listwarn* — Melihat daftar member bermasalah\n` +
            `• *${m.prefix}تصفير_الإنذارات @عضو* — Menghapus كل warning عضو\n\n` +
            `*PENJELASAN ALUR PENGGUNAAN:*\n` +
            `1. Saat عضو melakukan pelanggaran pertama, beri هم SP1: *${m.prefix}warn @user Spam رسالة*\n` +
            `2. البوت سوف mencatat "Spam رسالة" sebagai warning إلى-1 هم.\n` +
            `3. إذا melanggar مرة أخرى, beri تحذير kedua مع alasan جديد: *${m.prefix}warn @user Berkata kasar*\n` +
            `4. إذا total تحذير عضو mencapai batas maksimal (saat هذا *${maxWarns}*), البوت سوف otomatis ${warnAction === 'ignore' ? 'MENGABAIKAN' : 'MENGELUARKAN (Kick)'} عضو tersebut.\n` +
            `5. Riwayat pelanggaran يمكن dilihat lengkap مع mengetik *${m.prefix}listwarn @user*.`
        )
    }

    // ---------- .warn max <n> ----------
    if (args[0]?.toLowerCase() === 'max') {
        const newMax = parseInt(args[1])
        if (isNaN(newMax) || newMax < 1 || newMax > 20) {
            return m.reply(`❌ *فشل*\n\nBatas referensi warning يجب berupa angka 1-20.\nContoh: *${m.prefix}warn max 5*`)
        }
        groupData.maxWarnings = newMax
        db.setGroup(m.chat, groupData)
        return m.reply(`✅ *BATAS WARNING DIUBAH*\n\nMaksimal warning المجموعة هذا قد diupdate menjadi *${newMax} kali*.`)
    }

    // ---------- .warn action <kick/ignore> ----------
    if (args[0]?.toLowerCase() === 'action') {
        const newAction = args[1]?.toLowerCase()
        if (newAction !== 'kick' && newAction !== 'ignore') {
            return m.reply(`❌ *فشل*\n\nAksi يجب خطأ satu من: *kick* أو *ignore*.\nContoh: *${m.prefix}warn action ignore*`)
        }
        groupData.warnAction = newAction
        db.setGroup(m.chat, groupData)
        return m.reply(`✅ *AKSI WARNING DIUBAH*\n\nSaat عضو mencapai batas max, البوت الآن سوف: *${newAction === 'ignore' ? 'mengabaikan (ignore) member' : 'mengeluarkan (kick) member'}*.`)
    }

    // ---------- .warn stats ----------
    if (args[0]?.toLowerCase() === 'stats') {
        const entries = Object.keys(warnings)
            .map(jid => [jid, getActiveWarnings(warnings[jid])])
            .filter(([, active]) => active.length > 0)

        if (entries.length === 0) {
            return m.reply(`📊 *WARN STATS*\n\nBelum يوجد عضو مع warning مفعّل في المجموعة هذا.`)
        }
        const sorted = entries.sort((a, b) => b[1].length - a[1].length).slice(0, 10)
        let text = `📊 *WARN STATS* (Top ${sorted.length})\n\n`
        sorted.forEach(([jid, list], i) => {
            text += `${i + 1}. @${jid.split('@')[0]} — *${list.length}/${maxWarns}*\n`
        })
        return m.reply(text, { mentions: sorted.map(([jid]) => jid) })
    }

    // ---------- .warn unignore @user ----------
    if (args[0]?.toLowerCase() === 'unignore') {
        let targetUser = m.quoted ? m.quoted.sender : (m.mentionedJid?.[0] || null)
        if (!targetUser) {
            return m.reply(`⚠️ *طريقة الاستخدام*\n\nReply رسالة user أو mention: *${m.prefix}warn unignore @user*`)
        }
        const ignored = groupData.ignoredUsers || {}
        if (!ignored[targetUser]) {
            return m.reply(`ℹ️ عضو هذا لا جارٍ dalam الحالة diabaikan.`)
        }
        delete ignored[targetUser]
        groupData.ignoredUsers = ignored
        db.setGroup(m.chat, groupData)
        return m.reply(`✅ *Yatta~* الحالة diabaikan لـ @${targetUser.split('@')[0]} قد dicabut~ ✨`, { mentions: [targetUser] })
    }

    // ---------- .warn auto [on/off/set] <durasi> ----------
    if (args[0]?.toLowerCase() === 'auto') {
        const sub = args[1]?.toLowerCase()
        const autoReduce = groupData.autoReduce || { enabled: false, duration: 0 }

        if (!sub) {
            return m.reply(
                `⏱️ *AUTO-REDUCE WARNING*\n\n` +
                `الحالة: *${autoReduce.enabled ? 'Aktif' : 'Mati'}*\n` +
                `المدة: *${autoReduce.duration ? formatDuration(autoReduce.duration) : '-'}*\n\n` +
                `*${m.prefix}warn auto on <المدة>* — Nyalakan\n` +
                `*${m.prefix}warn auto off* — Matikan\n` +
                `*${m.prefix}warn auto set <المدة>* — Ubah المدة\n` +
                `مثال المدة: 1m, 1h30m, 2d, 1w, 1mo, 1y`
            )
        }

        if (sub === 'off') {
            groupData.autoReduce = { ...autoReduce, enabled: false }
            db.setGroup(m.chat, groupData)
            return m.reply(`✅ *Yatta~* Auto-reduce warning dimatikan~ ✨`)
        }

        if (sub === 'on' || sub === 'set') {
            const durStr = args.slice(2).join('')
            const ms = parseDuration(durStr)
            if (sub === 'on' && !durStr) {
                if (!autoReduce.duration) return m.reply(`❌ *همم~* لم يوجد المدة tersimpan, wajib isi المدة: *${m.prefix}warn auto on 1h*~ 🥺`)
                groupData.autoReduce = { ...autoReduce, enabled: true }
                db.setGroup(m.chat, groupData)
                return m.reply(`✅ *Yatta~* Auto-reduce warning diaktifkan (المدة: ${formatDuration(autoReduce.duration)})~ ✨`)
            }
            if (ms === null) return m.reply(`❌ *همم~* Format المدة خاطئ. مثال: *${m.prefix}warn auto ${sub} 1h30m*~ 🥺`)
            groupData.autoReduce = { enabled: true, duration: ms }
            db.setGroup(m.chat, groupData)
            return m.reply(`✅ Auto-reduce warning ${sub === 'set' ? 'durasi diubah' : 'diaktifkan'}: setiap warning akan otomatis hilang بعد *${formatDuration(ms)}*.`)
        }

        return m.reply(`❌ *همم~* Sub-الأمر لا dikenali. استخدم: on, off, set~ 🥺`)
    }

    // ---------- Beri warning ----------
    let targetUser = null
    if (m.quoted) {
        targetUser = m.quoted.sender
    } else if (m.mentionedJid && m.mentionedJid.length > 0) {
        targetUser = m.mentionedJid[0]
    }

    if (!targetUser) {
        await m.reply(
            `⚠️ *طريقة الاستخدام*\n\n` +
            `> ردّ على رسالة user + \`${m.prefix}warn alasan\`\n` +
            `> أو: \`${m.prefix}warn @user alasan\``
        )
        return
    }
    try {
        const groupMeta = m.groupMetadata
        const participant = groupMeta.participants.find(p => getParticipantJid(p) === targetUser)
        if (participant?.admin) {
            await m.reply(`❌ *عذراً* لا يمكن memberikan warning kepada مشرف المجموعة~ 🥺`)
            return
        }
    } catch (e) {}

    const botJid = sock.user?.id?.split(':')[0] + '@s.whatsapp.net'
    if (targetUser === botJid) {
        await m.reply(`❌ *همم~* لا usah warn أنا, أنا cuma bot~ 🥺`)
        return
    }

    const reasonArg = m.quoted ? m.text?.trim() : m.text?.replace(/@\d+/g, '').replace(/^\s*warn\s*/i, '').trim()
    const reason = reasonArg || 'غير موجود alasan'
    const evidence = m.quoted?.text ? m.quoted.text.trim().slice(0, 300) : null

    cleanExpiredUserWarnings(groupData, targetUser)
    warnings = groupData.warnings || {}

    let userWarnings = warnings[targetUser] || []
    const autoReduce = groupData.autoReduce || { enabled: false, duration: 0 }
    const newWarning = {
        reason: reason,
        by: m.sender,
        time: Date.now()
    }
    if (evidence) newWarning.evidence = evidence
    if (autoReduce.enabled && autoReduce.duration > 0) {
        newWarning.expireAt = Date.now() + autoReduce.duration
    }
    userWarnings.push(newWarning)

    warnings[targetUser] = userWarnings
    groupData.warnings = warnings
    db.setGroup(m.chat, groupData)

    const warnCount = userWarnings.length
    const targetName = targetUser.split('@')[0]

    if (warnCount >= maxWarns) {
        // Re-fetch fresh data sebelum write final, biar gak ketimpa perubahan lain di antara call
        let fresh = db.getGroup(m.chat) || {}
        const freshWarnings = fresh.warnings || {}

        if (warnAction === 'ignore') {
            const ignored = fresh.ignoredUsers || {}
            ignored[targetUser] = { reason, by: m.sender, time: Date.now() }
            fresh.ignoredUsers = ignored
            archiveWarnings(fresh, targetUser, 'ignore', freshWarnings[targetUser] || userWarnings)
            delete freshWarnings[targetUser]
            fresh.warnings = freshWarnings
            db.setGroup(m.chat, fresh)

            await m.reply(
                `🔇 *MAX WARNING TERCAPAI*\n\n` +
                `@${targetName} سوف diabaikan البوت في المجموعة هذا (كل الأمر لا سوف direspon) حتى مشرف mencabutnya مع *${m.prefix}warn unignore @${targetName}*.\n\n` +
                `*Rincian:*\n` +
                `> Warning: *${warnCount}/${maxWarns}*\n` +
                `> Alasan Terakhir: *${reason}*`,
                { mentions: [targetUser] }
            )
        } else {
            try {
                await sock.groupParticipantsUpdate(m.chat, [targetUser], 'remove')
                archiveWarnings(fresh, targetUser, 'kick', freshWarnings[targetUser] || userWarnings)
                delete freshWarnings[targetUser]
                fresh.warnings = freshWarnings
                db.setGroup(m.chat, fresh)

                await m.reply(
                    `🚨 *MAX WARNING TERCAPAI*\n\n` +
                    `@${targetName} قد dikeluarkan من المجموعة لأن mencapai batas pelanggaran!\n\n` +
                    `*Rincian:*\n` +
                    `> Warning: *${warnCount}/${maxWarns}*\n` +
                    `> Alasan Terakhir: *${reason}*`,
                    { mentions: [targetUser] }
                )
            } catch (e) {
        console.error("[MUSASHI][plugins_legacy/group/warn.js] exception", e?.stack || e);
                await m.reply("حدث خطأ، حاول لاحقاً")
            }
        }
    } else {
        await m.reply(
            `⚠️ *PERINGATAN DIBERIKAN*\n\n` +
            `@${targetName} telah menerima Surat تحذير (SP${warnCount})!\n\n` +
            `*Rincian:*\n` +
            `> Warning ke: *${warnCount}/${maxWarns}*\n` +
            `> السبب: *${reason}*\n\n` +
            `_${maxWarns - warnCount} warning مجدداً = ${warnAction === 'ignore' ? 'DIABAIKAN' : 'KICK'} OTOMATIS_`,
            { mentions: [targetUser] }
        )
    }
}

module.exports = {
    config: pluginConfig,
    handler,
    getActiveWarnings, 
    isUserIgnored
}