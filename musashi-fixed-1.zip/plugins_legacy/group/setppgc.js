const pluginConfig = {
    name: 'setppgc',
    alias: ['setprofilegc', 'setppgroup', 'setppgrup'],
    category: 'group',
    description: 'Mengubah صورة profil المجموعة',
    usage: '.setppgc (ردّ على صورة)',
    example: '.setppgc',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    isAdmin: true,
    isBotAdmin: true,
    cooldown: 10,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    let buffer = null
    if (m.quoted?.isImage) {
        try {
            buffer = await m.quoted.download()
        } catch (e) {
            await m.reply(`❌ *عذراً* فشل mengambil صورة~ 🥺`)
            return
        }
    } else if (m.isImage) {
        try {
            buffer = await m.download()
        } catch (e) {
            await m.reply(`❌ *عذراً* فشل mengambil صورة~ 🥺`)
            return
        }
    }
    if (!buffer) {
        await m.reply(
            `⚠️ *طريقة الاستخدام*\n\n` +
            `> ردّ على صورة + \`${m.prefix}setppgc\`\n` +
            `> أرسل صورة مع الوصف \`${m.prefix}setppgc\``
        )
        return
    }
    try {
        await sock.updateProfilePicture(m.chat, buffer)
        await m.reply(
            `✅ *Yatta~* صورة الملف الشخصي المجموعة بنجاح diperbarui~ ✨`
        )
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/group/setppgc.js] exception", error?.stack || error);
        await m.reply(
            "حدث خطأ، حاول لاحقاً"
        )
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
