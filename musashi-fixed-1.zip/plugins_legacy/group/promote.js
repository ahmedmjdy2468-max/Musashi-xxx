const { getParticipantJid } = require('../../src/lib/lidHelper')

const pluginConfig = {
    name: 'promote',
    alias: ['jadiadmin', 'مشرف'],
    category: 'group',
    description: "يرقّي العضو المحدد إلى مشرف في المجموعة.",
    usage: ".ترقية @عضو",
    example: ".ترقية @عضو",
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true,
    isAdmin: true,
    isBotAdmin: true
}

async function handler(m, { sock }) {
    let target = null

    if (m.quoted) {
        target = m.quoted.sender
    } else if (m.mentionedJid && m.mentionedJid.length > 0) {
        target = m.mentionedJid[0]
    }

    if (!target) {
        await m.reply(
            `❌ *الهدف غير موجود*\n\n` +
            `> ردّ على رسالة العضو أو امنشنه!\n` +
            `> مثال: \`${m.prefix}promote @user\``
        )
        return
    }

    try {
        const groupMeta = m.groupMetadata
        const participant = groupMeta.participants.find(p => getParticipantJid(p) === target)

        if (!participant) {
            await m.reply(`❌ *عذراً* ✦\n\n> المستخدم غير موجود في المجموعة~ 🥺`)
            return
        }

        if (participant.admin) {
            await m.reply(`❌ *عذراً* ✦\n\n> المستخدم تم menjadi مشرف~ 🥺`)
            return
        }

        await sock.groupParticipantsUpdate(m.chat, [target], 'promote')

        await m.reply(
            `✅ *Yatta~* @${target.split('@')[0]} الآن menjadi مشرف~ ✨`,
            { mentions: [target] }
        )

    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/group/promote.js] exception", error?.stack || error);
        await m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
