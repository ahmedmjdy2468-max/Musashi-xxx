const pluginConfig = {
    name: 'resetlinkgc',
    alias: ['resetlink', 'revokelink', 'newlink'],
    category: 'group',
    description: "يلغي رابط دعوة المجموعة الحالي ويولّد رابطاً جديداً.",
    usage: ".إعادة_رابط_المجموعة",
    example: "",
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 60,
    energi: 0,
    isEnabled: true,
    isAdmin: true,
    isBotAdmin: true
}

async function handler(m, { sock }) {
    m.react('🔄')
    
    try {
        await sock.groupRevokeInvite(m.chat)
        
        m.react('✅')
        m.reply(`✅ *ʟɪɴᴋ المجموعة ᴅɪʀᴇsᴇᴛ*\nانتهت صلاحية رابط المجموعة السابق.\nاستخدم \`${m.prefix}linkgc\` للحصول على رابط جديد.`)
        
    } catch (err) {
        console.error("[MUSASHI][plugins_legacy/group/resetlinkgc.js] exception", err?.stack || err);
        m.react('❌')
        m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
