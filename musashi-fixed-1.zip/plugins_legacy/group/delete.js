const pluginConfig = {
    name: "",
    alias: ['hapus', 'd'],
    category: 'group',
    description: "يحذف الرسالة التي ترد عليها.",
    usage: ".يحذف_المجموعة (بالرد على رسالة)",
    example: "",
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    isAdmin: false,
    isBotAdmin: false,
    cooldown: 3,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    if (!m.quoted) {
        return m.reply('⚠️ *ردّ على رسالة الذي يريد محذوفة!*')
    }
    
    const quotedSender = m.quoted.sender || m.quoted.key?.participant
    const botJid = sock.user?.id?.split(':')[0] + '@s.whatsapp.net'
    const isOwnMessage = m.quoted.key?.fromMe || quotedSender === m.sender
    const isBotMessage = quotedSender === botJid || m.quoted.key?.fromMe
    
    if (!isOwnMessage && !isBotMessage) {
        if (!m.isBotAdmin) {
            return m.reply('⚠️ *البوت يجب jadi مشرف لـ حذف رسالة أعضاء lain!*')
        }
        if (!m.isAdmin && !m.isOwner) {
            return m.reply('⚠️ *فقط مشرف الذي يمكن حذف رسالة أعضاء lain!*')
        }
    }
    
    try {
        const key = {
            remoteJid: m.chat,
            id: m.quoted.key.id,
            fromMe: m.quoted.key.fromMe,
            participant: quotedSender
        }
        
        await sock.sendMessage(m.chat, { delete: key })
        await m.react('✅')
        
    } catch (err) {
        if (err.message?.includes('not found') || err.message?.includes('forbidden')) {
            await m.reply('❌ *فشل menghapus!*\n> الرسالة ربما تم محذوفة أو terlalu سابق.')
        } else {
            await m.react('❌')
        }
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
