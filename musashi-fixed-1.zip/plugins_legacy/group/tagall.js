const { getParticipantJid, getParticipantJids } = require('../../src/lib/lidHelper')

const pluginConfig = {
    name: 'tagall',
    alias: ['all', 'everyone'],
    category: 'group',
    description: 'يرسل إعلاناً ويشير إلى أعضاء المجموعة باستثناء البوت؛ لمالك البوت إذا كان مشرفاً بالمجموعة.',
    usage: '.منشن_الجميع [رسالة]',
    example: '.منشن_الجميع مرحباً بالجميع',
    isOwner: true,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 30,
    energi: 0,
    isEnabled: true,
    isAdmin: true,
    isBotAdmin: true
}

async function handler(m, { sock }) {
    const text = m.text || 'مرحباً بالجميع!'
    const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net'
    const senderId = m.sender

    try {
        const groupMeta = m.groupMetadata
        const participants = groupMeta.participants || []

        if (!participants.length) {
            return await m.reply('❌ لا يوجد أعضاء في هذه المجموعة.')
        }

        // استبعاد البوت والمرسل من قائمة الإشارات العامة.
        const memberMentions = getParticipantJids(participants)
            .filter(jid => jid !== botId && jid !== senderId)

        const memberList = participants
            .filter(p => {
                const jid = getParticipantJid(p)
                return jid !== botId && jid !== senderId
            })
            .map(p => `> @${getParticipantJid(p).split('@')[0]}`)
            .join('\n')
            .trim()

        // اسم المرسل
        const senderObj = participants.find(p => getParticipantJid(p) === senderId)
        const senderName = senderObj?.name || `@${senderId.split('@')[0]}`

        // ضمّ المرسل والأعضاء إلى الإشارات.
        const allMentions = [senderId, ...memberMentions]

        // تنسيق الإعلان.
        const topBorder = '╔═══════════════════╗'
        const midBorder = '╠═══════════════════╣'
        const bottomBorder = '╚═══════════════════╝'

        const message = `${topBorder}\n` +
                        `*_--📢 إعلان من @${senderId.split('@')[0]} --_*\n` +
                        `${midBorder}\n\n` +
                        `${text}\n\n` +
                        `\`\`\`━━━ ${memberMentions.length} عضو ━━━\`\`\`\n` +
                        `${memberList}\n` +
                        `${bottomBorder}`

        await m.reply(message, { mentions: allMentions })

    } catch (err) {
        console.error("[MUSASHI][plugins_legacy/group/tagall.js] exception", err?.stack || err);
        await m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
