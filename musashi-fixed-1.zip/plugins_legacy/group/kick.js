const { findParticipantByNumber } = require('../../src/lib/lidHelper')

const pluginConfig = {
    name: 'kick',
    alias: ['remove', 'tendang'],
    category: 'group',
    description: 'يطرد عضواً من المجموعة.',
    usage: '.طرد_عضو @عضو',
    example: '.طرد_عضو @عضو',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true,
    isAdmin: true,
    isBotAdmin: true
}

async function handler(m, { sock }) {
    let targetJid = null

    if (m.quoted) {
        targetJid = m.quoted.sender
    } else if (m.mentionedJid && m.mentionedJid.length > 0) {
        targetJid = m.mentionedJid[0]
    }

    if (!targetJid) {
        await m.reply(
            `❌ *الهدف غير موجود*\n\n` +
            `> ردّ على رسالة العضو أو امنشنه!\n` +
            `> مثال: \`${m.prefix}طرد_عضو @عضو\``
        )
        return
    }

    const botNumber = sock.user?.id?.split(':')[0] + '@s.whatsapp.net'
    const targetNumber = targetJid.replace(/@.*$/, '')

    if (targetJid === botNumber || targetNumber === botNumber.replace(/@.*$/, '')) {
        await m.reply(`❌ لا يمكن للبوت طرد نفسه.`)
        return
    }

    if (targetJid === m.sender) {
        await m.reply(`❌ لا يمكنك طرد نفسك.`)
        return
    }

    try {
        const groupMeta = m.groupMetadata
        const targetParticipant = findParticipantByNumber(groupMeta.participants, targetJid)
        
        if (!targetParticipant) {
            await m.reply(`❌ العضو غير موجود في المجموعة.`)
            return
        }
        
        if (targetParticipant.admin) {
            await m.reply(`❌ لا يمكن طرد مشرف المجموعة.`)
            return
        }
        
        await sock.groupParticipantsUpdate(m.chat, [targetParticipant.id], 'remove')

        await m.reply(`✅ تم طرد @${targetNumber} من المجموعة.`, { mentions: [targetJid] })

    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/group/kick.js] exception", error?.stack || error);
        await m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
