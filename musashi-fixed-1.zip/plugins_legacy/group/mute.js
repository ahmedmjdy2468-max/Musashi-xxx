const { getDatabase } = require('../../src/lib/database')

const pluginConfig = {
    name: 'mute',
    alias: ['bisukan'],
    category: 'group',
    description: 'يقصر إرسال الرسائل في المجموعة على المشرفين.',
    usage: '.كتم_المجموعة',
    example: '.كتم_المجموعة',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    isAdmin: true,
    isBotAdmin: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const db = getDatabase()
    const group = db.getGroup(m.chat) || {}
    const groupName = m.groupMetadata.subject

    if (group.mute) return m.reply('❌ المجموعة مقيدة للمشرفين بالفعل.')

    db.setGroup(m.chat, { ...group, mute: true })
    m.reply(`✅ قُيّد إرسال الرسائل في مجموعة *${groupName}* بواسطة @${m.sender.split('@')[0]}.\n\nيمكن للمشرفين فقط إرسال الرسائل.\nاكتب *${m.prefix}إلغاء_الكتم* لإلغاء التقييد.`, { mentions: [m.sender] })
}

function isMuted(groupJid, db) {
    const group = db.getGroup(groupJid) || {}
    return !!group.mute
}

module.exports = {
    config: pluginConfig,
    handler,
    isMuted
}
