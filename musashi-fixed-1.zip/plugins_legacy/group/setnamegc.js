const pluginConfig = {
    name: 'setnamegc',
    alias: ['setnamegrup', 'setgcname', 'setnamegroup', 'setnamagrup'],
    category: 'group',
    description: 'Mengubah الاسم المجموعة',
    usage: '.setnamegc <nama جديد>',
    example: '.setnamegc المجموعة Keren',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    isAdmin: true,
    isBotAdmin: true,
    cooldown: 10,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const newName = m.text?.trim()
    
    if (!newName) {
        await m.reply(
            `⚠️ *طريقة الاستخدام*\n\n` +
            `> \`${m.prefix}setnamegc الاسم المجموعة Baru\``
        )
        return
    }
    
    if (newName.length < 1 || newName.length > 100) {
        await m.reply(
            `⚠️ *ᴠᴀʟɪᴅᴀsɪ*\n\n` +
            `> الاسم المجموعة يجب 1-100 حرفاً.`
        )
        return
    }
    
    try {
        await sock.groupUpdateSubject(m.chat, newName)
        
        await m.reply(
            `✅ *Yatta~* نجح mengubah الاسم المجموعة menjadi *${newName}*~ ✨`
        )
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/group/setnamegc.js] exception", error?.stack || error);
        await m.reply(
            "حدث خطأ، حاول لاحقاً"
        )
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
