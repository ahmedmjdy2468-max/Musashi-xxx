const { getDatabase } = require('../../src/lib/database')

const pluginConfig = {
    name: 'setrulesgrup',
    alias: ['setgrouprules', 'setaturangrup'],
    category: 'group',
    description: 'يعيّن قواعد مخصصة للمجموعة.',
    usage: '.setrulesgrup <النص>',
    example: '.setrulesgrup 1. تجنب الإزعاج\n2. احترم الأعضاء',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    isAdmin: true,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m) {
    const db = getDatabase()
    const text = m.text?.trim() || (m.quoted?.body || m.quoted?.text || '')
    
    if (!text) {
        return m.reply(
            `📝 *تعيين قواعد المجموعة*\n\n` +
            `> أرسل نص القواعد الجديدة.\n\n` +
            `\`مثال:\`\n` +
            `\`${m.prefix}setrulesgrup 1. Jangan spam\\n2. Hormati sesama\``
        )
    }
    
    db.setGroup(m.chat, { groupRules: text })
    
    m.reply(
            `✅ *تم تحديث قواعد المجموعة*\n\n` +
            `حُفظت القواعد الجديدة بنجاح.\n` +
            `اكتب \`${m.prefix}rulesgrup\` لعرضها.`
    )
}

module.exports = {
    config: pluginConfig,
    handler
}
