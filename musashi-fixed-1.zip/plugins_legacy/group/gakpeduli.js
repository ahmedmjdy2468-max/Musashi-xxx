const { getDatabase } = require('../../src/lib/database')

const pluginConfig = {
    name: 'gakpeduli',
    alias: ['ignore', 'silent', 'cuek'],
    category: 'group',
    description: 'للمالك: يبدّل وضع تجاهل الرسائل في المجموعة الحالية، مع استثناء المالك والشريك.',
    usage: '.عدم_الاستجابة',
    example: '.عدم_الاستجابة',
    isOwner: true,
    isAdmin: false, // Biar admin grup bisa nyalain
    isGroup: true,
    isEnabled: true
}

async function handler(m, { sock }) {
    const db = getDatabase()
    const group = db.getGroup(m.chat) || {}
    
    // تبديل وضع تجاهل الرسائل
    const newState = !group.ignore 
    db.setGroup(m.chat, { ...group, ignore: newState })
    
    if (newState) {
        m.reply(`✅ فُعّل وضع تجاهل الرسائل. لن يستجيب البوت لأوامر أعضاء هذه المجموعة، باستثناء المالك والشريك.`)
    } else {
        m.reply(`✅ أُوقف وضع تجاهل الرسائل. عاد البوت للاستجابة للأوامر.`)
    }
}

// Fungsi ini yang dipanggil di handler.js
function isIgnored(groupJid, db) {
    const group = db.getGroup(groupJid) || {}
    return !!group.ignore
}

module.exports = {
    config: pluginConfig,
    handler,
    isIgnored
}
