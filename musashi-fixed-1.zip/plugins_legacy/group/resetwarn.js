const { getDatabase } = require('../../src/lib/database')

const pluginConfig = {
    name: 'resetwarn',
    alias: ['clearwarn', 'hapuswarn', 'delwarn'],
    category: 'group',
    description: 'يمسح إنذارات العضو المحدد بالرد على رسالته أو بمنشنه؛ للمشرفين.',
    usage: '.تصفير_الإنذارات @عضو',
    example: '.تصفير_الإنذارات @عضو',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    isAdmin: true,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const db = getDatabase()
    
    let targetUser = null
    if (m.quoted) {
        targetUser = m.quoted.sender
    } else if (m.mentionedJid && m.mentionedJid.length > 0) {
        targetUser = m.mentionedJid[0]
    }
    
    if (!targetUser) {
        await m.reply(
            `⚠️ *طريقة الاستخدام*\n\n` +
            `> ردّ على رسالة العضو واكتب الأمر، أو حدّده بمنشن.\n` +
            `> مثال: \`${m.prefix}تصفير_الإنذارات @عضو\``
        )
        return
    }
    
    let groupData = db.getGroup(m.chat) || {}
    let warnings = groupData.warnings || {}
    const maxWarns = groupData.maxWarnings || 3
    
    const targetName = targetUser.split('@')[0]
    
    if (!warnings[targetUser] || warnings[targetUser].length === 0) {
        await m.reply(`✅ لا توجد إنذارات مسجلة على @${targetName}.`, { mentions: [targetUser] })
        return
    }
    
    const prevCount = warnings[targetUser].length
    delete warnings[targetUser]
    db.setGroup(m.chat, { ...groupData, warnings: warnings })
    
    await m.reply(
        `✅ تم تصفير إنذارات @${targetName}.\n` +
        `قبل التصفير: *${prevCount}/${maxWarns}*\n` +
        `الآن: *0/${maxWarns}*`,
        { mentions: [targetUser] }
    )
}

module.exports = {
    config: pluginConfig,
    handler
}
