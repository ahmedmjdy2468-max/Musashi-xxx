// Plugin Spamtag MUSASHI chan (Bot tidak membalas dirinya sendiri)

const { getConfig, isSelf } = require('../../config') // ambil config

const config = getConfig()

const pluginConfig = {
    name: 'spamtag',
    alias: ['spammention'],
    category: 'group',
    description: "يرسل تنبيهات متكررة إلى العضو أو الأعضاء الذين تحددهم.",
    usage: ".علامة_سبام @عضو [| عدد] [نص]",
    example: ".علامة_سبام @عضو | 3 انتبه",
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 15,
    energi: 3,
    isEnabled: true,
    isAdmin: true,
    isBotAdmin: false
}

async function handler(m, { sock }) {
    try {
        // Jangan proses jika bot sendiri yang di-mention
        if (m.mentionedJid?.some(jid => isSelf(jid))) {
            return m.reply(
`╭━━━🌸〔 ITSUKI CHAN 〕━━━⬣
┃ 💖 Senpai...
┃ ❌ لا أستطيع إرسال رسائل متكررة 😳
┃ ⚠️ لا تكرر الرسائل نعم~
╰━━━━━━━━━━━━━━━━━⬣`
            )
        }

        let target = null
        let jumlah = 3 // default jumlah spam
        let teks = '' // teks tambahan

        if (!m.mentionedJid || m.mentionedJid.length === 0) {
            return m.reply(
`╭━━━🌸〔 ITSUKI CHAN 〕━━━⬣
┃ ❌ الهدف غير موجود!
┃ 📌 Wajib mention user
┃ ✨ مثال: .spamtag @user أو .spamtag @user | 5
╰━━━━━━━━━━━━━━━━━⬣`
            )
        }

        target = m.mentionedJid[0]

        if (!target.includes('@')) target = `${target}@s.whatsapp.net`

        const nomor = target.replace(/@.*$/, '')

        // Ambil body tanpa prefix+command
        // Format bisa: .spamtag @user | 5 teks
        //              .spamtag @user teks
        //              .spamtag @user | 5

        // Hapus semua mention dari body agar lebih mudah diparse
        let bodyTanpaMention = m.body
            .replace(/\.spamtag\s*/i, '')
            .replace(/\.spammention\s*/i, '')
            .replace(/@\S+/g, '')
            .trim()

        if (bodyTanpaMention.includes('|')) {
            const parts = bodyTanpaMention.split('|')
            const afterPipe = parts[1]?.trim()

            if (!afterPipe) {
                // tidak ada apa-apa setelah |
            } else {
                // Cek apakah bagian pertama setelah | adalah angka
                const firstToken = afterPipe.split(' ')[0]
                if (!isNaN(firstToken) && firstToken !== '') {
                    jumlah = parseInt(firstToken)
                    jumlah = jumlah < 1 ? 1 : (jumlah > 10 ? 10 : jumlah)
                    // Sisa setelah angka adalah teks
                    teks = afterPipe.slice(firstToken.length).trim()
                } else {
                    return m.reply(
`╭━━━🌸〔 ITSUKI CHAN 〕━━━⬣
┃ ❌ كمية غير صالح!
┃ 📌 أدخل رقماً بعد | (maksimal 10)
┃ ✨ مثال: .spamtag @user | 5
╰━━━━━━━━━━━━━━━━━⬣`
                    )
                }
            }
        } else {
            // Tidak ada |, semua sisa adalah teks
            teks = bodyTanpaMention.trim()
        }

        const delay = 1000

        await new Promise(resolve => setTimeout(resolve, 500))

        for (let i = 0; i < jumlah; i++) {
            const pesanText = teks
                ? `💌 @${nomor} 💌\n\n${teks}`
                : `💌 @${nomor} 💌`

            await sock.sendMessage(m.chat, {
                text: pesanText,
                mentions: [target]
            })
            if (i < jumlah - 1) await new Promise(resolve => setTimeout(resolve, delay))
        }

    } catch (err) {
        console.error('[SPAMTAG ERROR]', err)
        m.reply(
"حدث خطأ، حاول لاحقاً"
        )
    }
}

module.exports = {
    config: pluginConfig,
    handler
}