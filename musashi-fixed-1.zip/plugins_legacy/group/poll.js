const pluginConfig = {
    name: 'poll',
    alias: ['voting', 'vote'],
    category: 'group',
    description: "ينشئ استطلاعاً في المجموعة بالسؤال والخيارات التي تحددها.",
    usage: ".تصويت <السؤال> | <خيار1>، <خيار2>",
    example: ".تصويت أين نلتقي؟ | المنزل، الحديقة",
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 30,
    energi: 1,
    isEnabled: true
};

async function handler(m, { sock }) {
    const text = m.text || '';
    
    if (!text || text.trim() === '') {
        await m.reply(
            `⚠️ *ᴠᴀʟɪᴅᴀsɪ فشل*\n\n` +
            `> الصيغة غير صالح!\n\n` +
            `*Format:*\n` +
            `> \`.poll pertanyaan | opsi1, opsi2\`\n\n` +
            `*مثال:*\n` +
            `> \`.poll Makan siang apa? | Nasi Goreng, Mie Ayam\`\n\n` +
            `*Opsi tambahan:*\n` +
            `> \`.poll multi | pertanyaan | opsi1, opsi2, opsi3, dst\`\n` +
            `> (للاختيار من متعدد)`
        );
        return;
    }
    
    let isMultiple = false;
    let parts = text.split('|').map(p => p.trim());
    
    if (parts[0].toLowerCase() === 'multi') {
        isMultiple = true;
        parts = parts.slice(1);
    }
    
    if (parts.length < 2) {
        await m.reply(
            `⚠️ *ᴠᴀʟɪᴅᴀsɪ فشل*\n\n` +
            `> Format: \`pertanyaan | opsi1, opsi2, ...\``
        );
        return;
    }
    
    const question = parts[0];
    const options = parts[1].split(',').map(o => o.trim()).filter(o => o);
    
    if (options.length < 2) {
        await m.reply(
            `⚠️ *ᴠᴀʟɪᴅᴀsɪ فشل*\n\n` +
            `> الحد الأدنى 2 opsi الخيارات!`
        );
        return;
    }
    
    if (options.length > 12) {
        await m.reply(
            `⚠️ *ᴠᴀʟɪᴅᴀsɪ فشل*\n\n` +
            `> الحد الأقصى 12 opsi الخيارات!`
        );
        return;
    }
    
    if (question.length > 255) {
        await m.reply(
            `⚠️ *ᴠᴀʟɪᴅᴀsɪ فشل*\n\n` +
            `> السؤال terlalu طويل!\n` +
            `> الحد الأقصى 255 حرفاً.`
        );
        return;
    }
    
    try {
        const pollMsg = `✅ نجاح membuat poll`;
        
        await m.reply(pollMsg, { mentions: [m.sender] });
        
        await sock.sendMessage(m.chat, {
            poll: {
                name: question,
                values: options,
                selectableCount: isMultiple ? options.length : 1
            }
        });
        
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/group/poll.js] exception", error?.stack || error);
        await m.reply(
            "حدث خطأ، حاول لاحقاً"
        );
    }
}

module.exports = {
    config: pluginConfig,
    handler
};
