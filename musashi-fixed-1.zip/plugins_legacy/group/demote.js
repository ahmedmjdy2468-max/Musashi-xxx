const { getParticipantJid } = require('../../src/lib/lidHelper')

const pluginConfig = {
    name: 'demote',
    alias: ['unadmin', 'turunkan'],
    category: 'group',
    description: "يزيل رتبة المشرف عن العضو المحدد.",
    usage: ".تخفيض @عضو",
    example: ".تخفيض @عضو",
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true,
    isAdmin: true,
    isBotAdmin: true
}

async function handler(m, { sock }) {
    let target = null

    if (m.quoted) {
        target = m.quoted.sender
    } else if (m.mentionedJid && m.mentionedJid.length > 0) {
        target = m.mentionedJid[0]
    }

    if (!target) {
        await m.reply(
            `❌ *الهدف غير موجود*\n\n` +
            `> ردّ على رسالة العضو أو امنشنه!\n` +
            `> مثال: \`${m.prefix}demote @user\``
        )
        return
    }

    try {
        const groupMeta = m.groupMetadata
        const participant = groupMeta.participants.find(p => getParticipantJid(p) === target)

        if (!participant) {
            await m.reply(`❌ *عذراً* ✦\n\n> المستخدم غير موجود في المجموعة~ 🥺`)
            return
        }

        if (!participant.admin) {
            await m.reply(`❌ *عذراً* ✦\n\n> المستخدم ليس مشرف~ 🥺`)
            return
        }

        if (participant.admin === 'superadmin') {
            await m.reply(`❌ *عذراً* ✦\n\n> لا يمكن demote owner المجموعة~ 🥺`)
            return
        }

        await sock.groupParticipantsUpdate(m.chat, [target], 'demote')

        await m.reply(
            `@${target.split('@')[0]} الآن ليس مشرف مرة أخرى.`,
            { mentions: [target] }
        )

    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/group/demote.js] exception", error?.stack || error);
        await m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
