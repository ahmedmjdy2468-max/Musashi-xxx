const { getDatabase } = require('../../src/lib/database')
const config = require('../../config')
const axios = require('axios')
const FormData = require('form-data')
const fetch = require('node-fetch')
const fs = require('fs')
const path = require('path')

// ─── Cache pesan ──────────────────────────────────────────────────────────────
const msgCache = new Map()

// ─── Cache buffer stiker (url → Buffer) ──────────────────────────────────────
// Download sekali, selanjutnya pakai dari RAM — hilang kalau bot restart
const stikerBufferCache = new Map()

// ─── Path DB stiker custom ────────────────────────────────────────────────────
const STIKER_DB_PATH = path.resolve('./database/other/cidukdelmsg.json')

// ─── Helper: baca / tulis DB stiker ──────────────────────────────────────────
// Struktur JSON:
// {
//   "groups": {
//     "120363xxxx@g.us": ["https://url1", "https://url2"],
//     "120363yyyy@g.us": ["https://url3"]
//   }
// }

function loadStikerDB() {
    try {
        if (!fs.existsSync(STIKER_DB_PATH)) {
            fs.mkdirSync(path.dirname(STIKER_DB_PATH), { recursive: true })
            fs.writeFileSync(STIKER_DB_PATH, JSON.stringify({ groups: {} }, null, 2))
            return { groups: {} }
        }
        const raw = JSON.parse(fs.readFileSync(STIKER_DB_PATH, 'utf8'))
        if (!raw.groups) raw.groups = {}
        return raw
    } catch {
        return { groups: {} }
    }
}

function saveStikerDB(data) {
    fs.mkdirSync(path.dirname(STIKER_DB_PATH), { recursive: true })
    fs.writeFileSync(STIKER_DB_PATH, JSON.stringify(data, null, 2))
}

// ─── Helper: ambil URL stiker random untuk grup tertentu ─────────────────────
// Return null kalau grup belum punya stiker custom
function getRandomStikerUrl(groupId) {
    const db = loadStikerDB()
    const list = db.groups?.[groupId] || []
    if (list.length === 0) return null
    return list[Math.floor(Math.random() * list.length)]
}

// ─── Helper: hapus stiker dari grup tertentu ─────────────────────────────────
// indexes: array of 1-based index (dari user), atau 'all'
function deleteStikerFromGroup(groupId, indexes) {
    const db = loadStikerDB()
    const list = db.groups?.[groupId] || []
    if (list.length === 0) return { ok: false, reason: 'empty' }

    if (indexes === 'all') {
        // Hapus semua buffer cache untuk URL grup ini
        for (const url of list) stikerBufferCache.delete(url)
        db.groups[groupId] = []
        saveStikerDB(db)
        return { ok: true, deleted: list.length, remaining: 0 }
    }

    // Validasi semua index
    const invalid = indexes.filter(i => i < 1 || i > list.length)
    if (invalid.length > 0) return { ok: false, reason: 'invalid', invalid }

    // Hapus dari belakang supaya index tidak geser
    const sorted = [...new Set(indexes)].sort((a, b) => b - a)
    for (const i of sorted) {
        stikerBufferCache.delete(list[i - 1]) // hapus cache URL yang dihapus
        list.splice(i - 1, 1)
    }

    db.groups[groupId] = list
    saveStikerDB(db)
    return { ok: true, deleted: sorted.length, remaining: list.length }
}

// ─── Helper: tambah stiker ke grup tertentu ───────────────────────────────────
function addStikerToGroup(groupId, url) {
    const db = loadStikerDB()
    if (!db.groups[groupId]) db.groups[groupId] = []
    if (db.groups[groupId].includes(url)) return { ok: false, reason: 'duplicate' }
    db.groups[groupId].push(url)
    saveStikerDB(db)
    // Preload buffer baru ke cache (opsional, akan di-fetch otomatis saat dipakai)
    stikerBufferCache.delete(url) // reset kalau pernah gagal sebelumnya
    return { ok: true, total: db.groups[groupId].length }
}

// ─── Helper: upload buffer ke catbox (fallback litterbox) ────────────────────
async function uploadStikerToHost(buffer, filename = 'sticker.webp') {
    const mime = require('mime-types')
    const contentType = mime.lookup(filename) || 'image/webp'

    // ── 1. Catbox (permanent) ────────────────────────────────────────────────
    try {
        const form = new FormData()
        form.append('reqtype', 'fileupload')
        form.append('fileToUpload', buffer, { filename, contentType })
        const res = await fetch('https://catbox.moe/user/api.php', {
            method: 'POST', body: form, headers: form.getHeaders(), timeout: 30000
        })
        const url = await res.text()
        if (url.startsWith('http')) return url
    } catch (e) { console.log('[CidukDelMsg] Catbox فشل:', e.message) }

    // ── 2. Litterbox (72h) ───────────────────────────────────────────────────
    try {
        const form = new FormData()
        form.append('reqtype', 'fileupload')
        form.append('time', '72h')
        form.append('fileToUpload', buffer, { filename, contentType })
        const res = await fetch('https://litterbox.catbox.moe/resources/internals/api.php', {
            method: 'POST', body: form, headers: form.getHeaders(), timeout: 30000
        })
        const url = await res.text()
        if (url.startsWith('http')) return url
    } catch (e) { console.log('[CidukDelMsg] Litterbox فشل:', e.message) }

    // ── 3. Qu.ax (permanent) ────────────────────────────────────────────────
    try {
        const form = new FormData()
        form.append('files[]', buffer, { filename, contentType })
        const res = await fetch('https://qu.ax/upload.php', {
            method: 'POST', body: form, headers: form.getHeaders(), timeout: 30000
        })
        const data = await res.json()
        if (data?.files?.[0]?.url) return data.files[0].url
    } catch (e) { console.log('[CidukDelMsg] Qu.ax فشل:', e.message) }

    // ── 4. TmpFiles (60 menit) ───────────────────────────────────────────────
    try {
        const form = new FormData()
        form.append('file', buffer, { filename, contentType })
        const res = await fetch('https://tmpfiles.org/api/v1/upload', {
            method: 'POST', body: form, headers: form.getHeaders(), timeout: 30000
        })
        const data = await res.json()
        if (data?.data?.url) {
            const idMatch = data.data.url.match(/\/(\d+)(?:\/|$)/)
            return idMatch
                ? `https://tmpfiles.org/dl/${idMatch[1]}/${filename}`
                : data.data.url.replace('tmpfiles.org/', 'tmpfiles.org/dl/')
        }
    } catch (e) { console.log('[CidukDelMsg] TmpFiles فشل:', e.message) }

    throw new Error('كل مضيف الرفع فشل')
}

// ─── Plugin config ────────────────────────────────────────────────────────────
const pluginConfig = {
    name: 'cidukdelmsg',
    alias: ['ciduk'],
    category: 'group',
    description: 'Ciduk user الذي حذف رسالة! البوت أرسل ملصق إذا يوجد رسالة محذوفة في المجموعة.',
    usage: '.cidukdelmsg <on/off/add/list>',
    example: '.cidukdelmsg on',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    isAdmin: true,
    cooldown: 3,
    energi: 1,
    isEnabled: true
}

// ─── Handler utama ────────────────────────────────────────────────────────────
async function handler(m, { sock }) {
    try {
        const db = getDatabase()
        const groupId = m.chat
        const groupData = db.getGroup(groupId) || {}

        const args = m.body.trim().split(' ')
        const sub  = args[1]?.toLowerCase()
        const sub2 = args[2]?.toLowerCase()

        // ── .cidukdelmsg on/off all → global (owner only) ──────────────────────
        if ((sub === 'on' || sub === 'off') && sub2 === 'all') {
            if (!m.isOwner) {
                return m.reply(config.messages?.ownerOnly || 'Muu~ هذا خاص بالمالك فقط lho~')
            }

            m.react('🕕')

            try {
                const groups = await sock.groupFetchAllParticipating()
                const groupIds = Object.keys(groups)
                let count = 0

                for (const gid of groupIds) {
                    const gData = db.getGroup(gid) || {}
                    gData.cidukdelmsg = sub === 'on'
                    db.setGroup(gid, gData)
                    count++
                }

                await db.save()
                m.react('✅')

                return m.reply(
                    `😈 *ᴄɪᴅᴜᴋ ᴅᴇʟ ᴍsɢ ɢʟᴏʙᴀʟ ${sub === 'on' ? 'ᴏɴ' : 'ᴏꜰꜰ'}* 💕\n\n` +
                    `> ${sub === 'on' ? '✅ MUSASHI udah aktifkan' : '🌙 MUSASHI udah nonaktifkan'} CidukDelMsg في *${count}* المجموعة!\n` +
                    `> ${sub === 'on' ? 'لا يمكن حذف الرسائل سراً الآن. 👁️' : 'MUSASHI istirahat dulu dari jaga-jaga ya~ 🌸'}`
                )
            } catch (err) {
        console.error("[MUSASHI][plugins_legacy/group/cidukdelmsg.js] exception", err?.stack || err);
                m.react('❌')
                return m.reply("حدث خطأ، حاول لاحقاً")
            }
        }

        // ── .cidukdelmsg on → per grup ──────────────────────────────────────────
        if (sub === 'on') {
            if (groupData.cidukdelmsg) {
                return m.reply(
                    `👁️ *ᴄɪᴅᴜᴋ ᴅᴇʟ ᴍsɢ ᴜᴅᴀʜ ᴀᴋᴛɪꜰ~*\n\n` +
                    `> الحالة: *✅ مفعّل*\n` +
                    `> MUSASHI تم jaga dari tadi lho~\n\n` +
                    `_استخدم \`${m.prefix}cidukdelmsg off\` إذا يريد dimatiin_`
                )
            }

            groupData.cidukdelmsg = true
            db.setGroup(groupId, groupData)
            await db.save()

            return m.reply(
                `✨ *Siap! موساشي جاهز للعمل مجدداً~* ✨\n\n` +
                `إذا يوجد الذي berani حذف رسالة في sini...\n` +
                `أنا الذي pertama tau, و أنا *لا سوف diem* 😈💕\n\n` +
                `> كل kebohongan بالتأكيد ketauan~ termasuk رسالة الذي محذوفة!`
            )
        }

        // ── .cidukdelmsg off → per grup ─────────────────────────────────────────
        if (sub === 'off') {
            if (!groupData.cidukdelmsg) {
                return m.reply(
                    `👁️ *ᴄɪᴅᴜᴋ ᴅᴇʟ ᴍsɢ ᴜᴅᴀʜ ᴍᴀᴛɪ~*\n\n` +
                    `> الحالة: *❌ متوقف*\n` +
                    `> MUSASHI emang تم istirahat di sini~\n\n` +
                    `_استخدم \`${m.prefix}cidukdelmsg on\` إذا يريد dihidupin مجدداً_`
                )
            }

            groupData.cidukdelmsg = false
            db.setGroup(groupId, groupData)
            await db.save()

            return m.reply(
                `💤 *Oke oke, أنا istirahat أولاً نعم.*\n\n` +
                `لكن لا تسيء الفهم...\n` +
                `MUSASHI selalu ingat segalanya~ 🌟\n\n` +
                `> اكتب \`${m.prefix}cidukdelmsg on\` إذا يريد أنا balik jaga~`
            )
        }

        // ── .cidukdelmsg add ────────────────────────────────────────────────────
        if (sub === 'add') {
            const isAll = sub2 === 'all'

            if (isAll && !m.isOwner) {
                return m.reply('Muu~ `.cidukdelmsg add all` خاص بالمالك فقط نعم~ 👑')
            }
            if (!m.isOwner && !m.isAdmin) {
                return m.reply('هذا خاص بالمشرفين/المالك فقط 😤')
            }

            m.react('🕕')

            let stikerUrl = null

            // Cek URL di argumen
            const urlArg = args.slice(isAll ? 3 : 2).find(a => a.startsWith('http'))
            if (urlArg) {
                stikerUrl = urlArg
            }

            // Cek reply media
            const quoted = m.quoted
            if (!stikerUrl && quoted) {
                const qType = quoted.type

                if (qType === 'stickerMessage') {
                    try {
                        const buf = await quoted.download()
                        stikerUrl = await uploadStikerToHost(buf, 'sticker.webp')
                    } catch (e) {
        console.error("[MUSASHI][plugins_legacy/group/cidukdelmsg.js] exception", e?.stack || e);
                        m.react('❌')
                        return m.reply("حدث خطأ، حاول لاحقاً")
                    }

                } else if (qType === 'imageMessage' || qType === 'videoMessage') {
                    try {
                        const buf = await quoted.download()
                        const ext = qType === 'videoMessage' ? 'mp4' : 'jpg'
                        stikerUrl = await uploadStikerToHost(buf, `sticker.${ext}`)
                    } catch (e) {
        console.error("[MUSASHI][plugins_legacy/group/cidukdelmsg.js] exception", e?.stack || e);
                        m.react('❌')
                        return m.reply("حدث خطأ، حاول لاحقاً")
                    }

                } else {
                    m.react('❌')
                    return m.reply(
                        `❌ *الصيغة غير مدعومة!*\n\n` +
                        `ردّ على مع:\n` +
                        `> 🖼️ صورة / فيديو → otomatis diupload\n` +
                        `> 💟 ملصق → langsung حفظه\n` +
                        `> 🔗 URL → \`${m.prefix}cidukdelmsg add https://...\``
                    )
                }
            }

            if (!stikerUrl) {
                m.react('❌')
                return m.reply(
                    `❓ *طريقة الاستخدام:*\n\n` +
                    `> ردّ على صورة/فيديو/ملصق + \`${m.prefix}cidukdelmsg add\`\n` +
                    `> أو: \`${m.prefix}cidukdelmsg add https://...\`\n` +
                    `> المالك كل المجموعة: \`${m.prefix}cidukdelmsg add all https://...\``
                )
            }

            // Simpan ke DB
            if (isAll) {
                let addedCount = 0
                let skipCount  = 0

                try {
                    const allGroups = await sock.groupFetchAllParticipating()
                    const allGroupIds = Object.keys(allGroups)

                    for (const gid of allGroupIds) {
                        const result = addStikerToGroup(gid, stikerUrl)
                        if (result.ok) addedCount++
                        else skipCount++
                    }

                    m.react('✅')
                    return m.reply(
                        `✨ *ملصق بنجاح ditambah إلى كل المجموعة!* 💕\n\n` +
                        `> URL: \`${stikerUrl}\`\n` +
                        `> نجح: *${addedCount}* المجموعة\n` +
                        `> تم يوجد: *${skipCount}* المجموعة\n\n` +
                        `MUSASHI bakal استخدام ملصق هذا في كل المجموعة~ 🌟`
                    )
                } catch (err) {
        console.error("[MUSASHI][plugins_legacy/group/cidukdelmsg.js] exception", err?.stack || err);
                    m.react('❌')
                    return m.reply("حدث خطأ، حاول لاحقاً")
                }

            } else {
                const result = addStikerToGroup(groupId, stikerUrl)

                if (!result.ok) {
                    m.react('❌')
                    return m.reply(`⚠️ URL ملصق ذلك تم يوجد في المجموعة هذا lho~ 👁️\n\n> \`${stikerUrl}\``)
                }

                m.react('✅')
                return m.reply(
                    `✨ *ملصق بنجاح ditambah إلى المجموعة هذا!* 💕\n\n` +
                    `> URL: \`${stikerUrl}\`\n` +
                    `> Total ملصق المجموعة هذا: *${result.total}*\n\n` +
                    `MUSASHI bakal استخدام ملصق جديد هذا في sini~ 🌟`
                )
            }
        }

        // ── .cidukdelmsg del ────────────────────────────────────────────────────
        // Admin  → del index / del 1/2/3 (grup sendiri saja)
        // Owner  → del index / del 1/2/3 (grup sendiri) / del all (grup sendiri)
        if (sub === 'del') {
            if (!m.isOwner && !m.isAdmin) {
                return m.reply('هذا خاص بالمشرفين/المالك فقط 😤')
            }

            const delArg = args[2]?.toLowerCase()

            if (!delArg) {
                m.react('❌')
                return m.reply(
                    `❓ *طريقة الاستخدام:*\n\n` +
                    `> \`${m.prefix}cidukdelmsg del 1\` — حذف ملصق إلى-1\n` +
                    `> \`${m.prefix}cidukdelmsg del 1/2/3\` — hapus بعض sekaligus\n` +
                    (m.isOwner ? `> \`${m.prefix}cidukdelmsg del all\` — حذف كل (owner)\n` : '') +
                    `\n_Lihat الرقم ملصق مع \`${m.prefix}cidukdelmsg list\`_`
                )
            }

            // del all → owner only
            if (delArg === 'all') {
                if (!m.isOwner) {
                    return m.reply('Muu~ \`.cidukdelmsg del all\` خاص بالمالك فقط نعم~ 👑')
                }

                const result = deleteStikerFromGroup(groupId, 'all')
                if (!result.ok && result.reason === 'empty') {
                    m.react('❌')
                    return m.reply(`⚠️ لا توجد ملصقات مخصصة لهذه المجموعة بعد`)
                }

                m.react('✅')
                return m.reply(
                    `🗑️ *كل ملصق المجموعة هذا محذوفة!*\n\n` +
                    `> *${result.deleted}* ملصق تم الحذف بنجاح~\n\n` +
                    `_Tambah مرة أخرى مع \`${m.prefix}cidukdelmsg add\`_`
                )
            }

            // del 1 atau del 1/2/3
            const rawIndexes = delArg.split('/').map(s => parseInt(s.trim()))
            const isValidNumbers = rawIndexes.every(n => !isNaN(n))

            if (!isValidNumbers) {
                m.react('❌')
                return m.reply(`❌ الصيغة خطأ~ استخدم angka, مثال: \`${m.prefix}cidukdelmsg del 1\` أو \`del 1/2/3\``)
            }

            const result = deleteStikerFromGroup(groupId, rawIndexes)

            if (!result.ok && result.reason === 'empty') {
                m.react('❌')
                return m.reply(`⚠️ لا توجد ملصقات مخصصة لهذه المجموعة بعد`)
            }

            if (!result.ok && result.reason === 'invalid') {
                m.react('❌')
                const stikerDB = loadStikerDB()
                const total = (stikerDB.groups?.[groupId] || []).length
                return m.reply(
                    `❌ *الرقم غير صالح.!*\n\n` +
                    `> الرقم الذي خطأ: *${result.invalid.join(', ')}*\n` +
                    `> Range الذي متاح: *1 - ${total}*\n\n` +
                    `_Cek القائمة مع \`${m.prefix}cidukdelmsg list\`_`
                )
            }

            m.react('✅')
            return m.reply(
                `🗑️ *ملصق تم الحذف بنجاح!*\n\n` +
                `> Dihapus: *${result.deleted}* ملصق\n` +
                `> المتبقي: *${result.remaining}* ملصق\n\n` +
                `_Lihat sisa ملصق مع \`${m.prefix}cidukdelmsg list\`_`
            )
        }

        // ── .cidukdelmsg list ────────────────────────────────────────────────────
        if (sub === 'list') {
            const stikerDB = loadStikerDB()

            // list all → owner only, tampilkan semua grup
            if (sub2 === 'all') {
                if (!m.isOwner) {
                    return m.reply('Muu~ `.cidukdelmsg list all` خاص بالمالك فقط نعم~ 👑')
                }

                const groups = stikerDB.groups || {}
                const groupIds = Object.keys(groups).filter(gid => groups[gid]?.length > 0)

                if (groupIds.length === 0) {
                    return m.reply(
                        `📋 *القائمة ملصق Ciduk — كل المجموعة*\n\n` +
                        `> لم يوجد المجموعات التي لديه ملصق custom هنا~\n\n` +
                        `_Tambah مع \`${m.prefix}cidukdelmsg add\`_`
                    )
                }

                let msg = `📋 *القائمة ملصق Ciduk — كل المجموعة* (${groupIds.length} المجموعة)\n`
                for (const gid of groupIds) {
                    const gList = groups[gid]
                    msg += `\n┌ *${gid}* (${gList.length})\n`
                    msg += gList.map((url, i) => `│ ${i + 1}. ${url}`).join('\n')
                    msg += `\n└──`
                }

                return m.reply(msg)
            }

            // list → grup ini saja
            const list = stikerDB.groups?.[groupId] || []

            if (list.length === 0) {
                return m.reply(
                    `📋 *القائمة ملصق Ciduk — المجموعة هذا*\n\n` +
                    `> لم يوجد ملصق custom هنا~\n` +
                    `> إضافة أولاً مع \`${m.prefix}cidukdelmsg add\`\n\n` +
                    `_ردّ على صورة/فيديو/ملصق أو langsung شكراً URL~_`
                )
            }

            const listStr = list.map((url, i) => `> ${i + 1}. ${url}`).join('\n')
            return m.reply(
                `📋 *القائمة ملصق Ciduk — المجموعة هذا* (${list.length})\n\n` +
                `${listStr}\n\n` +
                `_Stiker dipilih acak saat يوجد الذي حذف رسالة~_`
            )
        }

        // ── .cidukdelmsg → info ──────────────────────────────────────────────────
        const stikerDB = loadStikerDB()
        const stikerCount = (stikerDB.groups?.[groupId] || []).length

        return m.reply(
            `╭─「 ✨ *CIDUK DEL MSG* ✨ 」\n` +
            `│\n` +
            `│ Haii~ أنا MUSASHI, chan مع kebohongan sejuta watt~ 💫\n` +
            `│ لكن satu hal الذي أنا *لا* suka...\n` +
            `│ أعضاء الذي sembunyi-sembunyi حذف رسالة! 👁️\n` +
            `│\n` +
            `│ الحالة : *${groupData.cidukdelmsg ? '✅ Lagi aktif dong~' : '❌ Lagi tidur nih~'}*\n` +
            `│ ملصق : *${stikerCount > 0 ? stikerCount + ' custom' : 'belum ada, tambah dulu~'}*\n` +
            `│\n` +
            `│ *.cidukdelmsg on* — فعّل (مشرف)\n` +
            `│ *.cidukdelmsg off* — عطّل (مشرف)\n` +
            `│ *.cidukdelmsg on all* — Global ON (owner)\n` +
            `│ *.cidukdelmsg off all* — Global OFF (owner)\n` +
            `│\n` +
            `│ *.cidukdelmsg add* — أضف ملصقاً المجموعة ini\n` +
            `│   (رد على صورة أو فيديو أو ملصق، أو أرسل رابطاً)\n` +
            `│ *.cidukdelmsg add all* — إضافة إلى كل المجموعة (owner)\n` +
            `│ *.cidukdelmsg del 1* — احذف الملصق رقم 1\n` +
            `│ *.cidukdelmsg del 1/2/3* — احذف عدة ملصقات معاً\n` +
            `│ *.cidukdelmsg del all* — حذف كل ملصق (owner)\n` +
            `│ *.cidukdelmsg list* — اعرض ملصقات هذه المجموعة\n` +
            `│ *.cidukdelmsg list all* — اعرض ملصقات جميع المجموعات (owner)\n` +
            `╰──────────────────`
        )

    } catch (error) {
        console.error('CidukDelMsg Plugin الخطأ:', error)
        await m.reply(
            "حدث خطأ، حاول لاحقاً"
        )
    }
}

// ─── Cache pesan masuk ────────────────────────────────────────────────────────
function cacheMessage(m) {
    try {
        if (!m?.key?.id || !m?.chat) return
        const groupId = m.chat
        if (!groupId.endsWith('@g.us')) return

        if (!msgCache.has(groupId)) {
            msgCache.set(groupId, new Map())
        }

        const groupCache = msgCache.get(groupId)
        groupCache.set(m.key.id, {
            sender:    m.key.participant || m.sender || '',
            pushName:  m.pushName || 'المستخدم',
            body:      m.body || '',
            type:      m.type || '',
            key:       m.key,
            message:   m.message || null,
            timestamp: Date.now()
        })

        if (groupCache.size > 100) {
            const firstKey = groupCache.keys().next().value
            groupCache.delete(firstKey)
        }
    } catch {}
}

// ─── Handler deteksi pesan dihapus ───────────────────────────────────────────
async function handleCidukDelete(update, sock, db) {
    try {
        const key = update.key || update.update?.key
        if (!key?.remoteJid) return
        if (!key.remoteJid.endsWith('@g.us')) return

        const stubType = update.update?.messageStubType ?? update.messageStubType
        const isRevoke = stubType === 1 || stubType === 'REVOKE'
        if (!isRevoke) return

        const groupId   = key.remoteJid
        const freshDb   = db || getDatabase()
        const groupData = freshDb.getGroup(groupId) || {}
        if (!groupData.cidukdelmsg) return

        const groupCache = msgCache.get(groupId)
        const cachedMsg  = groupCache?.get(key.id)

        // Ambil stiker random milik grup ini
        const stikerUrl = getRandomStikerUrl(groupId)

        // Belum ada stiker custom → kirim pesan teks saja
        if (!stikerUrl) {
            await sock.sendMessage(groupId, {
                text: `👁️ *حُذفت رسالة~*\n\n> لكن MUSASHI لم لديه ملصق buat لرصد في المجموعة هذا!\n> المشرف, أضف أولاً yuk~ \`.cidukdelmsg add\``
            }, {
                quoted: cachedMsg?.key ? {
                    key: cachedMsg.key,
                    message: cachedMsg.message || { conversation: cachedMsg.body || '📩 الرسالة' }
                } : undefined
            })
            groupCache?.delete(key.id)
            return
        }

        // Download buffer stiker (pakai cache kalau sudah pernah didownload)
        let stikerBuffer = stikerBufferCache.get(stikerUrl)
        if (!stikerBuffer) {
            const stikerResp = await axios.get(stikerUrl, {
                responseType: 'arraybuffer',
                timeout: 10000
            })
            stikerBuffer = Buffer.from(stikerResp.data)
            stikerBufferCache.set(stikerUrl, stikerBuffer)
        }

        // Kirim stiker reply ke pesan yang dihapus
        if (cachedMsg?.key) {
            await sock.sendMessage(groupId, { sticker: stikerBuffer }, {
                quoted: {
                    key: cachedMsg.key,
                    message: cachedMsg.message || { conversation: cachedMsg.body || '📩 الرسالة' }
                }
            })
        } else {
            await sock.sendMessage(groupId, { sticker: stikerBuffer })
        }

        groupCache?.delete(key.id)

    } catch (error) {
        console.error('CidukDelMsg handleCidukDelete الخطأ:', error.message)
    }
}

module.exports = {
    config: pluginConfig,
    handler,
    cacheMessage,
    handleCidukDelete
}
