const { 
    getQuotedStickerHash, 
    deleteStickerCommand, 
    listStickerCommands,
    findByCommand 
} = require('../../src/lib/stickerCommand')

const pluginConfig = {
    name: 'delstickercmd',
    alias: ['delcmdsticker', 'removesticker', 'unsticker'],
    category: 'group',
    description: 'يحذف ربط ملصق بأمر أو يعرض الروابط المسجلة.',
    usage: '.حذف_أمر_ملصق [اسم_الأمر] (أو ردّ على ملصق)',
    example: '.حذف_أمر_ملصق قائمة',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    isAdmin: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const args = m.args || []
    const commandName = args[0]
    if (!commandName && !m.quoted) {
        const existingCmds = listStickerCommands()
        if (existingCmds.length === 0) {
            return m.reply(
                `🖼️ *ملصقات الأوامر*\n\n` +
                `> لا توجد روابط ملصقات مسجلة.\n` +
                `> أضف رابطاً باستخدام \`.addcmdsticker\``
            )
        }
        
        let txt = `🖼️ *ملصقات الأوامر*\n\n`
        txt += `╭┈┈⬡「 📋 *القائمة* 」\n`
        
        for (const cmd of existingCmds) {
            txt += `┃ 🖼️ → \`.${cmd.command}\`\n`
        }
        txt += `╰┈┈┈┈┈┈┈┈⬡\n\n`
        
        txt += `*طريقة الحذف:*\n`
        txt += `> \`.حذف_أمر_ملصق <اسم_الأمر>\`\n`
        txt += `> أو ردّ على الملصق ثم اكتب \`.حذف_أمر_ملصق\``
        
        return m.reply(txt)
    }
    
    let deleted = false
    let deletedCmd = ''
    if (m.quoted) {
        const stickerHash = getQuotedStickerHash(m)
        if (stickerHash) {
            const success = deleteStickerCommand(stickerHash)
            if (success) {
                deleted = true
                deletedCmd = 'الملصق الذي رددت عليه'
            }
        }
    }
    if (!deleted && commandName) {
        const cleanCmd = commandName.toLowerCase().replace(/^\./, '')
        const found = findByCommand(cleanCmd)
        
        if (found) {
            const success = deleteStickerCommand(found.hash)
            if (success) {
                deleted = true
                deletedCmd = cleanCmd
            }
        } else {
            return m.reply(
                `❌ لا يوجد ربط ملصق للأمر \`${cleanCmd}\`.\n\n` +
                `> اعرض القائمة باستخدام \`.حذف_أمر_ملصق\``
            )
        }
    }
    
    if (deleted) {
        await m.react('✅')
        await m.reply(
            `✅ *حُذف ربط الملصق*\n\n` +
            `> 🗑️ \`${deletedCmd}\` تم حذفه.`
        )
    } else {
        await m.reply(
            `❌ تعذر حذف الربط.\n\n` +
            `> ردّ على الملصق المطلوب حذفه, أو\n` +
            `> اكتب اسم الأمر بعد \`.حذف_أمر_ملصق\``
        )
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
