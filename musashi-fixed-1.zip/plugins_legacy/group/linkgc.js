const config = require('../../config')

const pluginConfig = {
    name: 'linkgc',
    alias: ['linkgrup', 'getlink', 'gclink'],
    category: 'group',
    description: "يجلب رابط دعوة المجموعة الحالية.",
    usage: ".رابط_دعوة_المجموعة",
    example: "",
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 10,
    energi: 0,
    isEnabled: true,
    isAdmin: true,
    isBotAdmin: true
}

async function handler(m, { sock }) {
    m.react('🕕')
    
    try {
        const code = await sock.groupInviteCode(m.chat)
        const urlGrup = `https://chat.whatsapp.com/${code}`
        await m.reply(`رابط المجموعة المجموعة هذا\n${urlGrup}`)
        
        m.react('✅')
        
    } catch (err) {
        console.error("[MUSASHI][plugins_legacy/group/linkgc.js] exception", err?.stack || err);
        m.react('❌')
        m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
