const pluginConfig = {
    name: 'notifpromote',
    alias: [],
    category: 'group',
    description: 'للمشرف: يفعّل أو يوقف إشعار المجموعة عند ترقية عضو إلى مشرف.',
    usage: '.تنبيه_ترقية <تشغيل|إيقاف>',
    example: '.تنبيه_ترقية تشغيل',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock, db }) {
    if (!m.isAdmin && !m.isOwner) {
        return m.reply(`❌ هذا الخيار متاح لمشرفي المجموعة فقط.`)
    }
    
    const rawArg = m.args[0]?.toLowerCase()
    const args = rawArg === 'تشغيل' ? 'on' : rawArg === 'إيقاف' ? 'off' : rawArg
    const group = db.getGroup(m.chat) || {}
    
    if (!['on', 'off'].includes(args)) {
        const status = group.notifPromote === true ? '✅ مفعّل' : '❌ متوقف'
        return m.reply(`👑 *تنبيه ترقية عضو*\n\nالحالة: ${status}\n\nالاستخدام:\n\`${m.prefix}تنبيه_ترقية تشغيل\`\n\`${m.prefix}تنبيه_ترقية إيقاف\``)
    }
    
    if (args === 'on') {
        group.notifPromote = true
        db.setGroup(m.chat, group)
        return m.reply(`✅ فُعّل إشعار ترقية العضو.`)
    }
    
    if (args === 'off') {
        group.notifPromote = false
        db.setGroup(m.chat, group)
        return m.reply(`❌ أُوقف إشعار ترقية العضو.`)
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
