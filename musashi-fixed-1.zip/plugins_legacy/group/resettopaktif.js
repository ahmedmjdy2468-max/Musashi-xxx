const fs = require('fs')
const path = require('path')

const DB_PATH = path.join(__dirname, '../../database/other/topaktif.json')
if (!fs.existsSync(path.dirname(DB_PATH))) fs.mkdirSync(path.dirname(DB_PATH), { recursive: true })

function saveDB(data) {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2))
}

const pluginConfig = {
    name: 'resettopaktif',
    alias: ['resetactive', 'resetleaderboard'],
    category: 'group',
    description: 'يصفّر نقاط لوحة النشاط في المجموعة الحالية؛ للمشرفين.',
    usage: '.تصفير_لوحة_النشاط',
    cooldown: 5,
    energi: 2,
    isGroup: true,
    isAdmin: true
}

async function handler(m, { sock }) {
    try {
        const jid = m.chat

        let cmd = (m.command || '').toLowerCase()
        if (!cmd) {
            cmd = (m.text || '').trim().toLowerCase()
            cmd = cmd.replace(/^\./, '').split(' ')[0]
        }

        if (['resettopaktif', 'resetactive', 'resetleaderboard', 'تصفير_لوحة_النشاط'].includes(cmd)) {
            let db = {}
            if (fs.existsSync(DB_PATH)) db = JSON.parse(fs.readFileSync(DB_PATH))
            
            if (!db[jid]) db[jid] = {}

            // تصفير نقاط جميع الأعضاء
            for (let user in db[jid]) {
                db[jid][user] = 0
            }
            
            saveDB(db)

            let reply = `╭───〔 🎤 *لوحة النشاط* 〕───⬡
┃ ✨ *تصفير النقاط*
╰───────────────────────⬡

✅ تم تصفير بيانات لوحة النشاط.
📉 أصبحت نقاط جميع الأعضاء **0**.
📊 يمكن بدء المنافسة من جديد.

╭───────────────────────⬡
┃ ✨ MUSASHI
╰───────────────────────⬡`
            
            return m.reply(reply)
        }

    } catch (err) {
        console.error('[RESET TOPAKTIF ERROR]', err)
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
