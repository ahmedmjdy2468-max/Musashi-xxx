const { getDatabase } = require('../../src/lib/database')
const config = require('../../config')
const timeHelper = require('../../src/lib/timeHelper')
const cron = require('node-cron')
const path = require('path')
const fs = require('fs')

const pluginConfig = {
    name: 'giveaway',
    alias: ['ga', 'gaway'],
    category: 'group',
    description: 'النظام giveaway لـ المجموعة',
    usage: '.giveaway <start/end/join/list/delete/reroll/notifadmin>',
    example: '.giveaway start',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    isAdmin: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

const CLEANUP_DELAY = 3 * 24 * 60 * 60 * 1000
const pendingGiveaway = new Map()

// Cache gambar giveaway sekali di memory — hindari readFileSync berulang
let cachedGiveawayImage = null
let imageLoaded = false

async function loadGiveawayImageOnce() {
    if (imageLoaded) return cachedGiveawayImage
    imageLoaded = true
    try {
        const { getAssetBuffer } = require('../../src/lib/assetManager')
        cachedGiveawayImage = (await getAssetBuffer('images.giveaway')) || (await getAssetBuffer('images.itsuki'))
        return cachedGiveawayImage
    } catch (e) {
        console.error('[Giveaway] فشل load الصورة:', e.message)
    }
    return null
}

function generateGiveawayId() {
    const random = Math.random().toString(36).substring(2, 8).toUpperCase()
    return `GA-${random}`
}

function parseTime(timeStr) {
    const regex = /(\d+)([smhd])/g
    let totalMs = 0
    let match
    
    while ((match = regex.exec(timeStr)) !== null) {
        const value = parseInt(match[1])
        const unit = match[2]
        
        if (unit === 's') totalMs += value * 1000
        if (unit === 'm') totalMs += value * 60 * 1000
        if (unit === 'h') totalMs += value * 60 * 60 * 1000
        if (unit === 'd') totalMs += value * 24 * 60 * 60 * 1000
    }
    
    return totalMs
}

function formatDuration(ms) {
    const seconds = Math.floor(ms / 1000)
    const minutes = Math.floor(seconds / 60)
    const hours = Math.floor(minutes / 60)
    const days = Math.floor(hours / 24)
    
    if (days > 0) return `${days} يوم ${hours % 24} jam`
    if (hours > 0) return `${hours} jam ${minutes % 60} دقيقة`
    if (minutes > 0) return `${minutes} دقيقة`
    return `${seconds} ثانية`
}

async function getGiveawayImage() {
    return await loadGiveawayImageOnce()
}

function extractAdminJid(input, mentionedJid) {
    if (mentionedJid && mentionedJid.length > 0) {
        return mentionedJid[0]
    }
    const match = input?.match(/@(\d+)/)
    if (match) {
        return `${match[1]}@s.whatsapp.net`
    }
    const numberMatch = input?.match(/(\d{10,15})/)
    if (numberMatch) {
        return `${numberMatch[1]}@s.whatsapp.net`
    }
    return null
}

function buildGiveawayMessage(giveaway, participantCount = 0, prefix = '.') {
    const endTimeFormatted = timeHelper.fromTimestamp(giveaway.endTime, 'DD/MM/YYYY HH:mm')
    const remaining = giveaway.endTime - Date.now()
    const remainingText = remaining > 0 ? formatDuration(remaining) : 'Berakhir'
    const adminTag = giveaway.adminJid ? `@${giveaway.adminJid.split('@')[0]}` : 'Creator'
    
    return `🎉 *ɢɪᴠᴇᴀᴡᴀʏ*

╭┈┈⬡「 🎁 *${giveaway.title}* 」
┃ 🏆 الجائزة: *${giveaway.prizeName || 'Hadiah Spesial'}*
┃ 📝 ᴅᴇsᴋ: _${giveaway.description}_
╰┈┈⬡

╭┈┈⬡「 📋 *ɪɴꜰᴏ* 」
┃ 👥 الفائز: \`${giveaway.winners} أعضاء\`
┃ 👤 ᴘᴇsᴇʀᴛᴀ: \`${participantCount} أعضاء\`
┃ ⏰ ʙᴇʀᴀᴋʜɪʀ: \`${endTimeFormatted}\`
┃ 🕕 sɪsᴀ: \`${remainingText}\`
┃ 👮 مشرف: ${adminTag}
┃ 🆔 ɪᴅ: \`${giveaway.giveawayId}\`
╰┈┈⬡

> *طريقة Ikut:*
> اكتب \`${prefix}giveaway join ${giveaway.giveawayId}\`

> _Good luck! 🍀_`
}

function buildWinnerMessage(giveaway, winners) {
    let winnerList = ''
    winners.forEach((w, i) => {
        winnerList += `┃ ${i + 1}. @${w.split('@')[0]}\n`
    })
    const adminTag = giveaway.adminJid ? `@${giveaway.adminJid.split('@')[0]}` : 'Creator'
    
    return `🎊 *ɢɪᴠᴇᴀᴡᴀʏ sᴇʟᴇsᴀɪ!*

╭┈┈⬡「 🎁 *${giveaway.title}* 」
┃ 🏆 الجائزة: *${giveaway.prizeName || 'Hadiah Spesial'}*
┃ 👮 مشرف: ${adminTag}
╰┈┈⬡

╭┈┈⬡「 🏅 *الفائز* 」
${winnerList}╰┈┈⬡

> 🎉 تهانينا kepada pemenang!
> Cek DM لـ detail جائزة.

> _ID: ${giveaway.giveawayId}_`
}

async function selectWinners(giveaway) {
    const participants = giveaway.participants || []
    const numWinners = Math.min(giveaway.winners, participants.length)
    const shuffled = [...participants].sort(() => Math.random() - 0.5)
    return shuffled.slice(0, numWinners)
}

async function endGiveaway(giveawayId, sock, db) {
    const giveaways = db.setting('giveaways') || {}
    const giveaway = giveaways[giveawayId]
    
    if (!giveaway || giveaway.ended) return
    
    const participants = giveaway.participants || []
    const notifAdmin = db.setting('giveawayNotifAdmin') ?? true
    const imageBuffer = await getGiveawayImage()
    
    if (participants.length === 0) {
        await sock.sendMessage(giveaway.chatId, {
            text: `❌ *ɢɪᴠᴇᴀᴡᴀʏ ʙᴇʀᴀᴋʜɪʀ*\n\n` +
                `> ID: \`${giveawayId}\`\n` +
                `> الحالة: غير موجود peserta\n\n` +
                `> _Giveaway dibatalkan._`
        })
        
        if (notifAdmin && giveaway.adminJid) {
            try {
                await sock.sendMessage(giveaway.adminJid, {
                    text: `❌ *ɢɪᴠᴇᴀᴡᴀʏ ʙᴇʀᴀᴋʜɪʀ*\n\n` +
                        `> ID: \`${giveawayId}\`\n` +
                        `> Title: ${giveaway.title}\n` +
                        `> الحالة: غير موجود peserta\n\n` +
                        `> _Giveaway dibatalkan._`
                })
            } catch (e) {}
        }
        
        giveaway.ended = true
        giveaway.endedAt = Date.now()
        db.setting('giveaways', giveaways)
        return
    }
    
    const winners = await selectWinners(giveaway)
    const winnerMsg = buildWinnerMessage(giveaway, winners)
    const mentions = giveaway.adminJid ? [...winners, giveaway.adminJid] : winners
    
    if (imageBuffer) {
        await sock.sendMessage(giveaway.chatId, {
            image: imageBuffer,
            caption: winnerMsg,
            mentions
        })
    } else {
        await sock.sendMessage(giveaway.chatId, {
            text: winnerMsg,
            mentions
        })
    }
    
    for (const winner of winners) {
        try {
            await sock.sendMessage(winner, {
                text: `🎉 *sᴇʟᴀᴍᴀᴛ!*\n\n` +
                    `> أنت memenangkan giveaway!\n\n` +
                    `╭┈┈⬡「 📋 *التفاصيل* 」\n` +
                    `┃ 🎁 ᴛɪᴛʟᴇ: \`${giveaway.title}\`\n` +
                    `┃ 🏆 الجائزة: *${giveaway.prizeName}*\n` +
                    `┃ 🆔 ɪᴅ: \`${giveawayId}\`\n` +
                    `╰┈┈⬡\n\n` +
                    `╭┈┈⬡「 🎁 *التفاصيل الجائزة* 」\n` +
                    `${giveaway.prizeDetails || 'Hubungi admin untuk detail'}\n` +
                    `╰┈┈⬡\n\n` +
                    `> _Ini informasi resmi dari bot._`
            })
        } catch (e) {}
    }
    
    if (notifAdmin && giveaway.adminJid) {
        try {
            let winnerListText = ''
            winners.forEach((w, i) => {
                winnerListText += `${i + 1}. @${w.split('@')[0]}\n`
            })
            
            await sock.sendMessage(giveaway.adminJid, {
                text: `🎊 *ɴᴏᴛɪꜰ ɢɪᴠᴇᴀᴡᴀʏ*\n\n` +
                    `> Giveaway telah berakhir!\n\n` +
                    `╭┈┈⬡「 📋 *التفاصيل* 」\n` +
                    `┃ 🎁 ᴛɪᴛʟᴇ: \`${giveaway.title}\`\n` +
                    `┃ 🏆 الجائزة: \`${giveaway.prize}\`\n` +
                    `┃ 👥 ᴘᴇsᴇʀᴛᴀ: \`${participants.length}\`\n` +
                    `┃ 🆔 ɪᴅ: \`${giveawayId}\`\n` +
                    `╰┈┈⬡\n\n` +
                    `╭┈┈⬡「 🏅 *الفائز* 」\n` +
                    `${winnerListText}╰┈┈⬡\n\n` +
                    `> _Ini notifikasi resmi dari bot._`,
                mentions: winners
            })
        } catch (e) {}
    }
    
    giveaway.ended = true
    giveaway.endedAt = Date.now()
    giveaway.winnerList = winners
    db.setting('giveaways', giveaways)
}

async function handler(m, { sock, args: rawArgs }) {
    const db = getDatabase()
    const args = rawArgs || m.args || []
    const action = args[0]?.toLowerCase() || ''
    const prefix = m.prefix || '.'
    const botConfig = config
    
    let giveaways = db.setting('giveaways') || {}
    
    if (action === '--confirm' && args[1]) {
        const targetGroupId = args[1]
        const pendingData = pendingGiveaway.get(m.sender)
        
        if (!pendingData) {
            return m.reply(`⚠️ *غير موجود data pending. رجاءً buat giveaway ulang.*`)
        }
        
        try {
            let groupName = 'المجموعة'
            try {
                const meta = await sock.groupMetadata(targetGroupId)
                groupName = meta.subject
            } catch (e) {}
            
            await m.reply(`🕕 *Memposting giveaway ke ${groupName}...*`)
            
            const giveawayId = generateGiveawayId()
            const endTime = Date.now() + pendingData.duration
            
            const giveaway = {
                giveawayId,
                chatId: targetGroupId,
                title: pendingData.title,
                prizeName: pendingData.prizeName,
                prizeDetails: pendingData.prizeDetails,
                description: pendingData.description,
                winners: pendingData.winners,
                endTime,
                creatorId: m.sender,
                adminJid: pendingData.adminJid || m.sender,
                participants: [],
                ended: false,
                createdAt: Date.now()
            }
            
            giveaways[giveawayId] = giveaway
            db.setting('giveaways', giveaways)
            
            const giveawayText = buildGiveawayMessage(giveaway, 0, prefix)
            const imageBuffer = await getGiveawayImage()
            
            const saluranId = botConfig.saluran?.id || '120363432546133683@newsletter'
            const saluranName = botConfig.saluran?.name || botConfig.bot?.name || 'MUSASHI'
            
            const contextInfo = {
                mentionedJid: [m.sender, giveaway.adminJid],
                forwardingScore: 9999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: saluranId,
                    newsletterName: saluranName,
                    serverMessageId: 127
                }
            }
            
            if (imageBuffer) {
                await sock.sendMessage(targetGroupId, {
                    image: imageBuffer,
                    caption: giveawayText,
                    contextInfo
                })
            } else {
                await sock.sendMessage(targetGroupId, {
                    text: giveawayText,
                    contextInfo
                })
            }
            

            
            const successMsg = `✅ *ɢɪᴠᴇᴀᴡᴀʏ ᴅɪᴘᴏsᴛ*

╭┈┈⬡「 📋 *التفاصيل* 」
┃ 🆔 ɪᴅ: \`${giveawayId}\`
┃ 🏠 المجموعة: *${groupName}*
┃ 🎁 ᴛɪᴛʟᴇ: \`${pendingData.title}\`
┃ 🏆 الجائزة: *${pendingData.prizeName}*
┃ ⏱️ ᴅᴜʀᴀsɪ: \`${formatDuration(pendingData.duration)}\`
╰┈┈⬡

> _Giveaway بنجاح diposting!_
> _Detail جائزة فقط سوف dikirim إلى pemenang._`
            
            await m.reply(successMsg)
            pendingGiveaway.delete(m.sender)
            m.react('🎉')
            
        } catch (error) {
        console.error("[MUSASHI][plugins_legacy/group/giveaway.js] exception", error?.stack || error);
            await m.reply(
                "حدث خطأ، حاول لاحقاً"
            )
        }
        return
    }
    
    if (!action) {
        return m.reply(
            `🎉 *ɢɪᴠᴇᴀᴡᴀʏ sʏsᴛᴇᴍ*\n\n` +
            `╭┈┈⬡「 📋 *الأمرs* 」\n` +
            `┃ 🎁 \`${prefix}giveaway start\`\n` +
            `┃    _Buat giveaway (private only)_\n` +
            `┃\n` +
            `┃ 🎫 \`${prefix}giveaway join <id>\`\n` +
            `┃    _شارك في السحب_\n` +
            `┃\n` +
            `┃ 📋 \`${prefix}giveaway list\`\n` +
            `┃    _Lihat giveaway aktif_\n` +
            `┃\n` +
            `┃ 🏁 \`${prefix}giveaway end <id>\`\n` +
            `┃    _Akhiri giveaway_\n` +
            `┃\n` +
            `┃ 🎲 \`${prefix}giveaway reroll <id>\`\n` +
            `┃    _اختر ulang pemenang_\n` +
            `┃\n` +
            `┃ 🗑️ \`${prefix}giveaway delete <id>\`\n` +
            `┃    _Hapus giveaway_\n` +
            `┃\n` +
            `┃ 🔔 \`${prefix}giveaway notifadmin\`\n` +
            `┃    _Toggle notifikasi مشرف_\n` +
            `╰┈┈⬡\n\n` +
            `> _مثال: ${prefix}giveaway start_`
        )
    }
    
    if (action === 'notifadmin') {
        if (!m.isAdmin && !m.isOwner) {
            return m.reply(`⚠️ *ᴀᴋsᴇs ᴅɪᴛᴏʟᴀᴋ*\n\n> فقط مشرف الذي يمكن mengatur notifikasi.`)
        }
        
        const subAction = args[1]?.toLowerCase()
        const current = db.setting('giveawayNotifAdmin') ?? true
        
        if (subAction === 'on') {
            db.setting('giveawayNotifAdmin', true)
            m.react('✅')
            return m.reply(`✅ *ɴᴏᴛɪꜰ مشرف ᴀᴋᴛɪꜰ*\n\n> المشرف سوف menerima DM pemenang giveaway.`)
        }
        
        if (subAction === 'off') {
            db.setting('giveawayNotifAdmin', false)
            m.react('❌')
            return m.reply(`❌ *ɴᴏᴛɪꜰ مشرف ɴᴏɴᴀᴋᴛɪꜰ*\n\n> المشرف لا سوف menerima DM pemenang.`)
        }
        
        return m.reply(
            `🔔 *ɴᴏᴛɪꜰ مشرف ɢɪᴠᴇᴀᴡᴀʏ*\n\n` +
            `> الحالة: \`${current ? 'ON ✅' : 'OFF ❌'}\`\n\n` +
            `> \`${prefix}giveaway notifadmin on\` - Aktifkan\n` +
            `> \`${prefix}giveaway notifadmin off\` - Nonaktifkan\n\n` +
            `> _Jika مفعّل, مشرف giveaway سوف\n> menerima DM القائمة pemenang._`
        )
    }
    
    if (action === 'start' || action === 'create' || action === 'new') {
        if (m.isGroup) {
            return m.reply(
                `⚠️ *خاص ᴏɴʟʏ*\n\n` +
                `> الأمر هذا يعمل في الخاص فقط chat.\n` +
                `> رجاءً chat البوت secara langsung.`
            )
        }
        
        if (!m.isAdmin && !m.isOwner) {
            return m.reply(`⚠️ *ᴀᴋsᴇs ᴅɪᴛᴏʟᴀᴋ*\n\n> فقط مشرف/owner الذي يمكن membuat giveaway.`)
        }
        
        const fullText = m.text || args.slice(1).join(' ')
        const firstPipe = fullText.indexOf('|')
        const input = firstPipe > -1 ? fullText : args.slice(1).join(' ')
        
        if (!input || !input.includes('|')) {
            return m.reply(
                `🎉 *ʙᴜᴀᴛ ɢɪᴠᴇᴀᴡᴀʏ*\n\n` +
                `> *Format:*\n` +
                `> \`${prefix}giveaway start <title>|<desk>|<pemenang>|<المدة>|<nama_hadiah>|<detail_hadiah>\`\n\n` +
                `> *مثال:*\n` +
                `> \`${prefix}giveaway start Event FF|Spesial merdeka|1|1d|Akun Free Fire|Email: xxx@mail.com\nPassword: 123456\`\n\n` +
                `> *Format المدة:*\n` +
                `> \`1m\` = 1 menit, \`1h\` = 1 jam, \`1d\` = 1 hari\n\n` +
                `> *Note:*\n` +
                `> - nama_hadiah: tampil في المجموعة (publik)\n` +
                `> - detail_hadiah: فقط dikirim إلى pemenang (rahasia)`
            )
        }
        
        const parts = input.split('|')
        
        if (parts.length < 6) {
            return m.reply(
                `⚠️ *ᴠᴀʟɪᴅᴀsɪ فشل*\n\n` +
                `> الصيغة لا lengkap!\n` +
                `> Butuh 6 parameter:\n` +
                `> \`title|desk|pemenang|المدة|nama_hadiah|detail_hadiah\`\n\n` +
                `> - nama_hadiah: tampil في المجموعة\n` +
                `> - detail_hadiah: rahasia لـ pemenang`
            )
        }
        
        const title = parts[0].trim()
        const description = parts[1].trim()
        const winnersStr = parts[2].trim()
        const timeStr = parts[3].trim()
        const prizeName = parts[4].trim()
        
        const firstFiveParts = parts.slice(0, 5).join('|')
        const prizeDetailsRaw = input.substring(firstFiveParts.length + 1)
        const prizeDetails = prizeDetailsRaw.trim() || 'Hubungi مشرف لـ detail'
        
        const winners = parseInt(winnersStr)
        const duration = parseTime(timeStr)
        
        if (isNaN(winners) || winners < 1) {
            return m.reply(
                `⚠️ *ᴠᴀʟɪᴅᴀsɪ فشل*\n\n` +
                `> كمية pemenang يجب angka minimal 1!`
            )
        }
        
        if (duration <= 0) {
            return m.reply(
                `⚠️ *ᴠᴀʟɪᴅᴀsɪ فشل*\n\n` +
                `> Format المدة خاطئ!\n` +
                `> استخدم: \`1m\`, \`1h\`, أو \`1d\``
            )
        }
        
        pendingGiveaway.set(m.sender, {
            title,
            prizeName,
            prizeDetails,
            description,
            winners,
            duration,
            adminJid: m.sender,
            timestamp: Date.now()
        })
        
        try {
            global.isFetchingGroups = true
            const groups = await sock.groupFetchAllParticipating()
            global.isFetchingGroups = false
            const groupList = Object.entries(groups)
            
            if (groupList.length === 0) {
                pendingGiveaway.delete(m.sender)
                return m.reply(`⚠️ *البوت لا berada في المجموعة manapun.*`)
            }
            
            const groupRows = groupList.map(([id, meta]) => ({
                title: meta.subject || 'Unknown المجموعة',
                description: `${meta.participants?.length || 0} members`,
                id: `${prefix}giveaway --confirm ${id}`
            }))
            
            const thumbnail = await loadGiveawayImageOnce()

await sock.sendButton(
    m.chat,
    thumbnail,
    `🎉 *ᴘɪʟɪʜ المجموعة ᴜɴᴛᴜᴋ ɢɪᴠᴇᴀᴡᴀʏ*\n\n` +
    `╭┈┈⬡「 📋 *التفاصيل* 」\n` +
    `┃ 🎁 ᴛɪᴛʟᴇ: \`${title}\`\n` +
    `┃ 🏆 الجائزة: *${prizeName}*\n` +
    `┃ 👥 الفائز: \`${winners} أعضاء\`\n` +
    `┃ ⏱️ ᴅᴜʀᴀsɪ: \`${formatDuration(duration)}\`\n` +
    `╰┈┈⬡\n\n` +
    `> Total المجموعة: *${groupList.length}*\n` +
    `> _اختر المجموعة dari daftar في الأسفل:_`,
    m,
    {
        type: 'image',
        contextInfo: {
            isForwarded: true,
            forwardingScore: 999,
            forwardedNewsletterMessageInfo: {
                newsletterJid: botConfig.saluran?.id,
                newsletterName: botConfig.saluran?.name
            }
        },
        footer: botConfig.bot?.name || 'MUSASHI',
        buttons: [
            {
                name: 'single_select',
                buttonParamsJson: JSON.stringify({
                    title: '🏠 اختر المجموعة المستهدفة',
                    sections: [{
                        title: 'Daftar المجموعة',
                        rows: groupRows
                    }]
                })
            },
            {
                name: 'quick_reply',
                buttonParamsJson: JSON.stringify({
                    display_text: '❌ Batal',
                    id: `${prefix}cancelga`
                })
            }
        ]
    }
)
            
        } catch (error) {
        console.error("[MUSASHI][plugins_legacy/group/giveaway.js] exception", error?.stack || error);
            pendingGiveaway.delete(m.sender)
            await m.reply(
                "حدث خطأ، حاول لاحقاً"
            )
        }
        return
    }
    
    if (action === 'join' || action === 'ikut') {
        if (!m.isGroup) {
            return m.reply(`⚠️ *للمجموعات فقط*\n\n> هذا الأمر يعمل داخل المجموعات فقط.`)
        }
        
        const giveawayId = args[1]?.toUpperCase()
        
        if (!giveawayId) {
            const activeGiveaways = Object.values(giveaways).filter(g => 
                g.chatId === m.chat && !g.ended && g.endTime > Date.now()
            )
            
            if (activeGiveaways.length === 0) {
                return m.reply(
                    `⚠️ *غير موجود ɢɪᴠᴇᴀᴡᴀʏ*\n\n` +
                    `> غير موجود giveaway مفعّل في المجموعة هذا.`
                )
            }
            
            if (activeGiveaways.length === 1) {
                const ga = activeGiveaways[0]
                
                if (ga.participants.includes(m.sender)) {
                    return m.reply(
                        `⚠️ *sᴜᴅᴀʜ ᴛᴇʀᴅᴀꜰᴛᴀʀ*\n\n` +
                        `> لقد شاركت في هذا السحب بالفعل!`
                    )
                }
                
                ga.participants.push(m.sender)
                db.setting('giveaways', giveaways)
                
                m.react('✅')
                return m.reply(
                    `✅ *نجح ɪᴋᴜᴛ!*\n\n` +
                    `╭┈┈⬡「 📋 *التفاصيل* 」\n` +
                    `┃ 🎁 ᴛɪᴛʟᴇ: \`${ga.title}\`\n` +
                    `┃ 🏆 الجائزة: \`${ga.prize}\`\n` +
                    `┃ 👤 ᴘᴇsᴇʀᴛᴀ ᴋᴇ: \`${ga.participants.length}\`\n` +
                    `╰┈┈⬡\n\n` +
                    `> _Good luck! 🍀_`
                )
            }
            
            return m.reply(
                `⚠️ *ᴘɪʟɪʜ ɢɪᴠᴇᴀᴡᴀʏ*\n\n` +
                `> Ada ${activeGiveaways.length} giveaway aktif.\n` +
                `> استخدم: \`${prefix}giveaway join <id>\``
            )
        }
        
        const giveaway = giveaways[giveawayId]
        
        if (!giveaway) {
            return m.reply(
                `⚠️ *غير موجود*\n\n` +
                `> Giveaway مع المعرّف ${giveawayId}\` غير موجود.`
            )
        }
        
        if (giveaway.chatId !== m.chat) {
            return m.reply(
                `⚠️ *ɢɪᴠᴇᴀᴡᴀʏ ʙᴜᴋᴀɴ ᴅɪ المجموعة ɪɴɪ*\n\n` +
                `> Giveaway هذا من المجموعة lain.`
            )
        }
        
        if (giveaway.ended) {
            return m.reply(
                `⚠️ *ɢɪᴠᴇᴀᴡᴀʏ ʙᴇʀᴀᴋʜɪʀ*\n\n` +
                `> Giveaway هذا تم berakhir.`
            )
        }
        
        if (giveaway.endTime < Date.now()) {
            return m.reply(
                `⚠️ *الوقت ʜᴀʙɪs*\n\n` +
                `> الوقت giveaway تم habis.`
            )
        }
        
        if (giveaway.participants.includes(m.sender)) {
            return m.reply(
                `⚠️ *sᴜᴅᴀʜ ᴛᴇʀᴅᴀꜰᴛᴀʀ*\n\n` +
                `> لقد شاركت في هذا السحب بالفعل!`
            )
        }
        
        giveaway.participants.push(m.sender)
        db.setting('giveaways', giveaways)
        
        m.react('✅')
        return m.reply(
            `✅ *نجح ɪᴋᴜᴛ!*\n\n` +
            `╭┈┈⬡「 📋 *التفاصيل* 」\n` +
            `┃ 🎁 ᴛɪᴛʟᴇ: \`${giveaway.title}\`\n` +
            `┃ 🏆 الجائزة: \`${giveaway.prize}\`\n` +
            `┃ 👤 ᴘᴇsᴇʀᴛᴀ ᴋᴇ: \`${giveaway.participants.length}\`\n` +
            `╰┈┈⬡\n\n` +
            `> _Good luck! 🍀_`
        )
    }
    
    if (action === 'list' || action === 'cek') {
        if (!m.isGroup) {
            return m.reply(`⚠️ *للمجموعات فقط*\n\n> هذا الأمر يعمل داخل المجموعات فقط.`)
        }
        
        const activeGiveaways = Object.values(giveaways).filter(g => 
            g.chatId === m.chat && !g.ended && g.endTime > Date.now()
        )
        
        if (activeGiveaways.length === 0) {
            return m.reply(
                `📋 *ᴅᴀꜰᴛᴀʀ ɢɪᴠᴇᴀᴡᴀʏ*\n\n` +
                `> غير موجود giveaway مفعّل في المجموعة هذا.\n\n` +
                `> Buat جديد: \`${prefix}giveaway start\` (di private)`
            )
        }
        
        let text = `📋 *ᴅᴀꜰᴛᴀʀ ɢɪᴠᴇᴀᴡᴀʏ ᴀᴋᴛɪꜰ*\n\n`
        
        activeGiveaways.forEach((g, i) => {
            const remaining = formatDuration(g.endTime - Date.now())
            text += `╭┈┈⬡「 ${i + 1}. *${g.title}* 」\n`
            text += `┃ 🆔 ɪᴅ: \`${g.giveawayId}\`\n`
            text += `┃ 🏆 الجائزة: \`${g.prize}\`\n`
            text += `┃ 👥 ᴘᴇsᴇʀᴛᴀ: \`${g.participants.length}\`\n`
            text += `┃ 🕕 sɪsᴀ: \`${remaining}\`\n`
            text += `╰┈┈⬡\n\n`
        })
        
        text += `> Join: \`${prefix}giveaway join <id>\``
        
        return m.reply(text)
    }
    
    if (action === 'end' || action === 'stop') {
        const giveawayId = args[1]?.toUpperCase()
        
        if (!giveawayId) {
            return m.reply(
                `⚠️ *ᴠᴀʟɪᴅᴀsɪ فشل*\n\n` +
                `> استخدم: \`${prefix}giveaway end <id>\``
            )
        }
        
        const giveaway = giveaways[giveawayId]
        
        if (!giveaway) {
            return m.reply(`⚠️ *غير موجود*\n\n> المعرّف ${giveawayId}\` غير موجود.`)
        }
        
        if (giveaway.creatorId !== m.sender && !m.isOwner) {
            return m.reply(`⚠️ *ʙᴜᴋᴀɴ ᴘᴇᴍʙᴜᴀᴛ*\n\n> فقط pembuat giveaway أو owner الذي يمكن mengakhiri.`)
        }
        
        if (giveaway.ended) {
            return m.reply(`⚠️ *sᴜᴅᴀʜ ʙᴇʀᴀᴋʜɪʀ*\n\n> Giveaway هذا تم berakhir.`)
        }
        
        await m.reply(`🕕 Mengakhiri giveaway و memilih pemenang...`)
        await endGiveaway(giveawayId, sock, db)
        
        m.react('✅')
        return
    }
    
    if (action === 'reroll') {
        const giveawayId = args[1]?.toUpperCase()
        
        if (!giveawayId) {
            return m.reply(
                `⚠️ *ᴠᴀʟɪᴅᴀsɪ فشل*\n\n` +
                `> استخدم: \`${prefix}giveaway reroll <id>\``
            )
        }
        
        const giveaway = giveaways[giveawayId]
        
        if (!giveaway) {
            return m.reply(`⚠️ *غير موجود*\n\n> المعرّف ${giveawayId}\` غير موجود.`)
        }
        
        if (giveaway.creatorId !== m.sender && !m.isOwner) {
            return m.reply(`⚠️ *ʙᴜᴋᴀɴ ᴘᴇᴍʙᴜᴀᴛ*\n\n> فقط pembuat أو owner الذي يمكن reroll.`)
        }
        
        if (!giveaway.ended) {
            return m.reply(`⚠️ *ʙᴇʟᴜᴍ ʙᴇʀᴀᴋʜɪʀ*\n\n> Giveaway هذا لم berakhir.`)
        }
        
        if (giveaway.participants.length === 0) {
            return m.reply(`⚠️ *غير موجود ᴘᴇsᴇʀᴛᴀ*\n\n> غير موجود peserta لـ في-reroll.`)
        }
        
        await m.reply(`🎲 Memilih ulang pemenang...`)
        
        const winners = await selectWinners(giveaway)
        const winnerMsg = buildWinnerMessage(giveaway, winners)
        const mentions = giveaway.adminJid ? [...winners, giveaway.adminJid] : winners
        
        await sock.sendMessage(giveaway.chatId, {
            text: `🎲 *ʀᴇʀᴏʟʟ الفائز*\n\n` + winnerMsg,
            mentions
        })
        
        const notifAdmin = db.setting('giveawayNotifAdmin') ?? true
        if (notifAdmin && giveaway.adminJid) {
            try {
                let winnerListText = ''
                winners.forEach((w, i) => {
                    winnerListText += `${i + 1}. @${w.split('@')[0]}\n`
                })
                
                await sock.sendMessage(giveaway.adminJid, {
                    text: `🎲 *ʀᴇʀᴏʟʟ ɢɪᴠᴇᴀᴡᴀʏ*\n\n` +
                        `> الفائز telah di-reroll!\n\n` +
                        `╭┈┈⬡「 📋 *التفاصيل* 」\n` +
                        `┃ 🎁 ᴛɪᴛʟᴇ: \`${giveaway.title}\`\n` +
                        `┃ 🆔 ɪᴅ: \`${giveawayId}\`\n` +
                        `╰┈┈⬡\n\n` +
                        `╭┈┈⬡「 🏅 *الفائز ʙᴀʀᴜ* 」\n` +
                        `${winnerListText}╰┈┈⬡`,
                    mentions: winners
                })
            } catch (e) {}
        }
        
        giveaway.winnerList = winners
        db.setting('giveaways', giveaways)
        
        m.react('🎲')
        return
    }
    
    if (action === 'delete' || action === 'hapus') {
        const giveawayId = args[1]?.toUpperCase()
        
        if (!giveawayId) {
            return m.reply(
                `⚠️ *ᴠᴀʟɪᴅᴀsɪ فشل*\n\n` +
                `> استخدم: \`${prefix}giveaway delete <id>\``
            )
        }
        
        const giveaway = giveaways[giveawayId]
        
        if (!giveaway) {
            return m.reply(`⚠️ *غير موجود*\n\n> المعرّف ${giveawayId}\` غير موجود.`)
        }
        
        if (giveaway.creatorId !== m.sender && !m.isOwner) {
            return m.reply(`⚠️ *ʙᴜᴋᴀɴ ᴘᴇᴍʙᴜᴀᴛ*\n\n> فقط pembuat أو owner الذي يمكن menghapus.`)
        }
        
        delete giveaways[giveawayId]
        db.setting('giveaways', giveaways)
        
        m.react('🗑️')
        return m.reply(
            `🗑️ *ɢɪᴠᴇᴀᴡᴀʏ ᴅɪʜᴀᴘᴜs*\n\n` +
            `> ID: \`${giveawayId}\`\n` +
            `> الحالة: تم الحذف بنجاح`
        )
    }
    
    return m.reply(
        `⚠️ *ᴀᴋsɪ لا ᴠᴀʟɪᴅ*\n\n` +
        `> استخدم: \`${prefix}giveaway\` لـ melihat القائمة الأمر.`
    )
}

let giveawayCheckerStarted = false

function startGiveawayChecker(sock) {
    if (giveawayCheckerStarted) return
    giveawayCheckerStarted = true

    cron.schedule('*/60 * * * * *', async () => {
        try {
            const db = getDatabase()
            const giveaways = db.setting('giveaways') || {}

            for (const [id, ga] of Object.entries(giveaways)) {
                if (ga.ended) continue
                if (ga.endTime && ga.endTime <= Date.now()) {
                    await endGiveaway(id, sock, db)
                }
            }
        } catch (e) {}
    })
}

module.exports = {
    config: pluginConfig,
    handler,
    startGiveawayChecker
}