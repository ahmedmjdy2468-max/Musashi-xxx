const { getDatabase } = require('../../src/lib/database')

const pluginConfig = {
    name: 'slowmode',
    alias: ['setslowmode'],
    category: 'group',
    description: 'يحدّد الفاصل بين رسائل أعضاء المجموعة، مع خيار تطبيقه على الأوامر فقط؛ للمشرفين.',
    usage: '.بطء_المحادثة <on/off/onlycommand> [الثواني]',
    example: '.بطء_المحادثة on 30',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    isAdmin: true,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

const lastMessageTime = new Map()

const PRESETS = {
    santai: 10,
    normal: 30,
    ketat: 60,
    superketat: 120,
    max: 300,
}

const MODES = {
    all: 'تُطبّق المهلة على الرسائل والأوامر',
    onlycommand: 'تُطبّق المهلة على الأوامر فقط، وتبقى الرسائل العادية متاحة',
}

const MODE_LABELS = { all: 'كل الرسائل والأوامر', onlycommand: 'الأوامر فقط' }
const PRESET_LABELS = { santai: 'هادئ', normal: 'عادي', ketat: 'مشدّد', superketat: 'مشدّد جداً', max: 'الحد الأقصى' }

async function handler(m, { sock }) {
    const db = getDatabase()
    const args = m.args || []
    const subCmd = args[0]?.toLowerCase()
    let groupData = db.getGroup(m.chat) || {}

    if (!subCmd || subCmd === 'status') {
        const sm = groupData.slowmode || {}
        const enabled = sm.enabled
        const delay = sm.delay || 30
        const mode = sm.mode || 'all'
        const presetList = Object.entries(PRESETS)
            .map(([name, sec]) => `  *بطء_المحادثة ${name}* — ${PRESET_LABELS[name]} (${sec} ثانية)`)
            .join('\n')

        return m.reply(
            `🐢 *إبطاء المحادثة*\n\n` +
            `الحالة: ${enabled ? `✅ مفعّل (${delay} ثانية)` : '❌ متوقف'}\n` +
            `الوضع: *${MODE_LABELS[mode] || MODE_LABELS.all}*\n\n` +
            `*طريقة الاستخدام:*\n` +
            `*.بطء_المحادثة on 30* — مهلة 30 ثانية بين الرسائل والأوامر\n` +
            `*.بطء_المحادثة onlycommand 30* — للأوامر فقط\n` +
            `*.بطء_المحادثة off* — إيقاف المهلة\n\n` +
            `*المدد الجاهزة:*\n${presetList}\n\n` +
            `*الأوضاع:*\n` +
            `  *all* — جميع الرسائل والأوامر\n` +
            `  *onlycommand* — الأوامر فقط\n\n` +
            `_لا يتأثر المشرفون ومالك البوت._`
        )
    }

    if (subCmd === 'off') {
        db.setGroup(m.chat, { ...groupData, slowmode: { enabled: false } })
        return m.reply('✅ أُوقفت مهلة إبطاء المحادثة.')
    }

    let mode = 'all'
    let delay
    let delayArg

    if (subCmd === 'onlycommand' || subCmd === 'oc') {
        mode = 'onlycommand'
        delayArg = args[1]
    } else if (subCmd === 'on' || subCmd === 'set') {
        delayArg = args[1]
    } else if (PRESETS[subCmd]) {
        delay = PRESETS[subCmd]
        mode = args[1]?.toLowerCase() === 'onlycommand' || args[1]?.toLowerCase() === 'oc'
            ? 'onlycommand' : 'all'
    } else {
        delay = parseInt(subCmd)
        if (isNaN(delay)) {
            return m.reply('❌ الصيغة غير صحيحة. استخدم .بطء_المحادثة on 30 أو .بطء_المحادثة onlycommand 30.')
        }
    }

    if (!delay) {
        if (delayArg && PRESETS[delayArg]) {
            delay = PRESETS[delayArg]
        } else {
            delay = parseInt(delayArg) || 30
        }
    }

    if (delay < 5 || delay > 600) {
        return m.reply('❌ يجب أن تكون المهلة بين 5 و600 ثانية.')
    }

    db.setGroup(m.chat, {
        ...groupData,
        slowmode: { enabled: true, delay, mode }
    })

    const presetName = Object.entries(PRESETS).find(([, v]) => v === delay)?.[0]
    const label = presetName ? ` (${presetName})` : ''
    const modeDesc = MODES[mode]

    await m.reply(
        `✅ *فُعّلت مهلة إبطاء المحادثة*\n\n` +
        `المهلة: *${delay} ثانية*${label}\n` +
        `الوضع: *${MODE_LABELS[mode] || MODE_LABELS.all}*\n` +
        `${modeDesc}\n\n` +
        `_لا يتأثر المشرفون ومالك البوت._`
    )
}

function checkSlowmode(m, sock, db) {
    if (!m.isGroup) return false

    const groupData = db.getGroup(m.chat) || {}
    if (!groupData.slowmode?.enabled) return false

    const sm = groupData.slowmode
    const mode = sm.mode || 'all'

    if (mode === 'onlycommand' && !m.isCommand) return false

    const delay = sm.delay || 30
    const key = `${m.chat}_${m.sender}`
    const now = Date.now()

    const lastTime = lastMessageTime.get(key) || 0
    const timePassed = (now - lastTime) / 1000

    if (timePassed < delay) {
        return { remaining: Math.ceil(delay - timePassed), mode }
    }

    lastMessageTime.set(key, now)

    if (lastMessageTime.size > 5000) {
        const cutoff = now - 600_000
        for (const [k, v] of lastMessageTime) {
            if (v < cutoff) lastMessageTime.delete(k)
        }
    }

    return false
}

module.exports = {
    config: pluginConfig,
    handler,
    checkSlowmode
}
