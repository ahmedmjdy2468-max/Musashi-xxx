const pluginConfig = {
    name: 'setdeskgc',
    alias: ['setdesc', 'setdescgc', 'setdeskripsi', 'setdesk'],
    category: 'group',
    description: "يضبط وصف المجموعة على النص الذي تدخله.",
    usage: ".ضبط_وصف_المجموعة <الوصف>",
    example: ".ضبط_وصف_المجموعة مجموعة الأصدقاء",
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    isAdmin: true,
    isBotAdmin: true,
    cooldown: 10,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const newDesc = m.text?.trim() || ''
    if (!m.text && m.args?.length === 0) {
        await m.reply(
            `⚠️ *طريقة الاستخدام*\n\n` +
            `> \`${m.prefix}setdeskgc Deskripsi جديد\`\n` +
            `> \`${m.prefix}setdeskgc clear\` - Hapus deskripsi`
        )
        return
    }
    const descToSet = newDesc.toLowerCase() === 'clear' ? '' : newDesc
    
    if (descToSet.length > 2048) {
        await m.reply(
            `⚠️ *ᴠᴀʟɪᴅᴀsɪ*\n\n` +
            `> Deskripsi maksimal 2048 حرفاً.`
        )
        return
    }
    
    try {
        await sock.groupUpdateDescription(m.chat, descToSet)
        
        if (descToSet) {
            await m.reply(
                `✅ *Yatta~* الوصف المجموعة بنجاح diperbarui~ ✨`
            )
        } else {
            await m.reply(
                `✅ *Yatta~* الوصف المجموعة تم الحذف بنجاح~ ✨`
            )
        }
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/group/setdeskgc.js] exception", error?.stack || error);
        await m.reply(
            "حدث خطأ، حاول لاحقاً"
        )
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
