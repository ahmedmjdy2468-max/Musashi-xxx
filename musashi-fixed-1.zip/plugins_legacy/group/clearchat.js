const pluginConfig = {
    name: ['clearchat', 'cc', 'cleangc', 'deletechat', 'delchat'],
    alias: [],
    category: 'group',
    description: 'يمسح سجل المحادثة المحلية في المجموعة من جهاز البوت؛ للمشرفين.',
    usage: '.مسح_المحادثة',
    example: '.مسح_المحادثة',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    isAdmin: true,
    isBotAdmin: true,
    cooldown: 60,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    m.react('🗑️')
    
    try {
        const now = Math.floor(Date.now() / 1000)
        
        await sock.chatModify({ 
            delete: true, 
            lastMessages: [{ 
                key: m.key, 
                messageTimestamp: m.messageTimestamp || now
            }] 
        }, m.chat)
        
        await m.reply(`✅ تم مسح سجل المحادثة المحلية بواسطة @${m.sender.split('@')[0]}.`, { mentions: [m.sender] })
        
    } catch (error) {
        try {
            await sock.chatModify({ 
                clear: { 
                    messages: [{ 
                        id: m.key.id, 
                        fromMe: m.key.fromMe,
                        timestamp: Math.floor(Date.now() / 1000)
                    }] 
                } 
            }, m.chat)
            
            await m.reply(`✅ تم مسح سجل المحادثة المحلية بواسطة @${m.sender.split('@')[0]}.`, { mentions: [m.sender] })
        } catch (e) {
        console.error("[MUSASHI][plugins_legacy/group/clearchat.js] exception", e?.stack || e);
            m.react('❌')
            m.reply("حدث خطأ، حاول لاحقاً")
        }
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
