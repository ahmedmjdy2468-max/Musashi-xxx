const config = require('../../config')
const { getDatabase } = require('../../src/lib/database')

const pluginConfig = {
    name: 'notifgantitag',
    alias: ['notiflabel', 'notiftag', 'labeltag'],
    category: 'group',
    description: 'Mengatur notifikasi perubahan label/tag member',
    usage: '.notifgantitag <on/off>',
    example: '.notifgantitag on',
    isGroup: true,
    isAdmin: true,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const db = getDatabase()
    const args = m.args || []
    const sub = args[0]?.toLowerCase()
    const sub2 = args[1]?.toLowerCase()
    const groupData = db.getGroup(m.chat) || {}
    const currentStatus = groupData.notifLabelChange === true
    
    if (sub === 'on' && sub2 === 'all') {
        if (!m.isOwner) {
            return m.reply(`❌ *لا، * للمالك فقط الذي يمكن menggunakan ميزة هذا~ 🥺`)
        }
        
        m.react('🕕')
        
        try {
            const groups = await sock.groupFetchAllParticipating()
            const groupIds = Object.keys(groups)
            let count = 0
            
            for (const groupId of groupIds) {
                db.setGroup(groupId, { notifLabelChange: true })
                count++
            }
            
            m.react('✅')
            return m.reply(
                `✅ *ɴᴏᴛɪꜰ ʟᴀʙᴇʟ ɢʟᴏʙᴀʟ ᴏɴ*\n\n` +
                `> Notifikasi غيّر label تم تفعيله في *${count}* المجموعة!`
            )
        } catch (err) {
        console.error("[MUSASHI][plugins_legacy/group/notifgantitag.js] exception", err?.stack || err);
            m.react('❌')
            return m.reply("حدث خطأ، حاول لاحقاً")
        }
    }
    
    if (sub === 'off' && sub2 === 'all') {
        if (!m.isOwner) {
            return m.reply(`❌ *لا، * للمالك فقط الذي يمكن menggunakan ميزة هذا~ 🥺`)
        }
        
        m.react('🕕')
        
        try {
            const groups = await sock.groupFetchAllParticipating()
            const groupIds = Object.keys(groups)
            let count = 0
            
            for (const groupId of groupIds) {
                db.setGroup(groupId, { notifLabelChange: false })
                count++
            }
            
            m.react('✅')
            return m.reply(
                `❌ *ɴᴏᴛɪꜰ ʟᴀʙᴇʟ ɢʟᴏʙᴀʟ ᴏꜰꜰ*\n\n` +
                `> Notifikasi غيّر label تم إيقافه في *${count}* المجموعة!`
            )
        } catch (err) {
        console.error("[MUSASHI][plugins_legacy/group/notifgantitag.js] exception", err?.stack || err);
            m.react('❌')
            return m.reply("حدث خطأ، حاول لاحقاً")
        }
    }
    
    if (sub === 'on') {
        if (currentStatus) {
            return m.reply(
                `⚠️ *ɴᴏᴛɪꜰ ʟᴀʙᴇʟ ᴀʟʀᴇᴀᴅʏ ᴀᴄᴛɪᴠᴇ*\n\n` +
                `> الحالة: *✅ مفعّل*\n` +
                `> Notifikasi غيّر label تم مفعّل في المجموعة هذا.\n\n` +
                `_استخدم \`${m.prefix}notifgantitag off\` لـ menonaktifkan._`
            )
        }
        db.setGroup(m.chat, { notifLabelChange: true })
        return m.reply(
            `✅ *ɴᴏᴛɪꜰ ʟᴀʙᴇʟ ᴀᴋᴛɪꜰ*\n\n` +
            `> Notifikasi perubahan label عضو بنجاح تم تفعيله!\n` +
            `> البوت سوف memberitahu ketika يوجد عضو الذي labelnya diganti.\n\n` +
            `_مثال: المشرف menambahkan tag "VIP" إلى عضو_`
        )
    }
    
    if (sub === 'off') {
        if (!currentStatus) {
            return m.reply(
                `⚠️ *ɴᴏᴛɪꜰ ʟᴀʙᴇʟ ᴀʟʀᴇᴀᴅʏ ɪɴᴀᴄᴛɪᴠᴇ*\n\n` +
                `> الحالة: *❌ متوقف*\n` +
                `> Notifikasi غيّر label تم متوقف في المجموعة هذا.\n\n` +
                `_استخدم \`${m.prefix}notifgantitag on\` لـ mengaktifkan._`
            )
        }
        db.setGroup(m.chat, { notifLabelChange: false })
        return m.reply(
            `❌ *ɴᴏᴛɪꜰ ʟᴀʙᴇʟ ɴᴏɴᴀᴋᴛɪꜰ*\n\n` +
            `> Notifikasi perubahan label عضو بنجاح تم إيقافه.`
        )
    }
    
    m.reply(
        `🏷️ *ɴᴏᴛɪꜰ ɢᴀɴᴛɪ ᴛᴀɢ/ʟᴀʙᴇʟ*\n\n` +
        `> الحالة: *${currentStatus ? '✅ ON' : '❌ OFF'}*\n\n` +
        `\`\`\`━━━ ᴘɪʟɪʜᴀɴ ━━━\`\`\`\n` +
        `> \`${m.prefix}notifgantitag on\` → Aktifkan\n` +
        `> \`${m.prefix}notifgantitag off\` → Nonaktifkan\n` +
        `> \`${m.prefix}notifgantitag on all\` → Global ON (owner)\n` +
        `> \`${m.prefix}notifgantitag off all\` → Global OFF (owner)\n\n` +
        `> 📋 *الميزة ini akan memberitahu saat:*\n` +
        `> • المشرف menambahkan label ke member\n` +
        `> • المشرف menghapus label dari member\n` +
        `> • Label member berubah`
    )
}

async function handleLabelChange(msg, sock) {
    try {
        const db = getDatabase()
        
        const protocolMessage = msg.message?.protocolMessage
        if (!protocolMessage) return false
        if (protocolMessage.type !== 30) return false
        
        const memberLabel = protocolMessage.memberLabel
        if (!memberLabel) return false
        
        const groupJid = msg.key.remoteJid
        if (!groupJid?.endsWith('@g.us')) return false
        
        const groupData = db.getGroup(groupJid) || {}
        
        const participant = msg.key.participant || msg.participant || 'Unknown'
        const label = memberLabel.label || ''
        
        const fs = require('fs')
        if (groupData.antitoxic && label && label.trim()) {
            try {
                const { isToxic, handleToxicMessage, DEFAULT_TOXIC_WORDS } = require('./antitoxic')
                const toxicWords = groupData.toxicWords || DEFAULT_TOXIC_WORDS
                const toxicCheck = isToxic(label, toxicWords)
                
                if (toxicCheck.toxic) {
                    await sock.sendText(groupJid, `Hei @${participant.split('@')[0]}, Tag أنت mengandung kata toxic !`, null, {
                        mentions: [participant],
                        contextInfo: {
                            mentionedJid: [participant],
                            forwardingScore: 99,
                            isForwarded: true,
                        },
                    })
                    return true
                }
            } catch {}
        }
        
        if (groupData.notifLabelChange !== true) return false
        
        let groupMeta = null
        try {
            groupMeta = await sock.groupMetadata(groupJid)
        } catch {}
        
        let notifText = ''
        
        if (label && label.trim()) {
            notifText = `🎉 @${participant.split('@')[0]} telah mengubah label menjadi *${label}*`
        } else {
            notifText = `🥗 @${participant.split('@')[0]} telah menghapus label`
        }

        console.log(notifText)
        
        await sock.sendText(groupJid, notifText, null, {
            mentions: [participant],
            contextInfo: {
                mentionedJid: [participant],
                forwardingScore: 99,
                isForwarded: true,
            },
        })
        
        return true
    } catch (error) {
        console.error('[NotifLabelChange] الخطأ:', error.message)
        return false
    }
}

module.exports = {
    config: pluginConfig,
    handler,
    handleLabelChange
}