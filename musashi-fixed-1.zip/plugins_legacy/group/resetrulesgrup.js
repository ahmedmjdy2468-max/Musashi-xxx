const { getDatabase } = require('../../src/lib/database')

const pluginConfig = {
    name: 'resetrulesgrup',
    alias: ['resetgrouprules'],
    category: 'group',
    description: 'للمشرف: يعيد قواعد المجموعة إلى الحالة الافتراضية.',
    usage: '.إعادة_قواعد_المجموعة',
    example: '.إعادة_قواعد_المجموعة',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    isAdmin: true,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m) {
    const db = getDatabase()
    
    db.setGroup(m.chat, { groupRules: null })
    
    m.reply(
        `✅ *أُعيدت قواعد المجموعة*\n` +
        `عادت قواعد المجموعة إلى الإعدادات الافتراضية.\n` +
        `اعرض القواعد عبر \`${m.prefix}قواعد_المجموعة\`.`
    )
}

module.exports = {
    config: pluginConfig,
    handler
}
