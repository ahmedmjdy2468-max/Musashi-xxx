const pluginConfig = {
    name: 'hapusabsen',
    alias: ['deleteabsen', 'tutupabsen', 'closeabsen', 'resetabsen'],
    category: 'group',
    description: 'للمشرف: ينهي جلسة تسجيل الحضور الحالية ويحذفها من المجموعة.',
    usage: '.إنهاء_الحضور',
    example: '.إنهاء_الحضور',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 10,
    energi: 0,
    isEnabled: true,
    isAdmin: true
}

if (!global.absensi) global.absensi = {}

async function handler(m) {
    const chatId = m.chat
    
    if (!global.absensi[chatId]) {
        return m.reply(
            `❌ *غير موجود الحضور*\n\n` +
            `> لا توجد جلسة حضور نشطة في هذه المجموعة.`
        )
    }
    
    const absen = global.absensi[chatId]
    const totalPeserta = absen.peserta.length
    
    delete global.absensi[chatId]
    
    await m.reply(
        `✅ *انتهت جلسة الحضور*\n\n` +
        `📝 التفاصيل: ${absen.keterangan}\n` +
        `👥 عدد الحاضرين: ${totalPeserta}\n\n` +
        `حُذفت الجلسة من المجموعة.`
    )
}

module.exports = {
    config: pluginConfig,
    handler
}
