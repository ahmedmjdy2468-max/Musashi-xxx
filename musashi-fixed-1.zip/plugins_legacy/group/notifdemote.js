const pluginConfig = {
    name: 'notifdemote',
    alias: [],
    category: 'group',
    description: 'للمشرف: يفعّل أو يوقف إشعار المجموعة عند خفض رتبة عضو.',
    usage: '.إشعار_تخفيض_الرتبة <تشغيل|إيقاف>',
    example: '.إشعار_تخفيض_الرتبة تشغيل',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock, db }) {
    if (!m.isAdmin && !m.isOwner) {
        return m.reply(`❌ هذا الخيار متاح لمشرفي المجموعة فقط.`)
    }
    
    const rawArg = m.args[0]?.toLowerCase()
    const args = rawArg === 'تشغيل' ? 'on' : rawArg === 'إيقاف' ? 'off' : rawArg
    const group = db.getGroup(m.chat) || {}
    
    if (!['on', 'off'].includes(args)) {
        const status = group.notifDemote === true ? '✅ مفعّل' : '❌ متوقف'
        return m.reply(`👤 *إشعار تخفيض الرتبة*\n\nالحالة: ${status}\n\nالاستخدام:\n\`${m.prefix}إشعار_تخفيض_الرتبة تشغيل\`\n\`${m.prefix}إشعار_تخفيض_الرتبة إيقاف\``)
    }
    
    if (args === 'on') {
        group.notifDemote = true
        db.setGroup(m.chat, group)
        return m.reply(`✅ فُعّل إشعار خفض رتبة العضو.`)
    }
    
    if (args === 'off') {
        group.notifDemote = false
        db.setGroup(m.chat, group)
        return m.reply(`❌ أُوقف إشعار خفض رتبة العضو.`)
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
