const pluginConfig = {
    name: 'cekonline',
    alias: ['checkonline', 'online', 'siapayangonline', 'whosonline'],
    category: 'group',
    description: 'يعرض حالات الحضور التي يرسلها واتساب لأعضاء المجموعة؛ قد لا تظهر حالة جميع الأعضاء.',
    usage: '.حالة_الأعضاء',
    example: '.حالة_الأعضاء',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 60,
    energi: 1,
    isEnabled: true
}

async function handler(m, { sock }) {
    m.react('🔍')
    
    try {
        const groupMetadata = m.groupMetadata
        const participants = m.groupMembers
        
        if (participants.length === 0) {
            m.react('❌')
            return m.reply('❌ تعذّر الحصول على قائمة أعضاء المجموعة.')
        }
        
        await m.reply(`🔍 *جارٍ فحص حالات الحضور*\n\n> طلب تحديث الحالة من ${participants.length} عضواً.\n> الوقت المتوقع: 5–10 ثوانٍ.`)
        
        const presences = {}
        
        const presenceHandler = (update) => {
            if (update.id === m.chat && update.presences) {
                for (const [jid, presence] of Object.entries(update.presences)) {
                    if (presence.lastKnownPresence === 'available' || 
                        presence.lastKnownPresence === 'composing' || 
                        presence.lastKnownPresence === 'recording') {
                        presences[jid] = presence.lastKnownPresence
                    }
                }
            }
        }
        
        sock.ev.on('presence.update', presenceHandler)
        
        const batchSize = 10
        for (let i = 0; i < participants.length; i += batchSize) {
            const batch = participants.slice(i, i + batchSize)
            await Promise.all(batch.map(p => 
                sock.presenceSubscribe(p.id).catch(() => {})
            ))
            await new Promise(resolve => setTimeout(resolve, 500))
        }
        
        await new Promise(resolve => setTimeout(resolve, 5000))
        
        sock.ev.off('presence.update', presenceHandler)
        
        const onlineMembers = Object.keys(presences)
        const mentions = onlineMembers
        
        let text = `📊 *حالات حضور الأعضاء*\n\n`
        text += `╭┈┈⬡「 📋 *معلومات المجموعة* 」\n`
        text += `┃ 👥 الاسم: *${groupMetadata.subject}*\n`
        text += `┃ 👤 إجمالي الأعضاء: \`${participants.length}\`\n`
        text += `┃ 🟢 الأعضاء الذين أرسلوا حالة حضور: \`${onlineMembers.length}\`\n`
        text += `╰┈┈⬡\n\n`
        
        if (onlineMembers.length === 0) {
            text += `> لم تصل حالة حضور متاحة من أعضاء المجموعة.\n`
            text += `> هذا لا يؤكد أن جميع الأعضاء غير متصلين.`
        } else {
            text += `╭┈┈⬡「 🟢 *حالات الحضور المتاحة* 」\n`
            
            let count = 0
            for (const jid of onlineMembers) {
                if (count >= 50) {
                    text += `┃ ... و${onlineMembers.length - 50} أعضاء آخرين\n`
                    break
                }
                const number = jid.split('@')[0]
                const participant = participants.find(p => p.id === jid)
                const isAdmin = participant?.admin === 'مشرف' || participant?.admin === 'superadmin'
                const adminBadge = isAdmin ? ' 👑' : ''
                
                let statusIcon = '🟢'
                if (presences[jid] === 'composing') statusIcon = '⌨️'
                if (presences[jid] === 'recording') statusIcon = '🎤'
                
                text += `┃ ${statusIcon} @${number}${adminBadge}\n`
                count++
            }
            
            text += `╰┈┈⬡\n\n`
            text += `> 🟢 متاح | ⌨️ يكتب | 🎤 يسجل مقطعاً صوتياً\n> الحالات بحسب تحديثات واتساب المتاحة للبوت.`
        }
        
        m.react('✅')
        await m.reply(text, { mentions: mentions })
        
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/group/cekonline.js] exception", error?.stack || error);
        m.react('❌')
        m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
