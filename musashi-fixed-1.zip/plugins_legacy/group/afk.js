const afkStorage = global.afkStorage || (global.afkStorage = new Map())

const pluginConfig = {
    name: 'afk',
    alias: ['away', 'brb', 'afkformat', 'afkhelp', 'afklist', 'afkremove'],
    category: 'group',
    description: 'Set الحالة AFK مع alasan و المدة opsional',
    usage: '.afk [--المدة] <alasan>',
    example: '.afk --2jam مجدداً meeting',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

// ── Storage helpers ────────────────────────────────────────────────────────

/**
 * Key: kalau di grup → "jid|groupId", kalau PM → "jid|global"
 */
function makeKey(jid, groupId = null) {
    return groupId ? `${jid}|${groupId}` : `${jid}|global`
}

function setAfkUser(jid, reason, groupId = null, expiresAt = null) {
    const key = makeKey(jid, groupId)
    afkStorage.set(key, {
        jid,
        groupId,
        reason: reason || 'غير موجود alasan',
        time: Date.now(),
        expiresAt,
        mentionLog: [] // [{sender, name, time}]
    })
}

function getAfkUser(jid, groupId = null) {
    // Cek per grup dulu, kalau tidak ada cek global
    if (groupId) {
        const groupKey = makeKey(jid, groupId)
        if (afkStorage.has(groupKey)) return afkStorage.get(groupKey)
    }
    const globalKey = makeKey(jid, null)
    if (afkStorage.has(globalKey)) return afkStorage.get(globalKey)
    return null
}

function removeAfkUser(jid, groupId = null) {
    if (groupId) afkStorage.delete(makeKey(jid, groupId))
    afkStorage.delete(makeKey(jid, null))
}

function isUserAfk(jid, groupId = null) {
    return !!getAfkUser(jid, groupId)
}

function addMentionLog(jid, groupId, senderJid, senderName) {
    const data = getAfkUser(jid, groupId)
    if (!data) return
    data.mentionLog.push({ sender: senderJid, name: senderName, time: Date.now() })
    // Max 10 log
    if (data.mentionLog.length > 10) data.mentionLog.shift()
}

function getAfkListInGroup(groupId) {
    const result = []
    for (const [key, data] of afkStorage.entries()) {
        if (data.groupId === groupId || data.groupId === null) {
            // Cek apakah expired
            if (data.expiresAt && Date.now() > data.expiresAt) {
                afkStorage.delete(key)
                continue
            }
            result.push(data)
        }
    }
    return result
}

// ── Time helpers ───────────────────────────────────────────────────────────

function formatDuration(ms) {
    const seconds = Math.floor(ms / 1000)
    const minutes = Math.floor(seconds / 60)
    const hours = Math.floor(minutes / 60)
    const days = Math.floor(hours / 24)
    const weeks = Math.floor(days / 7)
    const months = Math.floor(days / 30)

    if (months > 0) return `${months} bulan ${days % 30} يوم`
    if (weeks > 0) return `${weeks} minggu ${days % 7} يوم`
    if (days > 0) return `${days} يوم ${hours % 24} الساعة`
    if (hours > 0) return `${hours} الساعة ${minutes % 60} دقيقة`
    if (minutes > 0) return `${minutes} دقيقة ${seconds % 60} ثانية`
    return `${seconds} ثانية`
}

/**
 * Parse durasi dari string seperti --30menit, --2jam, --1hari, dll
 * Return: { ms: number|null, text: string (sisa teks), isYear: boolean }
 */
function parseDuration(text) {
    const durationRe = /^--(\d+)(ms|milidetik|detik|menit|jam|hari|minggu|bulan|tahun)\s*/i
    const match = text.trim().match(durationRe)
    if (!match) return { ms: null, text: text.trim(), isYear: false }

    const amount = parseInt(match[1])
    const unit = match[2].toLowerCase()
    const rest = text.trim().slice(match[0].length).trim()

    if (unit === 'tahun') return { ms: null, text: rest, isYear: true }

    const multipliers = {
        ms: 1, milidetik: 1,
        detik: 1000,
        menit: 60 * 1000,
        jam: 60 * 60 * 1000,
        hari: 24 * 60 * 60 * 1000,
        minggu: 7 * 24 * 60 * 60 * 1000,
        bulan: 30 * 24 * 60 * 60 * 1000
    }

    return { ms: amount * (multipliers[unit] || 1), text: rest, isYear: false }
}

// ── Handler ────────────────────────────────────────────────────────────────

async function handler(m, { sock }) {
    const rawText = m.text || ''
    const groupId = m.isGroup ? m.chat : null

    // ── .afkformat ────────────────────────────────────────────────────────
    if (m.command === 'afkformat' || m.command === 'afkhelp') {
        return m.reply(
            `💤 *Panduan ميزة AFK~* ✨\n\n` +
            `╭┈┈⬡「 📋 *الأمر* 」\n` +
            `┃ *Set AFK:*\n` +
            `┃ \`${m.prefix}afk <alasan>\`\n` +
            `┃ \`${m.prefix}afk --<المدة> <alasan>\`\n` +
            `┃\n` +
            `┃ *Lihat daftar AFK:*\n` +
            `┃ \`${m.prefix}afklist\` (مشرف only)\n` +
            `┃\n` +
            `┃ *إزالة حالة الغياب عن عضو:*\n` +
            `┃ \`${m.prefix}afkremove @user\` (owner only)\n` +
            `┃\n` +
            `┃ *Panduan ini:*\n` +
            `┃ \`${m.prefix}afkformat\`\n` +
            `╰┈┈┈┈┈┈┈┈⬡\n\n` +
            `╭┈┈⬡「 ⏱️ *ꜰᴏʀᴍᴀᴛ ᴅᴜʀᴀsɪ* 」\n` +
            `┃ \`--Xms\` atau \`--Xmilidetik\`\n` +
            `┃ \`--Xdetik\`\n` +
            `┃ \`--Xmenit\`\n` +
            `┃ \`--Xjam\`\n` +
            `┃ \`--Xhari\`\n` +
            `┃ \`--Xminggu\`\n` +
            `┃ \`--Xbulan\`\n` +
            `┃ ~\`--Xtahun\`~ (diluar المعقول 😂)\n` +
            `╰┈┈┈┈┈┈┈┈⬡\n\n` +
            `╭┈┈⬡「 📝 *ᴄᴏɴᴛᴏʜ* 」\n` +
            `┃ \`${m.prefix}afk مجدداً makan\`\n` +
            `┃ \`${m.prefix}afk --30menit istirahat\`\n` +
            `┃ \`${m.prefix}afk --2jam meeting\`\n` +
            `┃ \`${m.prefix}afk --1hari liburan\`\n` +
            `┃ \`${m.prefix}afk --1minggu\`\n` +
            `╰┈┈┈┈┈┈┈┈⬡\n\n` +
            `╭┈┈⬡「 ℹ️ *ɪɴꜰᴏ* 」\n` +
            `┃ تسري حالة الغياب في المجموعة الحالية فقط\n` +
            `┃ AFK di PM = صالح global\n` +
            `┃ أرسل رسالة apapun = AFK otomatis off\n` +
            `┃ البوت شكراً tau siapa الذي nyebut أنت\n` +
            `┃ خلال أنت AFK~ (max 10 log)\n` +
            `╰┈┈┈┈┈┈┈┈⬡\n\n` +
            `_"لا،  jangan تنسَ balik نعم."_ 💕🌸`
        )
    }

    
    if (m.command === 'afklist') {
        if (!m.isGroup) return m.reply(`لا،  الأمر هذا cuma يمكن dipakai في المجموعة فقط نعم~ 👥✨`)
        if (!m.isAdmin && !m.isOwner) return m.reply(`Muu~ هذا خاص بالمشرفين المجموعة فقط nee~ 👮‍♀️🌸`)

        const list = getAfkListInGroup(groupId)
        if (list.length === 0) return m.reply(`Yeay~ لا يوجد عضو في حالة غياب هنا~ الجميع نشط! ⭐💕`)

        let msg = `💤 *القائمة AFK في المجموعة هذا~* ✨\n\n`
        list.forEach((data, i) => {
            const expired = data.expiresAt ? ` (berakhir dalam ${formatDuration(data.expiresAt - Date.now())})` : ''
            msg += `${i + 1}. @${data.jid.split('@')[0]}\n`
            msg += `   > السبب: *${data.reason}*\n`
            msg += `   > Sejak: *${formatDuration(Date.now() - data.time)} الذي lalu*${expired}\n`
            msg += `   > Scope: *${data.groupId ? 'Grup ini' : 'Global'}*\n\n`
        })

        return m.reply(msg, { mentions: list.map(d => d.jid) })
    }

    // ── .afkremove @user ──────────────────────────────────────────────────
    if (m.command === 'afkremove') {
        if (!m.isOwner) return m.reply(`Muu~ هذا هذا الأمر للمالك فقط فقط lho~ 🌸`)

        const targets = m.mentionedJid || []
        if (targets.length === 0) return m.reply(`لا،  أشر إلى العضو أولاً~ مثال: \`${m.prefix}afkremove @user\` ✨`)

        const removed = []
        for (const jid of targets) {
            if (isUserAfk(jid, groupId)) {
                removeAfkUser(jid, groupId)
                removed.push(jid)
            }
        }

        if (removed.length === 0) return m.reply(`همم~ العضو الذي أشرت إليه لا يوجد الذي في حالة غياب~ 💕`)

        return m.reply(
            `✅ نجح hapus status AFK~ ⭐\n\n` +
            removed.map(j => `> @${j.split('@')[0]}`).join('\n'),
            { mentions: removed }
        )
    }

    // ── Set AFK ───────────────────────────────────────────────────────────
    const { ms, text: reason, isYear } = parseDuration(rawText)

    if (isYear) {
        return m.reply(
            `Hehe~ الذي صحيح فقط afk 1 سنة~ هذا غير معقول! 😂✨\n` +
            `لا يوجد الذي setahun AFK kali~ حاول استخدام المدة الذي wajar نعم~ 💕`
        )
    }

    const expiresAt = ms ? Date.now() + ms : null
    const finalReason = reason || 'غير موجود alasan'

    setAfkUser(m.sender, finalReason, groupId, expiresAt)

    let replyMsg =
        `💤 *AFK aktif~* ✨\n\n` +
        `> @${m.sender.split('@')[0]} الآن مرة أخرى AFK هنا~\n` +
        `> السبب: *${finalReason}*\n` +
        `> Scope: *${groupId ? 'هذه المجموعة فقط' : 'Global'}*`

    if (expiresAt) {
        replyMsg += `\n> المدة: *${formatDuration(ms)}*\n> Berakhir otomatis dalam *${formatDuration(ms)}*`
    }

    replyMsg += `\n\n_أرسل رسالة apapun لـ menonaktifkan AFK~_ 🌸`

    await m.reply(replyMsg, { mentions: [m.sender] })
}

// ── checkAfk (dipanggil dari handler.js) ──────────────────────────────────

async function checkAfk(m, sock) {
    const groupId = m.isGroup ? m.chat : null

    // Cek apakah sender sendiri lagi AFK
    const afkData = getAfkUser(m.sender, groupId)
    if (afkData) {
        // Skip kalau command afk/afklist/afkremove
        const skipCmds = ['afk', 'afklist', 'afkremove']
        if (m.isCommand && skipCmds.includes(m.command?.toLowerCase())) return

        // Cek expired
        if (afkData.expiresAt && Date.now() > afkData.expiresAt) {
            removeAfkUser(m.sender, groupId)
            return
        }

        removeAfkUser(m.sender, groupId)
        const duration = formatDuration(Date.now() - afkData.time)

        let backMsg =
            `👋 *تهانينا datang kembali~* ⭐\n\n` +
            `> @${m.sender.split('@')[0]} تم balik هنا!\n` +
            `> Durasi AFK: *${duration}*`

        // Mention log
        if (afkData.mentionLog && afkData.mentionLog.length > 0) {
            backMsg += `\n\n💬 *الذي nyebut-nyebut أنت خلال AFK:*\n`
            afkData.mentionLog.forEach(log => {
                backMsg += `> • ${log.name} — ${formatDuration(Date.now() - log.time)} الذي lalu\n`
            })
        }

        await m.reply(backMsg, { mentions: [m.sender] })
    }

    // Cek apakah ada yang di-mention dan sedang AFK
    if (m.mentionedJid && m.mentionedJid.length > 0) {
        const afkMentioned = []

        for (const mentioned of m.mentionedJid) {
            const mentionedAfk = getAfkUser(mentioned, groupId)
            if (!mentionedAfk) continue

            // Cek expired
            if (mentionedAfk.expiresAt && Date.now() > mentionedAfk.expiresAt) {
                removeAfkUser(mentioned, groupId)
                continue
            }

            // Catat ke mention log
            const senderName = m.pushName || m.sender.split('@')[0]
            addMentionLog(mentioned, groupId, m.sender, senderName)

            afkMentioned.push({ jid: mentioned, data: mentionedAfk })
        }

        if (afkMentioned.length === 0) return

        // Gabung semua jadi 1 pesan
        let msg = `💤 *Psst~ الذي أنت tag في حالة غياب~* 🌸\n\n`

        afkMentioned.forEach((entry, i) => {
            const duration = formatDuration(Date.now() - entry.data.time)
            const expiredInfo = entry.data.expiresAt
                ? ` (balik dalam ~${formatDuration(entry.data.expiresAt - Date.now())})`
                : ''

            msg += `${i + 1}. @${entry.jid.split('@')[0]}\n`
            msg += `   > السبب: *${entry.data.reason}*\n`
            msg += `   > Sejak: *${duration} الذي lalu*${expiredInfo}\n\n`
        })

        msg += `_Jangan diganggu أولاً نعم._ 💕`

        await m.reply(msg, { mentions: afkMentioned.map(e => e.jid) })
    }
}

module.exports = {
    config: pluginConfig,
    handler,
    checkAfk,
    getAfkUser,
    setAfkUser,
    removeAfkUser,
    isUserAfk
}
