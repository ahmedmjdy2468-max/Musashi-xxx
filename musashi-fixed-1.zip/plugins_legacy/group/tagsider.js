const fs = require('fs')
const path = require('path')

const pluginConfig = {
    name: 'tagsider',
    alias: ['tagnonaktif', 'panggilsider'],
    category: 'group',
    description: 'ينبّه أعضاء المجموعة الذين لم تُسجّل لهم مشاركة خلال فترة الرصد؛ للمشرفين فقط.',
    usage: '.منشن_غير_النشطين [رسالة]',
    example: '.منشن_غير_النشطين شاركونا الحديث',
    cooldown: 30,
    energi: 2,
    isGroup: true,
    isAdmin: true,
    isBotAdmin: true
}

async function handler(m, { sock }) {
    try {
        const jidGrup = m.chat
        const PERIODE_MENIT = 7 * 24 * 60
        const DB_PATH = path.join(__dirname, '../../database/other/sider.json')

        const textInput = m.text ? m.text.trim() : ''
        const pesanUser = textInput || 'لماذا أنتم صامتون؟ هيا نتحدث معاً.'

        if (!fs.existsSync(DB_PATH)) {
            return m.reply(
`🌸 *تنبيه موساشي* 🌸

🥺 قاعدة بيانات النشاط غير متاحة.
👉 أعد ضبط سجل النشاط أولاً باستخدام *.إعادة_فترة_رصد_النشاط*.

✨ بانتظارك!`
            )
        }

        const db = JSON.parse(fs.readFileSync(DB_PATH))
        const dataGrup = db[jidGrup] || {}

        if (!dataGrup.startDate) {
            return m.reply(
`💫 *لم يبدأ رصد النشاط في هذه المجموعة.*

😳 لا توجد فترة رصد مسجلة حالياً.
👉 ابدأ فترة الرصد باستخدام *.إعادة_فترة_رصد_النشاط*.

✨ بعد بدء الرصد يمكن معرفة الأعضاء غير النشطين.`
            )
        }

        const startDate = new Date(dataGrup.startDate)
        const sekarang = new Date()
        const selisihMs = sekarang - startDate
        const totalDetik = Math.floor(selisihMs / 1000)

        const sisaTotalDetik = Math.max(0, (PERIODE_MENIT * 60) - totalDetik)
        const periodeSelesai = sisaTotalDetik <= 0

        if (!periodeSelesai) {
            const sisaJam = Math.floor(sisaTotalDetik / 3600)
            const sisaMenit = Math.floor((sisaTotalDetik % 3600) / 60)

            const sisaWaktu = `${sisaJam.toString().padStart(2, '0')} ساعة و${sisaMenit.toString().padStart(2, '0')} دقيقة`

            return m.reply(
`⏳ *يرجى الانتظار* 😣

ما زالت فترة رصد النشاط مستمرة. 👀✨  
لم يحن وقت تنبيه غير النشطين بعد.

🕒 الوقت المتبقي: *${sisaWaktu}*

💭 انتظر حتى تنتهي الفترة، ثم أعد المحاولة.`
            )
        }

        await m.react('👀')

        const metaGrup = await sock.groupMetadata(jidGrup)
        const senderId = m.sender

        const semuaAnggota = metaGrup.participants.map(p => {
            let userId = p.jid || p.id || ''
            return userId.replace('@lid', '@s.whatsapp.net').split('@')[0]
        })

        const anggotaAktif = (dataGrup.activeUsers || []).map(id => id.split('@')[0])
        const siderList = semuaAnggota.filter(uid => !anggotaAktif.includes(uid))

        if (siderList.length === 0) {
            await m.react('🥳')
            return m.reply(
`🌟 *رائع!* 😆✨

كل أعضاء المجموعة نشطون خلال فترة الرصد.  
💖 شكراً لمشاركتكم.

🥰 أنتم تجعلون المجموعة نابضة بالحياة!`
            )
        }

        const siderMentions = siderList.map(n => n + '@s.whatsapp.net')

        const listText = siderList
            .map((nomor, i) => `│ ${i + 1}. @${nomor}`)
            .join('\n')

        const message =
`╭━━━『 🌸 *تنبيه الأعضاء غير النشطين* 🌸 』━━━
│
│ 🥺 *الرسالة:*
│ ${pesanUser}
│
│ 😎 *المرسل:*
│ @${senderId.split('@')[0]}
│
├━━━『 😶 *الأعضاء غير النشطين* 😶 』━━━
${listText}
│
╰━━━━━━━━━━━━━━━━━━━━━━━

😏 نرجو العودة للمشاركة في المجموعة.
🥀 رسالتكم ومشاركتكم تصنعان الفرق.
🥺 تحدثوا معنا عندما يتسنى لكم ذلك.
✨ يسعدنا وجودكم بيننا. 💖`

        await sock.sendMessage(m.chat, {
            text: message,
            mentions: [...siderMentions, senderId]
        }, { quoted: m })

        await m.react('💖')

    } catch (err) {
        console.error('[TAGSIDER ERROR]', err)
        await m.react('😵')

        return m.reply(
"حدث خطأ، حاول لاحقاً"
        )
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
