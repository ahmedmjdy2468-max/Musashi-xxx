const { getParticipantJid } = require('../../src/lib/lidHelper')

const pluginConfig = {
    name: 'tagadmin',
    alias: ['panggiladmin'],
    category: 'group',
    description: 'ينبّه مشرفي المجموعة الآخرين مع إرفاق رسالة اختيارية؛ للمشرفين فقط.',
    usage: '.تنبيه_المشرفين [رسالة]',
    example: '.تنبيه_المشرفين نحتاج إلى مساعدتكم',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 10,
    energi: 0,
    isEnabled: true,
    isAdmin: true, 
    isBotAdmin: false
}

async function handler(m, { sock }) {
    const text = m.text || 'يرجى من المشرفين الحضور.'
    const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net'
    const senderId = m.sender

    try {
        const groupMetadata = await sock.groupMetadata(m.chat)
        const participants = groupMetadata.participants || []

        // استبعاد البوت ومرسل الأمر، والإبقاء على المشرفين الآخرين.
        const admins = participants.filter(p => {
            const jid = getParticipantJid(p)
            const isAdmin = p.admin === 'admin' || p.admin === 'superadmin' || p.admin === 'مشرف'
            return isAdmin && jid !== botId && jid !== senderId
        })
        
        if (admins.length === 0) {
            return await m.reply('❌ لا يوجد مشرفون آخرون لتنبيههم.')
        }

        // Ambil JID untuk mentions (biru)
        const adminMentions = admins.map(p => getParticipantJid(p))
        
        // Buat daftar teks
        const adminList = admins
            .map((p, i) => {
                const jid = getParticipantJid(p)
                const role = p.admin === 'superadmin' ? ' [مالك المجموعة]' : ''
                return `│ ${i + 1}. @${jid.split('@')[0]}${role}`
            })
            .join('\n')

        const message = `╭──  🌟 *تنبيه المشرفين* ──\n` +
                        `│\n` +
                        `│ 📢 *الرسالة:* ${text}\n` +
                        `│ 👤 *المرسل:* @${senderId.split('@')[0]}\n` +
                        `│\n` +
                        `├───────  『 *قائمة المشرفين* 』\n` +
                        `${adminList}\n` +
                        `│\n` +
                        `╰──────────────────\n\n` +
                        `> 🌟 تنبيه موجّه إلى مشرفي المجموعة.`

        // تضمين المشرفين والمرسل في قائمة الإشارات.
        await sock.sendMessage(m.chat, { 
            text: message, 
            mentions: [...adminMentions, senderId] 
        }, { quoted: m })

    } catch (err) {
        console.error("[MUSASHI][plugins_legacy/group/tagadmin.js] exception", err?.stack || err)
        await m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
