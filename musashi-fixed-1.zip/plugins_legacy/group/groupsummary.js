const { getSummary } = require('../../src/lib/groupActivity')

const pluginConfig = {
    name: 'groupsummary',
    alias: ['gsummary', 'rekapgrup', 'aktivitasgrup'],
    category: 'group',
    description: 'يلخّص رسائل المجموعة وأوامرها والأعضاء الأكثر نشاطاً خلال عدد ساعات تحدده؛ للمجموعات فقط.',
    usage: '.ملخص_المجموعة [عدد_الساعات]',
    example: '.ملخص_المجموعة 12',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 10,
    energi: 0,
    isEnabled: true
}

const handler = async (m) => {
    let hours = parseInt(m.args?.[0]) || 24
    if (hours < 1) hours = 1
    if (hours > 168) hours = 168 // الحد الأقصى سبعة أيام

    const summary = getSummary(m.chat, hours)

    if (summary.totalMessages === 0 && summary.totalCommands === 0) {
        return m.reply(
            `📊 *ملخص المجموعة*\n\n` +
            `> لا توجد أنشطة مسجلة خلال آخر ${hours} ساعة.\n` +
            `> سيظهر الملخص بعد تسجيل رسائل أو أوامر جديدة.`
        )
    }

    const periodLabel = hours === 24 ? '24 ساعة' : `${hours} ساعة`

    let txt = `📊 *ملخص المجموعة* (آخر ${periodLabel})\n\n`

    // الملخص العام
    txt += `╭┈┈⬡「 📈 *الإجمالي* 」\n`
    txt += `┃ 💬 الرسائل: *${summary.totalMessages}*\n`
    txt += `┃ ⚡ الأوامر: *${summary.totalCommands}*\n`
    txt += `┃ 👥 المستخدمون النشطون: *${summary.activeUsers.length}*\n`
    txt += `╰┈┈┈┈┈┈┈┈⬡\n\n`

    // الأعضاء الأكثر نشاطاً
    const topUsers = summary.activeUsers.slice(0, 5)
    txt += `╭┈┈⬡「 🏆 *الأكثر نشاطاً* 」\n`
    topUsers.forEach((u, i) => {
        const rank = i + 1
        let icon = '🔹'
        if (rank === 1) icon = '👑'
        else if (rank === 2) icon = '🥈'
        else if (rank === 3) icon = '🥉'

        const total = u.messages + u.commands
        txt += `┃ ${icon} @${u.jid.split('@')[0]} — *${total}* نشاط\n`
        txt += `┃    └─ 💬 ${u.messages} رسالة، ⚡ ${u.commands} أمر\n`
    })
    txt += `╰┈┈┈┈┈┈┈┈⬡\n\n`

    // الأوامر الأكثر استخداماً
    if (summary.topCommands.length) {
        const topCmds = summary.topCommands.slice(0, 5)
        txt += `╭┈┈⬡「 🔥 *الأكثر استخداماً* 」\n`
        topCmds.forEach((c, i) => {
            txt += `┃ ${i + 1}. \`${c.cmd}\` — ${c.count} مرة\n`
        })
        txt += `╰┈┈┈┈┈┈┈┈⬡\n\n`
    }

    txt += `> ✨ شكراً لمساهمتكم في نشاط المجموعة.`

    return m.reply(txt, { mentions: topUsers.map(u => u.jid) })
}

module.exports = {
    config: pluginConfig,
    handler,
}
