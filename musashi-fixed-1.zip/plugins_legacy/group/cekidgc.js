const config = require("../../config");
const timeHelper = require("../../src/lib/timeHelper");
const { generateWAMessageFromContent, proto } = require("itsuki");

const pluginConfig = {
  name: "cekidgc",
  alias: ["idgc", "idgrup", "groupid"],
  category: "group",
  description: "يعرض معرّف المجموعة وبياناتها من المجموعة الحالية أو من رابط دعوة؛ يعمل للمستخدمين.",
  usage: ".معرف_المجموعة [رابط الدعوة]",
  example: ".معرف_المجموعة",
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  isAdmin: false,
  cooldown: 5,
  energi: 0,
  isEnabled: true,
};

async function handler(m, { sock }) {
  await m.react("📋");

  try {
    const input = m.text?.trim();
    let groupJid = null;
    let groupMeta = null;

    if (input && input.includes("chat.whatsapp.com/")) {
      const inviteCode = input
        .split("chat.whatsapp.com/")[1]
        ?.split(/[\s?]/)[0];

      if (!inviteCode) {
        m.react("❌");
        return m.reply("❌ رابط المجموعة غير صالح.");
      }

      try {
        groupMeta = await sock.groupGetInviteInfo(inviteCode);
        groupJid = groupMeta?.id;
      } catch (e) {
        m.react("❌");
        return m.reply(
          "❌ رابط المجموعة غير صالح أو منتهي الصلاحية.",
        );
      }
    } else if (input && input.endsWith("@g.us")) {
      groupJid = input;
      try {
        groupMeta = await sock.groupMetadata(groupJid);
      } catch (e) {
        m.react("❌");
        return m.reply("❌ تعذّر الوصول إلى بيانات هذه المجموعة.");
      }
    } else if (m.isGroup) {
      groupJid = m.chat;
      groupMeta = await sock.groupMetadata(groupJid);
    } else {
      return m.reply(
        `📋 *معرّف المجموعة*\n\n` +
          `> استخدم الأمر داخل المجموعة، أو أضف رابط دعوتها.\n\n` +
          `مثال:\n` +
          `\`${m.prefix}معرف_المجموعة\``,
      );
    }

    if (!groupMeta || !groupJid) {
      m.react("❌");
      return m.reply("❌ تعذّر العثور على بيانات المجموعة.");
    }

    const groupName = groupMeta?.subject || "غير معروف";
    const memberCount = groupMeta?.participants?.length || groupMeta?.size || 0;
    const createdAt = groupMeta?.creation
      ? timeHelper.fromTimestamp(groupMeta.creation * 1000, "D MMMM YYYY")
      : "-";
    const groupOwner = groupMeta?.owner || groupMeta?.subjectOwner || "-";

    const saluranId = config.saluran?.id || '120363432546133683@newsletter';
    const saluranName = config.saluran?.name || config.bot?.name || "MUSASHI";

    const text =
      `📋 *معلومات المجموعة*\n\n` +
      `╭┈┈⬡「 🏠 *التفاصيل* 」\n` +
      `┃ 📛 الاسم: *${groupName}*\n` +
      `┃ 🆔 المعرّف: \`${groupJid}\`\n` +
      `┃ 👥 الأعضاء: *${memberCount}*\n` +
      `┃ 📅 أنشأه: *${createdAt}*\n` +
      `╰┈┈┈┈┈┈┈┈⬡`;

    const buttons = [
      {
        name: "cta_copy",
        buttonParamsJson: JSON.stringify({
          display_text: "📋 نسخ معرّف المجموعة",
          copy_code: groupJid,
        }),
      },
    ];

    const msg = generateWAMessageFromContent(
      m.chat,
      {
        viewOnceMessage: {
          message: {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2,
            },
            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: text,
              }),
              footer: proto.Message.InteractiveMessage.Footer.fromObject({
                text: `© ${config.bot?.name || "MUSASHI"}`,
              }),
              nativeFlowMessage:
                proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                  buttons: buttons,
                }),
              contextInfo: {
                mentionedJid: [m.sender],
                forwardingScore: 9999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                  newsletterJid: saluranId,
                  newsletterName: saluranName,
                  serverMessageId: 127,
                },
              },
            }),
          },
        },
      },
      { userJid: m.sender, quoted: m },
    );

    await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    await m.react("✅");
  } catch (error) {
        console.error("[MUSASHI][plugins_legacy/group/cekidgc.js] exception", error?.stack || error);
    await m.react("❌");
    await m.reply("حدث خطأ، حاول لاحقاً");
  }
}

module.exports = {
  config: pluginConfig,
  handler,
};
