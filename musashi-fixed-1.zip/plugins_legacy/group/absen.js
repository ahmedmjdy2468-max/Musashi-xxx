const config = require('../../config')

const pluginConfig = {
    name: 'absen',
    alias: ['hadir', 'present'],
    category: 'group',
    description: 'يسجل حضورك في جلسة الحضور المفتوحة.',
    usage: '.الحضور',
    example: '.الحضور',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

if (!global.absensi) global.absensi = {}

async function handler(m, { sock }) {
    const chatId = m.chat

    if (!global.absensi[chatId]) {
        return m.reply(
`╭━━━〔 🌸 تسجيل الحضور 🌸 〕━━━⬣
┃ ❌ *لم يبدأ تسجيل الحضور بعد.*
┃
┃ 💬 يرجى التواصل مع أحد مشرفي المجموعة.
┃ ✨ استخدم:
┃ ➤ *بدء_الحضور [الوصف]*
╰━━━━━━━━━━━━━━━━⬣`
        )
    }

    const absen = global.absensi[chatId]

    if (!absen.data) absen.data = {}
    if (!absen.peserta) absen.peserta = []

    // 🔥 AMBIL NAMA WA (FIX)
    let senderName = m.pushName || await sock.getName(m.sender)

    if (!senderName || senderName === m.sender) {
        senderName = m.sender.split('@')[0]
    }

    senderName = senderName.trim()

    // cek sudah absen
    if (absen.peserta.includes(m.sender)) {
        return m.reply(
`╭━━━〔 ⚠️ تسجيل مكرر ⚠️ 〕━━━⬣
┃ 💢 لقد سجلت حضورك مسبقاً.
┃ 🌸 لا تحاول التسجيل مرة أخرى.
╰━━━━━━━━━━━━━━━━⬣`
        )
    }

    // simpan
    absen.peserta.push(m.sender)
    absen.data[m.sender] = senderName

    const moment = require('moment-timezone')
    const now = moment().tz('Asia/Jakarta').locale('ar')

    const dateStr = now.format('dddd, D MMMM YYYY')
    const timeStr = now.format('HH:mm:ss')

    // 🔥 LIST NAMA (NO NOMOR)
    const list = absen.peserta.map((jid, i) => {
        const name = absen.data?.[jid] || 'المستخدم'
        return `┃ ${i + 1}. ${name}`
    }).join('\n')

    await m.reply(
`╭━━━〔 🌸 تسجيل الحضور 🌸 〕━━━⬣
┃ 🎤 *${senderName} سجّل حضوره.*
┃
┃ 💖 *الهدف:* ${absen.keterangan}
┃
┣━━━〔 📋 معلومات 〕━━━⬣
┃ 📅 ${dateStr}
┃ ⏰ ${timeStr}
┃ 👥 إجمالي الحضور: ${absen.peserta.length} أعضاء
┃
┣━━━〔 📝 قائمة الحضور 〕━━━⬣
${list}
┃
╰━━━〔 🌟 ملاحظة 〕━━━⬣
> ✨ اكتب *${m.prefix}الحضور* لتسجيل الحضور
> 📊 اكتب *${m.prefix}قائمة_الحضور* لعرض القائمة
`
    )
}

module.exports = {
    config: pluginConfig,
    handler
}
