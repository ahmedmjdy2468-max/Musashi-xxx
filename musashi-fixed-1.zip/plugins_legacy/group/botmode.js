const { getDatabase } = require('../../src/lib/database')

const pluginConfig = {
    name: 'botmode',
    alias: ['setmode', 'mode'],
    category: 'group',
    description: 'يغيّر مجموعة الأوامر والميزات المتاحة في هذه المجموعة؛ للمشرفين فقط.',
    usage: '.وضع_البوت <md/cpanel/pushkontak/store/otp>',
    example: '.وضع_البوت store',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    isAdmin: true,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

const MODES = {
    md: {
        name: 'متعدد الأجهزة',
        desc: 'الوضع الافتراضي مع الميزات الأساسية',
        allowedCategories: null,
        excludeCategories: ['cpanel', 'pushkontak', 'store']
    },
    cpanel: {
        name: 'CPanel Pterodactyl',
        desc: 'وضع مخصص للوحة الخادم',
        allowedCategories: ['main', 'group', 'sticker', 'owner', 'tools', 'panel'],
        excludeCategories: null
    },
    pushkontak: {
        name: 'نشر جهات الاتصال',
        desc: 'وضع مخصص لإرسال جهات الاتصال إلى الأعضاء',
        allowedCategories: ['owner', 'main', 'group', 'sticker', 'pushkontak'],
        excludeCategories: null
    },
    store: {
        name: 'المتجر الإلكتروني',
        desc: 'وضع مخصص لإدارة المتجر الإلكتروني',
        allowedCategories: ['main', 'group', 'sticker', 'owner', 'store'],
        excludeCategories: null
    },
    otp: {
        name: 'خدمة رمز التحقق',
        desc: 'وضع مخصص لخدمة رمز التحقق لمرة واحدة',
        allowedCategories: ['main', 'group', 'sticker', 'owner'],
        excludeCategories: null
    }
}

async function handler(m, { sock }) {
    const db = getDatabase()
    const args = m.args || []
    const mode = (args[0] || '').toLowerCase()
    const flags = args.slice(1).map(f => f.toLowerCase())
    
    const groupData = db.getGroup(m.chat) || {}
    const currentMode = groupData.botMode || 'md'
    
    if (!mode) {
        let modeList = ''
        for (const [key, val] of Object.entries(MODES)) {
            const isCurrent = key === currentMode ? ' ⬅️' : ''
            modeList += `┃ \`${m.prefix}وضع_البوت ${key}\`${isCurrent}\n`
            modeList += `┃ └ ${val.desc}\n`
        }
        
        const autoorderStatus = groupData.storeConfig?.autoorder ? '✅ مفعّل' : '❌ متوقف'
        
        return m.reply(
            `🔧 *وضع البوت*\n\n` +
            `> الوضع الحالي: *${currentMode.toUpperCase()}* (${MODES[currentMode]?.name || 'غير معروف'})\n` +
            (currentMode === 'store' ? `> الطلب التلقائي: *${autoorderStatus}*\n` : '') +
            `\n╭─「 📋 *الأوضاع المتاحة* 」\n` +
            `${modeList}` +
            `╰───────────────\n\n` +
            `*إعداد المتجر:*\n` +
            `> \`${m.prefix}وضع_البوت store\` - طلبات يراجعها المشرف يدوياً\n` +
            `> الدفع التلقائي غير مفعّل في هذا المعالج.\n\n` +
            `> _يُحفظ الإعداد لكل مجموعة على حدة._`
        )
    }
    
    if (!Object.keys(MODES).includes(mode)) {
        return m.reply(`❌ الوضع غير صالح. الخيارات: \`md\`، \`cpanel\`، \`pushkontak\`، \`store\`، \`otp\`.`)
    }
    
    const isAutoorder = false
    
    console.log('[Botmode] Debug:', { args: m.args, mode, flags, isAutoorder })
    
    const newGroupData = {
        ...groupData,
        botMode: mode
    }
    
    if (mode === 'store') {
        let pakasirEnabled = false
        try {
            const pakasir = require('../../src/lib/pakasir')
            pakasirEnabled = pakasir.isEnabled()
        } catch (e) {}
        
        if (isAutoorder && !pakasirEnabled) {
            return m.reply(
                `⚠️ *تعذّر تفعيل الطلب التلقائي*\n\n` +
                `> خدمة الدفع غير مهيّأة.\n\n` +
                `> أو استخدم الوضع اليدوي:\n` +
                `\`${m.prefix}وضع_البوت store\``
            )
        }
        
        newGroupData.storeConfig = {
            ...(groupData.storeConfig || {}),
            autoorder: isAutoorder,
            products: groupData.storeConfig?.products || []
        }
    }
    
    db.setGroup(m.chat, newGroupData)
    db.save()
    
    m.react('✅')
    
    let extraInfo = ''
    if (mode === 'store') {
        const products = newGroupData.storeConfig?.products || []
        if (isAutoorder) {
            extraInfo = `\n\n✅ *فُعّلت الطلبات التلقائية*\n` +
                `> الدفع الآلي عبر خدمة الدفع\n` +
                `> عدد المنتجات: \`${products.length}\``
        } else {
            extraInfo = `\n\n📋 *الوضع اليدوي*\n` +
                `> يراجع المشرف الطلبات ويؤكدها يدوياً\n` +
                `> عدد المنتجات: \`${products.length}\`\n\n` +
                `*إدارة المنتجات:*\n` +
                `> \`${m.prefix}addprod <kode> <harga> <nama>\`\n` +
                `> \`${m.prefix}listprod\` - عرض المنتجات`
        }
    }
    
    return m.reply(
        `✅ *تغيّر وضع البوت*\n\n` +
        `> الوضع: *${mode.toUpperCase()}* (${MODES[mode].name})\n` +
        `> المجموعة: *${m.chat.split('@')[0]}*\n` +
        (mode === 'store' ? `> الطلب التلقائي: *${isAutoorder ? 'مفعّل' : 'متوقف'}*` : '') +
        extraInfo +
        `\n\n> اكتب \`${m.prefix}القائمة\` لعرض القائمة.`
    )
}

function getGroupMode(chatJid, db) {
    if (!chatJid?.endsWith('@g.us')) return 'md'
    const groupData = db.getGroup(chatJid) || {}
    return groupData.botMode || 'md'
}

function getModeCategories(mode) {
    const modeConfig = MODES[mode] || MODES.md
    return {
        allowed: modeConfig.allowedCategories,
        excluded: modeConfig.excludeCategories
    }
}

function filterCategoriesByMode(categories, mode) {
    const modeConfig = MODES[mode] || MODES.md
    
    if (modeConfig.allowedCategories) {
        return categories.filter(cat => modeConfig.allowedCategories.includes(cat.toLowerCase()))
    }
    
    if (modeConfig.excludeCategories) {
        return categories.filter(cat => !modeConfig.excludeCategories.includes(cat.toLowerCase()))
    }
    
    return categories
}

module.exports = {
    config: pluginConfig,
    handler,
    getGroupMode,
    getModeCategories,
    filterCategoriesByMode,
    MODES
}
