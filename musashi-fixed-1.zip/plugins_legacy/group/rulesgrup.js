const config = require('../../config')
const { getDatabase } = require('../../src/lib/database')
const fs = require('fs')
const path = require('path')

const pluginConfig = {
    name: 'rulesgrup',
    alias: ['grouprules', 'aturangrup', 'grules'],
    category: 'group',
    description: "يعرض قواعد المجموعة المحفوظة.",
    usage: ".قواعد_المجموعة",
    example: "",
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 10,
    energi: 0,
    isEnabled: true
}

const DEFAULT_GROUP_RULES = `📜 *ᴀᴛᴜʀᴀɴ المجموعة*

┃ 1️⃣ Dilarang spam/flood chat
┃ 2️⃣ Dilarang promosi tanpa izin
┃ 3️⃣ Dilarang konten SARA/Porn
┃ 4️⃣ Hormati sesama عضو
┃ 5️⃣ استخدم bahasa الذي sopan
┃ 6️⃣ Dilarang share رابط tanpa izin
┃ 7️⃣ Patuhi instruksi مشرف
┃ 8️⃣ No toxic & bullying

_Mau langgar? Siap-siap في Kick!_`

async function handler(m, { sock, config: botConfig }) {
    const db = getDatabase()
    const groupData = db.getGroup(m.chat) || {}
    const customRules = groupData.groupRules
    const rulesText = customRules || DEFAULT_GROUP_RULES

    const imageBuffer = await require('../../src/lib/assetManager').getAssetBuffer('images.itsukiRules')

    const saluranId = botConfig.saluran?.id || '120363432546133683@newsletter'
    const saluranName = botConfig.saluran?.name || botConfig.bot?.name || 'MUSASHI'

    if (imageBuffer) {
        await sock.sendMedia(m.chat, imageBuffer, rulesText, m, {
            type: 'image',
        })
    } else {
        await m.reply(rulesText)
    }
}

module.exports = {
    config: pluginConfig,
    handler,
    DEFAULT_GROUP_RULES
}
