const pluginConfig = {
    name: 'notifopengroup',
    alias: ['notifopen'],
    category: 'group',
    description: 'للمشرف: يفعّل أو يوقف إشعار فتح المجموعة.',
    usage: '.تنبيه_فتح_المجموعة <تشغيل|إيقاف>',
    example: '.تنبيه_فتح_المجموعة تشغيل',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock, db }) {
    if (!m.isAdmin && !m.isOwner) {
        return m.reply(`❌ هذا الخيار متاح لمشرفي المجموعة فقط.`)
    }
    
    const rawArg = m.args[0]?.toLowerCase()
    const args = rawArg === 'تشغيل' ? 'on' : rawArg === 'إيقاف' ? 'off' : rawArg
    const group = db.getGroup(m.chat) || {}
    
    if (!['on', 'off'].includes(args)) {
        const status = group.notifOpenGroup === true ? '✅ مفعّل' : '❌ متوقف'
        return m.reply(`🔓 *تنبيه فتح المجموعة*\n\nالحالة: ${status}\n\nالاستخدام:\n\`${m.prefix}تنبيه_فتح_المجموعة تشغيل\`\n\`${m.prefix}تنبيه_فتح_المجموعة إيقاف\``)
    }
    
    if (args === 'on') {
        group.notifOpenGroup = true
        db.setGroup(m.chat, group)
        return m.reply(`✅ فُعّل إشعار فتح المجموعة.`)
    }
    
    if (args === 'off') {
        group.notifOpenGroup = false
        db.setGroup(m.chat, group)
        return m.reply(`❌ أُوقف إشعار فتح المجموعة.`)
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
