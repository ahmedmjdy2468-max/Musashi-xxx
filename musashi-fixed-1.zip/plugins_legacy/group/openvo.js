const { downloadContentFromMessage } = require('itsuki')

const pluginConfig = {
    name: 'rvo',
    alias: [],
    category: 'group',
    description: 'ينزّل الوسائط من رسالة مشاهدة لمرة واحدة عند الرد عليها؛ أُبقي قيد المراجعة قبل إتاحته.',
    usage: '.تنزيل_مشاهدة_مرة (ردّ على الرسالة)',
    example: '.تنزيل_مشاهدة_مرة (ردّ على الرسالة)',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 1,
    isEnabled: true
}

async function handler(m, { sock }) {
    const quoted = m.quoted

    if (!quoted) {
        await m.reply(
            `❌ *لم تُحدّد رسالة*\n\n` +
            `> ردّ على رسالة مشاهدة لمرة واحدة ثم اكتب:\n` +
            `> \`${m.prefix}تنزيل_مشاهدة_مرة\``
        )
        return
    }

    const quotedMsg = quoted.message
    if (!quotedMsg) {
        await m.reply(
            `❌ محتوى الرسالة غير متاح.`
        )
        return
    }

    const type = Object.keys(quotedMsg)[0]
    const content = quotedMsg[type]

    if (!content) {
        await m.reply(
            `❌ تعذّر قراءة محتوى الرسالة.`
        )
        return
    }

    if (!content.viewOnce) {
        await m.reply(
            `❌ الرسالة التي رددت عليها ليست رسالة مشاهدة لمرة واحدة.\n` +
            `> ردّ على رسالة تحمل علامة المشاهدة لمرة واحدة (👁️).`
        )
        return
    }

    await m.react('🕕')

    try {
        let mediaType = null
        if (type.includes('image')) {
            mediaType = 'image'
        } else if (type.includes('video')) {
            mediaType = 'video'
        } else if (type.includes('audio')) {
            mediaType = 'audio'
        }

        if (!mediaType) {
            await m.reply(
                `هذا النوع غير مدعوم. الأنواع المدعومة: صورة أو فيديو أو صوت.`
            )
            return
        }

        const stream = await downloadContentFromMessage(content, mediaType)
        
        let buffer = Buffer.from([])
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk])
        }

        if (!buffer || buffer.length < 100) {
            await m.reply(
                `❌ تعذّر تنزيل الوسائط.\n` +
                `> قد تكون صلاحية الوسائط قد انتهت.`
            )
            return
        }
        const quoted = m.quoted ? m.quoted : m

        if (mediaType === 'image') {
            await sock.sendMedia(m.chat, buffer, null, quoted, {
                type: 'image'
            })
        } else if (mediaType === 'video') {
            await sock.sendMedia(m.chat, buffer, null, quoted, {
                type: 'video'
            })
        } else if (mediaType === 'audio') {
            await sock.sendMedia(m.chat, buffer, null, quoted, {
                type: 'audio',
                mimetype: 'audio/mpeg',
                ptt: true
            })
        }

    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/group/openvo.js] exception", error?.stack || error);
        await m.reply(
            "حدث خطأ، حاول لاحقاً"
        )
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
