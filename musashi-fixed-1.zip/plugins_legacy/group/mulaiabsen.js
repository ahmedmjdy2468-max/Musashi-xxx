const config = require('../../config')

const pluginConfig = {
    name: 'mulaiabsen',
    alias: ['startabsen', 'bukaabsen', 'openabsen'],
    category: 'group',
    description: 'يفتح تسجيل الحضور في المجموعة مع عنوان اختياري؛ للمشرفين.',
    usage: '.بدء_الحضور [عنوان]',
    example: '.بدء_الحضور اجتماع الأسبوع',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 10,
    energi: 0,
    isEnabled: true,
    isAdmin: true
}

if (!global.absensi) global.absensi = {}

async function handler(m, { sock }) {
    const chatId = m.chat
    
    if (global.absensi[chatId]) {
        return m.reply(
            `❌ يوجد تسجيل حضور مفتوح بالفعل في هذه المجموعة.\n\n` +
            `> استخدم *.مسح_الغياب* لإنهائه، أو *.فحص_الحضور* لعرض المسجلين.`
        )
    }
    
    const keterangan = m.text?.trim() || 'الحضور اليومي'
    
    global.absensi[chatId] = {
        keterangan: keterangan,
        createdBy: m.sender,
        createdAt: new Date().toISOString(),
        peserta: []
    }
    
    const saluranId = config.saluran?.id || '120363432546133683@newsletter'
    const saluranName = config.saluran?.name || config.bot?.name || 'MUSASHI'
    
    await m.reply(`📋 *بدأ تسجيل الحضور*\n\n` +
            `「 📋 *التفاصيل* 」\n` +
            `📝 ${keterangan}\n` +
            `👑 بدأه: @${m.sender.split('@')[0]}\n` +
            `👥 عدد المسجلين: 0\n\n` +
            `للتسجيل اكتب *${m.prefix}الحضور*، ولعرض القائمة اكتب *${m.prefix}فحص_الحضور*، ولإنهائها اكتب *${m.prefix}مسح_الغياب*.`, {mentions: [m.sender]})
}

module.exports = {
    config: pluginConfig,
    handler
}
