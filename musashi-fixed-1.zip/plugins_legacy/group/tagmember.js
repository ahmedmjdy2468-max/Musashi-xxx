const { getParticipantJid, getParticipantJids } = require('../../src/lib/lidHelper')

const pluginConfig = {
    name: 'tagmember',
    alias: ['member', 'members'],
    category: 'group',
    description: "يرسل رسالة ويشير إلى أعضاء المجموعة غير المشرفين؛ لمشرفي المجموعة فقط.",
    usage: ".منشن_الأعضاء [رسالة]",
    example: ".منشن_الأعضاء مرحباً بالجميع",
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 30,
    energi: 0,
    isEnabled: true,
    isAdmin: true,
    isBotAdmin: true
}

async function handler(m, { sock }) {
    const text = m.text || 'مرحباً بأعضاء المجموعة!'
    const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net'
    const senderId = m.sender

    try {
        const groupMeta = m.groupMetadata
        const participants = groupMeta.participants || []

        // استبعاد المشرفين والبوت ومرسل الأمر.
        const members = participants.filter(p => {
            const jid = getParticipantJid(p)
            const isNotAdmin = p.admin === null || p.admin === undefined
            return isNotAdmin && jid !== botId && jid !== senderId
        })

        if (members.length === 0) {
            return await m.reply('❌ لا يوجد أعضاء غير مشرفين للإشارة إليهم.')
        }

        // جمع معرّفات الأعضاء للإشارة إليهم.
        const memberMentions = members.map(p => getParticipantJid(p))

        // إعداد قائمة الأعضاء.
        const memberList = members
            .map(p => `> @${getParticipantJid(p).split('@')[0]}`)
            .join('\n')

        // تنسيق الرسالة.
        const topBorder = '╔═══════════════════╗'
        const midBorder = '╠═══════════════════╣'
        const bottomBorder = '╚═══════════════════╝'

        const message = `${topBorder}\n` +
                        `*_-- 🌟 تنبيه الأعضاء --_*\n` +
                        `${midBorder}\n\n` +
                        `📢 *الرسالة:* ${text}\n` +
                        `👤 *المرسل:* @${senderId.split('@')[0]}\n\n` +
                        `\`\`\`━━━ ${members.length} عضواً ━━━\`\`\`\n` +
                        `${memberList}\n\n` +
                        `${bottomBorder}\n` +
                        `> أنتم نجوم هذه المجموعة!`

        // إرسال التنبيه مع الإشارة إلى الأعضاء والمرسل.
        await sock.sendMessage(m.chat, { 
            text: message, 
            mentions: [...memberMentions, senderId] 
        }, { quoted: m })

    } catch (err) {
        console.error("[MUSASHI][plugins_legacy/group/tagmember.js] exception", err?.stack || err)
        await m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
