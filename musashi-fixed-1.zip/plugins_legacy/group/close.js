const pluginConfig = {
    name: 'close',
    alias: ['tutup', 'closegroup', 'tutupgroup'],
    category: 'group',
    description: 'يقفل المجموعة بحيث لا يستطيع إرسال الرسائل إلا المشرفون.',
    usage: '.إغلاق_المجموعة',
    example: '.إغلاق_المجموعة',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 10,
    energi: 0,
    isEnabled: true,
    isAdmin: true,
    isBotAdmin: true
};

async function handler(m, { sock }) {
    try {
        const groupMeta = m.groupMetadata;
        
        if (groupMeta.announce) {
            await m.reply(
                `⚠️ المجموعة مقفلة بالفعل.\n\n` +
                `> لا يستطيع إرسال الرسائل حالياً إلا المشرفون.`
            );
            return;
        }
        
        await sock.groupSettingUpdate(m.chat, 'announcement');
        
        const senderNum = m.sender.split('@')[0];
        
        const successMsg = `✅ @${senderNum} أغلق المجموعة.`;
        
        await m.reply(successMsg, {mentions: [m.sender]})
        
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/group/close.js] exception", error?.stack || error);
        await m.reply(
            "حدث خطأ، حاول لاحقاً"
        );
    }
}

module.exports = {
    config: pluginConfig,
    handler
};
