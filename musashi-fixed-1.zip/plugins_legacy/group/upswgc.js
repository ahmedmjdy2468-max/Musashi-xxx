const { generateWAMessageContent, generateWAMessageFromContent } = require('itsuki')
const crypto = require('crypto')

const pluginConfig = {
    name: 'upswgc',
    alias: ['swgcadmin', 'grupstory'],
    category: 'group', // Kategori diubah ke group
    description: "ينشر حالة (ستوري) بحدود خضراء في المجموعة.",
    usage: ".تحديث_المجموعة <النص> أو ردّ على الوسائط",
    example: ".تحديث_المجموعة مرحباً بأعضاء المجموعة",
    isOwner: false,
    isAdmin: true,   // Hanya admin yang bisa eksekusi
    isPremium: false,
    isGroup: true,    // Wajib di dalam grup
    isPrivate: false,
    cooldown: 10,
    isEnabled: true
}

/**
 * Fungsi internal untuk mengirim status grup (V2)
 */
async function sendGroupStatus(sock, jid, content) {
    const inside = await generateWAMessageContent(content, {
        upload: sock.waUploadToServer
    })
    const messageSecret = crypto.randomBytes(32)
    const m = generateWAMessageFromContent(jid, {
        messageContextInfo: {
            messageSecret
        },
        groupStatusMessageV2: {
            message: {
                ...inside,
                messageContextInfo: {
                    messageSecret
                }
            }
        }
    }, {})
    await sock.relayMessage(jid, m.message, {
        messageId: m.key.id
    })
    return m
}

async function handler(m, { sock }) {
    const text = m.text || ''
    let content = {}

    // 1. Cek jika reply media (Gambar/Video)
    if (m.quoted && (m.quoted.isImage || m.quoted.isVideo)) {
        try {
            const buffer = await m.quoted.download()
            const mediaType = m.quoted.isImage ? 'image' : 'video'
            content[mediaType] = buffer
            content.caption = text || ''
        } catch (e) {
        console.error("[MUSASHI][plugins_legacy/group/upswgc.js] exception", e?.stack || e);
            return m.reply("حدث خطأ، حاول لاحقاً")
        }
    } 
    // 2. Cek jika kirim media langsung dengan caption
    else if (m.isImage || m.isVideo) {
        try {
            const buffer = await m.download()
            const mediaType = m.isImage ? 'image' : 'video'
            content[mediaType] = buffer
            content.caption = text || ''
        } catch (e) {
        console.error("[MUSASHI][plugins_legacy/group/upswgc.js] exception", e?.stack || e);
            return m.reply("حدث خطأ، حاول لاحقاً")
        }
    } 
    // 3. Jika hanya teks
    else if (text && text.trim()) {
        content = { 
            text: text,
            font: 0,
            backgroundColor: '#128C7E' 
        }
    } 
    // 4. Jika tidak ada input sama sekali
    else {
        return m.reply(
            `⚠️ *طريقة الاستخدام*\n\n` +
            `> \`${m.prefix}upswgc teks\`\n` +
            `> ردّ على صورة/video + \`${m.prefix}upswgc\`\n` +
            `> أرسل صورة/video + caption \`${m.prefix}upswgc\``
        )
    }

    try {
        await m.react('⏳')
        
        // Kirim langsung ke m.chat (ID grup tempat perintah diketik)
        await sendGroupStatus(sock, m.chat, content)
        
        await m.react('✅')
        await m.reply(`✅ *نجح!* الحالة المجموعة قد diperbarui بواسطة مشرف.`)
        
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/group/upswgc.js] exception", error?.stack || error);
        await m.react('❌')
        await m.reply(
            "حدث خطأ، حاول لاحقاً"
        )
    }
}

module.exports = {
    config: pluginConfig,
    handler
}