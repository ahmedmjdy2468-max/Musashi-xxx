const pluginConfig = {
    name: 'delppgc',
    alias: ['delprofilegc', 'delppgroup', 'hapusppgc'],
    category: 'group',
    description: "يحذف صورة المجموعة الحالية.",
    usage: ".حذف_صورة_المجموعة",
    example: "",
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    isAdmin: true,
    isBotAdmin: true,
    cooldown: 10,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    try {
        await sock.removeProfilePicture(m.chat)
        
        await m.reply(
            `✅ *Yatta~* PP المجموعة الآن تم botak~ ✨`
        )
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/group/delppgc.js] exception", error?.stack || error);
        await m.reply(
            "حدث خطأ، حاول لاحقاً"
        )
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
