const pluginConfig = {
    name: 'notifclosegroup',
    alias: ['notifclose'],
    category: 'group',
    description: 'للمشرف: يفعّل أو يوقف إشعار إغلاق المجموعة.',
    usage: '.إشعار_إغلاق_المجموعة <تشغيل|إيقاف>',
    example: '.إشعار_إغلاق_المجموعة تشغيل',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock, db }) {
    if (!m.isAdmin && !m.isOwner) {
        return m.reply(`❌ هذا الخيار متاح لمشرفي المجموعة فقط.`)
    }
    
    const rawArg = m.args[0]?.toLowerCase()
    const args = rawArg === 'تشغيل' ? 'on' : rawArg === 'إيقاف' ? 'off' : rawArg
    const group = db.getGroup(m.chat) || {}
    
    if (!['on', 'off'].includes(args)) {
        const status = group.notifCloseGroup === true ? '✅ مفعّل' : '❌ متوقف'
        return m.reply(`🔒 *إشعار إغلاق المجموعة*\n\nالحالة: ${status}\n\nالاستخدام:\n\`${m.prefix}إشعار_إغلاق_المجموعة تشغيل\`\n\`${m.prefix}إشعار_إغلاق_المجموعة إيقاف\``)
    }
    
    if (args === 'on') {
        group.notifCloseGroup = true
        db.setGroup(m.chat, group)
        return m.reply(`✅ فُعّل إشعار إغلاق المجموعة.`)
    }
    
    if (args === 'off') {
        group.notifCloseGroup = false
        db.setGroup(m.chat, group)
        return m.reply(`❌ أُوقف إشعار إغلاق المجموعة.`)
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
