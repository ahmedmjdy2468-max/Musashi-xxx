const axios = require('axios')
const fs = require('fs')
const path = require('path')
const { exec } = require('child_process')
const { promisify } = require('util')
const config = require('../../config')

const execAsync = promisify(exec)

const pluginConfig = {
    name: 'playch',
    alias: ['pch'],
    category: 'search',
    description: "يبحث عن المقطع الصوتي ويرسله إلى قناة البوت.",
    usage: ".تشغيل_القناة <اسم_المقطع>",
    example: ".تشغيل_القناة YOASOBI Idol",
    cooldown: 20,
    energi: 1,
    isEnabled: true
}

async function handler(m, { sock }) {
    const query = m.text?.trim()

    if (!query) {
        return m.reply(`
╭━━━〔 🌸 MUSASHI 🌸 〕━━━⬣
┃ 🎤 Masukkan judul lagu نعم.
┃
┃ ✨ مثال:
┃ \`${m.prefix}playch chan yoasobi\`
╰━━━━━━━━━━━━━━━━━━⬣
        `.trim())
    }

    m.react('🎧')

    let tempMp3, output

    try {
        const api = `https://api.nexray.web.id/downloader/ytplay?q=${encodeURIComponent(query)}`
        const { data } = await axios.get(api)

        if (!data.status || !data.result) {
            throw "Lagu غير موجود"
        }

        const res = data.result

        const dl = await axios.get(res.download_url, { responseType: 'arraybuffer' })

        const tempDir = path.join(process.cwd(), 'temp')
        if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir)

        tempMp3 = path.join(tempDir, `play_${Date.now()}.mp3`)
        output = path.join(tempDir, `out_${Date.now()}.ogg`)

        fs.writeFileSync(tempMp3, Buffer.from(dl.data))

        await execAsync(`ffmpeg -y -i "${tempMp3}" -c:a libopus -b:a 64k "${output}"`)

        const ogg = fs.readFileSync(output)

        // 🌟 CAPTION ITSUKI AI STYLE
        const caption = `
╭━━━〔 🌟 MUSASHI LIVE 🌟 〕━━━⬣
┃ 🎤 Now Performing…
┃
┃ 🎶 Title : ${res.title}
┃ 📺 Channel : ${res.channel}
┃ 👁 Views : ${res.views}
┃ ⏱ Duration : ${res.duration}
┃
┃ 💫 「最高のアイドルステージへ！」
┃ 🌸 Feel the chan energy ~
╰━━━〔 💖 B-KOMACHI 💖 〕━━━⬣
        `.trim()

        await sock.sendMessage(config?.saluran?.id, {
            audio: ogg,
            mimetype: 'audio/ogg; codecs=opus',
            ptt: true,
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: config?.saluran?.name || "🌟 MUSASHI Stage",
                    newsletterId: config?.saluran?.id
                },
            }
        })

        // 🌸 Feedback ke user
        await m.reply(`
╭━━━〔 ✨ STAGE SUCCESS ✨ 〕━━━⬣
┃ 🎶 Lagu تم الإرسال بنجاح!
┃
┃ 💿 ${res.title}
┃ 📡 إلى القناة:
┃ ${config?.saluran?.id}
┃
┃ 💖 Enjoy نعم, chan vibes!
╰━━━━━━━━━━━━━━━━━━⬣
        `.trim())

        m.react('✨')

        // cleanup
        setTimeout(() => {
            try { fs.unlinkSync(tempMp3) } catch {}
            try { fs.unlinkSync(output) } catch {}
        }, 30000)

    } catch (e) {
        console.error('[PlayCH Itsuki]', e)

        m.react('❌')

        m.reply(`
╭━━━〔 ❌ خطأ STAGE 〕━━━⬣
┃ 💔 عذراً... الأغنية لا ketemu...
┃
┃ 🔍 حاول استخدام kata lain نعم!
╰━━━━━━━━━━━━━━━━━━⬣
        `.trim())
    }
}

module.exports = {
    config: pluginConfig,
    handler
}