/**
‎✧ Name    : ytplay
‎✧ Category: search
‎✧ Note    : sesuaikan path require('../../src/scraper/youtube') sama struktur folder kamu
**/

const { randomUUID } = require('crypto')
const axios = require('axios')
const { searchYoutube, getYoutubeDirectUrl } = require('../../src/scraper/youtube')

// pluginConfig = metadata plugin, dipakai handler.js buat registrasi command
const pluginConfig = {
    name: 'ytplay',
    alias: ['ytp', 'youtubeplay', 'playyt', 'playyoutube'],
    category: 'search',
    description: 'Cari & putar video YouTube langsung dalam bentuk player interaktif',
    usage: '.ytplay <judul/الرابط>',
    example: '.ytplay alan walker faded',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 2,
    isEnabled: true
}

// DISPLAY_WS_HOST = teks yang muncul di panel "WEBSOCKET VIDEO" (kosmetik saja).
// Koneksi WebSocket yang beneran dipakai tetap ke server proxy asli di bawah
// (lihat startVideoStream -> wsUrl), radiant di sini TIDAK pernah dipakai buat
// connect. Catatan: ini cuma menyembunyikan dari tampilan UI, bukan dari
// Network tab DevTools browser -- itu keterbatasan WebSocket, bukan kode ini.
const itsukiWs = require('../../src/lib/itsukiws/server')
// Host yang tampil di panel = host asli server WebSocket Itsuki (tidak disamarkan).
const DISPLAY_WS_HOST = itsukiWs.getPublicBase().replace(/^wss?:\/\//, '') || '(belum dikonfigurasi)'

function escapeHtmlJs(value) {
    return String(value ?? '')
        .replace(/\\/g, '\\\\')
        .replace(/"/g, '\\"')
        .replace(/`/g, '\\`')
        .replace(/\$\{/g, '\\${')
        .replace(/</g, '\\x3C')
}

function buildPlayerHtml({ title, channel, duration, videoUrl, wsUrl, displayWsHost, posterBase64 }) {
    const safeTitle = escapeHtmlJs(title)
    const safeChannel = escapeHtmlJs(channel)
    const safeDuration = escapeHtmlJs(duration)
    const safeVideoUrl = escapeHtmlJs(videoUrl)
    const safeWsUrl = escapeHtmlJs(wsUrl)
    const safeDisplayWsHost = escapeHtmlJs(displayWsHost)

    return `<style>
*{-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none;box-sizing:border-box}
body{margin:0;background:#090a0f;font-family:Arial,Helvetica,sans-serif;color:#fff;touch-action:manipulation;cursor:pointer}
input[type=range]{width:100%;height:4px;accent-color:#fff;cursor:pointer}
.player-wrap{width:100%;max-width:440px;margin:auto;padding:12px}
.player{position:relative;overflow:hidden;background:#111318;border:1px solid rgba(255,255,255,.12);border-radius:20px;box-shadow:0 10px 40px rgba(0,0,0,.55)}
.bg{position:absolute;inset:-25px;background-position:center;background-size:cover;filter:blur(22px);opacity:.38;transform:scale(1.15);pointer-events:none}
.bg-overlay{position:absolute;inset:0;background:linear-gradient(180deg,rgba(5,6,10,.35),rgba(5,6,10,.72));pointer-events:none}
.content{position:relative;padding:18px;z-index:2}
.top{display:flex;align-items:center;justify-content:space-between;margin-bottom:15px}
.top-title{font-size:13px;font-weight:700;letter-spacing:.8px;opacity:.85}
.top-sub{font-size:10px;opacity:.5;margin-top:3px;white-space:nowrap;overflow:hidden;النص-overflow:ellipsis;max-width:260px}
.icon-btn{width:34px;height:34px;border:0;border-radius:50%;background:rgba(255,255,255,.08);color:#fff;display:flex;align-items:center;justify-content:center;padding:0;flex-shrink:0}
.icon-btn svg{width:17px;height:17px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.فيديو-frame{position:relative;width:100%;aspect-ratio:16/9;border-radius:15px;overflow:hidden;background:#000;box-shadow:0 12px 35px rgba(0,0,0,.45);cursor:pointer}
.فيديو-frame فيديو{width:100%;height:100%;display:block;background:#000;object-fit:contain}
.big-play{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.18);transition:opacity .2s;z-index:3}
.big-btn{width:64px;height:64px;border:0;border-radius:50%;background:#fff;color:#08090d;display:flex;align-items:center;justify-content:center;padding:0;box-shadow:0 6px 18px rgba(0,0,0,.35)}
.big-btn svg{width:26px;height:26px;fill:currentColor;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.frame-playing .big-play{opacity:0;pointer-events:none}
.info{padding-top:15px}
.song-title{font-size:19px;font-weight:700;white-space:nowrap;overflow:hidden;النص-overflow:ellipsis}
.artist{font-size:13px;opacity:.6;margin-top:5px;white-space:nowrap;overflow:hidden;النص-overflow:ellipsis}
.progress{margin-top:18px}
.times{display:flex;justify-content:space-between;font-size:10px;opacity:.55;margin-top:7px}
.controls{display:flex;align-items:center;justify-content:center;gap:18px;margin-top:13px}
.side-btn{width:38px;height:38px;border:0;background:transparent;color:#fff;display:flex;align-items:center;justify-content:center;padding:0;opacity:.8}
.side-btn svg{width:19px;height:19px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.bottom{display:flex;align-items:center;justify-content:space-between;margin-top:15px;gap:12px}
.bottom-left,.bottom-right{display:flex;align-items:center;gap:9px}
.volume{width:85px}
.debug-wrap{margin-top:12px;background:#111318;border:1px solid rgba(255,255,255,.12);border-radius:16px;padding:12px;font-family:monospace}
.debug-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px}
.debug-title{font-size:11px;font-weight:700;letter-spacing:.8px;opacity:.85}
.debug-state{font-size:10px;font-weight:700;padding:3px 8px;border-radius:20px;background:rgba(255,255,255,.08);color:#ffd166;letter-spacing:.5px}
.debug-الخادم{font-size:9px;opacity:.5;word-break:break-all;margin-bottom:8px;line-height:1.4}
.debug-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-bottom:8px}
.debug-cell{background:rgba(255,255,255,.05);border-radius:8px;padding:6px 8px}
.debug-cell span{display:block;font-size:8px;opacity:.5;letter-spacing:.5px}
.debug-cell b{display:block;font-size:11px;margin-top:2px;white-space:nowrap;overflow:hidden;النص-overflow:ellipsis}
.debug-bar{height:4px;border-radius:4px;background:rgba(255,255,255,.08);overflow:hidden;margin-bottom:8px}
.debug-bar-fill{height:100%;width:0;background:linear-gradient(90deg,#4cc9f0,#7bff9f);transition:width .3s}
.debug-log{height:110px;overflow-y:auto;background:rgba(0,0,0,.35);border-radius:8px;padding:6px 8px;font-size:9px;line-height:1.6;color:rgba(255,255,255,.75);word-break:break-all;-webkit-overflow-scrolling:touch}
.log-line{white-space:pre-wrap}
</style>

<body>
<div class="player-wrap">
<div class="player">
<div class="bg" id="background"></div>
<div class="bg-overlay"></div>
<div class="content">
<div class="top">
<div>
<div class="top-title" id="playlistTitle">NOW PLAYING فيديو</div>
<div class="top-sub" id="playlistSub">${safeTitle}</div>
</div>
<button class="icon-btn" type="button" onclick="toggleMute()" id="muteButton">
<svg id="volumeIcon" viewBox="0 0 24 24"><path d="M11 5 6 9H2v6h4l5 4V5z"></path><path d="M19 9a5 5 0 0 1 0 6"></path><path d="M16 6.5a9 9 0 0 1 0 11"></path></svg>
</button>
</div>
<div class="فيديو-frame" id="videoFrame" onclick="toggleVideo()">
<فيديو id="videoPlayer" playsinline webkit-playsinline preload="none" poster="${posterBase64}"></فيديو>
<div class="big-play" id="bigPlay">
<button class="big-btn" type="button" onclick="event.stopPropagation();toggleVideo()">
<svg id="playIcon" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"></path></svg>
<svg id="pauseIcon" viewBox="0 0 24 24" style="display:none"><path d="M7 5v14"></path><path d="M17 5v14"></path></svg>
</button>
</div>
</div>
<div class="info">
<div class="song-title" id="songTitle">Unknown فيديو</div>
<div class="artist" id="artist">Unknown القناة</div>
</div>
<div class="progress">
<input id="progress" type="range" min="0" max="100" value="0" step="0.1" oninput="seekVideo(this.value)">
<div class="times"><span id="currentTime">0:00</span><span id="duration">0:00</span></div>
</div>
<div class="controls">
<button class="side-btn" type="button" onclick="previousVideo()"><svg viewBox="0 0 24 24"><path d="M19 20 9 12l10-8v16z"></path><path d="M5 19V5"></path></svg></button>
<button class="side-btn" type="button" onclick="toggleVideo()">
<svg id="smallPlayIcon" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"></path></svg>
<svg id="smallPauseIcon" viewBox="0 0 24 24" style="display:none"><path d="M7 5v14"></path><path d="M17 5v14"></path></svg>
</button>
<button class="side-btn" type="button" onclick="nextVideo()"><svg viewBox="0 0 24 24"><path d="m5 4 10 8-10 8V4z"></path><path d="M19 5v14"></path></svg></button>
</div>
<div class="bottom">
<div class="bottom-left">
<button class="icon-btn" type="button" onclick="toggleRepeat()" id="repeatButton">
<svg viewBox="0 0 24 24"><path d="M17 2l4 4-4 4"></path><path d="M3 11V9a3 3 0 0 1 3-3h15"></path><path d="m7 22-4-4 4-4"></path><path d="M21 13v2a3 3 0 0 1-3 3H3"></path></svg>
</button>
</div>
<div class="bottom-right">
<button class="icon-btn" type="button" onclick="toggleMute()"><svg viewBox="0 0 24 24"><path d="M11 5 6 9H2v6h4l5 4V5z"></path><path d="m19 9-5 6"></path><path d="m14 9 5 6"></path></svg></button>
<input class="volume" id="volume" type="range" min="0" max="1" step="0.01" value="1" oninput="changeVolume(this.value)">
</div>
</div>
</div>
</div>

<div class="debug-wrap">
<div class="debug-head"><div class="debug-title">WEBSOCKET فيديو</div><div class="debug-state" id="wsState">CONNECTING</div></div>
<div class="debug-الخادم" id="wsServer">-</div>
<div class="debug-grid">
<div class="debug-cell"><span>MIME</span><b id="dbgMime">-</b></div>
<div class="debug-cell"><span>Downloaded</span><b id="dbgDownloaded">0.00 MB</b></div>
<div class="debug-cell"><span>Total</span><b id="dbgTotal">-</b></div>
<div class="debug-cell"><span>Progress</span><b id="dbgProgress">0%</b></div>
<div class="debug-cell"><span>Chunks</span><b id="dbgChunks">0</b></div>
<div class="debug-cell"><span>Loop</span><b id="dbgLoop">OFF</b></div>
</div>
<div class="debug-bar"><div class="debug-bar-fill" id="dbgBarFill"></div></div>
<div class="debug-log" id="debugLog"></div>
</div>
</div>

<script>
window.VIDEO_CONFIG = {
    title: "${safeTitle}",
    القناة: "${safeChannel}",
    duration: "${safeDuration}",
    videoUrl: "${safeVideoUrl}",
    wsUrl: "${safeWsUrl}",
    displayWsHost: "${safeDisplayWsHost}",
    autoplay: false,
    volume: 0.8,
    loop: false
};

var فيديو = document.getElementById("videoPlayer");
var frame = document.getElementById("videoFrame");
var songTitle = document.getElementById("songTitle");
var artist = document.getElementById("artist");
var progress = document.getElementById("progress");
var currentTime = document.getElementById("currentTime");
var durationLabel = document.getElementById("duration");
var volume = document.getElementById("volume");
var smallPlayIcon = document.getElementById("smallPlayIcon");
var smallPauseIcon = document.getElementById("smallPauseIcon");
var repeatButton = document.getElementById("repeatButton");
var playlistSub = document.getElementById("playlistSub");
var background = document.getElementById("background");

var isLoop = false;
var userPressed = false;
var config = window.VIDEO_CONFIG || {};

songTitle.textContent = config.title || "Unknown فيديو";
artist.textContent = config.القناة || "Unknown القناة";
playlistSub.textContent = config.title || "Unknown فيديو";

if (فيديو.poster && background) background.style.backgroundImage = "url('" + فيديو.poster + "')";
if (config.volume !== undefined) { فيديو.volume = config.volume; volume.value = config.volume; }

isLoop = config.loop || false;
فيديو.loop = isLoop;
updateLoopStatus();

function formatTime(seconds) {
    if (!isFinite(seconds)) return "0:00";
    var min = Math.floor(seconds / 60);
    var sec = Math.floor(seconds % 60);
    if (sec < 10) sec = "0" + sec;
    return min + ":" + sec;
}

function updateUI() {
    if (فيديو.paused) {
        smallPlayIcon.style.display = "block"; smallPauseIcon.style.display = "none";
        frame.classList.remove("frame-playing");
    } else {
        smallPlayIcon.style.display = "none"; smallPauseIcon.style.display = "block";
        frame.classList.add("frame-playing");
    }
}

function playVideo() {
    var result = فيديو.play();
    if (result && result.catch) result.catch(function() {});
    updateUI();
}

function toggleVideo() {
    if (فيديو.paused) { if (!فيديو.src) userPressed = true; playVideo(); }
    else { userPressed = false; فيديو.pause(); }
    updateUI();
}

function previousVideo() { if (!isFinite(فيديو.duration)) return; فيديو.currentTime = Math.max(0, فيديو.currentTime - 10); }
function nextVideo() { if (!isFinite(فيديو.duration)) return; فيديو.currentTime = Math.min(فيديو.duration, فيديو.currentTime + 10); }
function seekVideo(value) { if (!isFinite(فيديو.duration)) return; فيديو.currentTime = (Number(value) / 100) * فيديو.duration; }
function changeVolume(value) { فيديو.volume = Number(value); if (فيديو.volume > 0) فيديو.muted = false; }
function toggleMute() { فيديو.muted = !فيديو.muted; }

function toggleRepeat() {
    isLoop = !isLoop; فيديو.loop = isLoop;
    repeatButton.style.opacity = isLoop ? "1" : ".55";
    repeatButton.title = isLoop ? "Loop ON" : "Loop OFF";
    updateLoopStatus();
}
function updateLoopStatus() { var el = document.getElementById("dbgLoop"); if (el) el.textContent = isLoop ? "ON" : "OFF"; }

فيديو.addEventListener("loadedmetadata", function() { durationLabel.textContent = formatTime(فيديو.duration); });
فيديو.addEventListener("timeupdate", function() {
    if (!isFinite(فيديو.duration)) return;
    progress.value = (فيديو.currentTime / فيديو.duration) * 100;
    currentTime.textContent = formatTime(فيديو.currentTime);
    durationLabel.textContent = formatTime(فيديو.duration);
});
فيديو.addEventListener("play", updateUI);
فيديو.addEventListener("pause", updateUI);
فيديو.addEventListener("ended", function() {
    if (!isLoop) { progress.value = 0; currentTime.textContent = "0:00"; فيديو.currentTime = 0; }
    updateUI();
});

var wsVideo = null, wsChunks = [], wsDownloaded = 0, wsTotal = null, wsMime = "video/mp4";
var wsObjectUrl = null, wsDone = false, wsLastLog = 0;

function fmtSize(bytes) {
    if (!isFinite(bytes)) return "0 B";
    if (bytes >= 1048576) return (bytes / 1048576).toFixed(2) + " MB";
    if (bytes >= 1024) return (bytes / 1024).toFixed(2) + " KB";
    return bytes + " B";
}
function setWsState(state) { var el = document.getElementById("wsState"); if (el) el.textContent = state; }
function writeLog(line) {
    var box = document.getElementById("debugLog"); if (!box) return;
    var div = document.createElement("div"); div.className = "log-line"; div.textContent = line;
    box.appendChild(div);
    while (box.childNodes.length > 80) box.removeChild(box.firstChild);
    box.scrollTop = box.scrollHeight;
}
function updateWsProgress() {
    var el = document.getElementById("dbgDownloaded"); if (el) el.textContent = fmtSize(wsDownloaded);
    if (wsTotal !== null && wsTotal > 0) {
        var pct = Math.min(100, (wsDownloaded / wsTotal) * 100);
        el = document.getElementById("dbgTotal"); if (el) el.textContent = fmtSize(wsTotal);
        el = document.getElementById("dbgProgress"); if (el) el.textContent = pct.toFixed(1) + "%";
        el = document.getElementById("dbgBarFill"); if (el) el.style.width = pct.toFixed(1) + "%";
    }
    el = document.getElementById("dbgChunks"); if (el) el.textContent = String(wsChunks.length);
}
function finishWsDownload(cfg) {
    if (wsDone) return; wsDone = true;
    setWsState("COMPLETE"); writeLog("اكتمل التنزيل");
    var blob = new Blob(wsChunks, { type: wsMime || "فيديو/mp4" });
    writeLog("Blob created (" + fmtSize(blob.size) + ")");
    if (wsObjectUrl) URL.revokeObjectURL(wsObjectUrl);
    wsObjectUrl = URL.createObjectURL(blob);
    writeLog("فيديو source attached");
    فيديو.src = wsObjectUrl; فيديو.load();
    writeLog("Player ready");
    if (wsVideo) { try { wsVideo.close(); } catch (e) {} }
    wsChunks = [];
    if (cfg.autoplay || userPressed) setTimeout(function() { playVideo(); }, 300);
}
function startVideoStream(cfg) {
    var videoUrl = cfg.videoUrl || "";
    var wsUrl = cfg.wsUrl || "";

    // النص الذي tampil في panel debug SENGAJA استخدام label terpisah
    // (displayWsHost), ليس host asli نتيجة parse wsUrl -- host asli
    // الذي صحيح-صحيح dipakai buat connect تبقى wsUrl في atas.
    var serverEl = document.getElementById("wsServer");
    if (serverEl) { serverEl.textContent = cfg.displayWsHost || "-"; }

    if (!wsUrl) { setWsState("خطأ"); writeLog("No فيديو URL متاح"); return; }
    if (typeof WebSocket === "undefined") { setWsState("خطأ"); writeLog("WebSocket API غير متاح"); return; }
    writeLog("Connecting..."); setWsState("CONNECTING");
    wsVideo = new WebSocket(wsUrl);
    wsVideo.binaryType = "arraybuffer";
    wsVideo.onopen = function() { writeLog("WebSocket OPEN"); setWsState("CONNECTED"); };
    wsVideo.onmessage = function(event) {
        if (typeof event.data === "string") {
            var message = null;
            try { message = JSON.parse(event.data); } catch (e) {}
            if (!message) return;
            if (message.type === "start") {
wsMime = message.mime || "video/mp4";
                if (message.contentLength !== undefined && message.contentLength !== null) wsTotal = Number(message.contentLength);
                else if (message.length !== undefined && message.length !== null) wsTotal = Number(message.length);
                var mimeEl = document.getElementById("dbgMime"); if (mimeEl) mimeEl.textContent = wsMime;
                writeLog("START | MIME: " + wsMime);
                if (wsTotal !== null && wsTotal > 0) writeLog("Size: " + fmtSize(wsTotal));
                setWsState("DOWNLOADING"); updateWsProgress();
                return;
            }
            if (message.type === "end") { writeLog("END"); finishWsDownload(config); return; }
            if (message.type === "خطأ") { writeLog("الخادم خطأ: " + (message.message || "unknown")); setWsState("خطأ"); return; }
            return;
        }
        wsChunks.push(event.data);
        var bytes = event.data.byteLength || 0;
        wsDownloaded += bytes;
        var now = Date.now();
        if (now - wsLastLog > 400) { wsLastLog = now; writeLog("Binary chunk: " + fmtSize(bytes)); }
        updateWsProgress();
    };
    wsVideo.onerror = function() { writeLog("WebSocket خطأ"); setWsState("خطأ"); };
    wsVideo.onclose = function(event) {
        if (wsDone) { setWsState("COMPLETE"); return; }
        writeLog("WebSocket closed unexpectedly");
        writeLog("Code: " + event.code + " Reason: " + (event.reason || "-"));
        setWsState("CLOSED");
    };
    window.addEventListener("beforeunload", function() {
        if (wsVideo) { try { wsVideo.close(); } catch (e) {} }
        if (wsObjectUrl) URL.revokeObjectURL(wsObjectUrl);
    });
}
startVideoStream(config);
</script>`
}

// handler = fungsi utama yang dijalanin tiap kali command ke-trigger.
// m    = objek pesan (m.text, m.sender, m.chat, m.reply(), m.react(), dll)
// sock = instance socket Baileys (buat relayMessage custom payload)
async function handler(m, { sock }) {
    const query = m.text?.trim()

    if (!query) {
        return m.reply(
            `📦 *ʏᴛᴘʟᴀʏ الإضافة* 🎤\n\n` +
            `> MUSASHI أحتاج العنوان أو رابط YouTube أولاً من فضلك~ ✨\n\n` +
            `> ${m.prefix}ytplay <judul/الرابط>\n\n` +
            `*ᴄᴏɴᴛᴏʜ:*\n` +
            `> ${m.prefix}ytplay alan walker faded\n` +
            `> ${m.prefix}ytp https://youtu.be/xxxxx`
        )
    }

    await m.react('🕕')

    try {
        const youtubeUrl = await searchYoutube(query)
        if (!youtubeUrl) throw new Error('Video YouTube غير موجود.')

        const info = await getYoutubeDirectUrl(youtubeUrl, '360')
        if (!info?.url) throw new Error('فشل mendapatkan direct الرابط video.')

        let posterBase64 = ''
        if (info.thumb) {
            try {
                const thumbRes = await axios.get(info.thumb, { responseType: 'arraybuffer', timeout: 10000 })
                posterBase64 = 'data:image/jpeg;base64,' + Buffer.from(thumbRes.data).toString('base64')
            } catch {
                posterBase64 = ''
            }
        }

        // Koneksi WS ke server stream milik Itsuki sendiri (src/lib/itsukiws).
        // Tidak ada host pihak ketiga yang dipakai.
        if (!itsukiWs.isExternal() && !itsukiWs.getStatus().running) itsukiWs.startServer()
        let wsUrl
        try {
            wsUrl = itsukiWs.buildStreamUrl(info.url)
        } catch (e) {
            throw new Error('الخادم stream لم siap: ' + e.message)
        }
        const duration = info.duration
            ? `${Math.floor(info.duration / 60)}:${String(info.duration % 60).padStart(2, '0')}`
            : ''

        const htmlPayload = buildPlayerHtml({
            title: info.title || 'YouTube Video',
            channel: info.author || 'YouTube',
            duration,
            videoUrl: info.url,
            wsUrl,
            displayWsHost: DISPLAY_WS_HOST,
            posterBase64
        })

        await sock.relayMessage(
            m.chat,
            {
                botForwardedMessage: {
                    message: {
                        richResponseMessage: {
                            messageType: 1,
                            unifiedResponse: {
                                data: Buffer.from(
                                    JSON.stringify({
                                        __typename: 'GenAIUnifiedResponse',
                                        response_id: randomUUID(),
                                        sections: [
                                            {
                                                __typename: 'GenAIUnifiedResponseSection',
                                                view_model: {
                                                    __typename: 'GenAISingleLayoutViewModel',
                                                    primitive: {
                                                        __typename: 'FOAHtmlPrimitiveDemoDONOTUSE',
                                                        trusted_sources: [],
                                                        payload: htmlPayload
                                                    }
                                                }
                                            }
                                        ]
                                    })
                                ).toString('base64')
                            },
                            contextInfo: { isForwarded: true, forwardOrigin: 4 }
                        }
                    }
                }
            },
            { additionalAttributes: { type: 'النص' }, edit: false }
        )

        await m.react('✅')
    } catch (error) {
        console.error('[ytplay] الخطأ:', error)
        await m.react('❌')
        return m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
