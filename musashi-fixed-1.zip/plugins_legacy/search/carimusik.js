const axios = require('axios')
const config = require('../../config')
const path = require('path')
const fs = require('fs')

const NEOXR_APIKEY = config.APIkey?.neoxr || 'Milik-Bot-Itsuki'

const pluginConfig = {
    name: 'carimusik',
    alias: ['searchmusic', 'scsearch', 'soundcloud', 'findsong'],
    category: 'search',
    description: 'بحث و download lagu من SoundCloud',
    usage: '.carimusik <judul>',
    example: '.carimusik komang',
    cooldown: 10,
    energi: 1,
    isEnabled: true
}

const musicSessions = new Map()

let thumbMusic = null
require('../../src/lib/assetManager').getAssetBuffer('images.itsukiMusic').then(b => { thumbMusic = b }).catch(() => {})

function getContextInfo(title, body, thumbnail) {
    const saluranId = config.saluran?.id || '120363432546133683@newsletter'
    const saluranName = config.saluran?.name || config.bot?.name || 'MUSASHI'

    const ctx = {
        forwardingScore: 9999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: saluranId,
            newsletterName: saluranName,
            serverMessageId: 127
        }
    }

    const thumb = thumbnail || thumbMusic

    return ctx
}

function formatDuration(ms) {
    const seconds = Math.floor(ms / 1000)
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
}

function formatNumber(num) {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M'
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K'
    return num.toString()
}

async function handler(m, { sock }) {
    const args = m.args || []
    const query = args.join(' ').trim()
    
    if (!query) {
        return m.reply(
            `🎵 *ᴄᴀʀɪ ᴍᴜsɪᴋ*\n\n` +
            `> بحث و download lagu من SoundCloud\n\n` +
            `*Format:*\n` +
            `> \`${m.prefix}carimusik <judul>\`\n\n` +
            `*مثال:*\n` +
            `> \`${m.prefix}carimusik komang\``
        )
    }
    
    m.react('🎵')
    
    try {
        const apiUrl = `https://api.neoxr.eu/api/song?q=${encodeURIComponent(query)}&apikey=${NEOXR_APIKEY}`
        const { data } = await axios.get(apiUrl, { timeout: 30000 })
        
        if (!data?.status || !data?.data?.length) {
            m.react('❌')
            return m.reply(`❌ *غير موجود*\n\n> Lagu "${query}" غير موجود`)
        }
        
        const songs = data.data.slice(0, 10)
        
        musicSessions.set(m.sender, {
            songs,
            query,
            timestamp: Date.now()
        })
        
        setTimeout(() => {
            musicSessions.delete(m.sender)
        }, 300000)
        
        let text = `🎵 *النتيجة ᴘᴇɴᴄᴀʀɪᴀɴ*\n\n`
        text += `> Ditemukan *${songs.length}* lagu لـ "${query}"\n\n`
        
        songs.forEach((s, i) => {
            const duration = formatDuration(s.duration || 0)
            const plays = formatNumber(s.playback_count || 0)
            const likes = formatNumber(s.likes_count || 0)
            text += `*${i + 1}. ${s.title}*\n`
            text += `> ⏱️ ${duration} | ▶️ ${plays} | ❤️ ${likes}\n`
            text += `> 👤 ${s.user?.username || '-'}\n\n`
        })
        
        text += `> _اختر lagu dari list في الأسفل_`
        
        const listItems = songs.map((s, i) => ({
            header: '',
            title: s.title?.substring(0, 24) || `Song ${i + 1}`,
            description: `${formatDuration(s.duration || 0)} | ${s.user?.username || '-'}`,
            id: `${m.prefix}getmusik ${i + 1}`
        }))
        
        await sock.sendMessage(m.chat, {
            text,
            footer: '🎵 SoundCloud Search',
            contextInfo: getContextInfo('🎵 CARI MUSIK', `${songs.length} نتيجة`),
            interactiveButtons: [
                {
                    name: 'single_select',
                    buttonParamsJson: JSON.stringify({
                        title: '🎵 اختر Lagu',
                        sections: [
                            {
                                title: 'النتيجة Pencarian',
                                rows: listItems
                            }
                        ]
                    })
                }
            ]
        }, { quoted: m })
        
        m.react('✅')
        
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/search/carimusik.js] exception", error?.stack || error);
        m.react('❌')
        m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler,
    musicSessions
}