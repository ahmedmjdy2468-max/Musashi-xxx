const axios = require('axios')

const pluginConfig = {
    name: 'searchgd',
    alias: ['carigd', 'gdsearch', 'searchlevel'],
    category: 'search',
    description: 'بحث المستوى Geometry Dash berdasarkan الاسم',
    usage: '.searchgd <الاسم المستوى>',
    example: '.searchgd Bloodbath',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 1,
    isEnabled: true
}

const RESULT_LIMIT = 5

function fmtNum(n) {
    return (n ?? 0).toLocaleString('id-ID')
}

function levelLine(idx, lvl) {
    return (
        `┌─ *${idx}. ${lvl.name || 'Tanpa Nama'}*\n` +
        `│ 🆔 ID: ${lvl.id ?? '-'}\n` +
        `│ 👤 Author: ${lvl.author || '-'}\n` +
        `│ 🎯 Difficulty: ${lvl.difficulty || '-'}\n` +
        `│ ⭐ Stars: ${fmtNum(lvl.stars)}${lvl.featured ? ' 🌟 Featured' : ''}${lvl.epic ? ' 💫 Epic' : ''}\n` +
        `│ 📥 Downloads: ${fmtNum(lvl.downloads)}  👍 Likes: ${fmtNum(lvl.likes)}\n` +
        `│ 📏 Length: ${lvl.length || '-'}\n` +
        `│ 🎵 Song: ${lvl.songName || '-'}\n` +
        `└─────────────────\n`
    )
}

async function handler(m, { sock }) {
    const query = m.args.join(' ').trim()

    if (!query) {
        return m.reply(
            `『 🔍 *ᴄᴀʀɪ المستوى ɢᴇᴏᴍᴇᴛʀʏ ᴅᴀsʜ* 🔍 』\n` +
            `✦✦✦✦✦✦✦✦✦✦✦✦✦✦✦\n\n` +
            `✨ *طريقة الاستخدام:*\n` +
            `\`${m.prefix}searchgd <الاسم المستوى>\`\n\n` +
            `💫 *مثال:*\n` +
            `\`${m.prefix}searchgd Bloodbath\`\n\n` +
            `✦✦✦✦✦✦✦✦✦✦✦✦✦✦✦\n` +
            `> 💖 MUSASHI bantu cariin level GD-nya~ 🌸`
        )
    }

    m.react('⭐')

    try {
        const res = await axios.get(
            `https://gdbrowser.com/api/search/${encodeURIComponent(query)}`,
            { params: { count: RESULT_LIMIT }, timeout: 20000 }
        )

        const results = res.data

        if (!results || results === '-1' || !Array.isArray(results) || results.length === 0) {
            m.react('❌')
            return m.reply(
                `『 💔 *غير موجود* 』\n\n` +
                `> المستوى مع kata kunci \`${query}\` لا ketemu هنا~\n` +
                `> حاول kata kunci lain نعم. 💕`
            )
        }

        const levelList = results
            .slice(0, RESULT_LIMIT)
            .map((lvl, i) => levelLine(i + 1, lvl))
            .join('\n')

        const caption =
            `『 🌟 *ʜᴏsʜɪɴᴏ ᴀɪ* — النتيجة ᴘᴇɴᴄᴀʀɪᴀɴ 🌟 』\n` +
            `✦✦✦✦✦✦✦✦✦✦✦✦✦✦✦\n\n` +
            `🔍 *Kata kunci:* ${query}\n` +
            `📋 *Menampilkan:* ${Math.min(results.length, RESULT_LIMIT)} المستوى\n\n` +
            levelList + '\n' +
            `💡 *Tips:* استخدام \`${m.prefix}levelgd <ID>\` buat lihat detail lengkap خطأ satu المستوى في atas~\n\n` +
            `✦✦✦✦✦✦✦✦✦✦✦✦✦✦✦\n` +
            `🌸 *MUSASHI Bot* ✨\n` +
            `> 「 *推しの子* 」\n` +
            `> موساشي دائماً معك 💖⭐`

        m.react('✅')
        await m.reply(caption)

    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/search/searchgd.js] exception", error?.stack || error);
        m.react('❌')
        m.reply(
            "حدث خطأ، حاول لاحقاً"
        )
    }
}

module.exports = {
    config: pluginConfig,
    handler
}