const dramaboxsearch = require('../../src/scraper/dramabox')

const pluginConfig = {
    name: 'dramabox',
    alias: ['drama', 'dramasearch'],
    category: 'search',
    description: "يبحث في DramaBox عن الدراما ويعرض النتائج.",
    usage: ".دراما_بوكس <اسم_الدراما>",
    example: ".دراما_بوكس billionaire",
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const query = m.text?.trim()
    
    if (!query) {
        return m.reply(
            `⚠️ *طريقة الاستخدام*\n\n` +
            `> \`${m.prefix}dramabox <query>\`\n\n` +
            `> مثال:\n` +
            `> \`${m.prefix}dramabox billionaire\``
        )
    }
    
    try {
        const data = await dramaboxsearch(query)
        
        if (data.status === 'eror' || !data.results?.length) {
            return m.reply(`❌ *همم~* غير موجود drama لـ: ${query} 🥺`)
        }
        
        const dramas = data.results.slice(0, 5)
        
        let txt = `🎬 *ᴅʀᴀᴍᴀʙᴏx sᴇᴀʀᴄʜ*\n\n`
        txt += `╭┈┈⬡「 🔍 *ɪɴꜰᴏ* 」\n`
        txt += `┃ 🔎 ǫᴜᴇʀʏ: *${query}*\n`
        txt += `┃ 📊 الإجمالي: *${data.total} نتيجة*\n`
        txt += `╰┈┈⬡\n\n`
        
        dramas.forEach((d, i) => {
            const desc = d.description?.substring(0, 80) || '-'
            txt += `╭┈┈⬡「 🎭 *${i + 1}* 」\n`
            txt += `┃ 📛 \`\`\`${d.title}\`\`\`\n`
            txt += `┃ 📺 ᴇᴘɪsᴏᴅᴇs: *${d.episodes || 0}*\n`
            txt += `┃ 📝 ${desc}${d.description?.length > 80 ? '...' : ''}\n`
            txt += `┃ 🔗 \`${d.play_url}\`\n`
            txt += `╰┈┈⬡\n\n`
        })
        
        return m.reply(txt.trim())
        
    } catch (err) {
        console.error("[MUSASHI][plugins_legacy/search/dramabox.js] exception", err?.stack || err);
        return m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
