const axios = require('axios')
const fs = require('fs')
const path = require('path')
const fetch = require('node-fetch')
const { exec } = require('child_process')
const { promisify } = require('util')
const { zencf } = require('zencf')
const config = require('../../config')
const { wrapper } = require('axios-cookiejar-support')
const { CookieJar } = require('tough-cookie')
const cheerio = require('cheerio')
const { f } = require('../../src/lib/undici')

const execAsync = promisify(exec)

const pluginConfig = {
    name: 'spotplay',
    alias: ['splay'],
    category: 'search',
    description: "يبحث عن المقطع الذي تدخله ويرسله بصيغة MP3.",
    usage: ".تشغيل_سبوتيفاي <اسم_المقطع>",
    example: ".تشغيل_سبوتيفاي Neffex Grateful",
    cooldown: 20,
    energi: 1,
    isEnabled: true
}

async function handler(m, { sock }) {
    const query = m.text?.trim()
    if (!query)
        return m.reply(
            `⚠️ *طريقة الاستخدام*\n\n> \`${m.prefix}spotplay <query>\``
        )

    m.react('🕕')

    try {
        const { result } = await f(`https://api.nexray.web.id/downloader/spotifyplay?q=${encodeURIComponent(query)}`)
        await sock.sendMedia(m.chat, result?.download_url, null, m, {
                type: 'audio',
                mimetype: 'audio/mpeg',
                ptt: false,
                fileName: `${result?.title}.mp3`,
                contextInfo: {
                }
            })
    } catch (e) {
        console.error("[MUSASHI][plugins_legacy/search/spotplay.js] exception", e?.stack || e);
        m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = { 
    config: pluginConfig, 
    handler 
}