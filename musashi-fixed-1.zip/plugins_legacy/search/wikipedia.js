const axios = require('axios')
const config = require('../../config')
const { f } = require('../../src/lib/undici')

const pluginConfig = {
    name: "",
    alias: ['wiki', 'ensiklopedia'],
    category: 'search',
    description: 'يبحث عن مقالة في ويكيبيديا باللغة العربية.',
    usage: '.ويكيبيديا <عبارة البحث>',
    example: '.ويكيبيديا تاريخ اليابان',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    const query = m.text?.trim()
    
    if (!query) {
        return m.reply(
            `📚 *ويكيبيديا*\n\n` +
            `> أرسل عبارة البحث.\n\n` +
            `> مثال: \`${m.prefix}ويكيبيديا تاريخ اليابان\``
        )
    }
    
    m.react('🕕')
    
    try {
        const apiKey = config.APIkey?.lolhuman
        
        if (!apiKey) {
            throw new Error('مفتاح API غير موجود في الإعدادات')
        }
        
        const res = await f(`https://api.lolhuman.xyz/api/wiki2?apikey=${apiKey}&query=${encodeURIComponent(query)}&lang=ar`)
        
        if (res.status !== 200 || !res.result) {
            throw new Error('Artikel غير موجود')
        }
        
        const result = res.result
        await m.reply(result)
        m.react('✅')
        
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/search/wikipedia.js] exception", error?.stack || error);
        m.react('❌')
        m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
