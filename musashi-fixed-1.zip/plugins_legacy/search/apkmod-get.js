const axios = require('axios')
const config = require('../../config')

const pluginConfig = {
    name: 'apkmod-get',
    alias: ['apkmodget', 'getapkmod'],
    category: 'search',
    description: "يبحث عن تطبيقات معدّلة ويتيح تنزيل النتيجة المحددة.",
    usage: ".تحميل_تطبيق <رقم_النتيجة> <بحث>",
    example: ".تحميل_تطبيق 1 vpn",
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 15,
    energi: 1,
    isEnabled: true
}

const NEOXR_APIKEY = config.APIkey?.neoxr || 'Milik-Bot-Itsuki'

async function handler(m, { sock }) {
    const args = m.args || []
    const no = parseInt(args[0])
    const query = args.slice(1).join(' ')
    
    if (!no || !query) {
        return m.reply(`❌ *همم~* Format: \`${m.prefix}apkmod-get <no> <query>\``)
    }
    
    m.react('📥')
    
    try {
        const { data } = await axios.get(`https://api.neoxr.eu/api/apkmod?q=${encodeURIComponent(query)}&no=${no}&apikey=${NEOXR_APIKEY}`, {
            timeout: 60000
        })
        
        if (!data?.status || !data?.data) {
            throw new Error('تعذّر جلب تفاصيل التطبيق')
        }
        
        const app = data.data
        const file = data.file
        
        const saluranId = config.saluran?.id || '120363432546133683@newsletter'
        const saluranName = config.saluran?.name || config.bot?.name || 'MUSASHI'
        
        let caption = `📱 *ᴀᴘᴋ ᴍᴏᴅ تنزيل*\n\n`
        caption += `╭┈┈⬡「 📋 *ɪɴꜰᴏ* 」\n`
        caption += `┃ 📛 *${app.name}*\n`
        caption += `┃ 👤 ${app.author}\n`
        caption += `┃ 📂 ${app.category}\n`
        caption += `┃ 📦 ${app.size}\n`
        caption += `┃ 🏷️ ${app.version}\n`
        caption += `┃ 🔓 ${app.mod}\n`
        caption += `┃ 💰 ${app.price}\n`
        caption += `┃ 📅 ${app.publish}\n`
        caption += `╰┈┈⬡\n\n`
        
        if (file?.url) {
            caption += `> 📥 جارٍ إرسال ملف التطبيق...`
            
            await sock.sendMessage(m.chat, {
                text: caption,
                contextInfo: {
                    forwardingScore: 9999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: saluranId,
                        newsletterName: saluranName,
                        serverMessageId: 127
                    }
                }
            }, { quoted: m })
            
            await sock.sendMessage(m.chat, {
                document: { url: file.url?.trim() },
                fileName: file.filename || `${app.name}.apk`,
                mimetype: 'application/vnd.android.package-archive',
                contextInfo: {
                    forwardingScore: 9999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: saluranId,
                        newsletterName: saluranName,
                        serverMessageId: 127
                    }
                }
            }, { quoted: m })
            
            m.react('✅')
        } else {
            caption += `> ⚠️ ملف APK غير متاح`
            
            await sock.sendMessage(m.chat, {
                text: caption,
                contextInfo: {
                    forwardingScore: 9999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: saluranId,
                        newsletterName: saluranName,
                        serverMessageId: 127
                    }
                }
            }, { quoted: m })
            
            m.react('⚠️')
        }
        
    } catch (err) {
        console.error("[MUSASHI][plugins_legacy/search/apkmod-get.js] exception", err?.stack || err);
        m.react('❌')
        return m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
