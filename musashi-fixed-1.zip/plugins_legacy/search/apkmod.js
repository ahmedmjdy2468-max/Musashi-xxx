const axios = require('axios')
const config = require('../../config')

const pluginConfig = {
    name: 'apkmod',
    alias: ['modapk2', 'apkpremium'],
    category: 'search',
    description: 'بحث و download APK MOD Premium',
    usage: '.apkmod <query>',
    example: '.apkmod vpn',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 1,
    isEnabled: true
}

const NEOXR_APIKEY = config.APIkey?.neoxr || 'Milik-Bot-Itsuki'

async function handler(m, { sock }) {
    const text = m.text?.trim()
    
    if (!text) {
        return m.reply(
            `📱 *ᴀᴘᴋ ᴍᴏᴅ sᴇᴀʀᴄʜ*\n\n` +
            `> Cari APK MOD Premium\n\n` +
            `> مثال:\n` +
            `\`${m.prefix}apkmod vpn\``
        )
    }
    
    m.react('🔍')
    
    try {
        const { data } = await axios.get(`https://api.neoxr.eu/api/apkmod?q=${encodeURIComponent(text)}&apikey=${NEOXR_APIKEY}`, {
            timeout: 30000
        })
        
        if (!data?.status || !data?.data?.length) {
            m.react('❌')
            return m.reply(`❌ *همم~* لا توجد نتائج لـ: \`${text}\``)
        }
        
        const apps = data.data.slice(0, 15)
        
        const saluranId = config.saluran?.id || '120363432546133683@newsletter'
        const saluranName = config.saluran?.name || config.bot?.name || 'MUSASHI'
        
        let caption = `📱 *ᴀᴘᴋ ᴍᴏᴅ sᴇᴀʀᴄʜ*\n\n`
        caption += `╭┈┈⬡「 🔍 *النتيجة* 」\n`
        caption += `┃ Query: *${text}*\n`
        caption += `┃ النتيجة: *${apps.length}* APK\n`
        caption += `╰┈┈⬡\n\n`
        
        apps.forEach((app, i) => {
            caption += `*${i + 1}.* \`${app.name}\`\n`
            caption += `   ├ 🏷️ ${app.version}\n`
            caption += `   └ 🔓 ${app.mod}\n\n`
        })
        
        caption += `> ردّ على مع angka (1-${apps.length}) لـ detail + download`
        
        const buttons = apps.slice(0, 10).map((app, i) => ({
            title: `${i + 1}. ${app.name.substring(0, 24)}`,
            description: `${app.version} • ${app.mod}`,
            id: `${m.prefix}apkmod-get ${i + 1} ${text}`
        }))
        
        global.apkmodSession = global.apkmodSession || {}
        global.apkmodSession[m.sender] = {
            results: apps,
            query: text,
            timestamp: Date.now()
        }
        
        m.react('✅')
        
        await sock.sendMessage(m.chat, {
            text: caption,
            contextInfo: {
                forwardingScore: 9999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: saluranId,
                    newsletterName: saluranName,
                    serverMessageId: 127
                }
            },
            interactiveButtons: [{
                name: 'single_select',
                buttonParamsJson: JSON.stringify({
                    title: '📱 اختر APK MOD',
                    sections: [{
                        title: `نتائج البحث عن "${text}"`,
                        rows: buttons
                    }]
                })
            }]
        }, { quoted: m })
        
    } catch (err) {
        console.error("[MUSASHI][plugins_legacy/search/apkmod.js] exception", err?.stack || err);
        m.react('❌')
        return m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
