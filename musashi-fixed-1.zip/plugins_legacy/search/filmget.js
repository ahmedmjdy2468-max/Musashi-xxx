const axios = require('axios')
const config = require('../../config')
const path = require('path')
const fs = require('fs')

const NEOXR_APIKEY = config.APIkey?.neoxr || 'Milik-Bot-Itsuki'

const pluginConfig = {
    name: 'filmget',
    alias: ['getfilm', 'filmdetail', 'filminfo'],
    category: 'search',
    description: "يجلب تفاصيل الفيلم وروابط المشاهدة أو التنزيل من رابطه.",
    usage: ".احصل_على_فيلم <رابط_الفيلم>",
    example: ".احصل_على_فيلم https://tv.example/film/title",
    cooldown: 10,
    energi: 1,
    isEnabled: true
}

async function handler(m, { sock }) {
    const args = m.args || []
    const url = args[0]?.trim()
    
    if (!url || !url.includes('neoxr.eu')) {
        return m.reply(
            `🎬 *ꜰɪʟᴍ التفاصيل*\n\n` +
            `> Ambil detail film dari URL\n\n` +
            `*Format:*\n` +
            `> \`${m.prefix}filmget <url>\`\n\n` +
            `> استخدم \`${m.prefix}film <العنوان>\` لـ بحث film أولاً`
        )
    }
    
    m.react('🎬')
    
    try {
        const apiUrl = `https://api.neoxr.eu/api/film-get?url=${encodeURIComponent(url)}&apikey=${NEOXR_APIKEY}`
        const { data } = await axios.get(apiUrl, { timeout: 30000 })
        
        if (!data?.status || !data?.data) {
            m.react('❌')
            return m.reply('❌ *عذراً* ✦\n\n> Film غير موجود~ 🥺')
        }
        
        const film = data.data
        const streams = data.stream || []
        const downloads = data.download || []
        
        let thumbBuffer = null
        if (film.thumbnail) {
            try {
                const thumbRes = await axios.get(film.thumbnail, { responseType: 'arraybuffer', timeout: 10000 })
                thumbBuffer = Buffer.from(thumbRes.data)
            } catch {}
        }
        
        let text = `🎬 *${film.title || 'Film'}*\n\n`
        text += `╭┈┈⬡「 📋 *ɪɴꜰᴏ* 」\n`
        text += `┃ ⭐ Rating: ${film.rating || '-'}\n`
        text += `┃ 📺 Quality: ${film.quality || '-'}\n`
        text += `┃ ⏱️ Duration: ${film.duration || '-'}\n`
        text += `┃ 📅 Release: ${film.release || '-'}\n`
        text += `┃ 🎭 Genre: ${film.tags || '-'}\n`
        text += `┃ 🎬 Director: ${film.director || '-'}\n`
        text += `┃ 👥 Actors: ${film.actors || '-'}\n`
        text += `╰┈┈┈┈┈┈┈┈⬡\n\n`
        
        text += `📝 *Synopsis:*\n`
        text += `> ${film.synopsis || '-'}\n\n`
        
        if (streams.length > 0) {
            text += `▶️ *Streaming:*\n`
            streams.forEach((s, i) => {
                text += `> ${i + 1}. ${s.server}\n`
            })
            text += `\n`
        }
        
        if (downloads.length > 0) {
            text += `📥 *Download:*\n`
            downloads.forEach((d, i) => {
                text += `> ${i + 1}. ${d.provider}\n`
            })
        }
        
        const buttons = []
        
        if (streams.length > 0) {
            buttons.push({
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                    display_text: `▶️ ${streams[0].server}`,
                    url: streams[0].url
                })
            })
        }
        
        downloads.slice(0, 2).forEach(d => {
            buttons.push({
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                    display_text: `📥 ${d.provider}`,
                    url: d.url
                })
            })
        })
        
        const saluranId = config.saluran?.id || '120363432546133683@newsletter'
        const saluranName = config.saluran?.name || config.bot?.name || 'MUSASHI'
        
        const msgContent = {
            text,
            footer: `🎬 Nonton Film Online`,
            contextInfo: {
                forwardingScore: 9999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: saluranId,
                    newsletterName: saluranName,
                    serverMessageId: 127
                }
            }
        }
        
        
        if (buttons.length > 0) {
            msgContent.interactiveButtons = buttons
        }
        
        await sock.sendMessage(m.chat, msgContent, { quoted: m })
        
        m.react('✅')
        
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/search/filmget.js] exception", error?.stack || error);
        m.react('❌')
        m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}