const axios = require('axios')
const config = require('../../config')
const path = require('path')
const fs = require('fs')

const NEOXR_APIKEY = config.APIkey?.neoxr || 'Milik-Bot-Itsuki'

const pluginConfig = {
    name: 'film',
    alias: ['movie', 'nonton', 'lk21'],
    category: 'search',
    description: 'بحث film و nonton online',
    usage: '.film <judul>',
    example: '.film civil war',
    cooldown: 10,
    energi: 1,
    isEnabled: true
}

const filmSessions = new Map()

let thumbFilm = null
require('../../src/lib/assetManager').getAssetBuffer('images.itsukiFilm').then(b => { thumbFilm = b }).catch(() => {})

function getContextInfo(title, body, thumbnail) {
    const saluranId = config.saluran?.id || '120363432546133683@newsletter'
    const saluranName = config.saluran?.name || config.bot?.name || 'MUSASHI'

    const ctx = {
        forwardingScore: 9999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: saluranId,
            newsletterName: saluranName,
            serverMessageId: 127
        }
    }

    const thumb = thumbnail || thumbFilm

    return ctx
}

async function handler(m, { sock }) {
    const args = m.args || []
    const query = args.join(' ').trim()
    
    if (!query) {
        return m.reply(
            `🎬 *ꜰɪʟᴍ sᴇᴀʀᴄʜ*\n\n` +
            `> بحث و nonton film online\n\n` +
            `*Format:*\n` +
            `> \`${m.prefix}film <judul>\`\n\n` +
            `*مثال:*\n` +
            `> \`${m.prefix}film civil war\``
        )
    }
    
    m.react('🎬')
    
    try {
        const apiUrl = `https://api.neoxr.eu/api/film?q=${encodeURIComponent(query)}&apikey=${NEOXR_APIKEY}`
        const { data } = await axios.get(apiUrl, { timeout: 30000 })
        
        if (!data?.status || !data?.data?.length) {
            m.react('❌')
            return m.reply(`❌ *غير موجود*\n\n> Film "${query}" غير موجود`)
        }
        
        const films = data.data.slice(0, 10)
        
        filmSessions.set(m.sender, {
            films,
            timestamp: Date.now()
        })
        
        setTimeout(() => {
            filmSessions.delete(m.sender)
        }, 300000)
        
        let text = `🎬 *النتيجة ᴘᴇɴᴄᴀʀɪᴀɴ*\n\n`
        text += `> Ditemukan *${films.length}* film لـ "${query}"\n\n`
        
        films.forEach((f, i) => {
            text += `*${i + 1}. ${f.title}*\n`
            text += `> ⭐ ${f.rating} | 📺 ${f.quality} | 📅 ${f.release}\n\n`
        })
        
        text += `> _اختر film dari list في الأسفل_`
        
        const listItems = films.map((f, i) => ({
            header: '',
            title: f.title,
            description: `⭐ ${f.rating} | ${f.quality} | ${f.release}`,
            id: `${m.prefix}filmget ${f.url}`
        }))
        
        await sock.sendMessage(m.chat, {
            text,
            footer: '🎬 Film Search',
            contextInfo: getContextInfo('🎬 FILM', `${films.length} نتيجة`),
            interactiveButtons: [
                {
                    name: 'single_select',
                    buttonParamsJson: JSON.stringify({
                        title: '🎬 اختر Film',
                        sections: [
                            {
                                title: 'النتيجة Pencarian',
                                rows: listItems
                            }
                        ]
                    })
                }
            ]
        }, { quoted: m })
        
        m.react('✅')
        
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/search/film.js] exception", error?.stack || error);
        m.react('❌')
        m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}