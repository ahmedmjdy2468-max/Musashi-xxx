const config = require('../../config')

const pluginConfig = {
    name: 'animelink',
    alias: [],
    category: 'search',
    description: 'Handler لـ رابط download anime',
    usage: 'Internal الأمر',
    example: '',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true,
    isHidden: true
}

async function handler(m, { sock }) {
    const data = m.text?.trim()
    
    if (!data) {
        return m.reply(`❌ *همم~* Data episode غير صالح~ 🥺`)
    }
    
    try {
        const episodeData = JSON.parse(data)
        const links = episodeData.links || []
        
        if (links.length === 0) {
            return m.reply(`❌ *همم~* غير موجود الرابط download متاح~ 🥺`)
        }
        
        let caption = `🎬 *${episodeData.episode}*\n\n`
        caption += `📥 *ʟɪɴᴋ تنزيل:*\n\n`
        
        for (const quality of links) {
            caption += `📺 *${quality.quality}*\n`
            for (const server of (quality.url || [])) {
                caption += `> • ${server.server}: ${server.url}\n`
            }
            caption += `\n`
        }
        
        caption += `> _اختر quality و الخادم الذي diinginkan_`
        
        await m.reply(caption)
        
    } catch (err) {
        console.error("[MUSASHI][plugins_legacy/search/animelink.js] exception", err?.stack || err);
        return m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
