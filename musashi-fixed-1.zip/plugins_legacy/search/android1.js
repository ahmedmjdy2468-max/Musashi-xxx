const axios = require('axios')
const config = require('../../config')
const { getDatabase } = require('../../src/lib/database')

const pluginConfig = {
    name: 'android1',
    alias: ['an1'],
    category: 'search',
    description: 'بحث و download APK MOD من Android1',
    usage: '.android1 <query>',
    example: '.android1 Subway Surfer',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 1,
    isEnabled: true
}

const NEOXR_APIKEY = config.APIkey?.neoxr || 'Milik-Bot-Itsuki'

async function handler(m, { sock }) {
    const db = getDatabase()
    const args = m.args || []
    const text = m.text?.trim()
    
    if (!text) {
        return m.reply(
            `📱 *ᴀɴᴅʀᴏɪᴅ1 sᴇᴀʀᴄʜ*\n\n` +
            `╭┈┈⬡「 📋 *طريقة الاستخدام* 」\n` +
            `┃ 🔍 \`${m.prefix}android1 <query>\` - Cari APK\n` +
            `╰┈┈⬡\n\n` +
            `> مثال:\n` +
            `\`${m.prefix}android1 Subway Surfer\``
        )
    }
    
    m.react('🔍')
    
    try {
        const { data } = await axios.get(`https://api.neoxr.eu/api/an1?q=${encodeURIComponent(text)}&apikey=${NEOXR_APIKEY}`, {
            timeout: 30000
        })
        
        if (!data?.status || !data?.data?.length) {
            m.react('❌')
            return m.reply(`❌ *همم~* لا توجد نتائج لـ: \`${text}\``)
        }
        
        const apps = data.data.slice(0, 10)
        
        if (!db.db.data.sessions) db.db.data.sessions = {}
        const sessionKey = `an1_${m.sender}`
        db.db.data.sessions[sessionKey] = {
            results: apps,
            query: text,
            timestamp: Date.now()
        }
        db.save()
        
        const saluranId = config.saluran?.id || '120363432546133683@newsletter'
        const saluranName = config.saluran?.name || config.bot?.name || 'MUSASHI'
        
        let caption = `📱 *ᴀɴᴅʀᴏɪᴅ1 sᴇᴀʀᴄʜ*\n\n`
        caption += `> Query: *${text}*\n`
        caption += `> النتيجة: *${apps.length}* aplikasi\n\n`
        
        apps.forEach((app, i) => {
            caption += `*${i + 1}.* \`${app.name}\`\n`
            caption += `   ├ 👤 ${app.developer}\n`
            caption += `   └ ⭐ ${app.rating}/5\n\n`
        })
        
        caption += `> اختر angka لـ download langsung`
        
        const buttons = apps.slice(0, 10).map((app, i) => ({
            title: `${i + 1}. ${app.name.substring(0, 20)}`,
            description: `${app.developer} • ⭐${app.rating}`,
            id: `${m.prefix}android1-get ${app.url}`
        }))
        
        m.react('✅')
        
        await sock.sendMessage(m.chat, {
            text: caption,
            contextInfo: {
                forwardingScore: 9999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: saluranId,
                    newsletterName: saluranName,
                    serverMessageId: 127
                }
            },
            interactiveButtons: [{
                name: 'single_select',
                buttonParamsJson: JSON.stringify({
                    title: '📱 اختر APK',
                    sections: [{
                        title: `نتائج البحث عن "${text}"`,
                        rows: buttons
                    }]
                })
            }]
        }, { quoted: m })
        
    } catch (err) {
        console.error("[MUSASHI][plugins_legacy/search/android1.js] exception", err?.stack || err);
        m.react('❌')
        return m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
