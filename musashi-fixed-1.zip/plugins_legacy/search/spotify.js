const { default: axios } = require("axios")

const pluginConfig = {
    name: "",
    alias: ['spotifysearch', 'spsearch'],
    category: 'search',
    description: "يبحث عن المقاطع في Spotify أو يجلب المقطع من رابطه.",
    usage: ".بحث_سبوتيفاي <اسم_مقطع أو رابط>",
    example: ".بحث_سبوتيفاي Neffex Grateful",
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m) {
    const query = m.text?.trim()

    if (!query) {
        return m.reply(
            `⚠️ *طريقة الاستخدام*\n\n` +
            `> \`${m.prefix}spotify <query>\`\n\n` +
            `> مثال:\n` +
            `> \`${m.prefix}spotify neffex grateful\``
        )
    }

    try {
        const res = await axios.get(`https://api.emiliabot.my.id/search/spotify?query=${encodeURIComponent(query)}`)
        const results = res.data
        if (!results.status) {
            return m.reply(`❌ *عذراً* ✦\n\n> غير موجود نتيجة لـ *${query}*~ 🥺`)
        }

        const tracks = results.result

        let txt = `🎵 *sᴘᴏᴛɪꜰʏ sᴇᴀʀᴄʜ*\n\n`
        txt += `> Query: *${query}*\n\n`

        tracks.forEach((t, i) => {
            txt += `*${i + 1}.* ${t.title}\n`
            txt += `   ├ 👤 ${t.artist}\n`
            txt += `   ├ 🔗 ${t.link}\n`
            txt += `   ├ 🖼️ ${t.popularity}\n\n`
        })

        txt += `> 💡 Download: \`${m.prefix}spdl <url / id>\` أو \`${m.prefix}spotplay ${query}\``

        return m.reply(txt.trim())
    } catch (err) {
        console.error("[MUSASHI][plugins_legacy/search/spotify.js] exception", err?.stack || err);
        return m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
