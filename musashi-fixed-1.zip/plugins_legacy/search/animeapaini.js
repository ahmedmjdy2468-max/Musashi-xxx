const axios = require('axios')
const config = require('../../config')
const { downloadContentFromMessage } = require('itsuki')
const FormData = require('form-data') 
const NEOXR_APIKEY = config.APIkey?.neoxr || 'Milik-Bot-Itsuki'

const pluginConfig = {
    name: 'animeapaini',
    alias: ['whatanime', 'animesearch', 'sauceanime', 'searchanime'],
    category: 'search',
    description: 'Identifikasi anime من صورة/screenshot',
    usage: '.animeapaini (ردّ على صورة)',
    example: '.animeapaini',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 15,
    energi: 1,
    isEnabled: true
}


async function uploadToTempfiles(buffer) {
    const form = new FormData()
    form.append('file', buffer, { filename: 'image.jpg', contentType: 'image/jpeg' })
    
    const response = await axios.post('https://tmpfiles.org/api/v1/upload', form, {
        headers: form.getHeaders(),
        timeout: 30000
    })
    
    if (response.data?.data?.url) {
        return response.data.data.url.replace('tmpfiles.org/', 'tmpfiles.org/dl/')
    }
    throw new Error('فشل الرفع')
}


async function handler(m, { sock }) {
    let imageBuffer = null
    let imageMsg = null
    
    if (m.isImage && m.message?.imageMessage) {
        imageMsg = m.message.imageMessage
    } else if (m.quoted?.isImage && m.quoted?.message?.imageMessage) {
        imageMsg = m.quoted.message.imageMessage
    } else if (m.quoted?.isImage) {
        try {
            imageBuffer = await m.quoted.download()
        } catch (e) {}
    }
    
    if (m.isVideo || m.quoted?.isVideo) {
        return m.reply(`❌ *لا ᴅɪᴅᴜᴋᴜɴɢ*\n\n> فقط صورة/screenshot الذي didukung\n> فيديو لا يمكن diproses\n\n\`ردّ على أو أرسل صورة مع caption ${m.prefix}animeapaini\``)
    }
    
    if (!imageMsg && !imageBuffer) {
        return m.reply(
            `🔍 *ᴀɴɪᴍᴇ ᴀᴘᴀ ɪɴɪ?*\n\n` +
            `> أرسل صورة مع caption:\n` +
            `> \`${m.prefix}animeapaini\`\n\n` +
            `> أو ردّ على صورة مع:\n` +
            `> \`${m.prefix}animeapaini\`\n\n` +
            `⚠️ *Catatan:* فيديو لا didukung, فقط صورة/screenshot`
        )
    }
    
    m.react('🔍')
    
    try {
        if (!imageBuffer && imageMsg) {
            const stream = await downloadContentFromMessage(imageMsg, 'image')
            let chunks = []
            for await (const chunk of stream) {
                chunks.push(chunk)
            }
            imageBuffer = Buffer.concat(chunks)
        }
        
        if (!imageBuffer || imageBuffer.length < 100) {
            m.react('❌')
            return m.reply(`❌ *عذراً* فشل mengambil صورة. أعد الإرسال~ 🥺`)
        }
        
        await m.reply(`🕕 *ᴍᴇɴᴄᴀʀɪ ᴀɴɪᴍᴇ...*\n\n> _Mengupload و menganalisis صورة..._`)
        
        const imageUrl = await uploadToTempfiles(imageBuffer)
        
        const res = await axios.get(`https://api.neoxr.eu/api/whatanime?url=${encodeURIComponent(imageUrl)}&apikey=${NEOXR_APIKEY}`, {
            timeout: 60000
        })
        
        if (!res.data?.status || !res.data?.data) {
            m.react('❌')
            return m.reply(`❌ *همم~* Anime غير موجود. حاول مع screenshot الذي أكثر jelas~ 🥺`)
        }
        
        const d = res.data.data
        
        const similarity = ((d.similarity || 0) * 100).toFixed(2)
        
        const formatTime = (seconds) => {
            if (!seconds) return '00:00'
            const mins = Math.floor(seconds / 60)
            const secs = Math.floor(seconds % 60)
            return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
        }
        
        const filename = d.filename || 'Unknown'
        const animeName = filename.replace(/\[.*?\]/g, '').replace(/\(.*?\)/g, '').replace(/\.mp4|\.mkv|\.avi/gi, '').trim() || 'Unknown Anime'
        
        const caption = `🔍 *ᴀɴɪᴍᴇ ᴀᴘᴀ ɪɴɪ?*\n\n` +
            `🎬 *Anime:* ${animeName}\n` +
            `📺 *Episode:* ${d.episode || 'Movie/OVA'}\n` +
            `🆔 *AniList ID:* ${d.anilist || '-'}\n\n` +
            `⏱️ *Timestamp:*\n` +
            `  ◦ From: \`${formatTime(d.from)}\`\n` +
            `  ◦ To: \`${formatTime(d.to)}\`\n\n` +
            `📊 *Similarity:* ${similarity}%\n\n` +
            `🔗 https://anilist.co/anime/${d.anilist || ''}`
        
        m.react('✅')
        
        if (d.image) {
            await sock.sendMessage(m.chat, {
                image: { url: d.image },
                caption
            }, { quoted: m })
        } else {
            await m.reply(caption)
        }
        
        if (d.video) {
            await sock.sendMessage(m.chat, {
                video: { url: d.video },
                caption: `🎬 *Preview Scene*\n\n> ${animeName}\n> Episode ${d.episode || 'Movie'} @ ${formatTime(d.at)}`,
            }, { quoted: m })
        }
        
    } catch (error) {
        console.error("[MUSASHI][plugins_legacy/search/animeapaini.js] exception", error?.stack || error);
        m.react('❌')
        m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
