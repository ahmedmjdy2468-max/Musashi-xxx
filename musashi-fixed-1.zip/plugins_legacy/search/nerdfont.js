const axios = require('axios')
const cheerio = require('cheerio');
const sharp = require('sharp');

async function nerdfonts() {
    try {
        const { data } = await axios.get('https://www.nerdfonts.com/font-downloads');
        const $ = cheerio.load(data);
        const result = [];
        
        $('div.item').each((_, rynn) => {
            const name = $(rynn).find('span.nerd-font-invisible-النص').text().trim();
            const textContent = $(rynn).find('div').first().text();
            const version = textContent.match(/Version:\s*([^\n\r]+)/)[1].trim() || null;
            const info = textContent.match(/Info:\s*([^\n\r]+)/)[1].trim() || null;
            const preview_image = 'https://www.nerdfonts.com' + $(rynn).find('a.font-preview').attr('style').match(/background-image\s*:\s*url\s*\(\s*['"]?([^'"]+)['"]?\s*\)/i)[1] || null;
            const preview_url = $(rynn).find('a.nf-oct-الرابط_external').attr('href') || null;
            const download_url = $(rynn).find('a.nf-fa-download').attr('href');
            
            if (name && download_url) {
                result.push({
                    name,
                    version,
                    info,
                    preview_image,
                    preview_url,
                    download_url
                });
            }
        });
        
        return result;
    } catch (error) {
        throw new Error(error.message);
    }
}


const pluginConfig = {
    name: 'dafont',
    alias: ['nerdfont', 'font'],
    category: 'search',
    description: 'Cari font di DaFont',
    usage: '.dafont <query>',
    example: '.dafont Coolvetica',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

function formatNumber(num) {
    const n = parseInt(num)
    if (isNaN(n)) return num
    if (n >= 1000000000) return (n / 1000000000).toFixed(1) + 'B'
    if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M'
    if (n >= 1000) return (n / 1000).toFixed(1) + 'K'
    return n.toString()
}

async function handler(m, { sock }) {
    const query = m.text?.trim()
    try {
        const res = await nerdfonts()
        const rows = res.map((f, i) => {
            return {
                header: `الخط ${f.name}`,
                title: f.info,
                description: `Version: ${f.version}`,
                id: `${m.prefix}nerdfont-ambil ${f.name}`
            }
        })
        await sock.sendMessage(m.chat, {
            text: 'Silahkan اختر font الذي يريد أنت download',
            footer: 'Click tombol في الأسفل هذا',
            interactiveButtons: [
                {
                    name: 'single_select',
                    buttonParamsJson: JSON.stringify({
                        title: `اختر الخط Disini`,
                        sections: [
                            {
                                title: 'أنا harap, font ini يمكن membantu أنت',
                                highlight_label: 'الخط الخيارات',
                                rows: rows
                            }
                        ]
                    })
                }
            ]
        }, { quoted: m })        
    } catch (err) {
        console.error("[MUSASHI][plugins_legacy/search/nerdfont.js] exception", err?.stack || err);
        return m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
