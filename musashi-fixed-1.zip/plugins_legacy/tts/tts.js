const gTTS = require('gtts')
const { spawn } = require('child_process')
const fs = require('fs')
const path = require('path')
const { f } = require('../../src/lib/undici')

const pluginConfig = {
    name: "",
    alias: ['say'],
    category: 'tts',
    description: 'Google Text To Speech',
    usage: '.tts <النص>',
    example: '.tts مرحباً كل',
    cooldown: 10,
    energi: 1,
    isEnabled: true
}

async function handler(m, { sock }) {
    const text = m.text?.trim()

    if (!text) {
        return m.reply(`🎤 *Google TTS*\n\nGunakan:\n${m.prefix}tts halo dunia`)
    }

    m.react('🎤')

async function textToSpeech2(text) {
    try {
        const res = await fetch(`https://api.nexray.web.id/ai/gemini-tts?text=${encodeURIComponent(text)}`)
        const json = await res.json()
        console.log('TTS JSON:', JSON.stringify(json))
        return json
    } catch (error) {
        console.log('TTS الخطأ:', error)
        return null
    }
}

    try {

        const t = await textToSpeech2(text)

// Cek dulu isi response-nya
console.log('TTS Response:', JSON.stringify(t))

if (!t || !t.result) {
    return m.reply(`❌ TTS فشل: API لا mengembalikan صوت.\nResponse: ${JSON.stringify(t)}`)
}

await sock.sendMessage(m.chat, {
    audio: { url: t.result },
    mimetype: 'audio/mpeg',
}, { quoted: m })
        m.react('✅')

    } catch (err) {
        console.error("[MUSASHI][plugins_legacy/tts/tts.js] exception", err?.stack || err);
        m.react('❌')
        m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}