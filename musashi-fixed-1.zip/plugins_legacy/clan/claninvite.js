const { getDatabase } = require('../../src/lib/database')

const pluginConfig = {
    name: 'claninvite',
    alias: ['inviteclan'],
    category: 'clan',
    description: 'يضيف العضو المحدد مباشرةً إلى عشيرتك، بالمنشن أو بالرد على رسالته.',
    usage: '.إضافة_عضو_للعشيرة @عضو',
    example: '.إضافة_عضو_للعشيرة @عضو',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 0,
    isEnabled: true
}

async function handler(m) {
    const db = getDatabase()
    const user = db.getUser(m.sender)

    if (!user?.clanId) return m.reply(`❌ ليس لديك عشيرة حالياً.`)
    if (!db.db.data.clans) db.db.data.clans = {}

    const clan = db.db.data.clans[user.clanId]
    if (!clan) return m.reply(`❌ تعذّر العثور على عشيرتك.`)

    const target = m.mentionedJid?.[0] || m.quoted?.sender
    if (!target) {
        return m.reply(
            `📨 *إضافة عضو إلى العشيرة*\n\n` +
            `حدّد العضو بالمنشن أو بالرد على رسالته.\n\n` +
            `مثال: *.إضافة_عضو_للعشيرة @عضو*`
        )
    }

    if (target === m.sender) return m.reply(`❌ لا يمكنك إضافة نفسك إلى عشيرتك.`)

    const targetUser = db.getUser(target)
    if (targetUser?.clanId) return m.reply(`❌ هذا العضو ينتمي بالفعل إلى عشيرة.`)
    if (clan.members.length >= 50) return m.reply(`❌ اكتمل الحد الأقصى لأعضاء العشيرة (50/50).`)

    clan.members.push(target)
    db.setUser(target, { clanId: user.clanId })
    db.save()

    const emblem = clan.emblem || '🏰'

    await m.reply(
        `${emblem} *أُضيف العضو إلى العشيرة*\n\n` +
        `انضم @${target.split('@')[0]} إلى *${clan.name}*.\n` +
        `الأعضاء: ${clan.members.length}/50`,
        { mentions: [m.sender, target] }
    )
}

module.exports = {
    config: pluginConfig,
    handler
}
