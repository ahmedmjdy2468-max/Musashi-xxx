const { getDatabase } = require('../../src/lib/database')

const pluginConfig = {
    name: 'clanleave',
    alias: ['leaveclan', 'guildleave'],
    category: 'clan',
    description: 'يخرجك من عشيرتك؛ على القائد نقل القيادة أولاً أو حل العشيرة إذا كان آخر أعضائها.',
    usage: '.مغادرة_العشيرة',
    example: '.مغادرة_العشيرة',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 0,
    isEnabled: true
}

async function handler(m) {
    const db = getDatabase()
    const user = db.getUser(m.sender)

    if (!user?.clanId) return m.reply('❌ لست عضواً في عشيرة حالياً.')
    if (!db.db.data.clans) db.db.data.clans = {}

    const clan = db.db.data.clans[user.clanId]
    if (!clan) {
        db.setUser(m.sender, { clanId: null })
        db.save()
        return m.reply('❌ لم تعد العشيرة موجودة؛ أُزيل ارتباطك بها من بياناتك.')
    }

    if (clan.leader === m.sender) {
        if (clan.members.length > 1) {
            return m.reply(
                `❌ أنت قائد العشيرة.\n\n` +
                `لا تتوفر ميزة نقل القيادة حالياً. أخرج بقية الأعضاء أولاً، ثم غادر العشيرة.`
            )
        }
        delete db.db.data.clans[user.clanId]
        db.setUser(m.sender, { clanId: null })
        db.save()

        const emblem = clan.emblem || '🏰'
        return m.reply(`${emblem} حُلّت عشيرة *${clan.name}*.`)
    }

    clan.members = clan.members.filter(jid => jid !== m.sender)
    db.setUser(m.sender, { clanId: null })
    db.save()

    await m.reply(`👋 غادرت عشيرة *${clan.name}*.`)
}

module.exports = {
    config: pluginConfig,
    handler
}
