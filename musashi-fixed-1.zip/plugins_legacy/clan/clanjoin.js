const { getDatabase } = require('../../src/lib/database')

const pluginConfig = {
    name: 'clanjoin',
    alias: ['joinclan', 'guildjoin'],
    category: 'clan',
    description: 'ينضم إلى عشيرة باستخدام معرّفها أو اسمها.',
    usage: '.انضمام_للعشيرة <المعرّف أو الاسم>',
    example: '.انضمام_للعشيرة clan_123456',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 0,
    isEnabled: true
}

const MAX_MEMBERS = 50

async function handler(m) {
    const db = getDatabase()
    const user = db.getUser(m.sender)
    const clanId = m.text?.trim()

    if (!clanId) {
        return m.reply(
            `🏰 *الانضمام إلى عشيرة*\n\n` +
            `أدخل معرّف العشيرة أو اسمها.\n\n` +
            `مثال: *.انضمام_للعشيرة clan_123456*\n` +
            `للعثور على عشيرة، استخدم *.ترتيب_العشائر*.`
        )
    }

    if (user.clanId) {
        return m.reply(`❌ أنت عضو في عشيرة بالفعل. غادرها أولاً باستخدام *.ترك_العشيرة*.`)
    }

    if (!db.db.data.clans) db.db.data.clans = {}

    const clan = db.db.data.clans[clanId]
        || Object.values(db.db.data.clans).find(c => c.name.toLowerCase() === clanId.toLowerCase())
        || Object.values(db.db.data.clans).find(c => c.id.toLowerCase() === clanId.toLowerCase())
    if (!clan) return m.reply(`❌ لم أعثر على عشيرة بهذا المعرّف أو الاسم.`)
    if (!clan.isOpen) return m.reply(`❌ باب الانضمام إلى *${clan.name}* مغلق.`)
    if (clan.members.length >= MAX_MEMBERS) return m.reply(`❌ اكتمل الحد الأقصى لأعضاء *${clan.name}* (${MAX_MEMBERS}/${MAX_MEMBERS}).`)

    clan.members.push(m.sender)
    db.setUser(m.sender, { clanId })
    db.save()

    const emblem = clan.emblem || '🏰'

    await m.reply(
        `${emblem} *أهلاً بك في العشيرة*\n\n` +
        `انضم @${m.sender.split('@')[0]} إلى *${clan.name}*.\n\n` +
        `القائد: @${clan.leader.split('@')[0]}\n` +
        `الأعضاء: ${clan.members.length}/${MAX_MEMBERS}\n\n` +
        `لعرض التفاصيل استخدم *.معلومات_العشيرة*.`,
        { mentions: [m.sender, clan.leader] }
    )
}

module.exports = {
    config: pluginConfig,
    handler
}
