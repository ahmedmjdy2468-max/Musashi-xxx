const { getDatabase } = require('../../src/lib/database')

const pluginConfig = {
    name: 'clanmembers',
    alias: ['clanmember', 'guildmembers'],
    category: 'clan',
    description: 'يعرض أعضاء عشيرتك ومستوى كل عضو ورصيده.',
    usage: '.أعضاء_العشيرة',
    example: '.أعضاء_العشيرة',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m) {
    const db = getDatabase()
    const user = db.getUser(m.sender)

    if (!user?.clanId) return m.reply('❌ لست عضواً في عشيرة حالياً.')
    if (!db.db.data.clans) db.db.data.clans = {}

    const clan = db.db.data.clans[user.clanId]
    if (!clan) return m.reply('❌ تعذّر العثور على بيانات العشيرة.')

    const emblem = clan.emblem || '🏰'
    const mentions = []

    const memberLines = clan.members.map((jid, i) => {
        const memberUser = db.getUser(jid)
        const isLeader = jid === clan.leader
        const level = memberUser?.rpg?.level || memberUser?.level || 1
        const koin = (memberUser?.koin || 0).toLocaleString('id-ID')
        mentions.push(jid)

        const role = isLeader ? '👑' : '•'
        return `${role} @${jid.split('@')[0]}  المستوى ${level} · الرصيد ${koin} روبية`
    })

    await m.reply(
        `${emblem} *${clan.name}* — الأعضاء\n\n` +
        memberLines.join('\n') +
        `\n\nعدد الأعضاء: ${clan.members.length}/50`,
        { mentions }
    )
}

module.exports = {
    config: pluginConfig,
    handler
}
