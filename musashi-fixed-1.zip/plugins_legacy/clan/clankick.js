const { getDatabase } = require('../../src/lib/database')

const pluginConfig = {
    name: 'clankick',
    alias: ['kickclan'],
    category: 'clan',
    description: 'يزيل العضو المحدد من عشيرتك بالمنشن أو بالرد على رسالته؛ للقائد فقط.',
    usage: '.طرد_من_العشيرة @عضو',
    example: '.طرد_من_العشيرة @عضو',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 0,
    isEnabled: true
}

async function handler(m) {
    const db = getDatabase()
    const user = db.getUser(m.sender)

    if (!user?.clanId) return m.reply(`❌ ليس لديك عشيرة حالياً.`)
    if (!db.db.data.clans) db.db.data.clans = {}

    const clan = db.db.data.clans[user.clanId]
    if (!clan) return m.reply(`❌ تعذّر العثور على عشيرتك.`)
    if (clan.leader !== m.sender) return m.reply(`❌ هذا الأمر متاح لقائد العشيرة فقط.`)

    const target = m.mentionedJid?.[0] || m.quoted?.sender
    if (!target) {
        return m.reply(
            `👢 *إزالة عضو من العشيرة*\n\n` +
            `حدّد العضو بالمنشن أو بالرد على رسالته.\n\n` +
            `مثال: *.طرد_من_العشيرة @عضو*`
        )
    }

    if (target === m.sender) return m.reply(`❌ *عذراً* لا يمكنك طرد نفسك~ 🥺`)
    if (!clan.members.includes(target)) return m.reply(`❌ هذا العضو ليس ضمن عشيرتك.`)

    clan.members = clan.members.filter(jid => jid !== target)
    db.setUser(target, { clanId: null })
    db.save()

    const emblem = clan.emblem || '🏰'

    await m.reply(
        `${emblem} *أُزيل العضو من العشيرة*\n\n` +
        `غادر @${target.split('@')[0]} عشيرة *${clan.name}*.\n` +
        `عدد الأعضاء: ${clan.members.length}/50`,
        { mentions: [target] }
    )
}

module.exports = {
    config: pluginConfig,
    handler
}
