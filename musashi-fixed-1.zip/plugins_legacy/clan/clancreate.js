const { getDatabase } = require('../../src/lib/database')

const pluginConfig = {
    name: 'clancreate',
    alias: ['createclan', 'guildcreate'],
    category: 'clan',
    description: 'ينشئ عشيرة جديدة مقابل الرصيد المطلوب ويعيّن منشئها قائداً.',
    usage: '.إنشاء_عشيرة <الاسم>',
    example: '.إنشاء_عشيرة MoonKnights',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 0,
    isEnabled: true
}

const CLAN_CREATE_COST = 50000
const MAX_CLAN_NAME = 20
const CLAN_EMBLEMS = ['🐉', '🦅', '🐺', '🦁', '🔥', '⚡', '🌙', '☀️', '💎', '🗡️']

function generateShortId(name, existingClans) {
    const clean = name.replace(/[^a-zA-Z]/g, '').toUpperCase()
    let id = clean.length >= 3 ? clean.slice(0, 3) : clean.padEnd(3, 'X')
    if (!existingClans[id]) return id
    id = clean.slice(0, 4) || id
    if (!existingClans[id]) return id
    for (let i = 1; i <= 99; i++) {
        const attempt = clean.slice(0, 3) + i
        if (!existingClans[attempt]) return attempt
    }
    return clean.slice(0, 2) + Math.random().toString(36).slice(2, 5).toUpperCase()
}

async function handler(m) {
    const db = getDatabase()
    const user = db.getUser(m.sender)
    const clanName = m.text?.trim()

    if (!clanName) {
        return m.reply(
            `⚔️ *إنشاء عشيرة*\n\n` +
            `اختر اسماً لعشيرتك واجمع الأعضاء.\n\n` +
            `التكلفة: *${CLAN_CREATE_COST.toLocaleString('id-ID')} روبية إندونيسية*\n` +
            `أقصى طول للاسم: *${MAX_CLAN_NAME} حرفاً*\n` +
            `يقبل الاسم أحرفاً لاتينية وأرقاماً ومسافات.\n\n` +
            `مثال: *.إنشاء_عشيرة MoonKnights*`
        )
    }

    if (clanName.length > MAX_CLAN_NAME) {
        return m.reply(`❌ يجب ألا يتجاوز اسم العشيرة ${MAX_CLAN_NAME} حرفاً.`)
    }

    if (!/^[a-zA-Z0-9\s]+$/.test(clanName)) {
        return m.reply(`❌ يجب أن يتكوّن اسم العشيرة من أحرف لاتينية أو أرقام أو مسافات فقط.`)
    }

    if (!db.db.data.clans) db.db.data.clans = {}

    if (user.clanId) {
        return m.reply(`❌ أنت عضو في عشيرة بالفعل. غادرها أولاً باستخدام *.ترك_العشيرة*.`)
    }

    const existingClan = Object.values(db.db.data.clans).find(c => c.name.toLowerCase() === clanName.toLowerCase())
    if (existingClan) {
        return m.reply(`❌ اسم العشيرة *${clanName}* مستخدم بالفعل.`)
    }

    if ((user.koin || 0) < CLAN_CREATE_COST) {
        return m.reply(
            `❌ العملات غير كافية\n\n` +
            `المطلوب: *${CLAN_CREATE_COST.toLocaleString('id-ID')} روبية إندونيسية*\n` +
            `رصيدك: *${(user.koin || 0).toLocaleString('id-ID')} روبية إندونيسية*`
        )
    }

    const emblem = CLAN_EMBLEMS[Math.floor(Math.random() * CLAN_EMBLEMS.length)]
    const clanId = generateShortId(clanName, db.db.data.clans)
    const clan = {
        id: clanId,
        name: clanName,
        emblem,
        leader: m.sender,
        members: [m.sender],
        exp: 0,
        level: 1,
        wins: 0,
        losses: 0,
        createdAt: new Date().toISOString(),
        description: 'لم يوجد الوصف',
        isOpen: true
    }

    db.db.data.clans[clanId] = clan
    db.updateKoin(m.sender, -CLAN_CREATE_COST)
    db.setUser(m.sender, { clanId })
    await db.save()

    await m.reply(
        `${emblem} *أُنشئت العشيرة*\n\n` +
        `*${clanName}*\n` +
        `القائد: @${m.sender.split('@')[0]}\n` +
        `الحالة: مفتوحة · الأعضاء 1/50\n\n` +
        `خُصم ${CLAN_CREATE_COST.toLocaleString('id-ID')} روبية إندونيسية.\n\n` +
        `لإضافة عضو استخدم *.إضافة_عضو_للعشيرة @عضو*.\n` +
        `معرّف العشيرة: *${clanId}*`,
        { mentions: [m.sender] }
    )
}

module.exports = {
    config: pluginConfig,
    handler
}
