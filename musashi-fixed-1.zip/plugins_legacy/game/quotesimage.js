const axios = require('axios')
const config = require('../../config')
const { f } = require('../../src/lib/undici')

const NEOXR_APIKEY = config.APIkey?.neoxr || 'Milik-Bot-Itsuki'

const pluginConfig = {
    name: 'quotesimage',
    alias: ['quoteimg', 'quotes-image', 'qimg'],
    category: 'random',
    description: 'Random quotes image',
    usage: '.quotesimage',
    example: '.quotesimage',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    m.react('🕕')
    
    try {
        const res = await f(`https://api.neoxr.eu/api/quotesimage?apikey=${NEOXR_APIKEY}`)
        
        if (!res.status || !res.data?.url) {
            m.react('❌')
            return m.reply(`❌ *عذراً* فشل mengambil quotes image~ 🥺`)
        }
        
        await sock.sendMedia(m.chat, res.data.url, null, m, {
            type: 'image'
        })
        
        m.react('✅')
        
    } catch (err) {
        console.error("[MUSASHI][plugins_legacy/game/quotesimage.js] exception", err?.stack || err);
        m.react('❌')
        return m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
