const config = require('../../config');
const { downloadMediaMessage } = require('itsuki');
const fs = require('fs');
const { default: axios } = require('axios');

const pluginConfig = {
    name: 'ppcouple',
    alias: ['cp'],
    category: 'random',
    description: 'Menjodohkan dua عضو المجموعة secara random',
    usage: '.ppcouple',
    isGroup: true,
    isBotAdmin: false,
    isAdmin: false,
    cooldown: 10,
    energi: 2,
    isEnabled: true
};

async function handler(m, { sock }) {
   try {
        const res = await axios.get(`https://api.deline.web.id/random/ppcouple`)
        const data = res.data.result
        const cowo = data.cowo
        const cewe = data.cewe
        await sock.sendMessage(m.chat, {
            albumMessage: [
                {
                    image: { url: cowo },
                },
                {
                    image: { url: cewe },
                }
            ]
        }, { quoted: m })
   } catch (error) {
        console.error("[MUSASHI][plugins_legacy/game/couple.js] exception", error?.stack || error);
    m.reply("حدث خطأ، حاول لاحقاً")
   }
}

module.exports = {
    config: pluginConfig,
    handler
};
