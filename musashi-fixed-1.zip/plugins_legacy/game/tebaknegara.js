const {
    getRandomItem, createSession, getSession, endSession,
    checkAnswerAdvanced, getHint, hasActiveSession, setSessionTimer,
    getRemainingTime, formatRemainingTime, isSurrender, isReplyToGame,
    GAME_REWARD,
    getRandomReward,
    getProgressiveHint
} = require('../../src/lib/gameData');
const { getDatabase } = require('../../src/lib/database');
const { addExpWithLevelCheck } = require('../../src/lib/levelHelper');
const {getGameContextInfo, getWinnerContextInfo, checkFastAnswer, getGameContextInfoV2 } = require('../../src/lib/contextHelper');

const pluginConfig = {
    name: 'tebaknegara',
    alias: ['tn', 'guesscountry'],
    category: 'game',
    description: 'Tebak negara dari fakta menarik',
    usage: '.tebaknegara',
    example: '.tebaknegara',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
};

async function handler(m, { sock }) {
    const chatId = m.chat;

    if (hasActiveSession(chatId)) {
        const session = getSession(chatId);
        if (session && session.gameType === 'tebaknegara') {
            const remaining = getRemainingTime(chatId);
            let text = `⚠️ *ᴍᴀsɪʜ ᴀᴅᴀ اللعبة*\n\n\`\`\`${session.question.soal}\`\`\`\n\n💡 Hint: *${getHint(session.question.jawaban, 2)}*\n⏱️ المتبقي: *${formatRemainingTime(remaining)}*\n\n_ردّ على رسالة سؤال لـ menjawab أو اكتب "استسلام"_`;
            await m.reply(text);
            return;
        }
    }

    const question = getRandomItem('tebaknegara.json');
    if (!question) {
        await m.reply('❌ *البيانات غير متاحة*\n\n> Ehh~ بيانات اللعبة غير متاحة بعد... أعد المحاولة لاحقاً 🥺');
        return;
    }

    let text = `🌍 *ᴛᴇʙᴀᴋ ɴᴇɢᴀʀᴀ*\n\n\`\`\`${question.soal}\`\`\`\n\n💡 Hint: *${getHint(question.jawaban, 2)}*\n⏱️ الوقت: *60 ثانية*\n🎁 الجائزة: *حد، عملات، خبرة (عشوائي)*\n\n_ردّ على رسالة هذا مع jawabanmu أو اكتب "استسلام"_`;

    const db = getDatabase();
    const contextVariant = db.setting('contextVariant') || 1;

    let sentMsg;
    if (contextVariant === 2) {
        sentMsg = await getGameContextInfoV2(sock, chatId, text, { quoted: m });
    } else {
        sentMsg = await sock.sendMessage(chatId, { text, contextInfo: getGameContextInfo('🌍 TEBAK NEGARA', 'Tebak negara dari fakta!') }, { quoted: m });
    }
    createSession(chatId, 'tebaknegara', question, sentMsg.key, 60000);

    setSessionTimer(chatId, async () => {
        await m.reply(`⏱️ *انتهى الوقت!*\n\nJawaban: *${question.jawaban}*\n\n_لا أحد أجاب_`);
    });
}

async function answerHandler(m, sock) {
    const chatId = m.chat;
    const session = getSession(chatId);
    if (!session || session.gameType !== 'tebaknegara') return false;

    const userAnswer = (m.body || '').trim();
    if (!userAnswer || userAnswer.startsWith('.')) return false;

    if (isSurrender(userAnswer)) {
        endSession(chatId);
        await m.reply(`🏳️ *ᴍᴇɴʏᴇʀᴀʜ!*\n\nJawaban: *${session.question.jawaban}*\n\n_@${m.sender.split('@')[0]} استسلم_`, { mentions: [m.sender] });
        return true;
    }

    if (!isReplyToGame(m, session)) return false;

    session.attempts++;

    const result = checkAnswerAdvanced(session.question.jawaban, userAnswer);

    if (result.status === 'correct') {
        endSession(chatId);
        const db = getDatabase();
        const user = db.getUser(m.sender);

        const reward = getRandomReward();
        let totalLimit = reward.limit;
        let totalBalance = reward.koin;
        let totalExp = reward.exp;
        let bonusText = '';

        const fastResult = checkFastAnswer(session);
        if (fastResult.isFast) {
            totalLimit += fastResult.bonus.limit;
            totalBalance += fastResult.bonus.koin;
            totalExp += fastResult.bonus.exp;
            bonusText = `\n\n${fastResult.praise}\n⚡ *مكافأة سريعة:* +${fastResult.bonus.limit} حد، +${fastResult.bonus.koin} عملة\n⏱️ الوقت: *${(fastResult.elapsed / 1000).toFixed(1)}s*`;
        }

        db.updateEnergi(m.sender, totalLimit);
        db.updateKoin(m.sender, totalBalance);
        if (!user.rpg) user.rpg = {};
        await addExpWithLevelCheck(sock, m, db, user, totalExp);
        db.save();

        let text = `🔥 *SABI COY! Jawabanmu tepat!*\n\nJawaban: *${session.question.jawaban}*\nPemenang: *@${m.sender.split('@')[0]}*\nPercobaan: *${session.attempts}x*\n\n`;
        text += `🎁 +${totalLimit} حد، +${totalBalance} عملة, +${totalExp} خبرة`;
        text += bonusText;

        await m.reply(text, { mentions: [m.sender] });
        return true;
    }

    if (result.status === 'close') {
        const remaining = getRemainingTime(chatId);
        await m.react('🔥');
        await m.reply(`🔥 *قريب!* إجابتك *${Math.round(result.similarity * 100)}%* متطابقة!\n_الوقت المتبقي: *${formatRemainingTime(remaining)}*_`);
        return false;
    }

    const remaining = getRemainingTime(chatId);
    if (remaining > 0 && session.attempts < 10) {
        await m.react('❌');
        const hint = getProgressiveHint(session.question.jawaban, session.attempts);
        await m.reply(`❌ *ليس صحيحاً بعد!* حاول مجدداً، هذا التلميح: *${hint}*\n_الوقت المتبقي: *${formatRemainingTime(remaining)}*_ 🌸`);
    }
    return false;
}

module.exports = { config: pluginConfig, handler, answerHandler };
