const { f } = require('../../src/lib/undici')

const pluginConfig = {
    name: 'tebakpikiran',
    alias: ['mindread', 'tebakin', 'tbpikiran'],
    category: 'game',
    description: 'البوت menebak apa الذي أنت pikirkan lewat السؤال AI',
    usage: '.tebakpikiran',
    example: '.tebakpikiran',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

if (!global.tebakPikiranSessions) global.tebakPikiranSessions = new Map()
const sessions = global.tebakPikiranSessions

const YES_ANSWERS = ['من فضلك', 'iya', 'yes', 'yep', 'y', 'betul', 'صحيح', 'benar', '✅', '👍']
const NO_ANSWERS = ['لا', 'لا', 'ngga', 'لا', 'ga', 'no', 'nope', 'n', 'bukan', '❌', '👎']
const SKIP_ANSWERS = [
    'skip', 'entah', '?', 'mungkin', 'ragu',
    'لا tau', 'لا أعرف',
    'gatau', 'ga tau', 'لا tau', 'لا tahu',
    'لست متأكداً', 'لست متأكداً',
    'لا tau', 'لا tahu',
    'ngga tau', 'ngga tahu'
]

function normalizeAnswer(text) {
    const t = text.trim().toLowerCase().replace(/\s+/g, ' ')
    if (YES_ANSWERS.includes(t)) return 'YA'
    if (NO_ANSWERS.includes(t)) return 'TIDAK'
    if (SKIP_ANSWERS.includes(t)) return 'لا أعرف'
    if (SKIP_ANSWERS.some(s => t.includes(s))) return 'لا أعرف'
    return null
}

function extractText(data) {
    if (!data) return null
    if (typeof data === 'string') return data.trim()
    if (typeof data === 'object') {
        if (data?.result?.text) return String(data.result.text).trim()
        if (data?.result) return String(data.result).trim()
        if (data?.response) return String(data.response).trim()
        if (data?.text) return String(data.text).trim()
        if (data?.data) return String(data.data).trim()
    }
    return null
}

async function callAI(prompt) {
    try {
        const data = await f(`https://api.zenzxz.my.id/ai/copilot?message=${encodeURIComponent(prompt)}&model=gpt-5`)
        console.log('[TebakPikiran] API1 raw:', JSON.stringify(data)?.slice(0, 200))
        const text = extractText(data)
        if (text) return text
    } catch (e) {
        console.log('[TebakPikiran] API 1 الخطأ:', e.message)
    }
    try {
        const data = await f(`https://api-faa.my.id/faa/claude-ai?text=${encodeURIComponent(prompt)}`)
        console.log('[TebakPikiran] API2 raw:', JSON.stringify(data)?.slice(0, 200))
        const text = extractText(data)
        if (text) return text
    } catch (e) {
        console.log('[TebakPikiran] API 2 الخطأ:', e.message)
    }
    return null
}

async function generateNextQuestion(answers) {
    const isFirst = answers.length === 0
    const summary = answers.length > 0
        ? answers.map((a, i) => `${i + 1}. ${a.q} → ${a.a}`).join('\n')
        : ''

    const prompt = isFirst
        ? `أنت جارٍ memainkan game خمّن pikiran dalam bahasa Indonesia.
مهمة: tulis SATU السؤال نعم/لا لـ memulai menebak sesuatu الذي dipikirkan user.
PENTING: tulis pertanyaannya SAJA. Dilarang keras menulis penjelasan, rekap, الرقم, أو kalimat lain apapun.
Output الذي صحيح contohnya: Apakah ذلك makhluk hidup?`
        : `أنت جارٍ memainkan game خمّن pikiran dalam bahasa Indonesia.
الإجابة user sejauh هذا:
${summary}

مهمة: tulis SATU السؤال نعم/لا جديد الذي membantu mempersempit tebakan.
PENTING: tulis pertanyaannya SAJA. Dilarang keras menulis penjelasan, rekap, الرقم, أو kalimat lain apapun.
Jangan أعد المحاولة السؤال الذي تم ditanya.
Output الذي صحيح contohnya: Apakah ذلك berwarna merah?`

    const result = await callAI(prompt)
    console.log('[TebakPikiran] generateNextQuestion result:', result)
    if (!result) return null

    const firstLine = result
        .split('\n')
        .map(l => l.trim())
        .find(l => l.endsWith('?') && l.length > 5)

    if (firstLine) return firstLine.replace(/^["'\d\.\-\s]+/, '').replace(/["']$/, '').trim()

    const fallbackLine = result.split('\n').map(l => l.trim()).find(l => l.length > 5)
    return fallbackLine ? fallbackLine.replace(/^["'\d\.\-\s]+/, '').replace(/["']$/, '').trim() : null
}

async function tryGuess(answers) {
    const summary = answers.map((a, i) => `${i + 1}. ${a.q} → ${a.a}`).join('\n')
    const prompt = `أنت جارٍ memainkan game خمّن pikiran dalam bahasa Indonesia.
الإجابة user sejauh هذا:
${summary}

مهمة: evaluasi seberapa yakin أنت يمكن menebak, lalu berikan الإجابة.
PENTING: ردّ على فقط مع JSON في الأسفل هذا, tanpa نص lain, tanpa markdown, tanpa backtick:
{"confidence": 7, "guess": ""}

Aturan:
- confidence: angka 1-10
- إذا confidence >= 8: isi guess مع الاسم tebakan singkat
- إذا confidence < 8: biarkan guess تبقى string kosong ""`

    const result = await callAI(prompt)
    console.log('[TebakPikiran] tryGuess raw:', result)
    if (!result) return { confidence: 0, guess: '' }

    try {
        const clean = result.replace(/```json|```/gi, '').trim()
        const match = clean.match(/\{[\s\S]*?"confidence"[\s\S]*?"guess"[\s\S]*?\}/)
        if (match) {
            const parsed = JSON.parse(match[0])
            return {
                confidence: parseInt(parsed.confidence) || 0,
                guess: (parsed.guess || '').trim()
            }
        }
    } catch (e) {
        console.log('[TebakPikiran] JSON parse error:', e.message)
    }

    return { confidence: 0, guess: '' }
}

async function handler(m, { sock }) {
    const sender = m.sender

    if (sessions.has(sender)) {
        return m.reply(
            `🧠 *ᴛᴇʙᴀᴋ ᴘɪᴋɪʀᴀɴ*\n\n` +
            `╭┈┈⬡「 ⚠️ *اللعبة ᴀᴋᴛɪꜰ* 」\n` +
            `┃ أنت ما زال لديه game الذي قيد التنفيذ!\n` +
            `┃ Jawab pertanyaannya أولاً نعم.\n` +
            `┃\n` +
            `┃ اكتب *إلغاء* لـ mengakhiri game.\n` +
            `╰┈┈┈┈┈┈┈┈⬡`
        )
    }

    await m.reply(
        `🧠 *ᴛᴇʙᴀᴋ ᴘɪᴋɪʀᴀɴ*\n\n` +
        `╭┈┈⬡「 🎮 *ᴍᴜʟᴀɪ اللعبة* 」\n` +
        `┃ Pikirkan sesuatu أولاً نعم.\n` +
        `┃ يمكن حرفاً, benda, hewan, أعضاء...\n` +
        `┃ Apapun boleh! Tapi jangan kasih tahu أنا 🙈\n` +
        `┃\n` +
        `┃ أنا سوف tanya terus حتى يمكن خمّن!\n` +
        `┃ Jawab مع: *نعم / لا / لا أعرف*\n` +
        `┃\n` +
        `┃ اكتب *إلغاء* لـ mengakhiri game.\n` +
        `╰┈┈┈┈┈┈┈┈⬡\n\n` +
        `_لحظة, أنا siapkan pertanyaan أولاً~_ 🤔`
    )

    const firstQ = await generateNextQuestion([])
    if (!firstQ) {
        return m.reply(`❌ فشل memulai game, API لا merespons. حاول مرة أخرى نعم~ *.tebakpikiran*`)
    }

    sessions.set(sender, {
        answers: [],
        currentQuestion: firstQ,
        waitingForAI: false
    })

    await m.reply(`❓ *السؤال 1:*\n${firstQ}`)
}

async function answerHandler(m, sock) {
    const sender = m.sender
    if (!sessions.has(sender)) return false

    const session = sessions.get(sender)
    const text = m.body?.trim()?.toLowerCase()?.replace(/\s+/g, ' ')
    if (!text) return false

    if (['batal', 'stop', 'cancel'].includes(text)) {
        sessions.delete(sender)
        await m.reply(
            `🧠 *ᴛᴇʙᴀᴋ ᴘɪᴋɪʀᴀɴ*\n\n` +
            `> Game dibatalkan. Sampai jumpa مجدداً نعم. 🌸`
        )
        return true
    }

    if (session.waitingForAI) {
        await m.reply(`⏳ Sabar نعم. أنا مجدداً berpikir keras هنا~ 🧠`)
        return true
    }

    const answer = normalizeAnswer(text)
    if (!answer) {
        await m.reply(
            `❓ Jawab مع:\n` +
            `• *نعم* — إذا صحيح\n` +
            `• *لا* — إذا خطأ\n` +
            `• *لا أعرف* — إذا ragu\n\n` +
            `أو اكتب *إلغاء* لـ keluar.`
        )
        return true
    }

    session.answers.push({ q: session.currentQuestion, a: answer })
    session.waitingForAI = true
    sessions.set(sender, session)

    const stepNum = session.answers.length

    if (stepNum >= 3 && stepNum % 3 === 0) {
        await m.reply(`🤔 _Hmm, أنا mulai لديه gambaran... قليلاً نعم._ 💭`)

        const { confidence, guess } = await tryGuess(session.answers)
        console.log('[TebakPikiran] confidence:', confidence, '| guess:', guess)

        if (confidence >= 8 && guess) {
            sessions.delete(sender)
            return await m.reply(
                `🧠 *ᴛᴇʙᴀᴋ ᴘɪᴋɪʀᴀɴ*\n\n` +
                `╭┈┈⬡「 🎯 *ᴛᴇʙᴀᴋᴀɴᴋᴜ* 」\n` +
                `┃ Setelah ${stepNum} pertanyaan...\n` +
                `┃\n` +
                `┃ 🌟 أنا menebak أنت memikirkan:\n` +
                `┃\n` +
                `┃ ✨ *${guess}* ✨\n` +
                `┃\n` +
                `┃ Betul لا? Hehehe~ 😏\n` +
                `╰┈┈┈┈┈┈┈┈⬡\n\n` +
                `> Mau main مجدداً? اكتب *.tebakpikiran* 🌸`
            )
        }
    }

    const nextQ = await generateNextQuestion(session.answers)

    if (!nextQ) {
        await m.reply(`🧠 _API مجدداً lemot, أنا حاول tebak أولاً من فضلك..._ 💭`)
        const { guess } = await tryGuess(session.answers)
        sessions.delete(sender)

        return await m.reply(
            guess
                ? `🧠 *ᴛᴇʙᴀᴋ ᴘɪᴋɪʀᴀɴ*\n\n` +
                  `╭┈┈⬡「 🎯 *ᴛᴇʙᴀᴋᴀɴᴋᴜ* 」\n` +
                  `┃ Setelah ${stepNum} pertanyaan...\n` +
                  `┃\n` +
                  `┃ ✨ *${guess}* ✨\n` +
                  `┃\n` +
                  `┃ Betul لا? 😏\n` +
                  `╰┈┈┈┈┈┈┈┈⬡\n\n` +
                  `> Mau main مجدداً? اكتب *.tebakpikiran* 🌸`
                : `🧠 *ᴛᴇʙᴀᴋ ᴘɪᴋɪʀᴀɴ*\n\n` +
                  `╭┈┈⬡「 😵 *ᴍᴇɴʏᴇʀᴀʜ* 」\n` +
                  `┃ عذراً~ API مجدداً gangguan 😢\n` +
                  `┃ حاول العب مرة أخرى لاحقاً نعم~\n` +
                  `╰┈┈┈┈┈┈┈┈⬡\n\n` +
                  `> اكتب *.tebakpikiran* 🌸`
        )
    }

    session.currentQuestion = nextQ
    session.waitingForAI = false
    sessions.set(sender, session)

    await m.reply(
        `✅ _Oke, أنا catat نعم._\n\n` +
        `❓ *السؤال ${stepNum + 1}:*\n${nextQ}`
    )

    return true
}

module.exports = {
    config: pluginConfig,
    handler,
    answerHandler
}