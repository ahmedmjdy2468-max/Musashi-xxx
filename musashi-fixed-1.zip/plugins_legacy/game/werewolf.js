/**
 * 🐺 WEREWOLF GAME
 * Social deduction game for WhatsApp
 * 
 * Based on reference: RTXZY-MD-pro/lib/werewolf.js
 * Enhanced for MUSASHI
 */

const { getDatabase } = require('../../src/lib/database')
const config = require('../../config')
const fs = require('fs')
const path = require('path')

const pluginConfig = {
    name: 'werewolf',
    alias: ['ww', 'wwgc'],
    category: 'game',
    description: 'Main Werewolf Game bersama player lain',
    usage: '.ww <create|join|start|vote|player|exit|delete>',
    example: '.ww create',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

if (!global.werewolfGames) global.werewolfGames = {}

let thumbWW = null
let thumbNight = null
let thumbDay = null
let thumbWin = null

;(async () => {
    try {
        const { getAssetBuffer } = require('../../src/lib/assetManager')
        thumbWW = await getAssetBuffer('images.itsukiGames')
        const base = await getAssetBuffer('images.itsuki')
        thumbNight = base
        thumbDay = base
        thumbWin = await getAssetBuffer('images.itsukiWinner')
    } catch (e) {
        console.log('[WW] فشل to load thumbnails:', e.message)
    }
})()

const ROLES = {
    werewolf: { emoji: '🐺', name: 'Werewolf', team: 'wolf', desc: 'Bunuh warga tiap malam' },
    seer: { emoji: '🔮', name: 'Seer', team: 'village', desc: 'Lihat role player tiap malam' },
    guardian: { emoji: '🛡️', name: 'Guardian', team: 'village', desc: 'Lindungi player tiap malam' },
    sorcerer: { emoji: '🧙', name: 'Sorcerer', team: 'wolf', desc: 'Cari tahu siapa Seer' },
    villager: { emoji: '👨‍🌾', name: 'Villager', team: 'village', desc: 'Diskusi و vote werewolf' }
}

const WIN_REWARD = { koin: 5000, exp: 1000 }
const MIN_PLAYERS = 4
const MAX_PLAYERS = 15
const PHASE_DURATION = {
    night: 60000,   // 60 seconds
    day: 90000      // 90 seconds
}


function getWWContextInfo(title = '🐺 WEREWOLF', body = 'Social deduction game!', thumbBuffer = thumbWW, mentions) {
    const saluranId = config.saluran?.id || '120363432546133683@newsletter'
    const saluranName = config.saluran?.name || config.bot?.name || 'MUSASHI'
    
    const contextInfo = {
        forwardingScore: 9999,
        isForwarded: true,
        mentionedJid: mentions,
        forwardedNewsletterMessageInfo: {
            newsletterJid: saluranId,
            newsletterName: saluranName,
            serverMessageId: 127
        }
    }
    
    return contextInfo
}

// Generate roles based on player count
function generateRoles(playerCount) {
    const roles = []
    
    // Role distribution based on player count (from reference)
    if (playerCount === 4) {
        roles.push('werewolf', 'seer', 'guardian', 'villager')
    } else if (playerCount === 5) {
        roles.push('werewolf', 'seer', 'guardian', 'villager', 'villager')
    } else if (playerCount === 6) {
        roles.push('werewolf', 'werewolf', 'seer', 'guardian', 'villager', 'villager')
    } else if (playerCount === 7) {
        roles.push('werewolf', 'werewolf', 'seer', 'guardian', 'villager', 'villager', 'villager')
    } else if (playerCount === 8) {
        roles.push('werewolf', 'werewolf', 'seer', 'guardian', 'villager', 'villager', 'villager', 'villager')
    } else if (playerCount === 9) {
        roles.push('werewolf', 'werewolf', 'seer', 'guardian', 'sorcerer', 'villager', 'villager', 'villager', 'villager')
    } else if (playerCount === 10) {
        roles.push('werewolf', 'werewolf', 'seer', 'guardian', 'sorcerer', 'villager', 'villager', 'villager', 'villager', 'villager')
    } else if (playerCount === 11) {
        roles.push('werewolf', 'werewolf', 'seer', 'guardian', 'guardian', 'sorcerer', 'villager', 'villager', 'villager', 'villager', 'villager')
    } else if (playerCount >= 12) {
        roles.push('werewolf', 'werewolf', 'seer', 'guardian', 'guardian', 'sorcerer')
        while (roles.length < playerCount) roles.push('villager')
    }
    
    // Shuffle roles
    for (let i = roles.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [roles[i], roles[j]] = [roles[j], roles[i]]
    }
    
    return roles
}

// Get role description for PM
function getRoleDescription(role, prefix = '.') {
    const descriptions = {
        werewolf: `🐺 *WEREWOLF*\n\n` +
            `أنت adalah predator malam!\n\n` +
            `╭┈┈⬡「 📋 *INFO* 」\n` +
            `┃ 🎯 الهدف: Bunuh جميع Villager\n` +
            `┃ ⚔️ Skill: Bunuh 1 player tiap malam\n` +
            `┃ 🕐 الفعل: الليل\n` +
            `╰┈┈┈┈┈┈┈┈⬡\n\n` +
            `> في الليل اكتب:\n` +
            `> \`${prefix}wwkill <nomor>\` di PM bot`,
        seer: `🔮 *SEER*\n\n` +
            `أنت يمكن melihat identitas player!\n\n` +
            `╭┈┈⬡「 📋 *INFO* 」\n` +
            `┃ 🎯 الهدف: Bantu Villager\n` +
            `┃ 🔮 Skill: Lihat role 1 player\n` +
            `┃ 🕐 الفعل: الليل\n` +
            `╰┈┈┈┈┈┈┈┈⬡\n\n` +
            `> في الليل اكتب:\n` +
            `> \`${prefix}wwsee <nomor>\` di PM bot`,
        guardian: `🛡️ *GUARDIAN*\n\n` +
            `أنت يمكن melindungi player!\n\n` +
            `╭┈┈⬡「 📋 *INFO* 」\n` +
            `┃ 🎯 الهدف: Lindungi Villager\n` +
            `┃ 🛡️ Skill: Lindungi 1 player\n` +
            `┃ 🕐 الفعل: الليل\n` +
            `╰┈┈┈┈┈┈┈┈⬡\n\n` +
            `> في الليل اكتب:\n` +
            `> \`${prefix}wwprotect <nomor>\` di PM bot`,
        sorcerer: `🧙 *SORCERER*\n\n` +
            `أنت sekutu Werewolf!\n\n` +
            `╭┈┈⬡「 📋 *INFO* 」\n` +
            `┃ 🎯 الهدف: Bantu Werewolf menang\n` +
            `┃ 🔍 Skill: Cek apakah target adalah Seer\n` +
            `┃ 🕐 الفعل: الليل\n` +
            `╰┈┈┈┈┈┈┈┈⬡\n\n` +
            `> في الليل اكتب:\n` +
            `> \`${prefix}wwsorcerer <nomor>\` di PM bot`,
        villager: `👨‍🌾 *VILLAGER*\n\n` +
            `أنت warga biasa!\n\n` +
            `╭┈┈⬡「 📋 *INFO* 」\n` +
            `┃ 🎯 الهدف: Temukan Werewolf\n` +
            `┃ 🗳️ Skill: Vote di siang hari\n` +
            `┃ 🕐 Aksi: Siang hari\n` +
            `╰┈┈┈┈┈┈┈┈⬡\n\n` +
            `> Diskusi dan vote werewolf!\n` +
            `> \`${prefix}ww vote <nomor>\` في المجموعة`
    }
    return descriptions[role] || 'Unknown Role'
}

async function handler(m, { sock }) {
    const db = getDatabase()
    const args = m.args || []
    const action = args[0]?.toLowerCase()
    const target = args[1]
    const ww = global.werewolfGames
    const prefix = m.prefix || config.command?.prefix || '.'
    
    const commands = {
        create: async () => {
            if (ww[m.chat]) {
                const game = ww[m.chat]
                if (game.status === 'waiting') {
                    return m.reply(`❌ *ROOM تم ADA*\n\n` +
                        `Room ما زال menunggu player\n` +
                        `اكتب \`${prefix}ww join\` لـ gabung\n` +
                        `Host: @${game.owner.split('@')[0]}`,
                        { mentions: [game.owner] })
                }
                return m.reply(`❌ *همم~* Game جارٍ berlangsung! انتظر حتى انتهى~ 🥺`)
            }
            
            // Check if player already in another room
            const existingRoom = Object.entries(ww).find(
                ([chatId, room]) => room.players.some(p => p.id === m.sender)
            )
            if (existingRoom) {
                return m.reply(`❌ *همم~* أنت ما زال dalam game في المجموعة lain~ 🥺`)
            }
            
            // Create new game room
            ww[m.chat] = {
                room: m.chat,
                owner: m.sender,
                status: 'waiting',
                day: 0,
                phase: 'lobby',
                players: [{
                    id: m.sender,
                    number: 1,
                    role: null,
                    alive: true,
                    voted: false,
                    skillUsed: false
                }],
                dead: [],
                votes: {},
                nightActions: {
                    kill: null,
                    protect: null,
                    see: null,
                    sorcerer: null
                },
                createdAt: Date.now(),
                timeout: null
            }
            
            await m.react('🐺')
            await m.reply(`🐺 *WEREWOLF GAME*\n\n` +
                `Room تم الإنشاء بنجاح!\n\n` +
                `╭┈┈⬡「 📋 *INFO ROOM* 」\n` +
                `┃ 👑 Host: @${m.sender.split('@')[0]}\n` +
                `┃ 👥 Player: 1/${MAX_PLAYERS}\n` +
                `┃ ⏱️ Min: ${MIN_PLAYERS} player\n` +
                `╰┈┈┈┈┈┈┈┈⬡\n\n` +
                `╭┈┈⬡「 🎮 *CARA MAIN* 」\n` +
                `┃ ➕ \`${prefix}ww join\` - Gabung\n` +
                `┃ ▶️ \`${prefix}ww start\` - Mulai (host)\n` +
                `┃ 👥 \`${prefix}ww player\` - List player\n` +
                `┃ 🚪 \`${prefix}ww exit\` - Keluar\n` +
                `╰┈┈┈┈┈┈┈┈⬡`,
                { mentions: [m.sender] })
        },
        
        join: async () => {
            if (!ww[m.chat]) {
                return m.reply(`❌ لم يوجد room!\n> اكتب \`${prefix}ww create\` لـ buat room`)
            }
            
            if (ww[m.chat].status !== 'waiting') {
                return m.reply(`❌ *همم~* Game تم dimulai! انتظر ronde berikutnya~ 🥺`)
            }
            
            if (ww[m.chat].players.length >= MAX_PLAYERS) {
                return m.reply(`❌ *همم~* Room penuh! (Max ${MAX_PLAYERS} player)~ 🥺`)
            }
            
            if (ww[m.chat].players.some(p => p.id === m.sender)) {
                return m.reply(`❌ *همم~* أنت تم bergabung~ 🥺`)
            }
            
            const existingRoom = Object.entries(ww).find(
                ([chatId, room]) => chatId !== m.chat && room.players.some(p => p.id === m.sender)
            )
            if (existingRoom) {
                return m.reply(`❌ *همم~* أنت ما زال dalam game في المجموعة lain~ 🥺`)
            }
            
            ww[m.chat].players.push({
                id: m.sender,
                number: ww[m.chat].players.length + 1,
                role: null,
                alive: true,
                voted: false,
                skillUsed: false
            })
            
            const playerList = ww[m.chat].players.map((p, i) => 
                `${i + 1}. @${p.id.split('@')[0]}`
            ).join('\n')
            
            const canStart = ww[m.chat].players.length >= MIN_PLAYERS
            
            await m.react('✅')
            await m.reply(`✅ *PLAYER BERGABUNG*\n\n` +
                `@${m.sender.split('@')[0]} masuk!\n\n` +
                `╭┈┈⬡「 👥 *PLAYER LIST* 」\n` +
                `${playerList.split('\n').map(l => `┃ ${l}`).join('\n')}\n` +
                `╰┈┈┈┈┈┈┈┈⬡\n\n` +
                `الإجمالي: ${ww[m.chat].players.length}/${MIN_PLAYERS} (min)\n` +
                (canStart ? `✅ يمكن ابدأ! \`${prefix}ww start\`` : `🕕 Butuh ${MIN_PLAYERS - ww[m.chat].players.length} player مجدداً`),
                { mentions: ww[m.chat].players.map(p => p.id) })
        },
        
        start: async () => {
            if (!ww[m.chat]) {
                return m.reply(`❌ *همم~* لم يوجد room~ 🥺`)
            }
            
            if (ww[m.chat].status !== 'waiting') {
                return m.reply(`❌ *همم~* Game تم berjalan~ 🥺`)
            }
            
            if (ww[m.chat].owner !== m.sender && !config.isOwner?.(m.sender)) {
                return m.reply(`❌ *لا، * فقط host الذي يمكن memulai game~ 🥺`)
            }
            
            if (ww[m.chat].players.length < MIN_PLAYERS) {
                return m.reply(`❌ الحد الأدنى ${MIN_PLAYERS} player!\n> Saat هذا: ${ww[m.chat].players.length} player`)
            }
            
            // Generate and assign roles
            const roles = generateRoles(ww[m.chat].players.length)
            ww[m.chat].players.forEach((p, i) => {
                p.role = roles[i]
            })
            
            ww[m.chat].status = 'playing'
            ww[m.chat].day = 1
            ww[m.chat].phase = 'night'
            
            // Send role to each player via PM
            for (const player of ww[m.chat].players) {
                try {
                    await sock.sendMessage(player.id, {
                        text: getRoleDescription(player.role, prefix),
                        contextInfo: getWWContextInfo(
                            `${ROLES[player.role].emoji} ${ROLES[player.role].name}`, 
                            'Role أنت!'
                        )
                    })
                } catch (e) {
                    console.log(`[WW] فشل to send role to ${player.id}:`, e.message)
                }
            }
            
            // Build player list
            const playerList = ww[m.chat].players.map((p, i) => 
                `${i + 1}. @${p.id.split('@')[0]}`
            ).join('\n')
            
            // Count roles
            const roleCount = {}
            ww[m.chat].players.forEach(p => {
                roleCount[p.role] = (roleCount[p.role] || 0) + 1
            })
            const roleInfo = Object.entries(roleCount).map(([role, count]) => 
                `${ROLES[role].emoji} ${ROLES[role].name}: ${count}`
            ).join('\n')
            
            await m.react('🌙')
            await m.reply(`🐺 *GAME DIMULAI!*\n\n` +
                `🌙 *ليل يوم إلى-1*\n\n` +
                `╭┈┈⬡「 👥 *PLAYERS* 」\n` +
                `${playerList.split('\n').map(l => `┃ ${l}`).join('\n')}\n` +
                `╰┈┈┈┈┈┈┈┈⬡\n\n` +
                `╭┈┈⬡「 🎭 *ROLES* 」\n` +
                `${roleInfo.split('\n').map(l => `┃ ${l}`).join('\n')}\n` +
                `╰┈┈┈┈┈┈┈┈⬡\n\n` +
                `📩 Cek PM لـ role kalian!\n` +
                `🌙 Werewolf berburu...\n` +
                `⏱️ الوقت ليل: ${PHASE_DURATION.night / 1000} ثانية`,
                { mentions: ww[m.chat].players.map(p => p.id) })
            
            // Send night skill prompts to special roles
            await sendNightPrompts(m.chat, sock, prefix)
            
            // Set timeout for night phase
            ww[m.chat].timeout = setTimeout(() => {
                processNightActions(m.chat, sock, db, prefix)
            }, PHASE_DURATION.night)
        },
        
        vote: async () => {
            if (!ww[m.chat] || ww[m.chat].status !== 'playing') {
                return m.reply(`❌ *همم~* غير موجود game aktif~ 🥺`)
            }
            
            if (ww[m.chat].phase !== 'day') {
                return m.reply(`❌ الآن ليس الوقت voting!\n> Phase: ${ww[m.chat].phase === 'night' ? '🌙 Malam' : ww[m.chat].phase}`)
            }
            
            const player = ww[m.chat].players.find(p => p.id === m.sender)
            if (!player) {
                return m.reply(`❌ *همم~* أنت ليس player dalam game هذا~ 🥺`)
            }
            
            if (!player.alive) {
                return m.reply(`❌ *عذراً* أنت تم mati! لا يمكن vote~ 🥺`)
            }
            
            if (player.voted) {
                return m.reply(`❌ *همم~* أنت تم vote! انتظر نتيجة voting~ 🥺`)
            }
            
            if (!target) {
                const alivePlayers = ww[m.chat].players.filter(p => p.alive)
                const list = alivePlayers.map(p => 
                    `${p.number}. @${p.id.split('@')[0]}`
                ).join('\n')
                return m.reply(`🗳️ *VOTING*\n\n` +
                    `اختر siapa الذي يريد dieliminasi:\n\n` +
                    `${list}\n\n` +
                    `اكتب: \`${prefix}ww vote <nomor>\``,
                    { mentions: alivePlayers.map(p => p.id) })
            }
            
            const targetNum = parseInt(target)
            if (isNaN(targetNum)) {
                return m.reply(`❌ *همم~* Masukkan nomor player! مثال: \`${prefix}ww vote 2\``)
            }
            
            const targetPlayer = ww[m.chat].players.find(p => p.number === targetNum)
            if (!targetPlayer) {
                return m.reply(`❌ *همم~* Player nomor ${targetNum} غير موجود~ 🥺`)
            }
            
            if (!targetPlayer.alive) {
                return m.reply(`❌ *همم~* Player tersebut تم mati~ 🥺`)
            }
            
            player.voted = true
            ww[m.chat].votes[targetPlayer.id] = (ww[m.chat].votes[targetPlayer.id] || 0) + 1
            
            const alivePlayers = ww[m.chat].players.filter(p => p.alive)
            const votedCount = alivePlayers.filter(p => p.voted).length
            
            await m.react('🗳️')
            await m.reply(`🗳️ *VOTE TERCATAT*\n\n` +
                `@${m.sender.split('@')[0]} ➜ @${targetPlayer.id.split('@')[0]}\n\n` +
                `Progress: ${votedCount}/${alivePlayers.length}`,
                { mentions: [m.sender, targetPlayer.id] })
            
            // Check if all votes are in
            if (votedCount >= alivePlayers.length) {
                if (ww[m.chat].timeout) clearTimeout(ww[m.chat].timeout)
                await executeVote(m.chat, sock, db, prefix)
            }
        },
        
        player: async () => {
            if (!ww[m.chat]) {
                return m.reply(`❌ *همم~* لا توجد لعبة في هذه الغرفة 🥺`)
            }
            
            const playerList = ww[m.chat].players.map((p, i) => {
                const status = p.alive ? '✅' : `☠️ (${ROLES[p.role]?.name || 'Unknown'})`
                return `${p.number}. @${p.id.split('@')[0]} ${status}`
            }).join('\n')
            
            const phaseEmoji = ww[m.chat].phase === 'night' ? '🌙' : ww[m.chat].phase === 'day' ? '☀️' : '🕕'
            
            await m.reply(`🐺 *WEREWOLF - STATUS*\n\n` +
                `╭┈┈⬡「 📊 *GAME INFO* 」\n` +
                `┃ 📅 Day: ${ww[m.chat].day}\n` +
                `┃ ${phaseEmoji} Phase: ${ww[m.chat].phase}\n` +
                `┃ 👤 Alive: ${ww[m.chat].players.filter(p => p.alive).length}\n` +
                `┃ ☠️ Dead: ${ww[m.chat].dead.length}\n` +
                `╰┈┈┈┈┈┈┈┈⬡\n\n` +
                `╭┈┈⬡「 👥 *PLAYERS* 」\n` +
                `${playerList.split('\n').map(l => `┃ ${l}`).join('\n')}\n` +
                `╰┈┈┈┈┈┈┈┈⬡`,
                { mentions: ww[m.chat].players.map(p => p.id) })
        },
        
        exit: async () => {
            if (!ww[m.chat]) {
                return m.reply(`❌ *همم~* لا توجد لعبة في هذه الغرفة 🥺`)
            }
            
            const playerIdx = ww[m.chat].players.findIndex(p => p.id === m.sender)
            if (playerIdx === -1) {
                return m.reply(`❌ *همم~* أنت لا يوجد في game هذا~ 🥺`)
            }
            
            if (ww[m.chat].status === 'playing') {
                return m.reply(`❌ *عذراً* لا يمكن keluar saat game berjalan~ 🥺`)
            }
            
            ww[m.chat].players.splice(playerIdx, 1)
            ww[m.chat].players.forEach((p, i) => p.number = i + 1)
            
            if (ww[m.chat].players.length === 0) {
                if (ww[m.chat].timeout) clearTimeout(ww[m.chat].timeout)
                delete ww[m.chat]
                return m.reply(`🗑️ Room حُذفت karena kosong.`)
            }
            
            // Transfer host if owner left
            if (ww[m.chat].owner === m.sender && ww[m.chat].players.length > 0) {
                ww[m.chat].owner = ww[m.chat].players[0].id
                await m.reply(`👋 @${m.sender.split('@')[0]} keluar.\n` +
                    `👑 Host جديد: @${ww[m.chat].owner.split('@')[0]}`,
                    { mentions: [m.sender, ww[m.chat].owner] })
            } else {
                await m.reply(`👋 @${m.sender.split('@')[0]} keluar dari game.`,
                    { mentions: [m.sender] })
            }
        },
        
        delete: async () => {
            if (!ww[m.chat]) {
                return m.reply(`❌ *همم~* لا توجد لعبة في هذه الغرفة 🥺`)
            }
            
            const isOwner = ww[m.chat].owner === m.sender
            const isBotOwner = config.isOwner?.(m.sender)
            
            if (!isOwner && !isBotOwner) {
                return m.reply(`❌ *لا، * فقط host أو مالك البوت الذي يمكن menghapus~ 🥺`)
            }
            
            if (ww[m.chat].timeout) clearTimeout(ww[m.chat].timeout)
            delete ww[m.chat]
            
            await m.react('🗑️')
            await m.reply(`🗑️ Game حُذفت!`)
        }
    }
    
    // Show help if no action
    if (!action || !commands[action]) {
        return m.reply(`🐺 *WEREWOLF GAME*\n\n` +
            `Permainan sosial mencari Werewolf!\n\n` +
            `╭┈┈⬡「 🎮 *COMMANDS* 」\n` +
            `┃ 🆕 \`${prefix}ww create\` - Buat room\n` +
            `┃ ➕ \`${prefix}ww join\` - Gabung\n` +
            `┃ ▶️ \`${prefix}ww start\` - Mulai (host)\n` +
            `┃ 🗳️ \`${prefix}ww vote <no>\` - Vote\n` +
            `┃ 👥 \`${prefix}ww player\` - List player\n` +
            `┃ 🚪 \`${prefix}ww exit\` - Keluar\n` +
            `┃ 🗑️ \`${prefix}ww delete\` - Hapus room\n` +
            `╰┈┈┈┈┈┈┈┈⬡\n\n` +
            `╭┈┈⬡「 🎭 *ROLES* 」\n` +
            `┃ 🐺 Werewolf - Bunuh warga\n` +
            `┃ 🧙 Sorcerer - Cari Seer\n` +
            `┃ 🔮 Seer - Lihat role\n` +
            `┃ 🛡️ Guardian - Lindungi\n` +
            `┃ 👨‍🌾 Villager - Vote werewolf\n` +
            `╰┈┈┈┈┈┈┈┈⬡\n\n` +
            `Min: ${MIN_PLAYERS} players | Max: ${MAX_PLAYERS} players`)
    }
    
    try {
        await commands[action]()
    } catch (error) {
        console.error('[WEREWOLF ERROR]', error)
        await m.reply("حدث خطأ، حاول لاحقاً")
    }
}

// Send night skill prompts to players
async function sendNightPrompts(chatId, sock, prefix) {
    const ww = global.werewolfGames
    if (!ww[chatId]) return
    
    const game = ww[chatId]
    const alivePlayers = game.players.filter(p => p.alive)
    
    // Build player list for prompts
    let playerListNormal = ''
    let playerListWolf = ''
    
    alivePlayers.forEach(p => {
        playerListNormal += `(${p.number}) @${p.id.split('@')[0]}\n`
        const roleTag = (p.role === 'werewolf' || p.role === 'sorcerer') ? ` [${ROLES[p.role].name}]` : ''
        playerListWolf += `(${p.number}) @${p.id.split('@')[0]}${roleTag}\n`
    })
    
    const mentions = alivePlayers.map(p => p.id)
    
    // Send prompts based on role
    for (const player of alivePlayers) {
        try {
            let text = ''
            
            switch (player.role) {
                case 'werewolf':
                    text = `🐺 *ليل يوم*\n\n` +
                        `Saatnya berburu! اختر target:\n\n` +
                        `${playerListWolf}\n` +
                        `> اكتب \`${prefix}wwkill <الرقم>\` لـ membunuh`
                    break
                case 'seer':
                    text = `🔮 *ليل يوم*\n\n` +
                        `Siapa الذي يريد أنت lihat rolenya?\n\n` +
                        `${playerListNormal}\n` +
                        `> اكتب \`${prefix}wwsee <الرقم>\` لـ melihat role`
                    break
                case 'guardian':
                    text = `🛡️ *ليل يوم*\n\n` +
                        `Siapa الذي يريد أنت lindungi?\n\n` +
                        `${playerListNormal}\n` +
                        `> اكتب \`${prefix}wwprotect <الرقم>\` لـ melindungi`
                    break
                case 'sorcerer':
                    text = `🧙 *ليل يوم*\n\n` +
                        `Cari tahu siapa Seer!\n\n` +
                        `${playerListWolf}\n` +
                        `> اكتب \`${prefix}wwsorcerer <الرقم>\` لـ mengecek`
                    break
                case 'villager':
                    text = `👨‍🌾 *ليل يوم*\n\n` +
                        `Sebagai warga, berhati-hatilah.\n` +
                        `ربما أنت هو target selanjutnya.\n\n` +
                        `${playerListNormal}`
                    break
            }
            
            if (text) {
                await sock.sendMessage(player.id, {
                    text,
                    mentions,
                    contextInfo: getWWContextInfo('🌙 NIGHT', 'استخدم skillmu!', thumbNight, mentions)
                })
            }
        } catch (e) {
            console.log(`[WW] فشل to send وصف to ${player.id}:`, e.message)
        }
    }
}

// Process night actions
async function processNightActions(chatId, sock, db, prefix) {
    const ww = global.werewolfGames
    if (!ww[chatId] || ww[chatId].phase !== 'night') return
    
    let killTarget = ww[chatId].nightActions.kill
    const protectTarget = ww[chatId].nightActions.protect
    
    let nightReport = `☀️ *PAGI HARI KE-${ww[chatId].day}*\n\n`
    
    // Process kill if not protected
    if (killTarget && killTarget !== protectTarget) {
        const victim = ww[chatId].players.find(p => p.id === killTarget)
        if (victim && victim.alive) {
            victim.alive = false
            ww[chatId].dead.push(victim)
            nightReport += `☠️ @${victim.id.split('@')[0]} ditemukan tewas!\n`
            nightReport += `> Role: ${ROLES[victim.role].emoji} ${ROLES[victim.role].name}\n\n`
        }
    } else if (killTarget && killTarget === protectTarget) {
        nightReport += `🛡️ Guardian بنجاح melindungi target!\n`
        nightReport += `> غير موجود korban ليل هذا.\n\n`
    } else {
        nightReport += `🌅 ليل الذي tenang...\n`
        nightReport += `> غير موجود korban.\n\n`
    }
    
    // Check win condition
    const winner = checkWinner(chatId)
    if (winner) {
        await sock.sendMessage(chatId, {
            text: nightReport,
            mentions: ww[chatId].players.map(p => p.id),
            contextInfo: getWWContextInfo('☀️ DAY', 'Pagi telah tiba...', thumbDay, ww[chatId].players.map(p => p.id))
        })
        await endGame(chatId, sock, db, winner)
        return
    }
    
    // Change phase to day
    ww[chatId].phase = 'day'
    ww[chatId].votes = {}
    ww[chatId].nightActions = { kill: null, protect: null, see: null, sorcerer: null }
    ww[chatId].players.forEach(p => {
        p.voted = false
        p.skillUsed = false
    })
    
    const alivePlayers = ww[chatId].players.filter(p => p.alive)
    const playerList = alivePlayers.map(p => 
        `${p.number}. @${p.id.split('@')[0]}`
    ).join('\n')
    
    nightReport += `╭┈┈⬡「 👥 *PLAYER HIDUP* 」\n`
    nightReport += `${playerList.split('\n').map(l => `┃ ${l}`).join('\n')}\n`
    nightReport += `╰┈┈┈┈┈┈┈┈⬡\n\n`
    nightReport += `> 🗳️ Waktunya voting!\n`
    nightReport += `> اكتب \`${prefix}ww vote <nomor>\`\n`
    nightReport += `> ⏱️ الوقت: ${PHASE_DURATION.day / 1000} ثانية`
    
    await sock.sendMessage(chatId, {
        text: nightReport,
        mentions: ww[chatId].players.map(p => p.id),
        contextInfo: getWWContextInfo('☀️ DAY', 'Voting time!', thumbDay, ww[chatId].players.map(p => p.id))
    })
    
    ww[chatId].timeout = setTimeout(() => {
        executeVote(chatId, sock, db, prefix)
    }, PHASE_DURATION.day)
}

// Execute vote results
async function executeVote(chatId, sock, db, prefix) {
    const ww = global.werewolfGames
    if (!ww[chatId] || ww[chatId].phase !== 'day') return
    
    let maxVotes = 0
    let eliminated = null
    let isTie = false
    
    for (const [playerId, votes] of Object.entries(ww[chatId].votes)) {
        if (votes > maxVotes) {
            maxVotes = votes
            eliminated = playerId
            isTie = false
        } else if (votes === maxVotes && maxVotes > 0) {
            isTie = true
        }
    }
    
    let resultText = `⚖️ *HASIL VOTING*\n\n`
    
    if (isTie || maxVotes === 0) {
        resultText += `🤷 غير موجود الذي tereliminasi!\n`
        resultText += `> ${isTie ? 'Vote seri!' : 'Tidak ada yang vote.'}\n\n`
    } else if (eliminated) {
        const player = ww[chatId].players.find(p => p.id === eliminated)
        if (player) {
            player.alive = false
            ww[chatId].dead.push(player)
            
            resultText += `⚰️ @${eliminated.split('@')[0]} dieliminasi!\n`
            resultText += `> Role: ${ROLES[player.role].emoji} ${ROLES[player.role].name}\n`
            resultText += `> Votes: ${maxVotes}\n\n`
        }
    }
    
    // Check win condition
    const winner = checkWinner(chatId)
    if (winner) {
        await sock.sendMessage(chatId, {
            text: resultText,
            mentions: eliminated ? [eliminated] : [],
            contextInfo: getWWContextInfo('⚖️ VOTING', 'النتيجة voting', thumbDay)
        })
        await endGame(chatId, sock, db, winner)
        return
    }
    
    // Change to night phase
    ww[chatId].phase = 'night'
    ww[chatId].day++
    ww[chatId].nightActions = { kill: null, protect: null, see: null, sorcerer: null }
    ww[chatId].players.forEach(p => {
        p.voted = false
        p.skillUsed = false
    })
    
    resultText += `🌙 *ليل يوم إلى-${ww[chatId].day}*\n\n`
    resultText += `> Werewolf berburu...\n`
    resultText += `> Special roles, استخدم skill أنتم في PM!\n`
    resultText += `> ⏱️ الوقت: ${PHASE_DURATION.night / 1000} ثانية`
    
    await sock.sendMessage(chatId, {
        text: resultText,
        mentions: eliminated ? [eliminated] : [],
        contextInfo: getWWContextInfo('🌙 NIGHT', 'Werewolf berburu...', thumbNight)
    })
    
    // Send night prompts
    await sendNightPrompts(chatId, sock, prefix)
    
    ww[chatId].timeout = setTimeout(() => {
        processNightActions(chatId, sock, db, prefix)
    }, PHASE_DURATION.night)
}

// Check win condition
function checkWinner(chatId) {
    const ww = global.werewolfGames
    if (!ww[chatId]) return null
    
    const alivePlayers = ww[chatId].players.filter(p => p.alive)
    const wolves = alivePlayers.filter(p => ROLES[p.role]?.team === 'wolf')
    const villagers = alivePlayers.filter(p => ROLES[p.role]?.team === 'village')
    
    if (wolves.length === 0) return 'village'
    if (wolves.length >= villagers.length) return 'wolf'
    
    return null
}

// End game and give rewards
async function endGame(chatId, sock, db, winner) {
    const ww = global.werewolfGames
    if (!ww[chatId]) return
    
    if (ww[chatId].timeout) clearTimeout(ww[chatId].timeout)
    
    const winningTeam = winner === 'wolf' ? 'wolf' : 'village'
    const winningPlayers = ww[chatId].players.filter(p => 
        ROLES[p.role]?.team === winningTeam
    )
    
    // Give rewards to winners
    for (const player of winningPlayers) {
        try {
            db.updateKoin(player.id, WIN_REWARD.koin)
            const user = db.getUser(player.id)
            if (user) {
                user.exp = (user.exp || 0) + WIN_REWARD.exp
                db.setUser(player.id, user)
            }
        } catch (e) {
            console.log(`[WW] فشل to give reward to ${player.id}:`, e.message)
        }
    }
    
    const allPlayers = ww[chatId].players.map(p => {
        const status = p.alive ? '✅' : '☠️'
        const isWinner = winningPlayers.some(w => w.id === p.id) ? '🏆' : ''
        return `${status} @${p.id.split('@')[0]} - ${ROLES[p.role].emoji} ${ROLES[p.role].name} ${isWinner}`
    }).join('\n')
    
    await sock.sendMessage(chatId, {
        text: `🎉 *GAME OVER!*\n\n` +
            `${winner === 'wolf' ? '🐺 *WEREWOLF MENANG!*' : '👨‍🌾 *VILLAGER MENANG!*'}\n\n` +
            `╭┈┈⬡「 👥 *كل PLAYER* 」\n` +
            `${allPlayers.split('\n').map(l => `┃ ${l}`).join('\n')}\n` +
            `╰┈┈┈┈┈┈┈┈⬡\n\n` +
            `╭┈┈⬡「 🎁 *HADIAH* 」\n` +
            `┃ 💰 +${WIN_REWARD.koin.toLocaleString()} عملة\n` +
            `┃ ⭐ +${WIN_REWARD.exp.toLocaleString()} خبرة\n` +
            `╰┈┈┈┈┈┈┈┈⬡\n\n` +
            `> GG WP! العب مجدداً? \`${config.command?.prefix || '.'}ww create\``,
        mentions: ww[chatId].players.map(p => p.id),
        contextInfo: getWWContextInfo(
            '🏆 GAME OVER', 
            `${winner === 'wolf' ? 'Werewolf' : 'Villager'} wins!`,
            thumbWin
        )
    })
    
    delete ww[chatId]
}

// Night action handler for PM commands
async function nightActionHandler(m, { sock }) {
    const db = getDatabase()
    const ww = global.werewolfGames
    const prefix = m.prefix || config.command?.prefix || '.'
    
    // Find the game this player is in
    const chatId = Object.keys(ww).find(id => 
        ww[id].players.some(p => p.id === m.sender && p.alive) &&
        ww[id].phase === 'night'
    )
    
    if (!chatId) {
        return m.reply(`❌ *همم~* أنت لا جارٍ dalam game werewolf أو ليس fase ليل~ 🥺`)
    }
    
    const game = ww[chatId]
    const player = game.players.find(p => p.id === m.sender)
    if (!player || !player.alive) {
        return m.reply(`❌ *همم~* أنت تم mati أو ليس player~ 🥺`)
    }
    
    // Check if skill already used
    if (player.skillUsed) {
        return m.reply(`❌ *همم~* أنت تم menggunakan skill ليل هذا~ 🥺`)
    }
    
    const cmd = m.command?.toLowerCase()
    const targetNum = parseInt(m.args?.[0])
    
    if (isNaN(targetNum)) {
        return m.reply(`❌ *همم~* Masukkan nomor target! مثال: \`${prefix}${cmd} 2\``)
    }
    
    const targetPlayer = game.players.find(p => p.number === targetNum && p.alive)
    if (!targetPlayer) {
        return m.reply(`❌ *همم~* Target غير صالح أو تم mati~ 🥺`)
    }
    
    // Process based on command and role
    if (cmd === 'wwkill' && player.role === 'werewolf') {
        if (targetPlayer.role === 'werewolf' || targetPlayer.role === 'sorcerer') {
            return m.reply(`❌ *عذراً* لا يمكن membunuh sesama team~ 🥺`)
        }
        game.nightActions.kill = targetPlayer.id
        player.skillUsed = true
        await m.reply(
            `🐺 *TARGET TERPILIH*\n\n` +
            `Target: @${targetPlayer.id.split('@')[0]}\n` +
            `> Menunggu malam berakhir...`,
            { mentions: [targetPlayer.id] }
        )
        return true
    }
    
    if (cmd === 'wwprotect' && player.role === 'guardian') {
        game.nightActions.protect = targetPlayer.id
        player.skillUsed = true
        await m.reply(
            `🛡️ *TARGET DILINDUNGI*\n\n` +
            `Melindungi: @${targetPlayer.id.split('@')[0]}\n` +
            `> Menunggu malam berakhir...`,
            { mentions: [targetPlayer.id] }
        )
        return true
    }
    
    if (cmd === 'wwsee' && player.role === 'seer') {
        const roleInfo = ROLES[targetPlayer.role]
        player.skillUsed = true
        await m.reply(
            `🔮 *HASIL PENGLIHATAN*\n\n` +
            `@${targetPlayer.id.split('@')[0]} adalah:\n` +
            `${roleInfo.emoji} *${roleInfo.name}*\n\n` +
            `> Team: ${roleInfo.team === 'wolf' ? '🐺 Wolf' : '👨‍🌾 Village'}`,
            { mentions: [targetPlayer.id] }
        )
        return true
    }
    
    if (cmd === 'wwsorcerer' && player.role === 'sorcerer') {
        const isSeer = targetPlayer.role === 'seer'
        player.skillUsed = true
        await m.reply(
            `🧙 *HASIL INVESTIGASI*\n\n` +
            `@${targetPlayer.id.split('@')[0]}\n` +
            `${isSeer ? '✅ *adalah SEER!*' : '❌ *bukan Seer*'}\n\n` +
            `> Lanjutkan membantu Werewolf!`,
            { mentions: [targetPlayer.id] }
        )
        return true
    }
    
    // Wrong role for command
    return m.reply(`❌ أنت لا memiliki kemampuan هذا!\n> صلاحيتك: ${ROLES[player.role]?.name || 'Unknown'}`)
}

module.exports = {
    config: pluginConfig,
    handler,
    nightActionHandler,
    ROLES,   // Export for other plugins
    getWWContextInfo  // Export for other plugins
}
