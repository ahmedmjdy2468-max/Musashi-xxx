const axios = require('axios')
const config = require('../../config')
const { f } = require('../../src/lib/undici')

const NEOXR_APIKEY = config.APIkey?.neoxr || 'Milik-Bot-Itsuki'

const pluginConfig = {
    name: 'meme',
    alias: ['memeindonesia'],
    category: 'random',
    description: 'Random meme Indonesia',
    usage: '.meme',
    example: '.meme',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    m.react('🕕') 
    try {
        const { data } = await f(`https://api.neoxr.eu/api/meme?apikey=${NEOXR_APIKEY}`)
        await sock.sendMedia(m.chat, data.url, data.title, m, {
            type: 'image'
        })
        m.react('✅')
    } catch (err) {
        console.error("[MUSASHI][plugins_legacy/game/meme.js] exception", err?.stack || err);
        m.react('❌')
        return m.reply("حدث خطأ، حاول لاحقاً")
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
