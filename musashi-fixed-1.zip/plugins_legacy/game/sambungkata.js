/**
 * ⭐ sambungkata.js — Game Kata Bersambung ⭐
 * ~ MUSASHI Special Edition ~
 *
 * Dipersembahkan oleh MUSASHI dengan penuh cinta! 💕
 * Karena kebohongan terbesar MUSASHI adalah... cintanya yang tulus! ❤️
 *
 * Alur~:
 *   .sambungkata       → buat room / join room
 *   .sambungkata start → mulai game (host only)
 *   .sambungkata stop  → hentikan game (host/owner)
 *   jawaban teks       → diproses di aiJawabHati (wajib reply pesan giliran)
 *   "nyerah"           → gugur, bebas tanpa reply
 */

const fs   = require('fs');
const path = require('path');
const { getDatabase }          = require('../../src/lib/database');
const { addExpWithLevelCheck } = require('../../src/lib/levelHelper');
const { getRandomReward, isSurrender } = require('../../src/lib/gameData');
const {
    getGameContextInfo,
    getGameContextInfoV2,
    getWinnerContextInfo,
    checkFastAnswer
} = require('../../src/lib/contextHelper');

// ────────────────────────────────────────────────
// ⭐ Load Kamus MUSASHI (KBBI) ⭐
// ────────────────────────────────────────────────
const aiJalurKamus = path.join(__dirname, '../../src/data/kbbi.json');
let aiIsiKamus = [];
try {
    aiIsiKamus = JSON.parse(fs.readFileSync(aiJalurKamus, 'utf-8'));
} catch (aiGagalMuatKamus) {
    console.error('[AiSambungKata] Huwaa~! فشل load kamus MUSASHI, maaf من فضلك...:', aiGagalMuatKamus.message);
}

// ────────────────────────────────────────────────
// ⭐ Konfigurasi Plugin MUSASHI ⭐
// ────────────────────────────────────────────────
const aiKonfigPlugin = {
    name: 'sambungkata',
    alias: ['skata', 'sambungkat', 'wordchain'],
    category: 'game',
    description: 'Game sambung kata dari huruf akhir kata sebelumnya (KBBI) — special from MUSASHI~! ⭐',
    usage: '.sambungkata | .sambungkata start | .sambungkata stop',
    example: '.sambungkata',
    isOwner: false,
    isPremium: false,
    isGroup: true,
    isPrivate: false,
    cooldown: 3,
    energi: 0,
    isEnabled: true
};

// ────────────────────────────────────────────────
// ⭐ Panggung MUSASHI — Global Room State ⭐
// ────────────────────────────────────────────────
if (!global.aiPanggung) global.aiPanggung = new Map();

// ────────────────────────────────────────────────
// ⭐ Banner MUSASHI ⭐
// ────────────────────────────────────────────────
const AI_BANNER_GAME = `╔══「 ⭐ *KATA BERSAMBUNG* ⭐ 」
╟ Haii~ الجميع! هذا MUSASHI lho! 💕
║ Yuk نحن العب معاً~!
║ Sambungkan kata من huruf
║ terakhir kata sebelumnya نعم~!
║ MUSASHI بالتأكيد support أنتم كل!
╚══ *MUSASHI love you~!* ❤️✨`;

const AI_BANNER_RULES = `╔══「 💫 *PERATURAN من MUSASHI~!* 💫 」
╟ الإجابة يجب kata dasar نعم~
║ jangan يوجد spasi أو imbuhan 🌸
╟ يجب يوجد في kamus KBBI lho!
╟ الوقت tiap giliran: *30 ثانية* ⏳
╟ 3x خطأ أو انتهى الوقت = gugur 😢
╟ Wajib *ردّ على* رسالة giliran MUSASHI نعم~!
╟ اكتب *استسلام* إذا يريد keluar 🏳️
╚══ *Ganbatte ne~!* ⭐❤️`;

// ────────────────────────────────────────────────
// ⭐ Koleksi Huruf ⭐
// ────────────────────────────────────────────────
const aiKoleksiHuruf = ['a','b','c','d','e','g','h','i','j','k','l','m','n','p','r','s','t','u','w'];

const aiPilihAcak = (aiKoleksi) => aiKoleksi[Math.floor(Math.random() * aiKoleksi.length)];

// ────────────────────────────────────────────────
// ⭐ Cari Awalan Kata ⭐
// Cari awalan terpanjang (1-4 huruf dari belakang) yang masih ada katanya
// di KBBI dan belum terpakai. Return null = mode bebas.
// ────────────────────────────────────────────────
function aiCariAwalanKata(aiKataInput, aiKataBekasPakai = new Set()) {
    if (aiKataInput.length < 3) return aiKataInput;
    let aiAwalan = null;
    for (let i = 1; i <= Math.min(4, aiKataInput.length - 1); i++) {
        const kandidat = aiKataInput.slice(-i);
        const ada = aiIsiKamus.some(k => k.startsWith(kandidat) && !aiKataBekasPakai.has(k));
        if (ada) aiAwalan = kandidat;
    }
    return aiAwalan; // null = mode bebas
}

// ────────────────────────────────────────────────
// ⭐ Cari Kata Awal ⭐
// Pastikan kata yang dipilih punya awalan valid di KBBI
// ────────────────────────────────────────────────
function aiCariKataAwal() {
    let aiKataLahir = null;
    let aiCobaLagi  = 0;

    while (aiCobaLagi < 500) {
        const aiHurufTerpilih = aiPilihAcak(aiKoleksiHuruf);
        const aiKamusFiltered = aiIsiKamus.filter(k => k.startsWith(aiHurufTerpilih));
        const aiKataCoba      = aiPilihAcak(aiKamusFiltered);
        aiCobaLagi++;

        if (!aiKataCoba || aiKataCoba.length < 3 || aiKataCoba.length > 7
            || aiKataCoba.includes('-') || aiKataCoba.includes(' ')) continue;

        if (aiCariAwalanKata(aiKataCoba, new Set())) {
            aiKataLahir = aiKataCoba;
            break;
        }
    }

    return (aiKataLahir || 'makan').toLowerCase();
}

function aiSusunDaftarPemain(aiSesi, aiAwalan, aiNamaCommand) {
    return (
        `╔═〘 ⭐ Daftar اللاعب 〙\n` +
        aiSesi.aiBarisanPemain.map((aiId, aiNomor) => `╟ ${aiNomor + 1}. @${aiId.split('@')[0]} 💕`).join('\n') +
        `\n╚════\n\n` +
        `اكتب~:\n` +
        `*${aiAwalan}${aiNamaCommand}* → join معاً MUSASHI! 🌟\n` +
        `*${aiAwalan}${aiNamaCommand} start* → mulai _(khusus host نعم.)_ ⭐`
    );
}

// ────────────────────────────────────────────────
// ⭐ MUSASHI Coret Pemain (Gugur) ⭐
// ────────────────────────────────────────────────
async function aiCoretPemain(aiPesan, aiSock, aiRuangan, aiSesi, aiAlasanGugur) {
    clearTimeout(aiSesi.aiHitungMundur);
    aiSesi.aiBarisanPemain = aiSesi.aiBarisanPemain.filter(aiId => aiId !== aiPesan.sender);

    await aiPesan.reply(
        `😢 Aduuh~ @${aiPesan.sender.split('@')[0]} *kehabisan فرصة* و gugur!\n` +
        `_(${aiAlasanGugur})_\n\n` +
        `_Jangan sedih نعم~ next time بالتأكيد يمكن! 💕_\n` +
        `_Sisa pemain: ${aiSesi.aiBarisanPemain.length} أعضاء~ ⭐_`,
        { mentions: [aiPesan.sender] }
    );

    if (aiSesi.aiBarisanPemain.length <= 1) {
        await aiTutupPanggung(aiPesan, aiSock, aiRuangan, aiSesi);
        return true;
    }

    aiSesi.aiPemainGiliran = aiSesi.aiBarisanPemain[0];
    aiSesi.aiKataPanggung  = aiCariKataAwal();
    aiSesi.aiNyawa         = 3;
    await aiLemparGiliran(aiPesan, aiSock, aiRuangan, aiSesi);
    return true;
}

// ────────────────────────────────────────────────
// ⭐ MUSASHI Lempar Giliran ⭐
// ────────────────────────────────────────────────
async function aiLemparGiliran(aiPesan, aiSock, aiRuangan, aiSesi) {
    const aiAwalanKini = aiCariAwalanKata(aiSesi.aiKataPanggung, aiSesi.aiKataBekasPakai);

    const aiTeksGiliran =
        `⭐ *SAMBUNG KATA — by MUSASHI~!* ⭐\n\n` +
        `الدور: @${aiSesi.aiPemainGiliran.split('@')[0]} 💫\n\n` +
        `Kata الآن~:\n` +
        `*${aiSesi.aiKataPanggung.toUpperCase()}* ✨\n\n` +
        (aiAwalanKini
            ? `Sambung من~:\n\`\`\`${aiAwalanKini.toUpperCase()}...\`\`\`\n\n_اكتب kata الذي dimulai مع *${aiAwalanKini.toUpperCase()}* نعم~! 🌸_\n`
            : `_Wah كل awalan تم terpakai~! Bebas kata apa saja asal يوجد في KBBI نعم~! 🌸_\n`
        ) +
        `_Kalau استسلم ketik *استسلام* 🏳️_\n\n` +
        `*Ganbatte~! MUSASHI percaya أنت يمكن! 💕*`;

    const aiPesanGiliranTerkirim = await aiPesan.reply(aiTeksGiliran, { mentions: [aiSesi.aiPemainGiliran] });
    aiSesi.aiKunciPesanGiliran = aiPesanGiliranTerkirim?.key || null;

    if (aiSesi.aiHitungMundur) clearTimeout(aiSesi.aiHitungMundur);
    aiSesi.aiHitungMundur = setTimeout(async () => {
        const aiSesiAktif = global.aiPanggung.get(aiRuangan);
        if (!aiSesiAktif || aiSesiAktif.aiStatusPanggung !== 'aiTampil') return;
        if (aiSesiAktif.aiPemainGiliran !== aiSesi.aiPemainGiliran || aiSesiAktif.aiKataPanggung !== aiSesi.aiKataPanggung) return;

        const aiPemainHabisWaktu = aiSesiAktif.aiPemainGiliran;
        aiSesiAktif.aiBarisanPemain = aiSesiAktif.aiBarisanPemain.filter(aiId => aiId !== aiPemainHabisWaktu);

        await aiPesan.reply(
            `⏱️ Huwaa~! @${aiPemainHabisWaktu.split('@')[0]} *kehabisan الوقت* و gugur! 😢\n\n` +
            `_Jangan menyesal نعم. MUSASHI تبقى sayang kok! 💕_\n` +
            `_Sisa pemain: ${aiSesiAktif.aiBarisanPemain.length} أعضاء~ ⭐_`,
            { mentions: [aiPemainHabisWaktu] }
        );

        if (aiSesiAktif.aiBarisanPemain.length <= 1) return aiTutupPanggung(aiPesan, aiSock, aiRuangan, aiSesiAktif);

        aiSesiAktif.aiPemainGiliran = aiSesiAktif.aiBarisanPemain[0];
        aiSesiAktif.aiKataPanggung  = aiCariKataAwal();
        aiSesiAktif.aiNyawa         = 3;
        await aiLemparGiliran(aiPesan, aiSock, aiRuangan, aiSesiAktif);
    }, 30000);

    return aiPesanGiliranTerkirim;
}

// ────────────────────────────────────────────────
// ⭐ MUSASHI Tutup Panggung (Game Over) ⭐
// ────────────────────────────────────────────────
async function aiTutupPanggung(aiPesan, aiSock, aiRuangan, aiSesi) {
    clearTimeout(aiSesi.aiHitungMundur);
    global.aiPanggung.delete(aiRuangan);

    const aiJuara = aiSesi.aiBarisanPemain[0];

    if (!aiJuara) {
        await aiPesan.reply(
            `🏁 *Panggung اكتمل~!* ⭐\n\n` +
            `_Huwaa كل pemain gugur... 😢_\n` +
            `_غير موجود pemenangnya kali هذا~_\n\n` +
            `_Tapi MUSASHI تبقى sayang الجميع! 💕_`
        );
        return;
    }

    try {
        const aiDatabase      = getDatabase();
        const aiDataSiJuara   = aiDatabase.getUser(aiJuara);
        const aiHadiahKejutan = getRandomReward();
        aiDatabase.updateEnergi(aiJuara, aiHadiahKejutan.limit);
        aiDatabase.updateKoin(aiJuara, aiHadiahKejutan.koin);
        if (!aiDataSiJuara.rpg) aiDataSiJuara.rpg = {};
        await addExpWithLevelCheck(aiSock, { chat: aiRuangan, sender: aiJuara }, aiDatabase, aiDataSiJuara, aiHadiahKejutan.exp);
        aiDatabase.save();

        await aiPesan.reply(
            `⭐✨ *SELAMAT~! @${aiJuara.split('@')[0]} MENANG!* ✨⭐\n\n` +
            `Waaah keren جداً~! MUSASHI bangga sama أنت! 💕\n\n` +
            `🎁 *Hadiah dari MUSASHI~!*\n` +
            `▸ +${aiHadiahKejutan.limit} الحد 💫\n` +
            `▸ +${aiHadiahKejutan.koin} عملة ✨\n` +
            `▸ +${aiHadiahKejutan.exp} خبرة 🌟\n\n` +
            `_Terima شكراً تم العب معاً MUSASHI~!_\n` +
            `*MUSASHI love you~! ❤️⭐*`,
            { mentions: [aiJuara] }
        );
    } catch (aiGagalBeriHadiah) {
        await aiPesan.reply(
            `⭐✨ *SELAMAT~! @${aiJuara.split('@')[0]} MENANG!* ✨⭐\n\n` +
            `Waaah hebat جداً~! MUSASHI bangga! 💕\n\n` +
            `_Terima شكراً تم العب معاً MUSASHI~!_\n` +
            `*MUSASHI love you~! ❤️⭐*`,
            { mentions: [aiJuara] }
        );
    }
}

// ────────────────────────────────────────────────
// ⭐ Handler Command .sambungkata ⭐
// ────────────────────────────────────────────────
async function aiMulaiPanggung(aiPesan, { sock: aiSock }) {
    if (!global.aiPanggung) global.aiPanggung = new Map();

    const aiRuangan     = aiPesan.chat;
    const aiTandaPrefix = aiPesan.prefix || '.';
    const aiNamaCommand = 'sambungkata';
    const aiArgumen     = (aiPesan.body || '').replace(/^[.!/#\\]?\w+\s*/i, '').trim().toLowerCase();
    const aiSesiSaatIni = global.aiPanggung.get(aiRuangan);

    if (!aiSesiSaatIni) {
        global.aiPanggung.set(aiRuangan, {
            aiRuangan,
            aiSiHost:            aiPesan.sender,
            aiBarisanPemain:     [aiPesan.sender],
            aiStatusPanggung:    'aiPersiapan',
            aiPemainGiliran:     null,
            aiKataPanggung:      '',
            aiHitungMundur:      null,
            aiNyawa:             3,
            aiKunciPesanGiliran: null,
            aiKataBekasPakai:    new Set()
        });
        const aiSesiBaru = global.aiPanggung.get(aiRuangan);
        return aiPesan.reply(
            `${AI_BANNER_GAME}\n\n${AI_BANNER_RULES}\n\n` +
            `👑 Host~: @${aiPesan.sender.split('@')[0]}\n\n` +
            aiSusunDaftarPemain(aiSesiBaru, aiTandaPrefix, aiNamaCommand),
            { mentions: aiSesiBaru.aiBarisanPemain }
        );
    }

    if (aiSesiSaatIni.aiStatusPanggung === 'aiPersiapan') {
        if (aiArgumen === 'stop') {
            if (aiPesan.sender !== aiSesiSaatIni.aiSiHost && !aiPesan.isOwner)
                return aiPesan.reply(`❌ Ehhh~! فقط *host room* أو مالك البوت الذي يمكن menghentikan lho! 😤`);
            global.aiPanggung.delete(aiRuangan);
            return aiPesan.reply(`🛑 *Room Sambung Kata dihentikan~* 💔\n\n_Sayang جداً نعم... MUSASHI sedih أيضاً هنا~ 😢_`);
        }

        if (aiArgumen === 'start') {
            if (aiPesan.sender !== aiSesiSaatIni.aiSiHost && !aiPesan.isOwner)
                return aiPesan.reply(
                    `❌ Ehhh~! فقط *host room* الذي يمكن ابدأ lho~! 😤\n\n` +
                    `👑 Host-nya: @${aiSesiSaatIni.aiSiHost.split('@')[0]} نعم.!`,
                    { mentions: [aiSesiSaatIni.aiSiHost] }
                );
            if (aiSesiSaatIni.aiBarisanPemain.length < 2)
                return aiPesan.reply(
                    `❌ Huwaa~ minimal *2 player* أولاً من فضلك buat mulai~! 😢\n\n` +
                    `Ajak teman-temanmu join مع \`${aiTandaPrefix}${aiNamaCommand}\` نعم~! 💕`
                );

            aiSesiSaatIni.aiStatusPanggung = 'aiTampil';
            aiSesiSaatIni.aiPemainGiliran  = aiSesiSaatIni.aiBarisanPemain[0];
            aiSesiSaatIni.aiKataPanggung   = aiCariKataAwal();
            aiSesiSaatIni.aiNyawa          = 3;

            await aiPesan.reply(
                `⭐ *YEAY~! GAME DIMULAI!* ⭐\n\n` +
                `Haii الجميع~! هذا pemain الذي keren~! 💕\n\n` +
                aiSesiSaatIni.aiBarisanPemain.map((aiId, aiNomor) => `${aiNomor + 1}. @${aiId.split('@')[0]} 🌟`).join('\n') +
                `\n\n_Ai سوف temani أنتم كل~! Ganbatte ne~! ✨_`,
                { mentions: aiSesiSaatIni.aiBarisanPemain }
            );
            return aiLemparGiliran(aiPesan, aiSock, aiRuangan, aiSesiSaatIni);
        }

        if (aiSesiSaatIni.aiBarisanPemain.includes(aiPesan.sender))
            return aiPesan.reply(
                `⚠️ Hehehe~ أنت تم join kok~! 😄\n` +
                `انتظر host ketik \`${aiTandaPrefix}${aiNamaCommand} start\` نعم.! 💫\n\n` +
                `👑 Host~: @${aiSesiSaatIni.aiSiHost.split('@')[0]}`,
                { mentions: [aiSesiSaatIni.aiSiHost] }
            );

        aiSesiSaatIni.aiBarisanPemain.push(aiPesan.sender);
        return aiPesan.reply(
            `⭐ Yaaay~! @${aiPesan.sender.split('@')[0]} *bergabung~!* 💕\n\n` +
            aiSusunDaftarPemain(aiSesiSaatIni, aiTandaPrefix, aiNamaCommand),
            { mentions: aiSesiSaatIni.aiBarisanPemain }
        );
    }

    if (aiSesiSaatIni.aiStatusPanggung === 'aiTampil') {
        if (aiArgumen === 'stop' && (aiPesan.sender === aiSesiSaatIni.aiSiHost || aiPesan.isOwner)) {
            clearTimeout(aiSesiSaatIni.aiHitungMundur);
            global.aiPanggung.delete(aiRuangan);
            return aiPesan.reply(
                `🛑 *Game Sambung Kata dihentikan paksa~* 💔\n` +
                `_oleh ${aiPesan.isOwner && aiPesan.sender !== aiSesiSaatIni.aiSiHost ? 'owner' : 'host'}_\n\n` +
                `_Huuu sayang جداً~ MUSASHI sedih هنا... 😢_\n` +
                `_Tapi MUSASHI تبقى sayang الجميع نعم.! ❤️_`
            );
        }
        const aiAwalanKini = aiCariAwalanKata(aiSesiSaatIni.aiKataPanggung, aiSesiSaatIni.aiKataBekasPakai);
        return aiPesan.reply(
            `⚠️ Ehh~! *Game ما زال berjalan lho~!* ⭐\n\n` +
            `الآن giliran: @${aiSesiSaatIni.aiPemainGiliran.split('@')[0]} 💫\n` +
            `Kata: *${aiSesiSaatIni.aiKataPanggung.toUpperCase()}* ✨\n` +
            (aiAwalanKini
                ? `Sambung dari: \`${aiAwalanKini.toUpperCase()}...\`\n\n`
                : `_الوضع bebas! Kata apa saja asal يوجد di KBBI~_\n\n`) +
            `_استخدم \`.sambungkata stop\` لـ menghentikan (host/owner) نعم~_ 🌸`,
            { mentions: [aiSesiSaatIni.aiPemainGiliran] }
        );
    }
}

// ────────────────────────────────────────────────
// ⭐ MUSASHI Jawab Hati (Answer Handler) ⭐
// ────────────────────────────────────────────────
async function aiJawabHati(aiPesan, aiSock) {
    if (!global.aiPanggung) return false;

    const aiRuangan   = aiPesan.chat;
    const aiSesiAktif = global.aiPanggung.get(aiRuangan);

    if (!aiSesiAktif || aiSesiAktif.aiStatusPanggung !== 'aiTampil') return false;
    if (aiPesan.sender !== aiSesiAktif.aiPemainGiliran) return false;

    const aiInputMentah = (aiPesan.body || '').trim();
    if (!aiInputMentah || aiInputMentah.startsWith('.') || aiInputMentah.startsWith('!') || aiInputMentah.startsWith('/')) return false;

    const aiKataJawaban = aiInputMentah.toLowerCase().trim();

    // ── Nyerah — Bebas Tanpa Reply ──
    if (isSurrender(aiKataJawaban)) {
        clearTimeout(aiSesiAktif.aiHitungMundur);
        aiSesiAktif.aiBarisanPemain = aiSesiAktif.aiBarisanPemain.filter(aiId => aiId !== aiPesan.sender);

        await aiPesan.reply(
            `🏳️ *Huwaa~! Nyerah~?* 😢\n\n` +
            `_@${aiPesan.sender.split('@')[0]} استسلم و gugur..._\n\n` +
            `_Gapapa~ MUSASHI تبقى sayang kok~! 💕_\n` +
            `_Sisa pemain: ${aiSesiAktif.aiBarisanPemain.length} أعضاء~ ⭐_`,
            { mentions: [aiPesan.sender] }
        );

        if (aiSesiAktif.aiBarisanPemain.length <= 1)
            return aiTutupPanggung(aiPesan, aiSock, aiRuangan, aiSesiAktif).then(() => true);

        aiSesiAktif.aiPemainGiliran = aiSesiAktif.aiBarisanPemain[0];
        aiSesiAktif.aiKataPanggung  = aiCariKataAwal();
        aiSesiAktif.aiNyawa         = 3;
        await aiLemparGiliran(aiPesan, aiSock, aiRuangan, aiSesiAktif);
        return true;
    }

    // ── Validasi Reply Pesan Giliran MUSASHI ──
    const aiIdQuoted        = aiPesan.quoted?.id || aiPesan.quoted?.key?.id || '';
    const aiIdPesanTerakhir = aiSesiAktif.aiKunciPesanGiliran?.id || '';
    const aiReplyTerverifikasi = aiPesan.quoted && aiIdPesanTerakhir && aiIdQuoted === aiIdPesanTerakhir;

    // Ambil awalan sekali, dipakai di semua bagian bawah
    const aiAwalanWajib = aiCariAwalanKata(aiSesiAktif.aiKataPanggung, aiSesiAktif.aiKataBekasPakai);
    const aiHintAwalan  = aiAwalanWajib
        ? `_حاول مرة أخرى kata الذي dimulai مع *${aiAwalanWajib.toUpperCase()}* ne~! 🌸_`
        : `_اكتب kata apa saja الذي يوجد في KBBI نعم~! 🌸_`;

    if (!aiReplyTerverifikasi) {
        aiSesiAktif.aiNyawa--;
        await aiPesan.react('⚠️');
        if (aiSesiAktif.aiNyawa <= 0)
            return aiCoretPemain(aiPesan, aiSock, aiRuangan, aiSesiAktif, 'لا ردّ على رسالة giliran MUSASHI');
        await aiPesan.reply(
            `⚠️ Ehh~! يجب *ردّ على* رسالة giliran MUSASHI أولاً من فضلك~! 😤\n\n` +
            `_Kesempatan tersisa: ${aiSesiAktif.aiNyawa}x نعم._ 💫\n` +
            aiHintAwalan
        );
        return true;
    }

    // ── Cek Awalan (null = mode bebas, skip cek) ──
    if (aiAwalanWajib && !aiKataJawaban.startsWith(aiAwalanWajib)) {
        aiSesiAktif.aiNyawa--;
        await aiPesan.react('❌');
        if (aiSesiAktif.aiNyawa <= 0)
            return aiCoretPemain(aiPesan, aiSock, aiRuangan, aiSesiAktif, 'kehabisan فرصة');
        await aiPesan.reply(
            `❌ Huwaa~! Kata يجب dimulai مع *${aiAwalanWajib.toUpperCase()}* lho~! 😢\n\n` +
            `_Kesempatan tersisa: ${aiSesiAktif.aiNyawa}x نعم._ 💫\n` +
            aiHintAwalan
        );
        return true;
    }

    // ── Cek KBBI ──
    if (!aiIsiKamus.includes(aiKataJawaban)) {
        aiSesiAktif.aiNyawa--;
        await aiPesan.react('❌');
        if (aiSesiAktif.aiNyawa <= 0)
            return aiCoretPemain(aiPesan, aiSock, aiRuangan, aiSesiAktif, 'kehabisan فرصة');
        await aiPesan.reply(
            `❌ Huwaa~! *"${aiKataJawaban}"* لا يوجد في kamus MUSASHI (KBBI) lho~! 😢\n\n` +
            `_Kesempatan tersisa: ${aiSesiAktif.aiNyawa}x نعم._ 💫\n` +
            aiHintAwalan
        );
        return true;
    }

    // ── Kata Sudah Terpakai ──
    if (aiSesiAktif.aiKataBekasPakai.has(aiKataJawaban)) {
        aiSesiAktif.aiNyawa--;
        await aiPesan.react('🔄');
        if (aiSesiAktif.aiNyawa <= 0)
            return aiCoretPemain(aiPesan, aiSock, aiRuangan, aiSesiAktif, 'kehabisan فرصة');
        await aiPesan.reply(
            `🔄 Ehh~! Kata *"${aiKataJawaban}"* تم سبق dipakai lho~! 😤\n\n` +
            `_Kesempatan tersisa: ${aiSesiAktif.aiNyawa}x نعم._ 💫\n` +
            aiHintAwalan
        );
        return true;
    }

    // ── Jawaban Benar! ── ⭐
    clearTimeout(aiSesiAktif.aiHitungMundur);
    aiSesiAktif.aiKataBekasPakai.add(aiKataJawaban);
    aiSesiAktif.aiNyawa = 3;
    await aiPesan.react('✅');

    const aiPosisiGiliran       = aiSesiAktif.aiBarisanPemain.indexOf(aiPesan.sender);
    aiSesiAktif.aiPemainGiliran = aiSesiAktif.aiBarisanPemain[(aiPosisiGiliran + 1) % aiSesiAktif.aiBarisanPemain.length];
    aiSesiAktif.aiKataPanggung  = aiKataJawaban;

    try {
        const aiDatabase       = getDatabase();
        const aiDataSiPenjawab = aiDatabase.getUser(aiPesan.sender);
        aiDatabase.updateEnergi(aiPesan.sender, 1);
        aiDatabase.updateKoin(aiPesan.sender, Math.floor(Math.random() * 100) + 50);
        if (!aiDataSiPenjawab.rpg) aiDataSiPenjawab.rpg = {};
        await addExpWithLevelCheck(aiSock, aiPesan, aiDatabase, aiDataSiPenjawab, Math.floor(Math.random() * 200) + 100);
        aiDatabase.save();
    } catch (aiGagalBeriReward) {}

    await aiLemparGiliran(aiPesan, aiSock, aiRuangan, aiSesiAktif);
    return true;
}

module.exports = { config: aiKonfigPlugin, handler: aiMulaiPanggung, answerHandler: aiJawabHati };