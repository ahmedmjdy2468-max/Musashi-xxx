const {
    getRandomItem, createSession, getSession, endSession,
    checkAnswerAdvanced, getHint, hasActiveSession, setSessionTimer,
    getRemainingTime, formatRemainingTime, isSurrender, isReplyToGame,
    GAME_REWARD,
    getRandomReward,
    getProgressiveHint
} = require('../../src/lib/gameData');
const { getDatabase } = require('../../src/lib/database');
const { addExpWithLevelCheck } = require('../../src/lib/levelHelper');
const {getGameContextInfo, getWinnerContextInfo, checkFastAnswer, getGameContextInfoV2 } = require('../../src/lib/contextHelper');

const pluginConfig = {
    name: 'tebakprofesi',
    alias: ['tp', 'guessjob'],
    category: 'game',
    description: 'خمّن profesi من الوصف الذي diberikan',
    usage: '.tebakprofesi',
    example: '.tebakprofesi',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
};

async function handler(m, { sock }) {
    const chatId = m.chat;

    if (hasActiveSession(chatId)) {
        const session = getSession(chatId);
        if (session && session.gameType === 'tebakprofesi') {
            const remaining = getRemainingTime(chatId);
            let text = `⚠️ *Eh يوجد game jalan هنا, jawab أولاً!*\n\n`;
            text += `\`\`\`${session.question.soal}\`\`\`\n\n`;
            text += `💡 Hint: *${getHint(session.question.jawaban, 2)}*\n`;
            text += `⏱️ المتبقي: *${formatRemainingTime(remaining)}*\n\n`;
            text += `_أجب مباشرة أو اكتب "استسلام"\nSetiap خاطئ, hint akan bertambah_`;
            await m.reply(text);
            return;
        }
    }

    const question = getRandomItem('tebakprofesi.json');
    if (!question) {
        await m.reply('❌ *البيانات غير متاحة*\n\n> Ehh~ بيانات اللعبة غير متاحة بعد... أعد المحاولة لاحقاً 🥺');
        return;
    }

    let text = `👔 *ᴛᴇʙᴀᴋ ᴘʀᴏꜰᴇsɪ*\n\n`;
    text += `\`\`\`${question.soal}\`\`\`\n\n`;
    text += `💡 Hint: *${getHint(question.jawaban, 2)}*\n`;
    text += `⏱️ الوقت: *60 ثانية*\n`;
    text += `🎁 الجائزة: *حد، عملات، خبرة (عشوائي)*\n\n`;
    text += `_أجب مباشرة أو اكتب "استسلام"\nSetiap خاطئ, hint akan bertambah_`;

    const db = getDatabase();
    const contextVariant = db.setting('contextVariant') || 1;

    let sentMsg;
    if (contextVariant === 2) {
        sentMsg = await getGameContextInfoV2(sock, chatId, text, { quoted: m });
    } else {
        sentMsg = await sock.sendMessage(chatId, { text, contextInfo: getGameContextInfo('👔 TEBAK PROFESI', 'Tebak profesi dari deskripsi!') }, { quoted: m });
    }
    createSession(chatId, 'tebakprofesi', question, sentMsg.key, 60000);

    setSessionTimer(chatId, async () => {
        let timeoutText = `⏱️ *انتهى الوقت!*\n\nJawaban: *${question.jawaban}*\n\n_لا أحد أجاب_`;
        await m.reply(timeoutText);
    });
}

async function answerHandler(m, sock) {
    const chatId = m.chat;
    const session = getSession(chatId);
    if (!session || session.gameType !== 'tebakprofesi') return false;

    const userAnswer = (m.body || '').trim();
    if (!userAnswer || userAnswer.startsWith('.')) return false;

    if (isSurrender(userAnswer)) {
        endSession(chatId);
        await m.reply(`🏳️ *ᴍᴇɴʏᴇʀᴀʜ!*\n\nJawaban: *${session.question.jawaban}*\n\n_@${m.sender.split('@')[0]} استسلم_`, { mentions: [m.sender] });
        return true;
    }

    if (!isReplyToGame(m, session)) return false;

    session.attempts++;

    const result = checkAnswerAdvanced(session.question.jawaban, userAnswer);

    if (result.status === 'correct') {
        endSession(chatId);
        const db = getDatabase();
        const user = db.getUser(m.sender);

        const reward = getRandomReward();
        let totalLimit = reward.limit;
        let totalBalance = reward.koin;
        let totalExp = reward.exp;
        let bonusText = '';

        const fastResult = checkFastAnswer(session);
        if (fastResult.isFast) {
            totalLimit += fastResult.bonus.limit;
            totalBalance += fastResult.bonus.koin;
            totalExp += fastResult.bonus.exp;
            bonusText = `\n\n${fastResult.praise}\n⚡ *مكافأة سريعة:* +${fastResult.bonus.limit} حد، +${fastResult.bonus.koin} عملة\n⏱️ الوقت: *${(fastResult.elapsed / 1000).toFixed(1)}s*`;
        }

        db.updateEnergi(m.sender, totalLimit);
        db.updateKoin(m.sender, totalBalance);
        if (!user.rpg) user.rpg = {};
        await addExpWithLevelCheck(sock, m, db, user, totalExp);
        db.save();

        let text = `💯 *TOP MARKOTOP! Lu nailed it!*\n\nJawaban: *${session.question.jawaban}*\nPemenang: *@${m.sender.split('@')[0]}*\nPercobaan: *${session.attempts}x*\n\n`;
        text += `🎁 +${totalLimit} حد، +${totalBalance} عملة, +${totalExp} خبرة`;
        text += bonusText;

        await m.reply(text, { mentions: [m.sender] });
        return true;
    }

    if (result.status === 'close') {
        const remaining = getRemainingTime(chatId);
        await m.react('🔥');
        await m.reply(`🔥 *قريب!* إجابتك *${Math.round(result.similarity * 100)}%* متطابقة!\n_الوقت المتبقي: *${formatRemainingTime(remaining)}*_`);
        return false;
    }

    const remaining = getRemainingTime(chatId);
    if (remaining > 0 && session.attempts < 10) {
        await m.react('❌');
        const hint = getProgressiveHint(session.question.jawaban, session.attempts);
        await m.reply(`❌ *ليس صحيحاً بعد!* حاول مجدداً، هذا التلميح: *${hint}*\n_الوقت المتبقي: *${formatRemainingTime(remaining)}*_ 🌸`);
    }
    return false;
}

module.exports = { config: pluginConfig, handler, answerHandler };
