import test, { beforeEach } from "node:test";
import assert from "node:assert/strict";
import { EventEmitter } from "node:events";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

import settingsHandler from "../plugins/admins/settings.js";
import menuHandler from "../plugins/menu.js";
import { mapCommandsByCategory, buildCategoryText, getCategoryById } from "../plugins/menu.js";
import helpHandler from "../plugins/info/help.js";
import antiLink from "../plugins/auto/anti-link.js";
import antiInsult from "../plugins/auto/anti-insult.js";
import antiSpam from "../plugins/auto/anti-spam.js";
import noBots from "../plugins/auto/noBots.js";
import featureGate from "../plugins/auto/01-feature-gate.js";
import { group as handleGroupEvent } from "../system/control.js";
import { getCatalogEntry } from "../system/catalog.js";
import { getUnderDevPlugin } from "../system/underDev.js";
import { isFeatureEnabled, setFeatureEnabled } from "../system/features.js";
import { antiSpamGuard } from "../system/anti-spam.js";
import { sendInstallConfirmation } from "../plugins/subs/sub.js";
import { registerLegacyPlugins } from "../system/legacy/loader.js";
import { buildLegacySock } from "../system/legacy/sock.js";
import UltraDB from "../system/UltraDB.js";
import controlHandler from "../plugins/admins/control.js";
import protectionCommands from "../plugins/admins/protection_cmds.js";
import { attachBotDiscoveryRecorder, loadBotPatterns, matchBotPatterns, recordGroupMessages } from "../system/botDiscovery.js";
import { canRunStrictOwnerCommand } from "../system/legacy/loader.js";

const CHAT = "120363099999999999@g.us";
const MEMBER = "887766554433@s.whatsapp.net";

function makeConn() {
  const sent = [];
  return {
    sent,
    async sendMessage(chat, payload) {
      sent.push({ chat, payload });
      return { key: { id: `test-${sent.length}` } };
    },
    async groupParticipantsUpdate(chat, participants, action) {
      sent.push({ chat, payload: { participants, action } });
      return [{ status: "200" }];
    },
  };
}

function makeMessage(overrides = {}) {
  const replies = [];
  return {
    replies,
    isGroup: true,
    isOwner: false,
    isAdmin: false,
    isBaileys: false,
    fromMe: false,
    chat: CHAT,
    sender: MEMBER,
    key: { id: `msg-${Math.random().toString(36).slice(2)}`, participant: MEMBER },
    text: "",
    async reply(text) { replies.push(String(text)); },
    ...overrides,
  };
}

beforeEach(() => {
  global.db = { groups: { [CHAT]: { features: {} } }, settings: {} };
  global.menus = {};
  global.__musashiWarnProcessed = new Set();
  antiSpamGuard.clear();
});

test("strict owner commands fail closed without an owner identity", () => {
  const oldOwner = process.env.OWNER_PHONE_NUMBER;
  const oldDeveloper = process.env.DEVELOPER_PHONE;
  delete process.env.OWNER_PHONE_NUMBER;
  delete process.env.DEVELOPER_PHONE;
  global.db.settings = {};
  try {
    assert.equal(canRunStrictOwnerCommand("111111111@s.whatsapp.net"), false);
    global.db.settings.ownerJid = "222222222@s.whatsapp.net";
    assert.equal(canRunStrictOwnerCommand("222222222@s.whatsapp.net"), true);
    assert.equal(canRunStrictOwnerCommand("111111111@s.whatsapp.net"), false);
  } finally {
    if (oldOwner !== undefined) process.env.OWNER_PHONE_NUMBER = oldOwner;
    if (oldDeveloper !== undefined) process.env.DEVELOPER_PHONE = oldDeveloper;
  }
});

test("kick refuses protected targets without kicking the command sender", async () => {
  const updates = [];
  const replies = [];
  const conn = { user: { id: "999999999:1@s.whatsapp.net" }, async groupParticipantsUpdate(...args) { updates.push(args); } };
  const bot = { config: { owners: [{ jid: "888888888@s.whatsapp.net" }] } };
  for (const target of ["888888888@s.whatsapp.net", "999999999@s.whatsapp.net"]) {
    await controlHandler({
      chat: CHAT, sender: MEMBER, quoted: { sender: target }, mentionedJid: [],
      async reply(value) { replies.push(String(value)); },
    }, { command: "طرد", conn, bot, text: "" });
  }
  assert.deepEqual(updates, []);
  assert.equal(replies.length, 2);
  assert.ok(replies.every((message) => /لا يمكن طرد/u.test(message)));
});

test("the group activation list is one message and stores a selected feature centrally", async () => {
  const conn = makeConn();
  const m = makeMessage({ isAdmin: true });
  await settingsHandler(m, { conn, bot: { getAllCommands: () => [] }, command: "تفعيل", text: "" });
  assert.equal(conn.sent.length, 1);
  assert.match(conn.sent[0].payload.text, /إعدادات هذه المجموعة/u);
  assert.match(conn.sent[0].payload.text, /الطقس/u);

  setFeatureEnabled("weather", false, { chatId: CHAT, isGroup: true });
  await settingsHandler(m, { conn, bot: { getAllCommands: () => [] }, command: "تفعيل", text: "3", args: ["3"] });
  assert.equal(global.db.groups[CHAT].features.weather, true);
  assert.equal(isFeatureEnabled("weather", { chatId: CHAT, isGroup: true }), true);

  conn.sent.length = 0;
  await settingsHandler(m, { conn, bot: { getAllCommands: () => [] }, command: "تفعيل", text: "" });
  assert.match(conn.sent[0].payload.text, /🟢 \*الطقس\*/u);
});

test("a non-admin cannot change group features", async () => {
  setFeatureEnabled("weather", true, { chatId: CHAT, isGroup: true });
  const m = makeMessage();
  await settingsHandler(m, { conn: makeConn(), bot: {}, command: "تعطيل", text: "3", args: ["3"] });
  assert.equal(global.db.groups[CHAT].features.weather, true);
  assert.match(m.replies.join("\n"), /لا تملك صلاحية التغيير/u);
});

test("main menu stays compact and points to the full section index", async () => {
  const conn = makeConn();
  await menuHandler(makeMessage({ pushName: "مختبر" }), {
    conn,
    bot: { getAllCommands: () => [] },
    args: [],
    command: "اوامر",
  });
  const caption = conn.sent.map(item => item.payload?.text || item.payload?.caption || "").join("\n");
  assert.match(caption, /الأقسام الأساسية/u);
  assert.match(caption, /\.اوامر اقسام/u);
  assert.match(caption, /\.اوامر 19/u);
  assert.doesNotMatch(caption, /العضويات والاشتراكات/u);
});

test("disabled games are blocked before execution and resume when enabled", async () => {
  const m = makeMessage({ body: ".سؤال" });
  setFeatureEnabled("games", false, { chatId: CHAT, isGroup: true });
  assert.equal(await featureGate(m), true);
  assert.match(m.replies.at(-1), /الألعاب.*متوقفة/u);
  setFeatureEnabled("games", true, { chatId: CHAT, isGroup: true });
  assert.equal(await featureGate(m), false);
});

test("untranslated game data is hidden from the menu and reports its localization status", async () => {
  const mapped = mapCommandsByCategory([
    { command: ["تخمين_صورة_فرعي"], category: "game" },
    { command: ["لغز"], category: "game" },
  ], { chatId: CHAT, isGroup: true });
  assert.equal(mapped.grouped.games.length, 1);
  assert.equal(mapped.grouped.games[0].displayList[0], "لغز");

  const m = makeMessage({ text: ".تخمين_صورة_فرعي", body: ".تخمين_صورة_فرعي" });
  assert.equal(await featureGate(m), true);
  assert.match(m.replies.at(-1), /هذه اللعبة قيد التعريب/u);
});

test("commands awaiting translation are listed in their own menu section with the current test name", () => {
  const mapped = mapCommandsByCategory([
    { command: ["gift", "kasih", "hadiah"], category: "rpg", filePath: path.resolve("plugins_legacy/rpg/gift.js") },
    { command: ["sendngl"], category: "tools", filePath: path.resolve("plugins_legacy/tools/sendngl.js") },
  ], { chatId: CHAT, isGroup: true });
  assert.equal(mapped.grouped.translation.length, 2);
  assert.equal(mapCommandsByCategory([], { chatId: CHAT, isGroup: true }).grouped.translation.length, 0);
  const review = buildCategoryText(getCategoryById(29), mapped.grouped.translation);
  assert.match(review, /جاري الترجمة/u);
  assert.match(review, /\.gift/u);
  assert.match(review, /قيد المراجعة/u);
  assert.match(review, /الخدمة غير مفعّلة/u);
});

test("Arabic localized group, clan and RPG commands are no longer held behind underDev", async () => {
  const ready = [
    "تنبيه_الجميع", "مسح_المحادثة", "تصفير_الإنذارات", "بدء_الحضور",
    "تصفير_لوحة_النشاط", "إعادة_فترة_رصد_النشاط", "غير_النشطين",
    "إنشاء_عشيرة", "إضافة_عضو_للعشيرة", "انضمام_للعشيرة", "طرد_من_العشيرة",
    "ترتيب_العشائر", "إشعار_المستوى",
    "سرقة_المغامرات", "مكافأة_أسبوعية", "قائمة_البوتات_الفرعية",
    "البوتات_الفرعية_النشطة", "إيقاف_البوتات_الفرعية", "إيقاف_وحذف_بوت_فرعي",
    "هل_سيحدث", "توقع_نعم_أم_لا", "كيف", "كم_العدد", "هل_أستطيع",
    "إنهاء_علاقة", "خمّن_حالتي", "أين_المكان", "هل_ينبغي", "متى", "لماذا",
    "تقييم_عشوائي", "إنقاص_الخبرة", "إنقاص_الطاقة", "نشر_فيديو_فوري",
    "قائمة_الحضور", "معرف_المجموعة", "تنبيه_المشرفين", "ملخص_المجموعة", "منشن_الجميع",
    "منشن_الأعضاء", "منشن_غير_النشطين", "ملصق_أفاتار", "حالة_الأعضاء", "بطء_المحادثة", "وضع_البوت",
  ];
  for (const command of ready) assert.equal(getUnderDevPlugin(command), null, `${command} should be available`);

});

test("marriage and divorce commands are removed while the existing سرقة command keeps its label", () => {
  for (const command of ["marry", "nikah", "wedding", "propose", "divorce", "pisah", "طلاق"]) {
    assert.equal(getCatalogEntry(command), null, `${command} must not remain in the command catalog`);
  }
  assert.equal(fs.existsSync("plugins_legacy/rpg/marry.js"), false);
  assert.equal(fs.existsSync("plugins_legacy/rpg/divorce.js"), false);
  assert.equal(fs.existsSync("plugins/group/divorce.js"), false);
  assert.equal(getCatalogEntry("سرقة")?.ar, "سرقة");
});

test("anti-link, anti-insult and anti-spam follow their feature switches", async () => {
  const conn = makeConn();
  const m = makeMessage({ text: "https://example.com" });
  assert.equal(await antiLink(m, { conn }), false);
  setFeatureEnabled("antilink", true, { chatId: CHAT, isGroup: true });
  assert.equal(await antiLink(m, { conn }), true);
  assert.ok(conn.sent.some(item => item.payload?.delete));

  conn.sent.length = 0;
  const insult = makeMessage({ text: "يا غبي" });
  assert.equal(await antiInsult(insult, { conn }), false);
  setFeatureEnabled("antibad", true, { chatId: CHAT, isGroup: true });
  assert.equal(await antiInsult(insult, { conn }), true);
  assert.ok(conn.sent.some(item => item.payload?.delete));

  conn.sent.length = 0;
  const spamMessage = () => makeMessage({ text: "رسالة متكررة" });
  setFeatureEnabled("antispam", true, { chatId: CHAT, isGroup: true });
  await antiSpam(spamMessage(), { conn });
  await antiSpam(spamMessage(), { conn });
  assert.equal(await antiSpam(spamMessage(), { conn }), true);
  assert.ok(conn.sent.some(item => item.payload?.delete));

  conn.sent.length = 0;
  setFeatureEnabled("antispam", false, { chatId: CHAT, isGroup: true });
  await antiSpam(spamMessage(), { conn });
  await antiSpam(spamMessage(), { conn });
  await antiSpam(spamMessage(), { conn });
  assert.equal(conn.sent.length, 0);
});

test("bot messages are not auto-removed while contact protection follows its switch", async () => {
  const conn = makeConn();
  const botMessage = makeMessage({ isBot: true, text: "رسالة آلية" });
  assert.equal(await noBots(botMessage, { conn, bot: {} }), false);
  setFeatureEnabled("antibot", true, { chatId: CHAT, isGroup: true });
  assert.equal(await noBots(botMessage, { conn, bot: {} }), false);
  assert.equal(conn.sent.some(item => item.payload?.action === "remove"), false);

  conn.sent.length = 0;
  const contactMessage = makeMessage({ message: { contactMessage: { displayName: "اختبار" } } });
  setFeatureEnabled("anticontact", false, { chatId: CHAT, isGroup: true });
  assert.equal(await noBots(contactMessage, { conn, bot: {} }), false);
  setFeatureEnabled("anticontact", true, { chatId: CHAT, isGroup: true });
  assert.equal(await noBots(contactMessage, { conn, bot: {} }), true);
  assert.ok(conn.sent.some(item => item.payload?.delete));
});

test("anti-bot legacy flags merge into one canonical group switch", () => {
  global.db.groups[CHAT] = { antiBots: false, antiBot: true };
  assert.equal(isFeatureEnabled("antibot", { chatId: CHAT, isGroup: true }), true);
  assert.equal(global.db.groups[CHAT].features.antibot, true);
  assert.equal(global.db.groups[CHAT].antiBots, true);
  assert.equal(global.db.groups[CHAT].antiBot, true);
});

test("bot discovery scans first message IDs, counts unexamined members, and waits for confirmation", async () => {
  const conn = makeConn();
  const botJid = "999999999@s.whatsapp.net";
  const adminJid = "777777777@s.whatsapp.net";
  const targetJid = "333333333@s.whatsapp.net";
  conn.user = { id: botJid };
  let metadataReads = 0;
  conn.groupMetadata = async () => {
    metadataReads++;
    return { participants: [
      { id: botJid, admin: "admin" },
      { id: adminJid, admin: "admin" },
      { id: targetJid },
      { id: "444444444@s.whatsapp.net" },
    ] };
  };

  const regularMember = makeMessage({ sender: "666666666@s.whatsapp.net" });
  await protectionCommands(regularMember, { conn, command: "كشف_البوتات", args: [] });
  assert.match(regularMember.replies.join("\n"), /للمشرفين في المجموعة فقط/u);
  assert.equal(metadataReads, 0);

  global.db.groups[CHAT].botDiscovery = {
    members: {
      [targetJid]: { jid: targetJid, aliases: [targetJid], firstMessageId: "BAEfirst-message", firstSeenAt: "2026-11-18T00:00:00.000Z" },
    },
    whitelist: [],
  };
  setFeatureEnabled("antibot", true, { chatId: CHAT, isGroup: true });
  const admin = makeMessage({ isAdmin: true, sender: adminJid });
  await protectionCommands(admin, { conn, command: "كشف_البوتات", args: [] });
  assert.equal(metadataReads, 1);
  assert.match(conn.sent[0].payload.text, /333333333.*معرّف الرسالة يبدأ بـ BAE/u);
  assert.match(conn.sent[0].payload.text, /لم يرسلوا منذ بدء التسجيل: \*2\*/u);
  assert.match(conn.sent[0].payload.text, /النتيجة تقريبية/u);
  assert.match(conn.sent[0].payload.text, /تأكيد الطرد/u);
  assert.equal(conn.sent.some(item => item.payload?.action === "remove"), false);

  const confirmation = makeMessage({ isAdmin: true, sender: adminJid, body: "تأكيد الطرد" });
  await protectionCommands.before(confirmation, { conn });
  assert.equal(conn.sent.filter(item => item.payload?.action === "remove").length, 1);
  assert.equal(conn.sent.at(-1).payload.text.includes("تم الطرد"), true);
});

test("messages.upsert discovery recorder stores only first IDs and does not alter messages", () => {
  const saved = [];
  const db = { groups: {}, flushSync() { saved.push(true); } };
  const messages = [
    {
      key: { remoteJid: CHAT, participant: MEMBER, participantAlt: "887766554433@lid", id: "3EB0" + "a".repeat(36) },
      messageTimestamp: 1_800_000_000,
      message: { conversation: "لا تحفظ نص الرسالة" },
    },
    {
      key: { remoteJid: CHAT, participant: MEMBER, id: "BAE-later" },
      messageTimestamp: 1_800_000_001,
      message: { conversation: "نص ثانٍ لا يُخزّن" },
    },
    {
      key: { remoteJid: MEMBER, id: "private-message-id" },
      message: { conversation: "رسالة خاصة لا تُسجّل" },
    },
  ];
  const original = JSON.stringify(messages);
  assert.equal(recordGroupMessages(messages, db), 1);
  const record = db.groups[CHAT].botDiscovery.members[MEMBER];
  assert.equal(record.firstMessageId, "3EB0" + "a".repeat(36));
  assert.equal(record.firstSeenAt, new Date(1_800_000_000_000).toISOString());
  assert.ok(record.aliases.includes("887766554433@lid"));
  assert.doesNotMatch(JSON.stringify(db), /لا تحفظ نص الرسالة|نص ثانٍ لا يُخزّن/u);
  assert.equal(JSON.stringify(messages), original);
  assert.equal(saved.length, 1);
});

test("bot discovery recorder attaches once to the Baileys messages.upsert event", () => {
  const ev = new EventEmitter();
  const sock = { ev };
  const db = { groups: {}, flushSync() {} };
  assert.equal(attachBotDiscoveryRecorder(sock, () => db), true);
  assert.equal(attachBotDiscoveryRecorder(sock, () => db), false);
  ev.emit("messages.upsert", {
    messages: [{
      key: { remoteJid: CHAT, participant: MEMBER, id: "BAE-upsert" },
      messageTimestamp: 1_800_000_010,
      message: { conversation: "لن يُقرأ هذا النص" },
    }],
  });
  assert.equal(db.groups[CHAT].botDiscovery.members[MEMBER].firstMessageId, "BAE-upsert");
  assert.doesNotMatch(JSON.stringify(db), /لن يُقرأ هذا النص/u);
});

test("bot discovery rules come from bot-patterns.json and enforce the configured length", () => {
  const loaded = loadBotPatterns();
  assert.equal(loaded.error, null);
  assert.deepEqual(matchBotPatterns("BAE-message", loaded.rules), [
    "معرّف الرسالة يبدأ بـ BAE",
    "معرّف الرسالة يحتوي على شرطة",
  ]);
  assert.deepEqual(matchBotPatterns("3EB0" + "a".repeat(36), loaded.rules), [
    "معرّف الرسالة يبدأ بـ 3EB0 وطوله 40",
  ]);
  assert.deepEqual(matchBotPatterns("3EB0" + "a".repeat(35), loaded.rules), []);
});

test("bot discovery whitelist is group-scoped and exempts the member from bot removal", async () => {
  const conn = makeConn();
  const target = "333333333@s.whatsapp.net";
  const m = makeMessage({ isAdmin: true, mentionedJid: [target] });
  await protectionCommands(m, { conn, command: "استثناء", args: [] });
  assert.deepEqual(global.db.groups[CHAT].botDiscovery.whitelist, [target]);

  setFeatureEnabled("antibot", true, { chatId: CHAT, isGroup: true });
  const message = makeMessage({ sender: target, isBot: true, text: "رسالة آلية" });
  assert.equal(await noBots(message, { conn, bot: {} }), false);
  assert.equal(conn.sent.some(item => item.payload?.action === "remove"), false);

  await protectionCommands(m, { conn, command: "إلغاء_الاستثناء", args: [] });
  assert.deepEqual(global.db.groups[CHAT].botDiscovery.whitelist, []);
});

test("bot discovery refuses to scan when the bot is not a group admin", async () => {
  const conn = makeConn();
  conn.user = { id: "999999999@s.whatsapp.net" };
  conn.groupMetadata = async () => ({
    participants: [
      { id: conn.user.id },
      { id: MEMBER, admin: "admin" },
    ],
  });
  setFeatureEnabled("antibot", true, { chatId: CHAT, isGroup: true });
  const admin = makeMessage({ isAdmin: true });
  await protectionCommands(admin, { conn, command: "كشف_البوتات", args: [] });
  assert.match(admin.replies.join("\n"), /يجب أن يكون البوت مشرفاً/u);
  assert.equal(conn.sent.length, 0);
});

test("confirmed bot removal reports a safe per-member failure", async () => {
  const conn = makeConn();
  conn.user = { id: "999999999@s.whatsapp.net" };
  conn.groupMetadata = async () => ({
    participants: [
      { id: conn.user.id, admin: "admin" },
      { id: "777777777@s.whatsapp.net", admin: "admin" },
      { id: "333333333@s.whatsapp.net" },
    ],
  });
  conn.groupParticipantsUpdate = async () => { throw new Error("simulated permission failure"); };
  global.db.groups[CHAT].botDiscovery = {
    members: {
      "333333333@s.whatsapp.net": {
        jid: "333333333@s.whatsapp.net",
        aliases: ["333333333@s.whatsapp.net"],
        firstMessageId: "BAE-first",
        firstSeenAt: new Date().toISOString(),
      },
    },
    whitelist: [],
  };
  setFeatureEnabled("antibot", true, { chatId: CHAT, isGroup: true });
  const admin = makeMessage({ isAdmin: true, sender: "777777777@s.whatsapp.net" });
  await protectionCommands(admin, { conn, command: "كشف_البوتات", args: [] });

  const previousError = console.error;
  console.error = () => {};
  try {
    const confirmation = makeMessage({ isAdmin: true, sender: admin.sender, body: "تأكيد الطرد" });
    await protectionCommands.before(confirmation, { conn });
  } finally {
    console.error = previousError;
  }
  assert.match(conn.sent.at(-1).payload.text, /❌ @333333333 — فشل الطرد/u);
  assert.doesNotMatch(conn.sent.at(-1).payload.text, /simulated permission failure/u);
});

test("welcome and goodbye events obey the unified switches", async () => {
  const sent = [];
  const ctx = { config: { info: { nameBot: "MUSASHI" } }, sock: { async msgUrl(chat, text) { sent.push({ chat, text }); } } };
  const addEvent = { chat: CHAT, participants: [MEMBER], subject: "مجموعة اختبار" };
  assert.equal(await handleGroupEvent(ctx, addEvent, "add"), 9999);
  assert.equal(sent.length, 0);
  setFeatureEnabled("welcome", true, { chatId: CHAT, isGroup: true });
  await handleGroupEvent(ctx, addEvent, "add");
  assert.equal(sent.length, 1);
  assert.match(sent[0].text, /أهلاً بك/u);

  setFeatureEnabled("goodbye", true, { chatId: CHAT, isGroup: true });
  await handleGroupEvent(ctx, { ...addEvent, participants: [MEMBER] }, "remove");
  assert.equal(sent.length, 2);
  assert.match(sent[1].text, /غادر/u);
});

test("legacy help lookup resolves to the Arabic catalog label and example", async () => {
  const entry = getCatalogEntry("compress_video");
  assert.equal(entry?.ar, "ضغط_فيديو");
  assert.match(entry?.example || "", /^\.ضغط_فيديو/u);

  const m = makeMessage({ isGroup: false, chat: MEMBER });
  await helpHandler(m, {
    args: ["compress_video"], prefix: ".",
    bot: { getAllCommands: () => [{ command: ["compress_video"], category: "tools", usage: ["compress_video"], desc: "" }] },
  });
  const help = m.replies.join("\n");
  assert.match(help, /شرح الأمر: \.ضغط_فيديو/u);
  assert.match(help, /مثال الاستخدام/u);
  assert.match(help, /الصلاحية/u);
});

test("installation confirmation is sent to the original PN/LID chat", async () => {
  const conn = makeConn();
  const m = makeMessage({ isGroup: false, chat: "123456789@lid", sender: "123456789@lid", pushName: "مستخدم" });
  await sendInstallConfirmation(conn, "123456789", m, "https://example.com/image.jpg", "123456789@s.whatsapp.net");
  assert.equal(conn.sent.length, 1);
  assert.equal(conn.sent[0].chat, m.chat);
  assert.match(conn.sent[0].payload.text, /تم تفعيل وتنصيب نسختك بنجاح/u);
});

test("group installation confirmation goes privately to the installer before reacting", async () => {
  const conn = makeConn();
  const events = [];
  const m = makeMessage({
    isGroup: true,
    chat: CHAT,
    sender: "123456789@lid",
    async react(emoji) { events.push(`react:${emoji}`); },
  });
  conn.sendMessage = async (chat, payload) => {
    events.push(`send:${chat}`);
    conn.sent.push({ chat, payload });
    return { key: { id: "confirmation-sent" } };
  };

  await sendInstallConfirmation(conn, "123456789", m, "https://example.com/image.jpg", "123456789@s.whatsapp.net");

  assert.equal(conn.sent[0].chat, m.sender);
  assert.deepEqual(events, [`send:${m.sender}`, "react:✅"]);
});

test("legacy commands with untranslated service output are blocked before their handler runs", async () => {
  const commands = [];
  const client = { registerCommand(command) { commands.push(command); }, getAllCommands() { return commands; } };
  await registerLegacyPlugins(client, { dir: "./plugins_legacy/primbon", logger: { log() {}, warn() {}, error() {} } });
  const command = commands.find(item => [].concat(item.command || []).includes("artinama"));
  assert.ok(command, "artinama should remain registered as a guarded command");
  const m = makeMessage({ isGroup: false });
  await command.execute(m, { conn: makeConn(), command: "artinama", db: {} });
  assert.equal(m.replies.at(-1), "🚧 قيد التعريب");
});

test("legacy services with placeholder API keys reply as unavailable before execution", async () => {
  const commands = [];
  const client = { registerCommand(command) { commands.push(command); }, getAllCommands() { return commands; } };
  await registerLegacyPlugins(client, { dir: "./plugins_legacy/tools", logger: { log() {}, warn() {}, error() {} } });
  const command = commands.find(item => [].concat(item.command || []).includes("qwa"));
  assert.ok(command, "qwa should remain registered behind the service guard");
  const m = makeMessage({ isGroup: false });
  await command.execute(m, { conn: makeConn(), command: "qwa", db: {} });
  assert.deepEqual(m.replies, ["هذه الخدمة غير مفعلة حالياً."]);
});

test("legacy tool cooldowns stay in seconds instead of becoming thousands of seconds", async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "musashi-legacy-cooldown-"));
  fs.writeFileSync(path.join(dir, "cooldowncheck.js"), "module.exports = { config: { name: 'cooldowncheck', category: 'tools', cooldown: 15 }, handler() { return true } };");
  const commands = [];
  const client = { registerCommand(command) { commands.push(command); }, getAllCommands() { return commands; } };
  try {
    await registerLegacyPlugins(client, { dir, enforcePermissions: false, logger: { log() {}, warn() {}, error() {} } });
    const command = commands.find(item => [].concat(item.command || []).includes("cooldowncheck"));
    assert.ok(command);
    assert.equal(command.cooldown, 15);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test("legacy exceptions are logged but the user receives only a generic Arabic reply", async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "musashi-legacy-error-"));
  const file = path.join(dir, "throwcheck.js");
  fs.writeFileSync(file, "module.exports = { config: { name: 'throwcheck', category: 'tools' }, handler() { throw new TypeError('Cannot read properties of undefined (reading x)') } };");
  const commands = [];
  const logs = [];
  const client = { registerCommand(command) { commands.push(command); }, getAllCommands() { return commands; } };
  try {
    await registerLegacyPlugins(client, { dir, enforcePermissions: false, logger: { log() {}, warn() {}, error(message) { logs.push(String(message)); } } });
    const command = commands.find(item => [].concat(item.command || []).includes("throwcheck"));
    assert.ok(command);
    const m = makeMessage({ isGroup: false });
    await command.execute(m, { conn: makeConn(), command: "throwcheck" });
    assert.deepEqual(m.replies, ["حدث خطأ، حاول لاحقاً"]);
    assert.match(logs.join("\n"), /Cannot read properties of undefined/u);
    assert.doesNotMatch(m.replies.join("\n"), /TypeError|Cannot read properties/u);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test("legacy db.getGroup returns writable initialized group metadata", () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "musashi-legacy-db-"));
  const file = path.join(dir, "database.json");
  try {
    const db = new UltraDB(file);
    const group = db.getGroup(CHAT);
    assert.ok(group);
    group.welcome = true;
    assert.equal(db.groups[CHAT].welcome, true);
    db.setGroup(CHAT, { antilink: true });
    assert.equal(db.getGroup(CHAT).antilink, true);
    db.flushSync();
    assert.deepEqual(JSON.parse(fs.readFileSync(file, "utf8")).groups[CHAT], { welcome: true, antilink: true, jid: CHAT });
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test("legacy socket does not send technical exception text in message captions", async () => {
  const conn = makeConn();
  const logs = [];
  const sock = buildLegacySock(conn, { logger: { error(message) { logs.push(String(message)); } } });
  await sock.sendMessage(CHAT, { text: "TypeError: Cannot read properties of undefined" });
  await sock.sendMessage(CHAT, { image: Buffer.from("image"), caption: "db.getGroup is not a function" });
  assert.equal(conn.sent[0].payload.text, "حدث خطأ، حاول لاحقاً");
  assert.equal(conn.sent[1].payload.caption, "حدث خطأ، حاول لاحقاً");
  assert.equal(logs.length, 2);
  assert.doesNotMatch(JSON.stringify(conn.sent), /TypeError|Cannot read properties|not a function/u);
});

