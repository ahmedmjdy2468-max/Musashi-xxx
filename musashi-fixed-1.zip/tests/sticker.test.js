import test from "node:test";
import assert from "node:assert/strict";
import sharp from "sharp";

import stickerHandler from "../plugins/sticker/s.js";
import toVideoHandler from "../plugins/tools/tovideo.js";
import { getCatalogEntry } from "../system/catalog.js";
import { mapCommandsByCategory } from "../plugins/menu.js";

test("the reply sticker command creates and sends a quoted sticker", async () => {
  const png = await sharp({
    create: { width: 64, height: 64, channels: 3, background: "#663399" },
  }).png().toBuffer();
  const sent = [];
  const replies = [];
  const m = {
    chat: "sticker-test@g.us",
    quoted: { mimetype: "image/png", async download() { return png; } },
    async reply(text) { replies.push(String(text)); },
  };
  const conn = { async sendMessage(...args) { sent.push(args); } };

  await stickerHandler(m, {
    conn,
    bot: { config: { info: { copyright: { pack: "MUSASHI", author: "Test" } } } },
  });

  assert.equal(replies.length, 0);
  assert.equal(sent.length, 1);
  assert.ok(Buffer.isBuffer(sent[0][1].sticker));
  assert.ok(sent[0][1].sticker.length > 0);
  assert.equal(sent[0][2].quoted, m);
});

test("sticker-to-video is placed under stickers and has a truthful Arabic catalog label", () => {
  assert.equal(toVideoHandler.category, "sticker");
  const entry = getCatalogEntry("ملصق_إلى_فيديو");
  assert.equal(entry.category, "sticker");
  assert.match(entry.desc, /الملصق المتحرك.*إلى فيديو/u);

  const mapped = mapCommandsByCategory([{
    command: toVideoHandler.command,
    usage: toVideoHandler.usage,
    category: toVideoHandler.category,
  }]);
  assert.equal(mapped.grouped.sticker[0].displayList[0], "ملصق_إلى_فيديو");
});
