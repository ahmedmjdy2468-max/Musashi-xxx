import test, { beforeEach } from "node:test";
import assert from "node:assert/strict";

import receptionHandler from "../plugins/admins/reception.js";
import nicknamesHandler from "../plugins/guild/nicknames.js";
import adminNicknameHandler from "../plugins/guild/nickname.js";
import availableNicknameHandler from "../plugins/guild/avai_nick.js";
import profileHandler from "../plugins/bank/profile.js";
import { handleReceptionMessage, buildPrivateAcceptanceMessage, validGroupInviteLink, removeGroupNicknamesWhenMembersLeave, welcomeRegisteredMembersInGroup, beginReceptionForMember } from "../system/reception.js";
import { isAnimeCharacterName } from "../system/animeNames.js";

const CHAT = "120363099999999999@g.us";
const PRIMARY_CHAT = "120363077777777777@g.us";
const ADMIN = "887766554433@s.whatsapp.net";
const MEMBER = "776655443322@s.whatsapp.net";

function makeConn() {
  const sent = [];
  return {
    sent,
    async sendMessage(chat, payload) {
      sent.push({ chat, payload });
      return { key: { id: `reception-${sent.length}` } };
    },
  };
}

beforeEach(() => {
  global.db = { groups: { [CHAT]: { features: { reception: true }, receptionInviteLink: "https://chat.whatsapp.com/AbCdEfGh12345678", rules: "قوانين المجموعة التجريبية", receptionWelcomeText: "مرحباً بك في مجموعتنا" } }, settings: {} };
});

test("reply command starts reception and the member finishes into the nickname registry", async () => {
  const conn = makeConn();
  const replies = [];
  global.db.groups[CHAT].receptionPrimaryGroupJid = PRIMARY_CHAT;
  global.db.groups[CHAT].receptionRules = "قوانين خاصة باستقبال المجموعة الأولى";
  global.db.groups[CHAT].receptionWelcomeText = "رسالة قبول المجموعة الأولى";
  global.db.groups[PRIMARY_CHAT] = {
    receptionInviteLink: "https://chat.whatsapp.com/PrimaryLinkCode123456",
    rules: "قوانين المجموعة الأساسية",
    receptionWelcomeText: "مرحباً بك في المجموعة الأساسية",
  };
  const adminMessage = {
    isGroup: true,
    isAdmin: true,
    isOwner: false,
    chat: CHAT,
    sender: ADMIN,
    quoted: { sender: MEMBER },
    async reply(text) { replies.push(String(text)); },
  };

  await receptionHandler(adminMessage, { conn, command: "استقبله", text: "" });
  assert.match(replies.at(-1), /بدأ استقبال/u);
  assert.equal(conn.sent.length, 1);
  assert.match(conn.sent[0].payload.text, /اختر لقب شخصية أنمي/u);
  assert.deepEqual(conn.sent[0].payload.mentions, [MEMBER]);
  assert.equal(global.db.groups[CHAT].receptionPending[MEMBER].step, "nickname");

  const nicknameReply = await handleReceptionMessage({
    isGroup: true,
    chat: CHAT,
    sender: MEMBER,
    body: "Naruto",
    key: { participant: MEMBER },
  });
  assert.match(nicknameReply, /من الشخص الذي أضافك/u);

  const completion = await handleReceptionMessage({
    isGroup: true,
    chat: CHAT,
    sender: MEMBER,
    body: "لا أعلم",
    key: { participant: MEMBER },
    sock: conn,
  });
  assert.match(completion, /اكتمل تسجيلك/u);
  const acceptance = conn.sent.find((entry) => entry.chat === MEMBER)?.payload.text || "";
  assert.match(acceptance, /AbCdEfGh12345678/u);
  assert.match(acceptance, /قوانين خاصة باستقبال المجموعة الأولى/u);
  assert.match(acceptance, /رسالة قبول المجموعة الأولى/u);
  assert.equal(global.db.groups[CHAT].receptionRegistrations[MEMBER].nickname, "Naruto");
  assert.equal(global.db.groups[CHAT].receptionMembers[MEMBER].nickname, "Naruto");
  assert.equal(global.db.settings.receptionMembers, undefined);
  assert.equal(global.db.groups[PRIMARY_CHAT].linkedReceptionMembers[MEMBER].nickname, "Naruto");
  assert.equal(global.db.groups[PRIMARY_CHAT].linkedReceptionMembers[MEMBER].sourceReceptionGroupJid, CHAT);

  await nicknamesHandler({
    isGroup: true,
    chat: CHAT,
    async reply(text) { replies.push(String(text)); },
  }, { conn });
  assert.match(conn.sent.at(-1).payload.text, /Naruto/u);
  assert.deepEqual(conn.sent.at(-1).payload.mentions, [MEMBER]);

  await nicknamesHandler({ isGroup: true, chat: PRIMARY_CHAT, async reply() {} }, { conn });
  assert.match(conn.sent.at(-1).payload.text, /Naruto/u);
  const welcomed = await welcomeRegisteredMembersInGroup({ sock: conn }, { chat: PRIMARY_CHAT, participants: [MEMBER] });
  assert.equal(welcomed.has(MEMBER), true);
  assert.match(conn.sent.at(-1).payload.text, /Naruto/u);
  assert.equal(conn.sent.at(-1).chat, PRIMARY_CHAT);
  assert.match((await import("../system/groupNicknames.js")).getGroupNickname(PRIMARY_CHAT, MEMBER).nickname, /Naruto/u);
  assert.match((await import("../system/groupNicknames.js")).getGroupNickname(CHAT, MEMBER).nickname, /Naruto/u);
  assert.equal((await import("../system/groupNicknames.js")).getGroupNickname("120363066666666666@g.us", MEMBER), null);
});

test("reception linking codes pair multiple reception groups to separate primary rosters", async () => {
  const primaryA = PRIMARY_CHAT;
  const primaryB = "120363066666666666@g.us";
  const receptionB = "120363088888888888@g.us";
  const receptionC = "120363055555555555@g.us";
  global.db.groups[primaryA] = { primaryInviteLink: "https://chat.whatsapp.com/PrimaryALink123456", receptionRules: "قوانين أساسية ألف", receptionWelcomeText: "رسالة المجموعة ألف" };
  global.db.groups[primaryB] = { primaryInviteLink: "https://chat.whatsapp.com/PrimaryBLink123456", receptionRules: "قوانين أساسية باء", receptionWelcomeText: "رسالة المجموعة باء" };
  global.db.groups[receptionB] = { features: { reception: true } };
  global.db.groups[receptionC] = { features: { reception: true } };
  const replies = [];
  const run = (chat, command, text = "") => receptionHandler({
    isGroup: true, isAdmin: true, isOwner: false, chat, sender: ADMIN,
    async reply(value) { replies.push(String(value)); },
  }, { conn: makeConn(), command, text });
  await run(primaryA, "تعيين_الجروب_الأساسي");
  const codeA = replies.at(-1).match(/\*([A-F0-9]{32})\*/u)?.[1];
  await run(primaryB, "تعيين_الجروب_الأساسي");
  const codeB = replies.at(-1).match(/\*([A-F0-9]{32})\*/u)?.[1];
  assert.ok(codeA && codeB && codeA !== codeB);
  await run(CHAT, "ربط_المجموعة_الأساسية", codeA);
  await run(receptionB, "ربط_المجموعة_الأساسية", codeB);
  await run(receptionC, "ربط_المجموعة_الأساسية", codeA);
  assert.equal(global.db.groups[CHAT].receptionPrimaryGroupJid, primaryA);
  assert.equal(global.db.groups[receptionB].receptionPrimaryGroupJid, primaryB);
  assert.deepEqual(global.db.groups[primaryA].linkedReceptionGroups, [CHAT, receptionC]);
  assert.deepEqual(global.db.groups[primaryB].linkedReceptionGroups, [receptionB]);
  assert.notEqual(global.db.groups[CHAT].receptionPrimaryGroupJid, global.db.groups[receptionB].receptionPrimaryGroupJid);

  const memberB = "665544332211@s.whatsapp.net";
  for (const [reception, member] of [[CHAT, MEMBER], [receptionB, memberB]]) {
    global.db.groups[reception].receptionPending = {
      [member]: { userJid: member, participantJids: [member], receptionGroupJid: reception, step: "nickname", startedAt: Date.now() },
    };
    const nickname = member === MEMBER ? "Naruto" : "Luffy";
    await handleReceptionMessage({ isGroup: true, chat: reception, sender: member, body: nickname, key: { participant: member } });
    await handleReceptionMessage({ isGroup: true, chat: reception, sender: member, body: "لا أعلم", key: { participant: member }, sock: makeConn() });
  }
  assert.equal(global.db.groups[primaryA].linkedReceptionMembers[MEMBER].nickname, "Naruto");
  assert.equal(global.db.groups[primaryA].linkedReceptionMembers[memberB], undefined);
  assert.equal(global.db.groups[primaryB].linkedReceptionMembers[memberB].nickname, "Luffy");
  assert.equal(global.db.groups[primaryB].linkedReceptionMembers[MEMBER], undefined);

  const memberC = "554433221100@s.whatsapp.net";
  const receptionD = "120363044444444444@g.us";
  const primaryBConn = makeConn();
  global.db.groups[receptionD] = { features: { reception: true }, receptionPrimaryGroupJid: primaryB };
  global.db.groups[receptionD].receptionPending = {
    [memberC]: { userJid: memberC, participantJids: [memberC], receptionGroupJid: receptionD, step: "nickname", startedAt: Date.now() },
  };
  await handleReceptionMessage({ isGroup: true, chat: receptionD, sender: memberC, body: "Gojo", key: { participant: memberC } });
  await handleReceptionMessage({ isGroup: true, chat: receptionD, sender: memberC, body: "لا أعلم", key: { participant: memberC }, sock: primaryBConn });
  const privateText = primaryBConn.sent.find((message) => message.chat === memberC)?.payload.text || "";
  assert.match(privateText, /PrimaryBLink123456/u);
  assert.doesNotMatch(privateText, /PrimaryALink123456/u);
  assert.match(privateText, /قوانين أساسية باء/u);
  assert.match(privateText, /رسالة المجموعة باء/u);

  const duplicateStart = await beginReceptionForMember({ sock: makeConn() }, { chat: receptionC, participant: MEMBER });
  assert.equal(duplicateStart.ok, false);
  assert.equal(duplicateStart.reason, "registered_in_linked_primary");
  assert.equal(global.db.groups[receptionC].receptionMembers[MEMBER].nickname, "Naruto");
  const differentPrimaryStart = await beginReceptionForMember({ sock: makeConn() }, { chat: receptionB, participant: MEMBER });
  assert.equal(differentPrimaryStart.ok, true);
});

test("reception admins can configure their own acceptance link, rules and message", async () => {
  const otherChat = "120363088888888888@g.us";
  global.db.groups[otherChat] = {};
  const replies = [];
  const run = (chat, command, text) => receptionHandler({
    isGroup: true, isAdmin: true, isOwner: false, chat,
    async reply(value) { replies.push(String(value)); },
  }, { conn: makeConn(), command, text });
  await run(CHAT, "تعيين_رابط_المجموعة", "https://chat.whatsapp.com/AbCdEfGh12345678");
  await run(CHAT, "تعيين_قوانين_الاستقبال", "الاحترام واجب في الاستقبال");
  await run(CHAT, "تعيين_نص_الاستقبال", "أهلاً بك في استقبالنا");
  await run(otherChat, "تعيين_قوانين_الاستقبال", "قوانين المجموعة الأخرى");
  await run(CHAT, "تعيين_الرابط_الأساسي", "https://chat.whatsapp.com/PrimaryOneLink123456");
  await run(otherChat, "تعيين_الرابط_الأساسي", "https://chat.whatsapp.com/PrimaryTwoLink123456");
  assert.equal(global.db.groups[CHAT].receptionInviteLink, "https://chat.whatsapp.com/AbCdEfGh12345678");
  assert.equal(global.db.groups[CHAT].receptionRules, "الاحترام واجب في الاستقبال");
  assert.equal(global.db.groups[CHAT].receptionWelcomeText, "أهلاً بك في استقبالنا");
  assert.equal(global.db.groups[otherChat].receptionRules, "قوانين المجموعة الأخرى");
  assert.equal(global.db.groups[CHAT].primaryInviteLink, "https://chat.whatsapp.com/PrimaryOneLink123456");
  assert.equal(global.db.groups[otherChat].primaryInviteLink, "https://chat.whatsapp.com/PrimaryTwoLink123456");
  assert.equal(global.db.settings.receptionMainGroupInvite, undefined);
  assert.ok(replies.some((message) => /حُفظت قوانين القبول/u.test(message)));
});

test("profile card shows the nickname registered through its linked reception group", async () => {
  global.db.groups[PRIMARY_CHAT] = { linkedReceptionMembers: { [MEMBER]: { nickname: "ناروتو" } } };
  const sent = [];
  const conn = {
    async profilePictureUrl() { return "https://example.invalid/profile.jpg"; },
    async sendMessage(chat, payload) { sent.push({ chat, payload }); },
  };
  await profileHandler({
    sender: MEMBER, chat: PRIMARY_CHAT, pushName: "محارب",
    async reply(text) { sent.push({ payload: { text } }); },
  }, { conn, bot: {} });
  assert.match(sent[0].payload.caption, /لقب المجموعة: \*ناروتو\*/u);
});

test("reply reception requires an administrator and an active reception group", async () => {
  const conn = makeConn();
  const replies = [];
  const base = {
    isGroup: true,
    isAdmin: false,
    isOwner: false,
    chat: CHAT,
    sender: MEMBER,
    quoted: { sender: ADMIN },
    async reply(text) { replies.push(String(text)); },
  };

  await receptionHandler(base, { conn, command: "استقبله", text: "" });
  assert.match(replies.at(-1), /لمشرفي الجروب/u);
  assert.equal(conn.sent.length, 0);
  assert.equal(Object.keys(global.db.groups[CHAT].receptionPending || {}).length, 0);
});

test("group invite links and reception messages are isolated per group", async () => {
  const otherChat = "120363088888888888@g.us";
  const replies = [];
  const handler = (chat) => ({
    isGroup: true, isAdmin: true, isOwner: false, chat,
    async reply(text) { replies.push(String(text)); },
  });
  await receptionHandler(handler(CHAT), {
    command: "تعيين_رابط_المجموعة", text: "https://chat.whatsapp.com/AbCdEfGh12345678",
  });
  await receptionHandler(handler(otherChat), {
    command: "تعيين_رابط_المجموعة", text: "https://chat.whatsapp.com/ZyXwVuTs87654321",
  });
  await receptionHandler(handler(CHAT), { command: "تعيين_نص_الاستقبال", text: "أهلاً بك في المجموعة الأولى" });

  assert.equal(global.db.groups[CHAT].receptionInviteLink, "https://chat.whatsapp.com/AbCdEfGh12345678");
  assert.equal(global.db.groups[otherChat].receptionInviteLink, "https://chat.whatsapp.com/ZyXwVuTs87654321");
  assert.equal(global.db.groups[CHAT].receptionWelcomeText, "أهلاً بك في المجموعة الأولى");
  assert.equal(global.db.groups[otherChat].receptionWelcomeText, undefined);
  assert.match(buildPrivateAcceptanceMessage({ nickname: "Naruto", inviteLink: global.db.groups[CHAT].receptionInviteLink, welcomeText: global.db.groups[CHAT].receptionWelcomeText, rules: "قوانين المجموعة الأولى" }), /المجموعة الأولى/u);
  assert.equal(validGroupInviteLink("https://chat.whatsapp.com/AbCdEfGh12345678"), true);
  assert.equal(validGroupInviteLink("https://example.com/not-a-group"), false);
});

test("manual nickname command bypasses bot matching but records the approving admin", async () => {
  const conn = makeConn();
  const replies = [];
  const originalFetch = global.fetch;
  global.fetch = async () => { throw new Error("manual registration must not call external verification"); };
  try {
    await adminNicknameHandler({
      isGroup: true, isAdmin: true, sender: ADMIN, chat: CHAT, mentionedJid: [MEMBER],
      async reply(text) { replies.push(String(text)); },
    }, { conn, text: "لقب رينغوكو" });
    const stored = global.db.groups[CHAT].nicknames[MEMBER];
    assert.equal(stored.nickname, "رينغوكو");
    assert.equal(stored.verification, "admin_manual");
    assert.equal(stored.verifiedBy, ADMIN);
    assert.match(conn.sent.at(-1).payload.text, /مسؤولية المشرف/u);
    assert.equal(replies.length, 0);
  } finally {
    global.fetch = originalFetch;
  }
});

test("manual nickname command rejects non-admins", async () => {
  const replies = [];
  await adminNicknameHandler({
    isGroup: true, isAdmin: false, isOwner: false, chat: CHAT, mentionedJid: [MEMBER],
    async reply(text) { replies.push(String(text)); },
  }, { conn: makeConn(), text: "لقب Naruto" });
  assert.match(replies.at(-1), /متاح لمشرفي المجموعة فقط/u);
});

test("manual nickname command keeps the nickname when context text contains only arguments", async () => {
  await adminNicknameHandler({
    isGroup: true, isAdmin: true, sender: ADMIN, chat: CHAT, mentionedJid: [MEMBER],
    async reply() {},
  }, { conn: makeConn(), text: "رينغوكو", command: "لقب" });
  assert.equal(global.db.groups[CHAT].nicknames[MEMBER].nickname, "رينغوكو");
});

test("manual anime nicknames are saved in the local group list and checked as occupied", async () => {
  const conn = makeConn();
  const replies = [];
  await adminNicknameHandler({
    isGroup: true, isAdmin: true, sender: ADMIN, chat: CHAT, mentionedJid: [MEMBER],
    async reply(text) { replies.push(String(text)); },
  }, { conn, text: "لقب Naruto" });
  assert.equal(global.db.groups[CHAT].nicknames[MEMBER].nickname, "Naruto");
  await availableNicknameHandler({ chat: CHAT, async reply(text) { replies.push(String(text)); } }, { text: "Naruto" });
  assert.match(replies.at(-1), /محجوز بالفعل/u);
  assert.equal(global.db.groups["120363088888888888@g.us"], undefined);
  await nicknamesHandler({ isGroup: true, chat: CHAT, async reply() {} }, { conn });
  assert.match(conn.sent.at(-1).payload.text, /Naruto/u);
});

test("AniList fuzzy results do not verify a different name", async () => {
  const originalFetch = global.fetch;
  global.db.settings.animeNameCache = {};
  global.fetch = async () => ({ ok: true, async json() { return { data: { Character: {
    id: 1,
    name: { full: "Naruto Uzumaki", first: "Naruto", last: "Uzumaki", native: "うずまきナルト", alternative: ["Naruto"], alternativeSpoiler: [] },
    media: { edges: [{ node: { type: "ANIME" } }] },
  } } }; } });
  try {
    const result = await isAnimeCharacterName("Definitely Not This Character");
    assert.equal(result.verified, false);
  } finally {
    global.fetch = originalFetch;
  }
});

test("AI suggests transliterations but AniList must verify the matching anime character", async () => {
  const originalFetch = global.fetch;
  const envKeys = ["OPENROUTER_API_KEY", "GROQ_API_KEY", "GEMINI_API_KEY", "OPENAI_API_KEY"];
  const originalEnv = Object.fromEntries(envKeys.map((key) => [key, process.env[key]]));
  for (const key of envKeys) delete process.env[key];
  global.db.settings.animeNameCache = {};
  const searches = [];
  global.fetch = async (url, options = {}) => {
    if (String(url).includes("text.pollinations.ai")) {
      return { ok: true, async json() { return { choices: [{ message: { content: '["Eren Yeager"]' } }] }; } };
    }
    const request = JSON.parse(options.body || "{}");
    const search = request.variables?.search;
    searches.push(search);
    const character = search === "Eren Yeager" ? {
      id: 2,
      name: { full: "Eren Yeager", first: "Eren", last: "Yeager", native: "エレン・イェーガー", alternative: [], alternativeSpoiler: [] },
      media: { edges: [{ node: { type: "ANIME" } }] },
    } : null;
    return { ok: true, async json() { return { data: { Character: character } }; } };
  };
  try {
    const result = await isAnimeCharacterName("ايرين ييغر");
    assert.equal(result.verified, true);
    assert.equal(result.data.source, "anilist+ai-transliteration");
    assert.ok(searches.includes("Eren Yeager"));
  } finally {
    global.fetch = originalFetch;
    for (const key of envKeys) {
      if (originalEnv[key] === undefined) delete process.env[key];
      else process.env[key] = originalEnv[key];
    }
  }
});

test("common Arabic anime character spellings are accepted by the local name list", async () => {
  const names = ["ناروتو", "لوفي", "غوجو", "ليفاي", "تانجيرو", "إيرين", "ميكاسا", "زورو", "ساسكي", "ريم"];
  for (const name of names) {
    const result = await isAnimeCharacterName(name);
    assert.equal(result.verified, true, `expected ${name} to be recognized`);
    assert.equal(result.data.source, "local");
  }
});

test("each group can register members independently, including the configured primary group", async () => {
  global.db.settings.receptionMainGroupJid = CHAT;
  global.db.groups[CHAT].receptionPending = {
    [MEMBER]: { userJid: MEMBER, participantJids: [MEMBER], receptionGroupJid: CHAT, step: "nickname", startedAt: Date.now() },
  };
  const response = await handleReceptionMessage({
    isGroup: true, chat: CHAT, sender: MEMBER, body: "Naruto", key: { participant: MEMBER },
  });
  assert.match(response, /من الشخص الذي أضافك/u);
  assert.equal(global.db.groups[CHAT].receptionPending[MEMBER].nickname, "Naruto");
});

test("leaving one group removes only that group's nickname registry", async () => {
  const otherChat = "120363088888888888@g.us";
  global.db.groups[CHAT].receptionRegistrations = { [MEMBER]: { nickname: "Naruto" } };
  global.db.groups[CHAT].receptionMembers = { [MEMBER]: { nickname: "Naruto" } };
  global.db.groups[otherChat] = {
    receptionRegistrations: { [MEMBER]: { nickname: "Luffy" } },
    receptionMembers: { [MEMBER]: { nickname: "Luffy" } },
    nicknames: { [MEMBER]: "Luffy" },
  };
  await removeGroupNicknamesWhenMembersLeave({ chat: CHAT, participants: [MEMBER] });
  assert.equal(global.db.groups[CHAT].receptionRegistrations[MEMBER], undefined);
  assert.equal(global.db.groups[otherChat].receptionRegistrations[MEMBER].nickname, "Luffy");
  assert.equal(global.db.groups[otherChat].nicknames[MEMBER], "Luffy");
});

test("registered return welcome is sent only to the group that owns the record", async () => {
  const otherChat = "120363088888888888@g.us";
  global.db.groups[CHAT].receptionRegistrations = { [MEMBER]: { nickname: "Naruto" } };
  global.db.groups[otherChat] = { receptionRegistrations: { [MEMBER]: { nickname: "Luffy" } } };
  const sent = [];
  const result = await welcomeRegisteredMembersInGroup({ sock: { async sendMessage(chat, payload) { sent.push({ chat, payload }); } } }, {
    chat: CHAT, participants: [MEMBER],
  });
  assert.equal(sent.length, 1);
  assert.equal(sent[0].chat, CHAT);
  assert.match(sent[0].payload.text, /Naruto/u);
  assert.equal(result.has(MEMBER), true);
  assert.equal(global.db.groups[otherChat].receptionRegistrations[MEMBER].nickname, "Luffy");
});
